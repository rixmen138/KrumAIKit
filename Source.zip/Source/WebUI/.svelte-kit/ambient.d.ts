
// this file is generated — do not edit it


/// <reference types="@sveltejs/kit" />

/**
 * Environment variables [loaded by Vite](https://vitejs.dev/guide/env-and-mode.html#env-files) from `.env` files and `process.env`. Like [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), this module cannot be imported into client-side code. This module only includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured).
 * 
 * _Unlike_ [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), the values exported from this module are statically injected into your bundle at build time, enabling optimisations like dead code elimination.
 * 
 * ```ts
 * import { API_KEY } from '$env/static/private';
 * ```
 * 
 * Note that all environment variables referenced in your code should be declared (for example in an `.env` file), even if they don't have a value until the app is deployed:
 * 
 * ```
 * MY_FEATURE_FLAG=""
 * ```
 * 
 * You can override `.env` values from the command line like so:
 * 
 * ```sh
 * MY_FEATURE_FLAG="enabled" npm run dev
 * ```
 */
declare module '$env/static/private' {
	export const ACTIONS_ORCHESTRATION_ID: string;
	export const ALLUSERSPROFILE: string;
	export const APPDATA: string;
	export const CI: string;
	export const CommonProgramFiles: string;
	export const CommonProgramW6432: string;
	export const COMPUTERNAME: string;
	export const ComSpec: string;
	export const DriverData: string;
	export const GCP_PROJECT_ID: string;
	export const GCP_ZONE: string;
	export const GCS_BUCKET: string;
	export const GITHUB_ACTION: string;
	export const GITHUB_ACTIONS: string;
	export const GITHUB_ACTION_REF: string;
	export const GITHUB_ACTION_REPOSITORY: string;
	export const GITHUB_ACTOR: string;
	export const GITHUB_ACTOR_ID: string;
	export const GITHUB_API_URL: string;
	export const GITHUB_BASE_REF: string;
	export const GITHUB_ENV: string;
	export const GITHUB_EVENT_NAME: string;
	export const GITHUB_EVENT_PATH: string;
	export const GITHUB_GRAPHQL_URL: string;
	export const GITHUB_HEAD_REF: string;
	export const GITHUB_JOB: string;
	export const GITHUB_OUTPUT: string;
	export const GITHUB_PATH: string;
	export const GITHUB_REF: string;
	export const GITHUB_REF_NAME: string;
	export const GITHUB_REF_PROTECTED: string;
	export const GITHUB_REF_TYPE: string;
	export const GITHUB_REPOSITORY: string;
	export const GITHUB_REPOSITORY_ID: string;
	export const GITHUB_REPOSITORY_OWNER: string;
	export const GITHUB_REPOSITORY_OWNER_ID: string;
	export const GITHUB_RETENTION_DAYS: string;
	export const GITHUB_RUN_ATTEMPT: string;
	export const GITHUB_RUN_ID: string;
	export const GITHUB_RUN_NUMBER: string;
	export const GITHUB_SERVER_URL: string;
	export const GITHUB_SHA: string;
	export const GITHUB_STATE: string;
	export const GITHUB_STEP_SUMMARY: string;
	export const GITHUB_TRIGGERING_ACTOR: string;
	export const GITHUB_WORKFLOW: string;
	export const GITHUB_WORKFLOW_REF: string;
	export const GITHUB_WORKFLOW_SHA: string;
	export const GITHUB_WORKSPACE: string;
	export const GooGetRoot: string;
	export const GOPATH: string;
	export const LOCALAPPDATA: string;
	export const LOCK_FILE: string;
	export const NODE: string;
	export const NODE_ENV: string;
	export const npm_command: string;
	export const npm_config_local_prefix: string;
	export const npm_config_user_agent: string;
	export const npm_execpath: string;
	export const npm_lifecycle_event: string;
	export const npm_lifecycle_script: string;
	export const npm_node_execpath: string;
	export const npm_package_json: string;
	export const npm_package_name: string;
	export const npm_package_version: string;
	export const NUMBER_OF_PROCESSORS: string;
	export const OS: string;
	export const Path: string;
	export const PATHEXT: string;
	export const PLUGIN_NAME: string;
	export const PLUGIN_SLUG: string;
	export const POWERSHELL_DISTRIBUTION_CHANNEL: string;
	export const PROCESSOR_ARCHITECTURE: string;
	export const PROCESSOR_IDENTIFIER: string;
	export const PROCESSOR_LEVEL: string;
	export const PROCESSOR_REVISION: string;
	export const ProgramData: string;
	export const ProgramFiles: string;
	export const ProgramW6432: string;
	export const PSModulePath: string;
	export const PUBLIC: string;
	export const PWD: string;
	export const RUNNER_ARCH: string;
	export const RUNNER_ENVIRONMENT: string;
	export const RUNNER_NAME: string;
	export const RUNNER_OS: string;
	export const RUNNER_TEMP: string;
	export const RUNNER_TOOL_CACHE: string;
	export const RUNNER_TRACKING_ID: string;
	export const RUNNER_WORKSPACE: string;
	export const SystemDrive: string;
	export const SystemRoot: string;
	export const TEMP: string;
	export const TMP: string;
	export const UE_VERSIONS: string;
	export const UPLUGIN_FILE: string;
	export const USERDOMAIN: string;
	export const USERNAME: string;
	export const USERPROFILE: string;
	export const VERSION: string;
	export const VM_NAME: string;
	export const windir: string;
}

/**
 * Similar to [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private), except that it only includes environment variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`), and can therefore safely be exposed to client-side code.
 * 
 * Values are replaced statically at build time.
 * 
 * ```ts
 * import { PUBLIC_BASE_URL } from '$env/static/public';
 * ```
 */
declare module '$env/static/public' {
	
}

/**
 * This module provides access to runtime environment variables, as defined by the platform you're running on. For example if you're using [`adapter-node`](https://github.com/sveltejs/kit/tree/main/packages/adapter-node) (or running [`vite preview`](https://svelte.dev/docs/kit/cli)), this is equivalent to `process.env`. This module only includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured).
 * 
 * This module cannot be imported into client-side code.
 * 
 * ```ts
 * import { env } from '$env/dynamic/private';
 * console.log(env.DEPLOYMENT_SPECIFIC_VARIABLE);
 * ```
 * 
 * > [!NOTE] In `dev`, `$env/dynamic` always includes environment variables from `.env`. In `prod`, this behavior will depend on your adapter.
 */
declare module '$env/dynamic/private' {
	export const env: {
		ACTIONS_ORCHESTRATION_ID: string;
		ALLUSERSPROFILE: string;
		APPDATA: string;
		CI: string;
		CommonProgramFiles: string;
		CommonProgramW6432: string;
		COMPUTERNAME: string;
		ComSpec: string;
		DriverData: string;
		GCP_PROJECT_ID: string;
		GCP_ZONE: string;
		GCS_BUCKET: string;
		GITHUB_ACTION: string;
		GITHUB_ACTIONS: string;
		GITHUB_ACTION_REF: string;
		GITHUB_ACTION_REPOSITORY: string;
		GITHUB_ACTOR: string;
		GITHUB_ACTOR_ID: string;
		GITHUB_API_URL: string;
		GITHUB_BASE_REF: string;
		GITHUB_ENV: string;
		GITHUB_EVENT_NAME: string;
		GITHUB_EVENT_PATH: string;
		GITHUB_GRAPHQL_URL: string;
		GITHUB_HEAD_REF: string;
		GITHUB_JOB: string;
		GITHUB_OUTPUT: string;
		GITHUB_PATH: string;
		GITHUB_REF: string;
		GITHUB_REF_NAME: string;
		GITHUB_REF_PROTECTED: string;
		GITHUB_REF_TYPE: string;
		GITHUB_REPOSITORY: string;
		GITHUB_REPOSITORY_ID: string;
		GITHUB_REPOSITORY_OWNER: string;
		GITHUB_REPOSITORY_OWNER_ID: string;
		GITHUB_RETENTION_DAYS: string;
		GITHUB_RUN_ATTEMPT: string;
		GITHUB_RUN_ID: string;
		GITHUB_RUN_NUMBER: string;
		GITHUB_SERVER_URL: string;
		GITHUB_SHA: string;
		GITHUB_STATE: string;
		GITHUB_STEP_SUMMARY: string;
		GITHUB_TRIGGERING_ACTOR: string;
		GITHUB_WORKFLOW: string;
		GITHUB_WORKFLOW_REF: string;
		GITHUB_WORKFLOW_SHA: string;
		GITHUB_WORKSPACE: string;
		GooGetRoot: string;
		GOPATH: string;
		LOCALAPPDATA: string;
		LOCK_FILE: string;
		NODE: string;
		NODE_ENV: string;
		npm_command: string;
		npm_config_local_prefix: string;
		npm_config_user_agent: string;
		npm_execpath: string;
		npm_lifecycle_event: string;
		npm_lifecycle_script: string;
		npm_node_execpath: string;
		npm_package_json: string;
		npm_package_name: string;
		npm_package_version: string;
		NUMBER_OF_PROCESSORS: string;
		OS: string;
		Path: string;
		PATHEXT: string;
		PLUGIN_NAME: string;
		PLUGIN_SLUG: string;
		POWERSHELL_DISTRIBUTION_CHANNEL: string;
		PROCESSOR_ARCHITECTURE: string;
		PROCESSOR_IDENTIFIER: string;
		PROCESSOR_LEVEL: string;
		PROCESSOR_REVISION: string;
		ProgramData: string;
		ProgramFiles: string;
		ProgramW6432: string;
		PSModulePath: string;
		PUBLIC: string;
		PWD: string;
		RUNNER_ARCH: string;
		RUNNER_ENVIRONMENT: string;
		RUNNER_NAME: string;
		RUNNER_OS: string;
		RUNNER_TEMP: string;
		RUNNER_TOOL_CACHE: string;
		RUNNER_TRACKING_ID: string;
		RUNNER_WORKSPACE: string;
		SystemDrive: string;
		SystemRoot: string;
		TEMP: string;
		TMP: string;
		UE_VERSIONS: string;
		UPLUGIN_FILE: string;
		USERDOMAIN: string;
		USERNAME: string;
		USERPROFILE: string;
		VERSION: string;
		VM_NAME: string;
		windir: string;
		[key: `PUBLIC_${string}`]: undefined;
		[key: `${string}`]: string | undefined;
	}
}

/**
 * Similar to [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private), but only includes variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`), and can therefore safely be exposed to client-side code.
 * 
 * Note that public dynamic environment variables must all be sent from the server to the client, causing larger network requests — when possible, use `$env/static/public` instead.
 * 
 * ```ts
 * import { env } from '$env/dynamic/public';
 * console.log(env.PUBLIC_DEPLOYMENT_SPECIFIC_VARIABLE);
 * ```
 */
declare module '$env/dynamic/public' {
	export const env: {
		[key: `PUBLIC_${string}`]: string | undefined;
	}
}
