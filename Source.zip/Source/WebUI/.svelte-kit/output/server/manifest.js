export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["robots.txt"]),
	mimeTypes: {".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.Dj3PsxO9.js",app:"_app/immutable/entry/app.C4E5kTVl.js",imports:["_app/immutable/entry/start.Dj3PsxO9.js","_app/immutable/chunks/DYjNAi3f.js","_app/immutable/chunks/Cq2zEFYO.js","_app/immutable/entry/app.C4E5kTVl.js","_app/immutable/chunks/PPVm8Dsz.js","_app/immutable/chunks/Cq2zEFYO.js","_app/immutable/chunks/D2XwtSTN.js","_app/immutable/chunks/DDQmN5tQ.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js'))
		],
		remotes: {
			
		},
		routes: [
			
		],
		prerendered_routes: new Set(["/"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
