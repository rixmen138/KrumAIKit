

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.D6CEQAzt.js","_app/immutable/chunks/D2XwtSTN.js","_app/immutable/chunks/Cq2zEFYO.js","_app/immutable/chunks/DDQmN5tQ.js","_app/immutable/chunks/CtqsVq5y.js","_app/immutable/chunks/PPVm8Dsz.js","_app/immutable/chunks/O9We9dFo.js"];
export const stylesheets = ["_app/immutable/assets/2.Be-T0sb8.css"];
export const fonts = [];
