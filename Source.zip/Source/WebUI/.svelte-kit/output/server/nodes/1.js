

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.ZsV6XYpZ.js","_app/immutable/chunks/D2XwtSTN.js","_app/immutable/chunks/Cq2zEFYO.js","_app/immutable/chunks/O9We9dFo.js","_app/immutable/chunks/DYjNAi3f.js"];
export const stylesheets = [];
export const fonts = [];
