import * as universal from '../entries/pages/_layout.ts.js';

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/+layout.ts";
export const imports = ["_app/immutable/nodes/0.DPi_5kO7.js","_app/immutable/chunks/D2XwtSTN.js","_app/immutable/chunks/Cq2zEFYO.js","_app/immutable/chunks/DDQmN5tQ.js","_app/immutable/chunks/CtqsVq5y.js","_app/immutable/chunks/O9We9dFo.js"];
export const stylesheets = ["_app/immutable/assets/0.VOQ0JK6J.css"];
export const fonts = [];
