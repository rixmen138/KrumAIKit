import { w as writable, d as derived, g as get } from "./index.js";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { v as lifecycle_function_unavailable, g as derived$1, o as on, e as attr, c as attr_class, d as clsx$1 } from "./index2.js";
import { a7 as ATTACHMENT_KEY, a8 as ssr_context, a0 as run, _ as hasContext, $ as getContext, Z as setContext } from "./context.js";
import "style-to-object";
function createAttachmentKey() {
  return Symbol(ATTACHMENT_KEY);
}
function html(value) {
  var html2 = String(value ?? "");
  var open = "<!---->";
  return open + html2 + "<!---->";
}
function onDestroy(fn) {
  /** @type {SSRContext} */
  ssr_context.r.on_destroy(fn);
}
function mount() {
  lifecycle_function_unavailable("mount");
}
function unmount() {
  lifecycle_function_unavailable("unmount");
}
async function tick() {
}
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
function createUUID() {
  const cryptoObj = globalThis.crypto;
  if (cryptoObj?.randomUUID) {
    return cryptoObj.randomUUID();
  }
  const bytes = new Uint8Array(16);
  if (cryptoObj?.getRandomValues) {
    cryptoObj.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
  }
  bytes[6] = bytes[6] & 15 | 64;
  bytes[8] = bytes[8] & 63 | 128;
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0"));
  return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex.slice(6, 8).join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10, 16).join("")}`;
}
function getBridge() {
  if (typeof window !== "undefined" && window.ue?.bridge) {
    return window.ue.bridge;
  }
  return null;
}
function parseResult(value) {
  const raw = value && typeof value === "object" && "ReturnValue" in value ? value.ReturnValue : value;
  if (typeof raw === "string") {
    return JSON.parse(raw);
  }
  return raw;
}
let continuationDraftBound = false;
const continuationDraftResolvers = /* @__PURE__ */ new Map();
function ensureContinuationDraftBinding() {
  const bridge = getBridge();
  if (!bridge || continuationDraftBound) return;
  bridge.bindoncontinuationdraftready((requestId, resultJson) => {
    const resolver = continuationDraftResolvers.get(requestId);
    if (!resolver) return;
    continuationDraftResolvers.delete(requestId);
    try {
      resolver(JSON.parse(resultJson));
    } catch {
      resolver({ success: false, error: "Failed to parse continuation draft result" });
    }
  });
  continuationDraftBound = true;
}
async function getContinuationSummarySettings() {
  const bridge = getBridge();
  if (bridge) {
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error("getContinuationSummarySettings timed out")), 8e3);
    });
    const result = await Promise.race([bridge.getcontinuationsummarysettings(), timeoutPromise]);
    return parseResult(result);
  }
  return {
    provider: "openrouter",
    modelId: "x-ai/grok-4.1-fast",
    defaultDetail: "compact",
    hasOpenRouterKey: false
  };
}
async function setContinuationSummaryProvider(provider) {
  const bridge = getBridge();
  if (bridge) {
    await bridge.setcontinuationsummaryprovider(provider);
  }
}
async function setContinuationSummaryDefaultDetail(detail) {
  const bridge = getBridge();
  if (bridge) {
    await bridge.setcontinuationsummarydefaultdetail(detail);
  }
}
const defaultNotificationSettings = {
  onlyWhenUnfocused: false,
  notifyOnComplete: true,
  flashTaskbar: true,
  playSound: true,
  soundVolume: 1,
  completionSound: "",
  errorSound: "",
  playPermissionSound: false,
  permissionSoundVolume: 1,
  permissionRequestSound: ""
};
async function getNotificationSettings() {
  const bridge = getBridge();
  if (bridge) {
    const result = await bridge.getnotificationsettings();
    const parsed = parseResult(result);
    return { ...defaultNotificationSettings, ...parsed };
  }
  return { ...defaultNotificationSettings };
}
async function createSession(agentName) {
  const bridge = getBridge();
  if (bridge) {
    const result = await bridge.createsession(agentName);
    return parseResult(result);
  }
  return { sessionId: createUUID(), agentName };
}
async function resumeSession(sessionId) {
  const bridge = getBridge();
  if (bridge) {
    const result = await bridge.resumesession(sessionId);
    return parseResult(result);
  }
  return { success: false, error: "Not in UE" };
}
async function getSessionTerminalResumeCommand(sessionId) {
  const bridge = getBridge();
  if (bridge) {
    const result = await bridge.getsessionterminalresumecommand(sessionId);
    return parseResult(result);
  }
  return { supported: false, error: "Not in UE" };
}
async function buildContinuationDraft(sourceSessionId, targetAgentName, summaryMode = "compact") {
  const bridge = getBridge();
  if (bridge) {
    ensureContinuationDraftBinding();
    const startRaw = await bridge.requestcontinuationdraft(sourceSessionId, targetAgentName, summaryMode);
    const start = parseResult(startRaw);
    if (!start.success || !start.requestId) {
      return { success: false, error: start.error || "Failed to start continuation draft generation" };
    }
    const requestId = start.requestId;
    return await new Promise((resolve) => {
      continuationDraftResolvers.set(requestId, resolve);
      setTimeout(() => {
        if (!continuationDraftResolvers.has(requestId)) return;
        continuationDraftResolvers.delete(requestId);
        resolve({ success: false, error: "Continuation draft generation timed out" });
      }, 18e4);
    });
  }
  return { success: false, error: "Not in UE" };
}
async function deleteSession(sessionId) {
  const bridge = getBridge();
  if (bridge) {
    const result = await bridge.deletesession(sessionId);
    return parseResult(result);
  }
  return { success: false };
}
async function exportSessionToMarkdown(sessionId) {
  const bridge = getBridge();
  if (bridge) {
    const result = await bridge.exportsessiontomarkdown(sessionId);
    return parseResult(result);
  }
  return { success: false, error: "Not in UE" };
}
async function getAgentInstallInfo(agentName) {
  const bridge = getBridge();
  if (bridge) {
    const result = await bridge.getagentinstallinfo(agentName);
    return parseResult(result);
  }
  return { agentName, baseExecutableName: "", installCommand: "", installUrl: "", requiresAdapter: false, requiresBaseCLI: false };
}
async function getModels(agentName) {
  const bridge = getBridge();
  if (bridge) {
    const result = await bridge.getmodels(agentName);
    return parseResult(result);
  }
  return { models: [], currentModelId: "" };
}
async function setModel(agentName, modelId) {
  const bridge = getBridge();
  if (bridge) {
    await bridge.setmodel(agentName, modelId);
  }
}
async function setReasoningLevel(agentName, level) {
  const bridge = getBridge();
  if (bridge) {
    await bridge.setreasoninglevel(agentName, level);
  }
}
async function setMode(agentName, modeId) {
  const bridge = getBridge();
  if (bridge) {
    await bridge.setmode(agentName, modeId);
  }
}
async function getIndexingSettings() {
  const bridge = getBridge();
  if (bridge) {
    const result = await bridge.getindexingsettings();
    return parseResult(result);
  }
  return {
    provider: "openrouter",
    endpointUrl: "",
    apiKey: "",
    model: "google/gemini-embedding-001",
    dimensions: 768,
    autoIndex: false,
    scope: { blueprints: true, cppFiles: true, assets: true, levels: true, config: false, documents: true },
    hasOpenRouterKey: false
  };
}
async function getIndexingStatus() {
  const bridge = getBridge();
  if (bridge) {
    const result = await bridge.getindexingstatus();
    return parseResult(result);
  }
  return { state: "idle", totalChunks: 0, indexedChunks: 0, lastIndexedAt: "", indexSizeBytes: 0, errorMessage: "", breakdown: { blueprints: 0, cppFiles: 0, assets: 0, levels: 0, config: 0, documents: 0 }, embeddingModel: "", embeddingDimensions: 0 };
}
async function openSourceControlChangelist() {
  const bridge = getBridge();
  if (bridge) {
    await bridge.opensourcecontrolchangelist();
  }
}
async function openSourceControlSubmit() {
  const bridge = getBridge();
  if (bridge) {
    await bridge.opensourcecontrolsubmit();
  }
}
const agents = writable([]);
const selectedAgent = writable(null);
function withAlpha(color, alpha) {
  if (color.startsWith("#")) {
    const hex = color.replace("#", "");
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }
  if (color.startsWith("hsl(")) {
    return color.replace("hsl(", "hsla(").replace(")", `, ${alpha})`);
  }
  return color;
}
function statusDotColor(status) {
  switch (status) {
    case "available":
      return "bg-emerald-500";
    case "missing_key":
      return "bg-amber-500";
    case "not_installed":
      return "bg-red-500/60";
    default:
      return "bg-zinc-500/60";
  }
}
const sessions = writable([]);
const currentSessionId = writable(null);
const isLoadingSessions = writable(false);
const isConnectingAgents = writable(false);
const groupedSessions = derived(sessions, ($sessions) => {
  const groups = [];
  const groupMap = /* @__PURE__ */ new Map();
  const now = /* @__PURE__ */ new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today.getTime() - 864e5);
  const weekAgo = new Date(today.getTime() - 7 * 864e5);
  const monthAgo = new Date(today.getTime() - 30 * 864e5);
  for (const session of $sessions) {
    const date = new Date(session.lastModifiedAt);
    let label;
    if (date >= today) {
      label = "Today";
    } else if (date >= yesterday) {
      label = "Yesterday";
    } else if (date >= weekAgo) {
      label = "This Week";
    } else if (date >= monthAgo) {
      label = "This Month";
    } else {
      label = "Older";
    }
    if (!groupMap.has(label)) {
      groupMap.set(label, []);
    }
    groupMap.get(label).push(session);
  }
  const order = ["Today", "Yesterday", "This Week", "This Month", "Older"];
  for (const label of order) {
    const items = groupMap.get(label);
    if (items && items.length > 0) {
      groups.push({ label, sessions: items });
    }
  }
  return groups;
});
async function createNewSession(agentName) {
  try {
    const result = await createSession(agentName);
    const newSession = {
      sessionId: result.sessionId,
      agentName: result.agentName,
      title: "",
      messageCount: 0,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      lastModifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
      isConnected: false,
      isActive: true
    };
    sessions.update((list) => [newSession, ...list]);
    currentSessionId.set(result.sessionId);
    return result.sessionId;
  } catch (e) {
    console.warn("Failed to create session:", e);
    return null;
  }
}
async function selectSession(sessionId) {
  try {
    const result = await resumeSession(sessionId);
    if (result.success && result.agentName) {
      const agentList = get(agents);
      const sessionAgent = agentList.find((a) => a.name === result.agentName);
      if (sessionAgent) {
        selectedAgent.set(sessionAgent);
      }
      currentSessionId.set(sessionId);
      return result.agentName;
    }
    currentSessionId.set(sessionId);
  } catch (e) {
    console.warn("Failed to resume session:", e);
    currentSessionId.set(sessionId);
  }
  return null;
}
async function removeSession(sessionId) {
  try {
    const result = await deleteSession(sessionId);
    if (result.success) {
      sessions.update((list) => list.filter((s) => s.sessionId !== sessionId));
      if (get(currentSessionId) === sessionId) {
        currentSessionId.set(null);
      }
    }
    return result.success;
  } catch (e) {
    console.warn("Failed to delete session:", e);
    return false;
  }
}
function formatTimeAgo(isoDate) {
  if (!isoDate) return "now";
  const now = Date.now();
  const then = new Date(isoDate).getTime();
  if (!Number.isFinite(then)) return "now";
  const seconds = Math.floor((now - then) / 1e3);
  if (seconds < 60) return "now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d`;
  const months = Math.floor(days / 30);
  return `${months}mo`;
}
const SvelteMap = globalThis.Map;
class MediaQuery {
  current;
  /**
   * @param {string} query
   * @param {boolean} [matches]
   */
  constructor(query, matches = false) {
    this.current = matches;
  }
}
function createSubscriber(_) {
  return () => {
  };
}
const sessionStates = writable({});
const activeSessionId = writable(null);
const mcpStatusMap = writable({});
const recentlyFinished = writable(/* @__PURE__ */ new Set());
const currentState = derived(
  [sessionStates, activeSessionId],
  ([$states, $activeId]) => {
    if (!$activeId) return null;
    return $states[$activeId] ?? null;
  }
);
const currentMcpStatus = derived(
  [mcpStatusMap, activeSessionId],
  ([$map, $activeId]) => {
    if (!$activeId) return "none";
    return $map[$activeId] ?? "none";
  }
);
const stateDisplay = {
  disconnected: { label: "Disconnected", dotClass: "bg-zinc-500", pulse: false },
  connecting: { label: "Connecting", dotClass: "bg-amber-500", pulse: true },
  initializing: { label: "Initializing", dotClass: "bg-amber-500", pulse: true },
  ready: { label: "Ready", dotClass: "bg-emerald-500", pulse: false },
  in_session: { label: "Connected", dotClass: "bg-emerald-500", pulse: false },
  prompting: { label: "Working", dotClass: "bg-blue-500", pulse: true },
  error: { label: "Error", dotClass: "bg-red-500", pulse: false }
};
function getSessionSidebarStatus(sessionId, states, finished) {
  if (states[sessionId]?.state === "prompting") return "working";
  if (finished.has(sessionId)) return "finished";
  return "idle";
}
const emptyUsage = {
  inputTokens: 0,
  outputTokens: 0,
  totalTokens: 0,
  cacheReadTokens: 0,
  cacheCreationTokens: 0,
  reasoningTokens: 0,
  costAmount: 0,
  costCurrency: "USD",
  turnCostUSD: 0,
  contextUsed: 0,
  contextSize: 0,
  numTurns: 0,
  durationMs: 0,
  modelUsage: []
};
const usageBySession = writable({});
const sessionUsage = derived(
  [usageBySession, currentSessionId],
  ([$bySession, $sid]) => $sid ? $bySession[$sid] ?? { ...emptyUsage } : { ...emptyUsage }
);
const hasUsage = derived(sessionUsage, (u) => u.contextSize > 0 || u.totalTokens > 0 || u.inputTokens > 0 || u.outputTokens > 0);
const contextPercent = derived(
  sessionUsage,
  (u) => u.contextSize > 0 ? Math.min(100, Math.round(u.contextUsed / u.contextSize * 100)) : 0
);
function formatTokens(count) {
  if (count >= 1e6) return `${(count / 1e6).toFixed(1)}M`;
  if (count >= 1e3) return `${(count / 1e3).toFixed(1)}k`;
  return `${count}`;
}
function formatCost(amount, currency = "USD") {
  if (amount <= 0) return "";
  if (currency === "USD") return `$${amount.toFixed(4)}`;
  return `${amount.toFixed(4)} ${currency}`;
}
const messages = writable([]);
const isStreaming = writable(false);
const messagesBySession = writable({});
const streamingBySession = writable({});
currentSessionId.subscribe((sid) => {
  if (!sid) {
    messages.set([]);
    isStreaming.set(false);
    return;
  }
  const allMessages = get(messagesBySession);
  messages.set(allMessages[sid] ?? []);
  const allStreaming = get(streamingBySession);
  isStreaming.set(allStreaming[sid] ?? false);
});
const permissionQueues = writable({});
const sessionsNeedingAttention = derived(
  permissionQueues,
  ($queues) => {
    const ids = /* @__PURE__ */ new Set();
    for (const [sid, queue] of Object.entries($queues)) {
      if (queue.length > 0) ids.add(sid);
    }
    return ids;
  }
);
derived(
  [permissionQueues, currentSessionId],
  ([$queues, $activeSessionId]) => {
    if (!$activeSessionId) return null;
    const queue = $queues[$activeSessionId] ?? [];
    return queue[0] ?? null;
  }
);
const commandsBySession = writable({});
const availableCommands = derived(
  [commandsBySession, currentSessionId],
  ([$bySession, $sid]) => $sid ? $bySession[$sid] ?? [] : []
);
const planBySession = writable({});
const currentPlan = derived(
  [planBySession, currentSessionId],
  ([$bySession, $sid]) => $sid ? $bySession[$sid] ?? null : null
);
const hasPlan = derived(currentPlan, ($plan) => $plan !== null && $plan.entries.length > 0);
const planProgress = derived(currentPlan, ($plan) => {
  if (!$plan || $plan.totalCount === 0) return 0;
  return Math.round($plan.completedCount / $plan.totalCount * 100);
});
const rateLimitCache = writable({});
const currentRateLimits = derived(
  [rateLimitCache, selectedAgent],
  ([$cache, $agent]) => $agent ? $cache[$agent.name] ?? null : null
);
const hasRateLimits = derived(currentRateLimits, (d) => d !== null && (d.hasData || d.isLoading));
derived(currentRateLimits, (d) => d !== null && d.hasData);
const peakUsagePercent = derived(currentRateLimits, (d) => {
  if (!d || !d.hasData) return 0;
  let peak = 0;
  if (d.primary.hasData) peak = Math.max(peak, d.primary.usedPercent);
  if (d.secondary.hasData) peak = Math.max(peak, d.secondary.usedPercent);
  if (d.modelSpecific.hasData) peak = Math.max(peak, d.modelSpecific.usedPercent);
  return Math.round(peak);
});
function formatResetTime(isoDate) {
  if (!isoDate) return "";
  const resetAt = new Date(isoDate);
  const now = /* @__PURE__ */ new Date();
  const diffMs = resetAt.getTime() - now.getTime();
  if (diffMs <= 0) return "now";
  const diffMin = Math.floor(diffMs / 6e4);
  if (diffMin < 60) return `${diffMin}m`;
  const diffH = Math.floor(diffMin / 60);
  if (diffH < 24) return `${diffH}h ${diffMin % 60}m`;
  const diffD = Math.floor(diffH / 24);
  return `${diffD}d ${diffH % 24}h`;
}
function formatWindowDuration(minutes) {
  if (minutes <= 0) return "";
  if (minutes < 60) return `${minutes}m`;
  const h = Math.floor(minutes / 60);
  if (h < 24) return `${h}h`;
  const d = Math.floor(h / 24);
  return `${d}d`;
}
function formatLastUpdated(isoDate) {
  if (!isoDate) return "";
  const updated = new Date(isoDate);
  const now = /* @__PURE__ */ new Date();
  const diffSec = Math.floor((now.getTime() - updated.getTime()) / 1e3);
  if (diffSec < 10) return "Updated just now";
  if (diffSec < 60) return `Updated ${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  return `Updated ${diffMin}m ago`;
}
function currencySymbol(code) {
  switch (code.toUpperCase()) {
    case "USD":
      return "$";
    case "EUR":
      return "€";
    case "GBP":
      return "£";
    default:
      return code + " ";
  }
}
function usageColor(pct) {
  if (pct < 60) return "#22c55e";
  if (pct < 85) return "#eab308";
  return "#ef4444";
}
const attachments = writable([]);
derived(attachments, ($a) => $a.length > 0);
const emptyStatus = {
  enabled: false,
  provider: "",
  branch: "",
  changesCount: -1,
  connected: false
};
const scStatus = writable({ ...emptyStatus });
const scEnabled = derived(scStatus, (s) => s.enabled);
const branchName = derived(scStatus, (s) => s.branch || "");
const hasChanges = derived(scStatus, (s) => s.changesCount > 0);
const changesLabel = derived(
  scStatus,
  (s) => s.changesCount > 0 ? `+${s.changesCount}` : ""
);
function isFunction$1(value) {
  return typeof value === "function";
}
function isObject$1(value) {
  return value !== null && typeof value === "object";
}
const CLASS_VALUE_PRIMITIVE_TYPES = ["string", "number", "bigint", "boolean"];
function isClassValue(value) {
  if (value === null || value === void 0)
    return true;
  if (CLASS_VALUE_PRIMITIVE_TYPES.includes(typeof value))
    return true;
  if (Array.isArray(value))
    return value.every((item) => isClassValue(item));
  if (typeof value === "object") {
    if (Object.getPrototypeOf(value) !== Object.prototype)
      return false;
    return true;
  }
  return false;
}
const BoxSymbol$1 = /* @__PURE__ */ Symbol("box");
const isWritableSymbol$1 = /* @__PURE__ */ Symbol("is-writable");
function boxWith$1(getter, setter) {
  const derived2 = getter();
  if (setter) {
    return {
      [BoxSymbol$1]: true,
      [isWritableSymbol$1]: true,
      get current() {
        return derived2;
      },
      set current(v) {
        setter(v);
      }
    };
  }
  return {
    [BoxSymbol$1]: true,
    get current() {
      return getter();
    }
  };
}
function isBox$1(value) {
  return isObject$1(value) && BoxSymbol$1 in value;
}
function isWritableBox$1(value) {
  return isBox$1(value) && isWritableSymbol$1 in value;
}
function boxFrom$1(value) {
  if (isBox$1(value)) return value;
  if (isFunction$1(value)) return boxWith$1(value);
  return simpleBox(value);
}
function boxFlatten$1(boxes) {
  return Object.entries(boxes).reduce(
    (acc, [key, b]) => {
      if (!isBox$1(b)) {
        return Object.assign(acc, { [key]: b });
      }
      if (isWritableBox$1(b)) {
        Object.defineProperty(acc, key, {
          get() {
            return b.current;
          },
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          set(v) {
            b.current = v;
          }
        });
      } else {
        Object.defineProperty(acc, key, {
          get() {
            return b.current;
          }
        });
      }
      return acc;
    },
    {}
  );
}
function toReadonlyBox$1(b) {
  if (!isWritableBox$1(b)) return b;
  return {
    [BoxSymbol$1]: true,
    get current() {
      return b.current;
    }
  };
}
function simpleBox(initialValue) {
  let current = initialValue;
  return {
    [BoxSymbol$1]: true,
    [isWritableSymbol$1]: true,
    get current() {
      return current;
    },
    set current(v) {
      current = v;
    }
  };
}
function onDestroyEffect(fn) {
}
function afterTick(fn) {
  tick().then(fn);
}
const ELEMENT_NODE = 1;
const DOCUMENT_NODE = 9;
const DOCUMENT_FRAGMENT_NODE = 11;
function isHTMLElement$1(node) {
  return isObject$1(node) && node.nodeType === ELEMENT_NODE && typeof node.nodeName === "string";
}
function isDocument(node) {
  return isObject$1(node) && node.nodeType === DOCUMENT_NODE;
}
function isWindow(node) {
  return isObject$1(node) && node.constructor?.name === "VisualViewport";
}
function isNode(node) {
  return isObject$1(node) && node.nodeType !== void 0;
}
function isShadowRoot(node) {
  return isNode(node) && node.nodeType === DOCUMENT_FRAGMENT_NODE && "host" in node;
}
function contains(parent, child) {
  if (!parent || !child)
    return false;
  if (!isHTMLElement$1(parent) || !isHTMLElement$1(child))
    return false;
  const rootNode = child.getRootNode?.();
  if (parent === child)
    return true;
  if (parent.contains(child))
    return true;
  if (rootNode && isShadowRoot(rootNode)) {
    let next = child;
    while (next) {
      if (parent === next)
        return true;
      next = next.parentNode || next.host;
    }
  }
  return false;
}
function getDocument(node) {
  if (isDocument(node))
    return node;
  if (isWindow(node))
    return node.document;
  return node?.ownerDocument ?? document;
}
function getWindow(node) {
  if (isShadowRoot(node))
    return getWindow(node.host);
  if (isDocument(node))
    return node.defaultView ?? window;
  if (isHTMLElement$1(node))
    return node.ownerDocument?.defaultView ?? window;
  return window;
}
function getActiveElement$3(rootNode) {
  let activeElement = rootNode.activeElement;
  while (activeElement?.shadowRoot) {
    const el = activeElement.shadowRoot.activeElement;
    if (el === activeElement)
      break;
    else
      activeElement = el;
  }
  return activeElement;
}
class DOMContext {
  element;
  #root = derived$1(() => {
    if (!this.element.current) return document;
    const rootNode = this.element.current.getRootNode() ?? document;
    return rootNode;
  });
  get root() {
    return this.#root();
  }
  set root($$value) {
    return this.#root($$value);
  }
  constructor(element) {
    if (typeof element === "function") {
      this.element = boxWith$1(element);
    } else {
      this.element = element;
    }
  }
  getDocument = () => {
    return getDocument(this.root);
  };
  getWindow = () => {
    return this.getDocument().defaultView ?? window;
  };
  getActiveElement = () => {
    return getActiveElement$3(this.root);
  };
  isActiveElement = (node) => {
    return node === this.getActiveElement();
  };
  getElementById(id) {
    return this.root.getElementById(id);
  }
  querySelector = (selector) => {
    if (!this.root) return null;
    return this.root.querySelector(selector);
  };
  querySelectorAll = (selector) => {
    if (!this.root) return [];
    return this.root.querySelectorAll(selector);
  };
  setTimeout = (callback, delay) => {
    return this.getWindow().setTimeout(callback, delay);
  };
  clearTimeout = (timeoutId) => {
    return this.getWindow().clearTimeout(timeoutId);
  };
}
function attachRef(ref, onChange) {
  return {
    [createAttachmentKey()]: (node) => {
      if (isBox$1(ref)) {
        ref.current = node;
        run(() => onChange?.(node));
        return () => {
          if ("isConnected" in node && node.isConnected)
            return;
          ref.current = null;
          onChange?.(null);
        };
      }
      ref(node);
      run(() => onChange?.(node));
      return () => {
        if ("isConnected" in node && node.isConnected)
          return;
        ref(null);
        onChange?.(null);
      };
    }
  };
}
const defaultWindow$2 = void 0;
function getActiveElement$2(document2) {
  let activeElement = document2.activeElement;
  while (activeElement?.shadowRoot) {
    const node = activeElement.shadowRoot.activeElement;
    if (node === activeElement)
      break;
    else
      activeElement = node;
  }
  return activeElement;
}
let ActiveElement$2 = class ActiveElement {
  #document;
  #subscribe;
  constructor(options = {}) {
    const { window: window2 = defaultWindow$2, document: document2 = window2?.document } = options;
    if (window2 === void 0) return;
    this.#document = document2;
    this.#subscribe = createSubscriber();
  }
  get current() {
    this.#subscribe?.();
    if (!this.#document) return null;
    return getActiveElement$2(this.#document);
  }
};
new ActiveElement$2();
class Context {
  #name;
  #key;
  /**
   * @param name The name of the context.
   * This is used for generating the context key and error messages.
   */
  constructor(name) {
    this.#name = name;
    this.#key = Symbol(name);
  }
  /**
   * The key used to get and set the context.
   *
   * It is not recommended to use this value directly.
   * Instead, use the methods provided by this class.
   */
  get key() {
    return this.#key;
  }
  /**
   * Checks whether this has been set in the context of a parent component.
   *
   * Must be called during component initialisation.
   */
  exists() {
    return hasContext(this.#key);
  }
  /**
   * Retrieves the context that belongs to the closest parent component.
   *
   * Must be called during component initialisation.
   *
   * @throws An error if the context does not exist.
   */
  get() {
    const context = getContext(this.#key);
    if (context === void 0) {
      throw new Error(`Context "${this.#name}" not found`);
    }
    return context;
  }
  /**
   * Retrieves the context that belongs to the closest parent component,
   * or the given fallback value if the context does not exist.
   *
   * Must be called during component initialisation.
   */
  getOr(fallback) {
    const context = getContext(this.#key);
    if (context === void 0) {
      return fallback;
    }
    return context;
  }
  /**
   * Associates the given value with the current component and returns it.
   *
   * Must be called during component initialisation.
   */
  set(context) {
    return setContext(this.#key, context);
  }
}
function runWatcher(sources, flush, effect, options = {}) {
  const { lazy = false } = options;
}
function watch(sources, effect, options) {
  runWatcher(sources, "post", effect, options);
}
function watchPre(sources, effect, options) {
  runWatcher(sources, "pre", effect, options);
}
watch.pre = watchPre;
function boolToStr(condition) {
  return condition ? "true" : "false";
}
function boolToEmptyStrOrUndef(condition) {
  return condition ? "" : void 0;
}
function getDataOpenClosed(condition) {
  return condition ? "open" : "closed";
}
function getAriaChecked(checked, indeterminate) {
  return checked ? "true" : "false";
}
class BitsAttrs {
  #variant;
  #prefix;
  attrs;
  constructor(config) {
    this.#variant = config.getVariant ? config.getVariant() : null;
    this.#prefix = this.#variant ? `data-${this.#variant}-` : `data-${config.component}-`;
    this.getAttr = this.getAttr.bind(this);
    this.selector = this.selector.bind(this);
    this.attrs = Object.fromEntries(config.parts.map((part) => [part, this.getAttr(part)]));
  }
  getAttr(part, variantOverride) {
    if (variantOverride)
      return `data-${variantOverride}-${part}`;
    return `${this.#prefix}${part}`;
  }
  selector(part, variantOverride) {
    return `[${this.getAttr(part, variantOverride)}]`;
  }
}
function createBitsAttrs(config) {
  const bitsAttrs = new BitsAttrs(config);
  return {
    ...bitsAttrs.attrs,
    selector: bitsAttrs.selector,
    getAttr: bitsAttrs.getAttr
  };
}
const isBrowser$1 = typeof document !== "undefined";
const isIOS = getIsIOS();
function getIsIOS() {
  return isBrowser$1 && window?.navigator?.userAgent && (/iP(ad|hone|od)/.test(window.navigator.userAgent) || // The new iPad Pro Gen3 does not identify itself as iPad, but as Macintosh.
  window?.navigator?.maxTouchPoints > 2 && /iPad|Macintosh/.test(window?.navigator.userAgent));
}
function isHTMLElement(element) {
  return element instanceof HTMLElement;
}
function isElement(element) {
  return element instanceof Element;
}
function isElementOrSVGElement(element) {
  return element instanceof Element || element instanceof SVGElement;
}
function isFocusVisible(element) {
  return element.matches(":focus-visible");
}
function isNotNull(value) {
  return value !== null;
}
function isSelectableInput(element) {
  return element instanceof HTMLInputElement && "select" in element;
}
class AnimationsComplete {
  #opts;
  #currentFrame = null;
  constructor(opts) {
    this.#opts = opts;
  }
  #cleanup() {
    if (!this.#currentFrame)
      return;
    window.cancelAnimationFrame(this.#currentFrame);
    this.#currentFrame = null;
  }
  run(fn) {
    this.#cleanup();
    const node = this.#opts.ref.current;
    if (!node)
      return;
    if (typeof node.getAnimations !== "function") {
      this.#executeCallback(fn);
      return;
    }
    this.#currentFrame = window.requestAnimationFrame(() => {
      const animations = node.getAnimations();
      if (animations.length === 0) {
        this.#executeCallback(fn);
        return;
      }
      Promise.allSettled(animations.map((animation) => animation.finished)).then(() => {
        this.#executeCallback(fn);
      });
    });
  }
  #executeCallback(fn) {
    const execute = () => {
      fn();
    };
    if (this.#opts.afterTick) {
      afterTick(execute);
    } else {
      execute();
    }
  }
}
class PresenceManager {
  #opts;
  #enabled;
  #afterAnimations;
  #shouldRender = false;
  constructor(opts) {
    this.#opts = opts;
    this.#shouldRender = opts.open.current;
    this.#enabled = opts.enabled ?? true;
    this.#afterAnimations = new AnimationsComplete({ ref: this.#opts.ref, afterTick: this.#opts.open });
    watch(() => this.#opts.open.current, (isOpen) => {
      if (isOpen) this.#shouldRender = true;
      if (!this.#enabled) return;
      this.#afterAnimations.run(() => {
        if (isOpen === this.#opts.open.current) {
          if (!this.#opts.open.current) {
            this.#shouldRender = false;
          }
          this.#opts.onComplete?.();
        }
      });
    });
  }
  get shouldRender() {
    return this.#shouldRender;
  }
}
function isPointInPolygon(point, polygon) {
  const [x, y] = point;
  let isInside = false;
  const length = polygon.length;
  for (let i = 0, j = length - 1; i < length; j = i++) {
    const [xi, yi] = polygon[i] ?? [0, 0];
    const [xj, yj] = polygon[j] ?? [0, 0];
    const intersect = yi >= y !== yj >= y && x <= (xj - xi) * (y - yi) / (yj - yi) + xi;
    if (intersect) {
      isInside = !isInside;
    }
  }
  return isInside;
}
function isInsideRect(point, rect) {
  return point[0] >= rect.left && point[0] <= rect.right && point[1] >= rect.top && point[1] <= rect.bottom;
}
function getSide(triggerRect, contentRect) {
  const triggerCenterX = triggerRect.left + triggerRect.width / 2;
  const triggerCenterY = triggerRect.top + triggerRect.height / 2;
  const contentCenterX = contentRect.left + contentRect.width / 2;
  const contentCenterY = contentRect.top + contentRect.height / 2;
  const deltaX = contentCenterX - triggerCenterX;
  const deltaY = contentCenterY - triggerCenterY;
  if (Math.abs(deltaX) > Math.abs(deltaY)) {
    return deltaX > 0 ? "right" : "left";
  }
  return deltaY > 0 ? "bottom" : "top";
}
class SafePolygon {
  #opts;
  #buffer;
  // tracks the cursor position when leaving trigger or content
  #exitPoint = null;
  // tracks what we're moving toward: "content" when leaving trigger, "trigger" when leaving content
  #exitTarget = null;
  constructor(opts) {
    this.#opts = opts;
    this.#buffer = opts.buffer ?? 1;
    watch([opts.triggerNode, opts.contentNode, opts.enabled], ([triggerNode, contentNode, enabled]) => {
      if (!triggerNode || !contentNode || !enabled) {
        this.#exitPoint = null;
        this.#exitTarget = null;
        return;
      }
      const doc = getDocument(triggerNode);
      const handlePointerMove = (e) => {
        this.#onPointerMove(e, triggerNode, contentNode);
      };
      const handleTriggerLeave = (e) => {
        const target = e.relatedTarget;
        if (isElement(target) && contentNode.contains(target)) {
          return;
        }
        this.#exitPoint = [e.clientX, e.clientY];
        this.#exitTarget = "content";
      };
      const handleTriggerEnter = () => {
        this.#exitPoint = null;
        this.#exitTarget = null;
      };
      const handleContentEnter = () => {
        this.#exitPoint = null;
        this.#exitTarget = null;
      };
      const handleContentLeave = (e) => {
        const target = e.relatedTarget;
        if (isElement(target) && triggerNode.contains(target)) {
          return;
        }
        this.#exitPoint = [e.clientX, e.clientY];
        this.#exitTarget = "trigger";
      };
      return [
        on(doc, "pointermove", handlePointerMove),
        on(triggerNode, "pointerleave", handleTriggerLeave),
        on(triggerNode, "pointerenter", handleTriggerEnter),
        on(contentNode, "pointerenter", handleContentEnter),
        on(contentNode, "pointerleave", handleContentLeave)
      ].reduce(
        (acc, cleanup) => () => {
          acc();
          cleanup();
        },
        () => {
        }
      );
    });
  }
  #onPointerMove(e, triggerNode, contentNode) {
    if (!this.#exitPoint || !this.#exitTarget) return;
    const clientPoint = [e.clientX, e.clientY];
    const triggerRect = triggerNode.getBoundingClientRect();
    const contentRect = contentNode.getBoundingClientRect();
    if (this.#exitTarget === "content" && isInsideRect(clientPoint, contentRect)) {
      this.#exitPoint = null;
      this.#exitTarget = null;
      return;
    }
    if (this.#exitTarget === "trigger" && isInsideRect(clientPoint, triggerRect)) {
      this.#exitPoint = null;
      this.#exitTarget = null;
      return;
    }
    const side = getSide(triggerRect, contentRect);
    const corridorPoly = this.#getCorridorPolygon(triggerRect, contentRect, side);
    if (corridorPoly && isPointInPolygon(clientPoint, corridorPoly)) {
      return;
    }
    const targetRect = this.#exitTarget === "content" ? contentRect : triggerRect;
    const safePoly = this.#getSafePolygon(this.#exitPoint, targetRect, side, this.#exitTarget);
    if (isPointInPolygon(clientPoint, safePoly)) {
      return;
    }
    this.#exitPoint = null;
    this.#exitTarget = null;
    this.#opts.onPointerExit();
  }
  /**
   * Creates a rectangular corridor between trigger and content
   * This prevents closing when cursor is in the gap between them
   */
  #getCorridorPolygon(triggerRect, contentRect, side) {
    const buffer = this.#buffer;
    switch (side) {
      case "top":
        return [
          [
            Math.min(triggerRect.left, contentRect.left) - buffer,
            triggerRect.top
          ],
          [
            Math.min(triggerRect.left, contentRect.left) - buffer,
            contentRect.bottom
          ],
          [
            Math.max(triggerRect.right, contentRect.right) + buffer,
            contentRect.bottom
          ],
          [
            Math.max(triggerRect.right, contentRect.right) + buffer,
            triggerRect.top
          ]
        ];
      case "bottom":
        return [
          [
            Math.min(triggerRect.left, contentRect.left) - buffer,
            triggerRect.bottom
          ],
          [
            Math.min(triggerRect.left, contentRect.left) - buffer,
            contentRect.top
          ],
          [
            Math.max(triggerRect.right, contentRect.right) + buffer,
            contentRect.top
          ],
          [
            Math.max(triggerRect.right, contentRect.right) + buffer,
            triggerRect.bottom
          ]
        ];
      case "left":
        return [
          [
            triggerRect.left,
            Math.min(triggerRect.top, contentRect.top) - buffer
          ],
          [
            contentRect.right,
            Math.min(triggerRect.top, contentRect.top) - buffer
          ],
          [
            contentRect.right,
            Math.max(triggerRect.bottom, contentRect.bottom) + buffer
          ],
          [
            triggerRect.left,
            Math.max(triggerRect.bottom, contentRect.bottom) + buffer
          ]
        ];
      case "right":
        return [
          [
            triggerRect.right,
            Math.min(triggerRect.top, contentRect.top) - buffer
          ],
          [
            contentRect.left,
            Math.min(triggerRect.top, contentRect.top) - buffer
          ],
          [
            contentRect.left,
            Math.max(triggerRect.bottom, contentRect.bottom) + buffer
          ],
          [
            triggerRect.right,
            Math.max(triggerRect.bottom, contentRect.bottom) + buffer
          ]
        ];
    }
  }
  /**
   * Creates a triangular/trapezoidal safe zone from the exit point to the target
   */
  #getSafePolygon(exitPoint, targetRect, side, exitTarget) {
    const buffer = this.#buffer * 4;
    const [x, y] = exitPoint;
    const effectiveSide = exitTarget === "trigger" ? this.#flipSide(side) : side;
    switch (effectiveSide) {
      case "top":
        return [
          [x - buffer, y + buffer],
          [x + buffer, y + buffer],
          [targetRect.right + buffer, targetRect.bottom],
          [targetRect.right + buffer, targetRect.top],
          [targetRect.left - buffer, targetRect.top],
          [targetRect.left - buffer, targetRect.bottom]
        ];
      case "bottom":
        return [
          [x - buffer, y - buffer],
          [x + buffer, y - buffer],
          [targetRect.right + buffer, targetRect.top],
          [targetRect.right + buffer, targetRect.bottom],
          [targetRect.left - buffer, targetRect.bottom],
          [targetRect.left - buffer, targetRect.top]
        ];
      case "left":
        return [
          [x + buffer, y - buffer],
          [x + buffer, y + buffer],
          [targetRect.right, targetRect.bottom + buffer],
          [targetRect.left, targetRect.bottom + buffer],
          [targetRect.left, targetRect.top - buffer],
          [targetRect.right, targetRect.top - buffer]
        ];
      case "right":
        return [
          [x - buffer, y - buffer],
          [x - buffer, y + buffer],
          [targetRect.left, targetRect.bottom + buffer],
          [targetRect.right, targetRect.bottom + buffer],
          [targetRect.right, targetRect.top - buffer],
          [targetRect.left, targetRect.top - buffer]
        ];
    }
  }
  #flipSide(side) {
    switch (side) {
      case "top":
        return "bottom";
      case "bottom":
        return "top";
      case "left":
        return "right";
      case "right":
        return "left";
    }
  }
}
class TimeoutFn {
  #interval;
  #cb;
  #timer = null;
  constructor(cb, interval) {
    this.#cb = cb;
    this.#interval = interval;
    this.stop = this.stop.bind(this);
    this.start = this.start.bind(this);
    onDestroyEffect(this.stop);
  }
  #clear() {
    if (this.#timer !== null) {
      window.clearTimeout(this.#timer);
      this.#timer = null;
    }
  }
  stop() {
    this.#clear();
  }
  start(...args) {
    this.#clear();
    this.#timer = window.setTimeout(() => {
      this.#timer = null;
      this.#cb(...args);
    }, this.#interval);
  }
}
const tooltipAttrs = createBitsAttrs({ component: "tooltip", parts: ["content", "trigger"] });
const TooltipProviderContext = new Context("Tooltip.Provider");
const TooltipRootContext = new Context("Tooltip.Root");
class TooltipProviderState {
  static create(opts) {
    return TooltipProviderContext.set(new TooltipProviderState(opts));
  }
  opts;
  isOpenDelayed = true;
  isPointerInTransit = simpleBox(false);
  #timerFn;
  #openTooltip = null;
  constructor(opts) {
    this.opts = opts;
    this.#timerFn = new TimeoutFn(
      () => {
        this.isOpenDelayed = true;
      },
      this.opts.skipDelayDuration.current
    );
  }
  #startTimer = () => {
    const skipDuration = this.opts.skipDelayDuration.current;
    if (skipDuration === 0) {
      return;
    } else {
      this.#timerFn.start();
    }
  };
  #clearTimer = () => {
    this.#timerFn.stop();
  };
  onOpen = (tooltip) => {
    if (this.#openTooltip && this.#openTooltip !== tooltip) {
      this.#openTooltip.handleClose();
    }
    this.#clearTimer();
    this.isOpenDelayed = false;
    this.#openTooltip = tooltip;
  };
  onClose = (tooltip) => {
    if (this.#openTooltip === tooltip) {
      this.#openTooltip = null;
    }
    this.#startTimer();
  };
  isTooltipOpen = (tooltip) => {
    return this.#openTooltip === tooltip;
  };
}
class TooltipRootState {
  static create(opts) {
    return TooltipRootContext.set(new TooltipRootState(opts, TooltipProviderContext.get()));
  }
  opts;
  provider;
  #delayDuration = derived$1(() => this.opts.delayDuration.current ?? this.provider.opts.delayDuration.current);
  get delayDuration() {
    return this.#delayDuration();
  }
  set delayDuration($$value) {
    return this.#delayDuration($$value);
  }
  #disableHoverableContent = derived$1(() => this.opts.disableHoverableContent.current ?? this.provider.opts.disableHoverableContent.current);
  get disableHoverableContent() {
    return this.#disableHoverableContent();
  }
  set disableHoverableContent($$value) {
    return this.#disableHoverableContent($$value);
  }
  #disableCloseOnTriggerClick = derived$1(() => this.opts.disableCloseOnTriggerClick.current ?? this.provider.opts.disableCloseOnTriggerClick.current);
  get disableCloseOnTriggerClick() {
    return this.#disableCloseOnTriggerClick();
  }
  set disableCloseOnTriggerClick($$value) {
    return this.#disableCloseOnTriggerClick($$value);
  }
  #disabled = derived$1(() => this.opts.disabled.current ?? this.provider.opts.disabled.current);
  get disabled() {
    return this.#disabled();
  }
  set disabled($$value) {
    return this.#disabled($$value);
  }
  #ignoreNonKeyboardFocus = derived$1(() => this.opts.ignoreNonKeyboardFocus.current ?? this.provider.opts.ignoreNonKeyboardFocus.current);
  get ignoreNonKeyboardFocus() {
    return this.#ignoreNonKeyboardFocus();
  }
  set ignoreNonKeyboardFocus($$value) {
    return this.#ignoreNonKeyboardFocus($$value);
  }
  contentNode = null;
  contentPresence;
  triggerNode = null;
  #wasOpenDelayed = false;
  #timerFn;
  #stateAttr = derived$1(() => {
    if (!this.opts.open.current) return "closed";
    return this.#wasOpenDelayed ? "delayed-open" : "instant-open";
  });
  get stateAttr() {
    return this.#stateAttr();
  }
  set stateAttr($$value) {
    return this.#stateAttr($$value);
  }
  constructor(opts, provider) {
    this.opts = opts;
    this.provider = provider;
    this.#timerFn = new TimeoutFn(
      () => {
        this.#wasOpenDelayed = true;
        this.opts.open.current = true;
      },
      this.delayDuration ?? 0
    );
    this.contentPresence = new PresenceManager({
      open: this.opts.open,
      ref: boxWith$1(() => this.contentNode),
      onComplete: () => {
        this.opts.onOpenChangeComplete.current(this.opts.open.current);
      }
    });
    watch(() => this.delayDuration, () => {
      if (this.delayDuration === void 0) return;
      this.#timerFn = new TimeoutFn(
        () => {
          this.#wasOpenDelayed = true;
          this.opts.open.current = true;
        },
        this.delayDuration
      );
    });
    watch(
      () => this.opts.open.current,
      (isOpen) => {
        if (isOpen) {
          this.provider.onOpen(this);
        } else {
          this.provider.onClose(this);
        }
      },
      { lazy: true }
    );
  }
  handleOpen = () => {
    this.#timerFn.stop();
    this.#wasOpenDelayed = false;
    this.opts.open.current = true;
  };
  handleClose = () => {
    this.#timerFn.stop();
    this.opts.open.current = false;
  };
  #handleDelayedOpen = () => {
    this.#timerFn.stop();
    const shouldSkipDelay = !this.provider.isOpenDelayed;
    const delayDuration = this.delayDuration ?? 0;
    if (shouldSkipDelay || delayDuration === 0) {
      this.#wasOpenDelayed = delayDuration > 0 && shouldSkipDelay;
      this.opts.open.current = true;
    } else {
      this.#timerFn.start();
    }
  };
  onTriggerEnter = () => {
    this.#handleDelayedOpen();
  };
  onTriggerLeave = () => {
    if (this.disableHoverableContent) {
      this.handleClose();
    } else {
      this.#timerFn.stop();
    }
  };
}
class TooltipTriggerState {
  static create(opts) {
    return new TooltipTriggerState(opts, TooltipRootContext.get());
  }
  opts;
  root;
  attachment;
  #isPointerDown = simpleBox(false);
  #hasPointerMoveOpened = false;
  #isDisabled = derived$1(() => this.opts.disabled.current || this.root.disabled);
  domContext;
  #transitCheckTimeout = null;
  constructor(opts, root) {
    this.opts = opts;
    this.root = root;
    this.domContext = new DOMContext(opts.ref);
    this.attachment = attachRef(this.opts.ref, (v) => this.root.triggerNode = v);
  }
  #clearTransitCheck = () => {
    if (this.#transitCheckTimeout !== null) {
      clearTimeout(this.#transitCheckTimeout);
      this.#transitCheckTimeout = null;
    }
  };
  handlePointerUp = () => {
    this.#isPointerDown.current = false;
  };
  #onpointerup = () => {
    if (this.#isDisabled()) return;
    this.#isPointerDown.current = false;
  };
  #onpointerdown = () => {
    if (this.#isDisabled()) return;
    this.#isPointerDown.current = true;
    this.domContext.getDocument().addEventListener(
      "pointerup",
      () => {
        this.handlePointerUp();
      },
      { once: true }
    );
  };
  #onpointerenter = (e) => {
    if (this.#isDisabled()) return;
    if (e.pointerType === "touch") return;
    if (this.root.provider.isPointerInTransit.current) {
      this.#clearTransitCheck();
      this.#transitCheckTimeout = window.setTimeout(
        () => {
          if (this.root.provider.isPointerInTransit.current) {
            this.root.provider.isPointerInTransit.current = false;
            this.root.onTriggerEnter();
            this.#hasPointerMoveOpened = true;
          }
        },
        250
      );
      return;
    }
    this.root.onTriggerEnter();
    this.#hasPointerMoveOpened = true;
  };
  #onpointermove = (e) => {
    if (this.#isDisabled()) return;
    if (e.pointerType === "touch") return;
    if (this.#hasPointerMoveOpened) return;
    this.#clearTransitCheck();
    this.root.provider.isPointerInTransit.current = false;
    this.root.onTriggerEnter();
    this.#hasPointerMoveOpened = true;
  };
  #onpointerleave = () => {
    if (this.#isDisabled()) return;
    this.#clearTransitCheck();
    this.root.onTriggerLeave();
    this.#hasPointerMoveOpened = false;
  };
  #onfocus = (e) => {
    if (this.#isPointerDown.current || this.#isDisabled()) return;
    if (this.root.ignoreNonKeyboardFocus && !isFocusVisible(e.currentTarget)) return;
    this.root.handleOpen();
  };
  #onblur = () => {
    if (this.#isDisabled()) return;
    this.root.handleClose();
  };
  #onclick = () => {
    if (this.root.disableCloseOnTriggerClick || this.#isDisabled()) return;
    this.root.handleClose();
  };
  #props = derived$1(() => ({
    id: this.opts.id.current,
    "aria-describedby": this.root.opts.open.current ? this.root.contentNode?.id : void 0,
    "data-state": this.root.stateAttr,
    "data-disabled": boolToEmptyStrOrUndef(this.#isDisabled()),
    "data-delay-duration": `${this.root.delayDuration}`,
    [tooltipAttrs.trigger]: "",
    tabindex: this.#isDisabled() ? void 0 : this.opts.tabindex.current,
    disabled: this.opts.disabled.current,
    onpointerup: this.#onpointerup,
    onpointerdown: this.#onpointerdown,
    onpointerenter: this.#onpointerenter,
    onpointermove: this.#onpointermove,
    onpointerleave: this.#onpointerleave,
    onfocus: this.#onfocus,
    onblur: this.#onblur,
    onclick: this.#onclick,
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class TooltipContentState {
  static create(opts) {
    return new TooltipContentState(opts, TooltipRootContext.get());
  }
  opts;
  root;
  attachment;
  constructor(opts, root) {
    this.opts = opts;
    this.root = root;
    this.attachment = attachRef(this.opts.ref, (v) => this.root.contentNode = v);
    new SafePolygon({
      triggerNode: () => this.root.triggerNode,
      contentNode: () => this.root.contentNode,
      enabled: () => this.root.opts.open.current && !this.root.disableHoverableContent,
      onPointerExit: () => {
        if (this.root.provider.isTooltipOpen(this.root)) {
          this.root.handleClose();
        }
      }
    });
  }
  onInteractOutside = (e) => {
    if (isElement(e.target) && this.root.triggerNode?.contains(e.target) && this.root.disableCloseOnTriggerClick) {
      e.preventDefault();
      return;
    }
    this.opts.onInteractOutside.current(e);
    if (e.defaultPrevented) return;
    this.root.handleClose();
  };
  onEscapeKeydown = (e) => {
    this.opts.onEscapeKeydown.current?.(e);
    if (e.defaultPrevented) return;
    this.root.handleClose();
  };
  onOpenAutoFocus = (e) => {
    e.preventDefault();
  };
  onCloseAutoFocus = (e) => {
    e.preventDefault();
  };
  get shouldRender() {
    return this.root.contentPresence.shouldRender;
  }
  #snippetProps = derived$1(() => ({ open: this.root.opts.open.current }));
  get snippetProps() {
    return this.#snippetProps();
  }
  set snippetProps($$value) {
    return this.#snippetProps($$value);
  }
  #props = derived$1(() => ({
    id: this.opts.id.current,
    "data-state": this.root.stateAttr,
    "data-disabled": boolToEmptyStrOrUndef(this.root.disabled),
    style: { outline: "none" },
    [tooltipAttrs.content]: "",
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
  popperProps = {
    onInteractOutside: this.onInteractOutside,
    onEscapeKeydown: this.onEscapeKeydown,
    onOpenAutoFocus: this.onOpenAutoFocus,
    onCloseAutoFocus: this.onCloseAutoFocus
  };
}
const defaultWindow$1 = void 0;
function getActiveElement$1(document2) {
  let activeElement = document2.activeElement;
  while (activeElement?.shadowRoot) {
    const node = activeElement.shadowRoot.activeElement;
    if (node === activeElement)
      break;
    else
      activeElement = node;
  }
  return activeElement;
}
let ActiveElement$1 = class ActiveElement2 {
  #document;
  #subscribe;
  constructor(options = {}) {
    const { window: window2 = defaultWindow$1, document: document2 = window2?.document } = options;
    if (window2 === void 0) return;
    this.#document = document2;
    this.#subscribe = createSubscriber();
  }
  get current() {
    this.#subscribe?.();
    if (!this.#document) return null;
    return getActiveElement$1(this.#document);
  }
};
new ActiveElement$1();
function getStorage(storageType, window2) {
  switch (storageType) {
    case "local":
      return window2.localStorage;
    case "session":
      return window2.sessionStorage;
  }
}
class PersistedState {
  #current;
  #key;
  #serializer;
  #storage;
  #subscribe;
  #version = 0;
  constructor(key, initialValue, options = {}) {
    const {
      storage: storageType = "local",
      serializer = { serialize: JSON.stringify, deserialize: JSON.parse },
      syncTabs = true,
      window: window2 = defaultWindow$1
    } = options;
    this.#current = initialValue;
    this.#key = key;
    this.#serializer = serializer;
    if (window2 === void 0) return;
    const storage = getStorage(storageType, window2);
    this.#storage = storage;
    const existingValue = storage.getItem(key);
    if (existingValue !== null) {
      this.#current = this.#deserialize(existingValue);
    } else {
      this.#serialize(initialValue);
    }
    if (syncTabs && storageType === "local") {
      this.#subscribe = createSubscriber();
    }
  }
  get current() {
    this.#subscribe?.();
    this.#version;
    const root = this.#deserialize(this.#storage?.getItem(this.#key)) ?? this.#current;
    const proxies = /* @__PURE__ */ new WeakMap();
    const proxy = (value) => {
      if (value === null || value?.constructor.name === "Date" || typeof value !== "object") {
        return value;
      }
      let p = proxies.get(value);
      if (!p) {
        p = new Proxy(value, {
          get: (target, property) => {
            this.#version;
            return proxy(Reflect.get(target, property));
          },
          set: (target, property, value2) => {
            this.#version += 1;
            Reflect.set(target, property, value2);
            this.#serialize(root);
            return true;
          }
        });
        proxies.set(value, p);
      }
      return p;
    };
    return proxy(root);
  }
  set current(newValue) {
    this.#serialize(newValue);
    this.#version += 1;
  }
  #handleStorageEvent = (event) => {
    if (event.key !== this.#key || event.newValue === null) return;
    this.#current = this.#deserialize(event.newValue);
    this.#version += 1;
  };
  #deserialize(value) {
    try {
      return this.#serializer.deserialize(value);
    } catch (error) {
      console.error(`Error when parsing "${value}" from persisted store "${this.#key}"`, error);
      return;
    }
  }
  #serialize(value) {
    try {
      if (value != void 0) {
        this.#storage?.setItem(this.#key, this.#serializer.serialize(value));
      }
    } catch (error) {
      console.error(`Error when writing value from persisted store "${this.#key}" to ${this.#storage}`, error);
    }
  }
}
function sanitizeClassNames(classNames) {
  return classNames.filter((className) => className.length > 0);
}
const noopStorage = {
  getItem: (_key) => null,
  setItem: (_key, _value) => {
  }
};
const isBrowser = typeof document !== "undefined";
function isFunction(value) {
  return typeof value === "function";
}
function isObject(value) {
  return value !== null && typeof value === "object";
}
const BoxSymbol = /* @__PURE__ */ Symbol("box");
const isWritableSymbol = /* @__PURE__ */ Symbol("is-writable");
function isBox(value) {
  return isObject(value) && BoxSymbol in value;
}
function isWritableBox(value) {
  return box.isBox(value) && isWritableSymbol in value;
}
function box(initialValue) {
  let current = initialValue;
  return {
    [BoxSymbol]: true,
    [isWritableSymbol]: true,
    get current() {
      return current;
    },
    set current(v) {
      current = v;
    }
  };
}
function boxWith(getter, setter) {
  const derived2 = getter();
  if (setter) {
    return {
      [BoxSymbol]: true,
      [isWritableSymbol]: true,
      get current() {
        return derived2;
      },
      set current(v) {
        setter(v);
      }
    };
  }
  return {
    [BoxSymbol]: true,
    get current() {
      return getter();
    }
  };
}
function boxFrom(value) {
  if (box.isBox(value)) return value;
  if (isFunction(value)) return box.with(value);
  return box(value);
}
function boxFlatten(boxes) {
  return Object.entries(boxes).reduce(
    (acc, [key, b]) => {
      if (!box.isBox(b)) {
        return Object.assign(acc, { [key]: b });
      }
      if (box.isWritableBox(b)) {
        Object.defineProperty(acc, key, {
          get() {
            return b.current;
          },
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          set(v) {
            b.current = v;
          }
        });
      } else {
        Object.defineProperty(acc, key, {
          get() {
            return b.current;
          }
        });
      }
      return acc;
    },
    {}
  );
}
function toReadonlyBox(b) {
  if (!box.isWritableBox(b)) return b;
  return {
    [BoxSymbol]: true,
    get current() {
      return b.current;
    }
  };
}
box.from = boxFrom;
box.with = boxWith;
box.flatten = boxFlatten;
box.readonly = toReadonlyBox;
box.isBox = isBox;
box.isWritableBox = isWritableBox;
function createParser(matcher, replacer) {
  const regex = RegExp(matcher, "g");
  return (str) => {
    if (typeof str !== "string") {
      throw new TypeError(`expected an argument of type string, but got ${typeof str}`);
    }
    if (!str.match(regex))
      return str;
    return str.replace(regex, replacer);
  };
}
const camelToKebab = createParser(/[A-Z]/, (match) => `-${match.toLowerCase()}`);
function styleToCSS(styleObj) {
  if (!styleObj || typeof styleObj !== "object" || Array.isArray(styleObj)) {
    throw new TypeError(`expected an argument of type object, but got ${typeof styleObj}`);
  }
  return Object.keys(styleObj).map((property) => `${camelToKebab(property)}: ${styleObj[property]};`).join("\n");
}
function styleToString(style = {}) {
  return styleToCSS(style).replace("\n", " ");
}
const srOnlyStyles = {
  position: "absolute",
  width: "1px",
  height: "1px",
  padding: "0",
  margin: "-1px",
  overflow: "hidden",
  clip: "rect(0, 0, 0, 0)",
  whiteSpace: "nowrap",
  borderWidth: "0",
  transform: "translateX(-100%)"
};
styleToString(srOnlyStyles);
const defaultWindow = void 0;
function getActiveElement(document2) {
  let activeElement = document2.activeElement;
  while (activeElement?.shadowRoot) {
    const node = activeElement.shadowRoot.activeElement;
    if (node === activeElement)
      break;
    else
      activeElement = node;
  }
  return activeElement;
}
class ActiveElement3 {
  #document;
  #subscribe;
  constructor(options = {}) {
    const { window: window2 = defaultWindow, document: document2 = window2?.document } = options;
    if (window2 === void 0) return;
    this.#document = document2;
    this.#subscribe = createSubscriber();
  }
  get current() {
    this.#subscribe?.();
    if (!this.#document) return null;
    return getActiveElement(this.#document);
  }
}
new ActiveElement3();
const modeStorageKey = box("mode-watcher-mode");
const themeStorageKey = box("mode-watcher-theme");
const modes = ["dark", "light", "system"];
function isValidMode(value) {
  if (typeof value !== "string")
    return false;
  return modes.includes(value);
}
class UserPrefersMode {
  #defaultValue = "system";
  #storage = isBrowser ? localStorage : noopStorage;
  #initialValue = this.#storage.getItem(modeStorageKey.current);
  #value = isValidMode(this.#initialValue) ? this.#initialValue : this.#defaultValue;
  #persisted = this.#makePersisted();
  #makePersisted(value = this.#value) {
    return new PersistedState(modeStorageKey.current, value, {
      serializer: {
        serialize: (v) => v,
        deserialize: (v) => {
          if (isValidMode(v)) return v;
          return this.#defaultValue;
        }
      }
    });
  }
  constructor() {
  }
  get current() {
    return this.#persisted.current;
  }
  set current(newValue) {
    this.#persisted.current = newValue;
  }
}
class SystemPrefersMode {
  #defaultValue = void 0;
  #track = true;
  #current = this.#defaultValue;
  #mediaQueryState = typeof window !== "undefined" && typeof window.matchMedia === "function" ? new MediaQuery("prefers-color-scheme: light") : { current: false };
  query() {
    if (!isBrowser) return;
    this.#current = this.#mediaQueryState.current ? "light" : "dark";
  }
  tracking(active) {
    this.#track = active;
  }
  constructor() {
    this.query = this.query.bind(this);
    this.tracking = this.tracking.bind(this);
  }
  get current() {
    return this.#current;
  }
}
const userPrefersMode = new UserPrefersMode();
const systemPrefersMode = new SystemPrefersMode();
class CustomTheme {
  #storage = isBrowser ? localStorage : noopStorage;
  #initialValue = this.#storage.getItem(themeStorageKey.current);
  #value = this.#initialValue === null || this.#initialValue === void 0 ? "" : this.#initialValue;
  #persisted = this.#makePersisted();
  #makePersisted(value = this.#value) {
    return new PersistedState(themeStorageKey.current, value, {
      serializer: {
        serialize: (v) => {
          if (typeof v !== "string") return "";
          return v;
        },
        deserialize: (v) => v
      }
    });
  }
  constructor() {
  }
  /**
   * The current theme.
   * @returns The current theme.
   */
  get current() {
    return this.#persisted.current;
  }
  /**
   * Set the current theme.
   * @param newValue The new theme to set.
   */
  set current(newValue) {
    this.#persisted.current = newValue;
  }
}
const customTheme = new CustomTheme();
let timeoutAction;
let timeoutEnable;
let hasLoaded = false;
let styleElement = null;
function getStyleElement() {
  if (styleElement)
    return styleElement;
  styleElement = document.createElement("style");
  styleElement.appendChild(document.createTextNode(`* {
		-webkit-transition: none !important;
		-moz-transition: none !important;
		-o-transition: none !important;
		-ms-transition: none !important;
		transition: none !important;
	}`));
  return styleElement;
}
function withoutTransition(action, synchronous = false) {
  if (typeof document === "undefined")
    return;
  if (!hasLoaded) {
    hasLoaded = true;
    action();
    return;
  }
  const isTest = typeof process !== "undefined" && process.env?.NODE_ENV === "test" || typeof window !== "undefined" && window.__vitest_worker__;
  if (isTest) {
    action();
    return;
  }
  clearTimeout(timeoutAction);
  clearTimeout(timeoutEnable);
  const style = getStyleElement();
  const disable = () => document.head.appendChild(style);
  const enable = () => {
    if (style.parentNode) {
      document.head.removeChild(style);
    }
  };
  function executeAction() {
    action();
    window.requestAnimationFrame(enable);
  }
  if (typeof window.requestAnimationFrame !== "undefined") {
    disable();
    if (synchronous) {
      executeAction();
    } else {
      window.requestAnimationFrame(() => {
        executeAction();
      });
    }
    return;
  }
  disable();
  timeoutAction = window.setTimeout(() => {
    action();
    timeoutEnable = window.setTimeout(enable, 16);
  }, 16);
}
const themeColors = box(void 0);
const disableTransitions = box(true);
const synchronousModeChanges = box(false);
const darkClassNames = box([]);
const lightClassNames = box([]);
function createDerivedMode() {
  const current = (() => {
    if (!isBrowser) return void 0;
    const derivedMode2 = userPrefersMode.current === "system" ? systemPrefersMode.current : userPrefersMode.current;
    const sanitizedDarkClassNames = sanitizeClassNames(darkClassNames.current);
    const sanitizedLightClassNames = sanitizeClassNames(lightClassNames.current);
    function update() {
      const htmlEl = document.documentElement;
      const themeColorEl = document.querySelector('meta[name="theme-color"]');
      if (derivedMode2 === "light") {
        if (sanitizedDarkClassNames.length) htmlEl.classList.remove(...sanitizedDarkClassNames);
        if (sanitizedLightClassNames.length) htmlEl.classList.add(...sanitizedLightClassNames);
        htmlEl.style.colorScheme = "light";
        if (themeColorEl && themeColors.current) {
          themeColorEl.setAttribute("content", themeColors.current.light);
        }
      } else {
        if (sanitizedLightClassNames.length) htmlEl.classList.remove(...sanitizedLightClassNames);
        if (sanitizedDarkClassNames.length) htmlEl.classList.add(...sanitizedDarkClassNames);
        htmlEl.style.colorScheme = "dark";
        if (themeColorEl && themeColors.current) {
          themeColorEl.setAttribute("content", themeColors.current.dark);
        }
      }
    }
    if (disableTransitions.current) {
      withoutTransition(update, synchronousModeChanges.current);
    } else {
      update();
    }
    return derivedMode2;
  })();
  return {
    get current() {
      return current;
    }
  };
}
function createDerivedTheme() {
  const current = (() => {
    customTheme.current;
    if (!isBrowser) return void 0;
    function update() {
      const htmlEl = document.documentElement;
      htmlEl.setAttribute("data-theme", customTheme.current);
    }
    if (disableTransitions.current) {
      withoutTransition(update, run(() => synchronousModeChanges.current));
    } else {
      update();
    }
    return customTheme.current;
  })();
  return {
    get current() {
      return current;
    }
  };
}
const derivedMode = createDerivedMode();
createDerivedTheme();
function Icon($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { icon, size = 24, strokeWidth, class: className = "" } = $$props;
    function processAttrs(attrs) {
      return Object.entries(attrs).filter(([key]) => key !== "key").map(([key, value]) => {
        const kebab = key.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
        if (kebab === "stroke-width" && strokeWidth !== void 0) {
          return `${kebab}="${strokeWidth}"`;
        }
        return `${kebab}="${value}"`;
      }).join(" ");
    }
    function buildSvgContent(elements) {
      return elements.map(([tag, attrs]) => `<${tag} ${processAttrs(attrs)}/>`).join("");
    }
    $$renderer2.push(`<svg xmlns="http://www.w3.org/2000/svg"${attr("width", size)}${attr("height", size)} viewBox="0 0 24 24" fill="none" color="currentColor" style="display: inline-block; vertical-align: middle;"${attr_class(clsx$1(className))}>${html(buildSvgContent(icon))}</svg>`);
  });
}
const currentTab = writable("chat");
export {
  isNotNull as $,
  isHTMLElement as A,
  BoxSymbol$1 as B,
  Context as C,
  isBrowser$1 as D,
  watch as E,
  mount as F,
  unmount as G,
  getDocument as H,
  Icon as I,
  isSelectableInput as J,
  getWindow as K,
  isElement as L,
  attachRef as M,
  DOMContext as N,
  afterTick as O,
  PresenceManager as P,
  isElementOrSVGElement as Q,
  simpleBox as R,
  createBitsAttrs as S,
  TooltipProviderState as T,
  getDataOpenClosed as U,
  boolToEmptyStrOrUndef as V,
  boolToStr as W,
  getAriaChecked as X,
  contains as Y,
  SvelteMap as Z,
  isIOS as _,
  disableTransitions as a,
  messages as a$,
  TooltipRootState as a0,
  TooltipContentState as a1,
  TooltipTriggerState as a2,
  cn as a3,
  tick as a4,
  createAttachmentKey as a5,
  onDestroy as a6,
  groupedSessions as a7,
  agents as a8,
  statusDotColor as a9,
  currentMcpStatus as aA,
  permissionQueues as aB,
  availableCommands as aC,
  hasPlan as aD,
  sessionUsage as aE,
  contextPercent as aF,
  hasUsage as aG,
  scEnabled as aH,
  branchName as aI,
  hasChanges as aJ,
  changesLabel as aK,
  createUUID as aL,
  usageColor as aM,
  formatWindowDuration as aN,
  formatResetTime as aO,
  currencySymbol as aP,
  formatLastUpdated as aQ,
  hasRateLimits as aR,
  currentRateLimits as aS,
  peakUsagePercent as aT,
  getIndexingSettings as aU,
  getIndexingStatus as aV,
  getNotificationSettings as aW,
  setContinuationSummaryProvider as aX,
  setContinuationSummaryDefaultDetail as aY,
  stateDisplay as aZ,
  currentState as a_,
  isConnectingAgents as aa,
  sessions as ab,
  isLoadingSessions as ac,
  getSessionSidebarStatus as ad,
  recentlyFinished as ae,
  sessionStates as af,
  sessionsNeedingAttention as ag,
  formatTimeAgo as ah,
  createNewSession as ai,
  buildContinuationDraft as aj,
  getSessionTerminalResumeCommand as ak,
  exportSessionToMarkdown as al,
  selectSession as am,
  removeSession as an,
  getContinuationSummarySettings as ao,
  derivedMode as ap,
  currentPlan as aq,
  planProgress as ar,
  withAlpha as as,
  attachments as at,
  formatTokens as au,
  formatCost as av,
  openSourceControlChangelist as aw,
  openSourceControlSubmit as ax,
  messagesBySession as ay,
  isStreaming as az,
  boxWith$1 as b,
  createSubscriber as c,
  darkClassNames as d,
  themeColors as e,
  currentTab as f,
  setMode as g,
  html as h,
  selectedAgent as i,
  getAgentInstallInfo as j,
  setModel as k,
  lightClassNames as l,
  modeStorageKey as m,
  setReasoningLevel as n,
  getModels as o,
  currentSessionId as p,
  isWritableSymbol$1 as q,
  boxFrom$1 as r,
  synchronousModeChanges as s,
  themeStorageKey as t,
  boxFlatten$1 as u,
  toReadonlyBox$1 as v,
  isBox$1 as w,
  isWritableBox$1 as x,
  isClassValue as y,
  defaultWindow$2 as z
};
