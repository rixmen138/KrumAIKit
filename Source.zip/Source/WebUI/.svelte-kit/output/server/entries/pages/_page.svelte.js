import { g as derived, o as on, p as props_id, k as attributes, q as bind_props, e as attr, s as spread_props, d as clsx$1, f as ensure_array_like, t as element$1, n as store_get, u as unsubscribe_stores, j as attr_style, l as stringify, c as attr_class } from "../../chunks/index2.js";
import { clsx } from "clsx";
import parse from "style-to-object";
import { g as setMode, i as selectedAgent, j as getAgentInstallInfo, k as setModel, n as setReasoningLevel, o as getModels, p as currentSessionId, q as isWritableSymbol$1, B as BoxSymbol$1, r as boxFrom$1, b as boxWith$1, u as boxFlatten$1, v as toReadonlyBox$1, w as isBox$1, x as isWritableBox$1, y as isClassValue$1, z as defaultWindow$3, c as createSubscriber, A as isHTMLElement$1, C as Context$1, D as isBrowser$1, E as watch$2, F as mount, G as unmount, H as getDocument$1, J as isSelectableInput, K as getWindow, L as isElement, P as PresenceManager, M as attachRef$1, N as DOMContext$1, O as afterTick$1, Q as isElementOrSVGElement, R as simpleBox, S as createBitsAttrs, U as getDataOpenClosed, V as boolToEmptyStrOrUndef, W as boolToStr, X as getAriaChecked, Y as contains, Z as SvelteMap, _ as isIOS, $ as isNotNull, a0 as TooltipRootState, a1 as TooltipContentState, a2 as TooltipTriggerState, a3 as cn$1, a4 as tick, a5 as createAttachmentKey, a6 as onDestroy, a7 as groupedSessions, a8 as agents, I as Icon$1, a9 as statusDotColor, aa as isConnectingAgents, ab as sessions, ac as isLoadingSessions, ad as getSessionSidebarStatus, ae as recentlyFinished, af as sessionStates, ag as sessionsNeedingAttention, ah as formatTimeAgo, ai as createNewSession, aj as buildContinuationDraft, ak as getSessionTerminalResumeCommand, f as currentTab, al as exportSessionToMarkdown, am as selectSession, an as removeSession, ao as getContinuationSummarySettings, h as html, ap as derivedMode, aq as currentPlan, ar as planProgress, as as withAlpha, at as attachments, au as formatTokens, av as formatCost, aw as openSourceControlChangelist, ax as openSourceControlSubmit, ay as messagesBySession, az as isStreaming, aA as currentMcpStatus, aB as permissionQueues, aC as availableCommands, aD as hasPlan, aE as sessionUsage, aF as contextPercent, aG as hasUsage, aH as scEnabled, aI as branchName, aJ as hasChanges, aK as changesLabel, aL as createUUID, aM as usageColor, aN as formatWindowDuration, aO as formatResetTime, aP as currencySymbol, aQ as formatLastUpdated, aR as hasRateLimits, aS as currentRateLimits, aT as peakUsagePercent, aU as getIndexingSettings, aV as getIndexingStatus, aW as getNotificationSettings, aX as setContinuationSummaryProvider, aY as setContinuationSummaryDefaultDetail, aZ as stateDisplay, a_ as currentState$1, a$ as messages } from "../../chunks/navigation.js";
import { a3 as is_array, a4 as get_prototype_of, a5 as object_prototype, a6 as getAllContexts, a0 as run, _ as hasContext, $ as getContext, Z as setContext, a1 as escape_html } from "../../chunks/context.js";
import { ArrowDown01Icon, ReloadIcon, Search01Icon, MessageMultiple01Icon, PencilEdit01Icon, Delete02Icon, Settings02Icon, Loading03Icon, Layers01Icon, Copy01Icon, Image01Icon, ArrowUp01Icon, ThreeDMoveIcon, CheckmarkCircle02Icon, Cancel01Icon, CommandLineIcon, File01Icon, Alert02Icon, Tick02Icon, CheckmarkBadge01Icon, Shield02Icon, MessageQuestionIcon, CommandIcon, CodeIcon, Add01Icon, StopIcon, ChangeScreenModeIcon, GitBranchIcon, RefreshIcon, RunningShoesIcon, BodyPartMuscleIcon, RepeatIcon, PaintBrushIcon, CubeIcon, Image02Icon, ArrowRight01Icon, Download04Icon, Key01Icon, SparklesIcon, ArrowReloadHorizontalIcon, CloudIcon, Link01Icon, Globe02Icon, Database02Icon, Wrench01Icon, UserIcon, Notification03Icon, InformationCircleIcon, ArrowLeft02Icon, SidebarLeftIcon, LayoutLeftIcon, MoreHorizontalIcon } from "@hugeicons/core-free-icons";
import { isTabbable, tabbable, isFocusable, focusable } from "tabbable";
import { computePosition, offset, shift, limitShift, flip, size, arrow, hide, autoPlacement, autoUpdate } from "@floating-ui/dom";
import { w as writable, g as get$3, d as derived$1 } from "../../chunks/index.js";
import { createHighlighterCore } from "shiki/core";
import { createJavaScriptRegexEngine } from "shiki/engine/javascript";
import githubDark from "@shikijs/themes/github-dark";
import githubLight from "@shikijs/themes/github-light";
import githubLightDefault from "@shikijs/themes/github-light-default";
import githubDarkDefault from "@shikijs/themes/github-dark-default";
import { Lexer } from "marked";
import { twMerge } from "tailwind-merge";
import "@xterm/xterm";
import "@xterm/addon-web-links";
const empty = [];
function snapshot(value, skip_warning = false, no_tojson = false) {
  return clone(value, /* @__PURE__ */ new Map(), "", empty, null, no_tojson);
}
function clone(value, cloned, path, paths, original = null, no_tojson = false) {
  if (typeof value === "object" && value !== null) {
    var unwrapped = cloned.get(value);
    if (unwrapped !== void 0) return unwrapped;
    if (value instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(value)
    );
    if (value instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(value)
    );
    if (is_array(value)) {
      var copy = (
        /** @type {Snapshot<any>} */
        Array(value.length)
      );
      cloned.set(value, copy);
      if (original !== null) {
        cloned.set(original, copy);
      }
      for (var i = 0; i < value.length; i += 1) {
        var element2 = value[i];
        if (i in value) {
          copy[i] = clone(element2, cloned, path, paths, null, no_tojson);
        }
      }
      return copy;
    }
    if (get_prototype_of(value) === object_prototype) {
      copy = {};
      cloned.set(value, copy);
      if (original !== null) {
        cloned.set(original, copy);
      }
      for (var key in value) {
        copy[key] = clone(
          // @ts-expect-error
          value[key],
          cloned,
          path,
          paths,
          null,
          no_tojson
        );
      }
      return copy;
    }
    if (value instanceof Date) {
      return (
        /** @type {Snapshot<T>} */
        structuredClone(value)
      );
    }
    if (typeof /** @type {T & { toJSON?: any } } */
    value.toJSON === "function" && !no_tojson) {
      return clone(
        /** @type {T & { toJSON(): any } } */
        value.toJSON(),
        cloned,
        path,
        paths,
        // Associate the instance with the toJSON clone
        value
      );
    }
  }
  if (value instanceof EventTarget) {
    return (
      /** @type {Snapshot<T>} */
      value
    );
  }
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(value)
    );
  } catch (e) {
    return (
      /** @type {Snapshot<T>} */
      value
    );
  }
}
function createRawSnippet(fn) {
  return (renderer, ...args) => {
    var getters = (
      /** @type {Getters<Params>} */
      args.map((value) => () => value)
    );
    renderer.push(
      fn(...getters).render().trim()
    );
  };
}
const authState = writable("none");
const authAgentName = writable("");
const authError = writable("");
const availableModes = writable([]);
const currentModeId = writable("");
async function changeMode(agentName, modeId) {
  currentModeId.set(modeId);
  await setMode(agentName, modeId);
}
function isInPlanMode(modeId) {
  const lower = modeId.toLowerCase();
  return lower === "plan" || lower === "architect" || lower.includes("plan");
}
const registryAgents = writable([]);
const registryLoaded = writable(false);
const registryLoading = writable(false);
const installingAgents = writable(/* @__PURE__ */ new Set());
const setupAgent = writable(null);
const setupState = writable("idle");
const setupProgress = writable("");
const setupError = writable("");
const setupInstallInfo = writable(null);
function enterSetup(agent) {
  setupAgent.set(agent);
  selectedAgent.set(agent);
  setupError.set(agent.statusMessage || "");
  setupProgress.set("");
  setupInstallInfo.set(null);
  void getAgentInstallInfo(agent.name).then((info) => {
    setupInstallInfo.set(info);
  }).catch(() => {
  });
  if (agent.status === "missing_key") {
    setupState.set("missing_key");
  } else {
    setupState.set("idle");
  }
}
const models = writable([]);
const currentModelId = writable("");
const isLoadingModels = writable(false);
const reasoningLevel = writable("high");
const modelBrowserOpen = writable(false);
const allModels = writable([]);
const isLoadingAllModels = writable(false);
const modelCache = /* @__PURE__ */ new Map();
let lastModelLoadRequestId = 0;
function applyModelState(state) {
  models.set(state.models);
  if (state.currentModelId) {
    currentModelId.set(state.currentModelId);
  } else if (state.models.length > 0) {
    currentModelId.set(state.models[0].id);
  }
}
async function loadModelsForAgent(agentName) {
  const requestId = ++lastModelLoadRequestId;
  const isStillActiveTarget = () => {
    const activeAgent = get$3(selectedAgent);
    const activeSession = get$3(currentSessionId);
    return !!activeSession && !!activeAgent && activeAgent.name === agentName;
  };
  const cached = modelCache.get(agentName);
  if (cached && cached.models.length > 0) {
    if (isStillActiveTarget()) {
      applyModelState(cached);
    }
    if (requestId === lastModelLoadRequestId) {
      isLoadingModels.set(false);
    }
    return;
  }
  isLoadingModels.set(true);
  try {
    const state = await getModels(agentName);
    modelCache.set(agentName, { models: state.models, currentModelId: state.currentModelId });
    if (requestId !== lastModelLoadRequestId) return;
    if (state.models.length > 0) {
      if (isStillActiveTarget()) {
        applyModelState({ models: state.models, currentModelId: state.currentModelId });
      }
    } else {
      if (isStillActiveTarget()) {
        models.set([]);
        currentModelId.set("");
      }
    }
  } catch (e) {
    if (requestId !== lastModelLoadRequestId) return;
    console.warn("Failed to load models:", e);
    if (isStillActiveTarget()) {
      models.set([]);
      currentModelId.set("");
    }
  } finally {
    if (requestId === lastModelLoadRequestId) {
      isLoadingModels.set(false);
    }
  }
}
async function changeModel(agentName, modelId) {
  const previousModelId = get$3(currentModelId);
  const nextModelId = modelId;
  if (!nextModelId || nextModelId === "special:browse_all") {
    return;
  }
  currentModelId.set(nextModelId);
  const cached = modelCache.get(agentName);
  if (cached) {
    cached.currentModelId = nextModelId;
  }
  try {
    await setModel(agentName, nextModelId);
    const curated = get$3(models);
    if (!curated.some((m) => m.id === nextModelId)) {
      const knownFromFull = get$3(allModels).find((m) => m.id === nextModelId);
      if (knownFromFull) {
        const nextCurated = [knownFromFull, ...curated.filter((m) => m.id !== "special:browse_all")];
        models.set(nextCurated);
        const cachedCurated = modelCache.get(agentName);
        if (cachedCurated) {
          cachedCurated.models = nextCurated;
          cachedCurated.currentModelId = nextModelId;
        }
      }
    }
  } catch (error) {
    currentModelId.set(previousModelId);
    if (cached) {
      cached.currentModelId = previousModelId;
    }
    throw error;
  }
}
async function changeReasoningLevel(level) {
  const agent = get$3(selectedAgent);
  if (!agent) return;
  reasoningLevel.set(level);
  await setReasoningLevel(agent.name, level);
}
const reasoningLabels = {
  none: "Off",
  low: "Low",
  medium: "Medium",
  high: "High",
  max: "Max"
};
function box$1(initialValue) {
  let current = initialValue;
  return {
    [BoxSymbol$1]: true,
    [isWritableSymbol$1]: true,
    get current() {
      return current;
    },
    set current(v) {
      current = v;
    }
  };
}
box$1.from = boxFrom$1;
box$1.with = boxWith$1;
box$1.flatten = boxFlatten$1;
box$1.readonly = toReadonlyBox$1;
box$1.isBox = isBox$1;
box$1.isWritableBox = isWritableBox$1;
function composeHandlers$1(...handlers) {
  return function(e) {
    for (const handler of handlers) {
      if (!handler)
        continue;
      if (e.defaultPrevented)
        return;
      if (typeof handler === "function") {
        handler.call(this, e);
      } else {
        handler.current?.call(this, e);
      }
    }
  };
}
const NUMBER_CHAR_RE$1 = /\d/;
const STR_SPLITTERS$1 = ["-", "_", "/", "."];
function isUppercase$1(char = "") {
  if (NUMBER_CHAR_RE$1.test(char))
    return void 0;
  return char !== char.toLowerCase();
}
function splitByCase$1(str) {
  const parts = [];
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = STR_SPLITTERS$1.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase$1(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function pascalCase$1(str) {
  if (!str)
    return "";
  return splitByCase$1(str).map((p) => upperFirst$1(p)).join("");
}
function camelCase$1(str) {
  return lowerFirst$1(pascalCase$1(str || ""));
}
function upperFirst$1(str) {
  return str ? str[0].toUpperCase() + str.slice(1) : "";
}
function lowerFirst$1(str) {
  return str ? str[0].toLowerCase() + str.slice(1) : "";
}
function cssToStyleObj$1(css) {
  if (!css)
    return {};
  const styleObj = {};
  function iterator(name, value) {
    if (name.startsWith("-moz-") || name.startsWith("-webkit-") || name.startsWith("-ms-") || name.startsWith("-o-")) {
      styleObj[pascalCase$1(name)] = value;
      return;
    }
    if (name.startsWith("--")) {
      styleObj[name] = value;
      return;
    }
    styleObj[camelCase$1(name)] = value;
  }
  parse(css, iterator);
  return styleObj;
}
function executeCallbacks$1(...callbacks) {
  return (...args) => {
    for (const callback of callbacks) {
      if (typeof callback === "function") {
        callback(...args);
      }
    }
  };
}
function createParser$1(matcher, replacer) {
  const regex = RegExp(matcher, "g");
  return (str) => {
    if (typeof str !== "string") {
      throw new TypeError(`expected an argument of type string, but got ${typeof str}`);
    }
    if (!str.match(regex))
      return str;
    return str.replace(regex, replacer);
  };
}
const camelToKebab$1 = createParser$1(/[A-Z]/, (match) => `-${match.toLowerCase()}`);
function styleToCSS$1(styleObj) {
  if (!styleObj || typeof styleObj !== "object" || Array.isArray(styleObj)) {
    throw new TypeError(`expected an argument of type object, but got ${typeof styleObj}`);
  }
  return Object.keys(styleObj).map((property) => `${camelToKebab$1(property)}: ${styleObj[property]};`).join("\n");
}
function styleToString$1(style = {}) {
  return styleToCSS$1(style).replace("\n", " ");
}
const EVENT_LIST$1 = [
  "onabort",
  "onanimationcancel",
  "onanimationend",
  "onanimationiteration",
  "onanimationstart",
  "onauxclick",
  "onbeforeinput",
  "onbeforetoggle",
  "onblur",
  "oncancel",
  "oncanplay",
  "oncanplaythrough",
  "onchange",
  "onclick",
  "onclose",
  "oncompositionend",
  "oncompositionstart",
  "oncompositionupdate",
  "oncontextlost",
  "oncontextmenu",
  "oncontextrestored",
  "oncopy",
  "oncuechange",
  "oncut",
  "ondblclick",
  "ondrag",
  "ondragend",
  "ondragenter",
  "ondragleave",
  "ondragover",
  "ondragstart",
  "ondrop",
  "ondurationchange",
  "onemptied",
  "onended",
  "onerror",
  "onfocus",
  "onfocusin",
  "onfocusout",
  "onformdata",
  "ongotpointercapture",
  "oninput",
  "oninvalid",
  "onkeydown",
  "onkeypress",
  "onkeyup",
  "onload",
  "onloadeddata",
  "onloadedmetadata",
  "onloadstart",
  "onlostpointercapture",
  "onmousedown",
  "onmouseenter",
  "onmouseleave",
  "onmousemove",
  "onmouseout",
  "onmouseover",
  "onmouseup",
  "onpaste",
  "onpause",
  "onplay",
  "onplaying",
  "onpointercancel",
  "onpointerdown",
  "onpointerenter",
  "onpointerleave",
  "onpointermove",
  "onpointerout",
  "onpointerover",
  "onpointerup",
  "onprogress",
  "onratechange",
  "onreset",
  "onresize",
  "onscroll",
  "onscrollend",
  "onsecuritypolicyviolation",
  "onseeked",
  "onseeking",
  "onselect",
  "onselectionchange",
  "onselectstart",
  "onslotchange",
  "onstalled",
  "onsubmit",
  "onsuspend",
  "ontimeupdate",
  "ontoggle",
  "ontouchcancel",
  "ontouchend",
  "ontouchmove",
  "ontouchstart",
  "ontransitioncancel",
  "ontransitionend",
  "ontransitionrun",
  "ontransitionstart",
  "onvolumechange",
  "onwaiting",
  "onwebkitanimationend",
  "onwebkitanimationiteration",
  "onwebkitanimationstart",
  "onwebkittransitionend",
  "onwheel"
];
const EVENT_LIST_SET$1 = new Set(EVENT_LIST$1);
function isEventHandler$1(key) {
  return EVENT_LIST_SET$1.has(key);
}
function mergeProps$1(...args) {
  const result = { ...args[0] };
  for (let i = 1; i < args.length; i++) {
    const props = args[i];
    if (!props)
      continue;
    for (const key of Object.keys(props)) {
      const a = result[key];
      const b = props[key];
      const aIsFunction = typeof a === "function";
      const bIsFunction = typeof b === "function";
      if (aIsFunction && typeof bIsFunction && isEventHandler$1(key)) {
        const aHandler = a;
        const bHandler = b;
        result[key] = composeHandlers$1(aHandler, bHandler);
      } else if (aIsFunction && bIsFunction) {
        result[key] = executeCallbacks$1(a, b);
      } else if (key === "class") {
        const aIsClassValue = isClassValue$1(a);
        const bIsClassValue = isClassValue$1(b);
        if (aIsClassValue && bIsClassValue) {
          result[key] = clsx(a, b);
        } else if (aIsClassValue) {
          result[key] = clsx(a);
        } else if (bIsClassValue) {
          result[key] = clsx(b);
        }
      } else if (key === "style") {
        const aIsObject = typeof a === "object";
        const bIsObject = typeof b === "object";
        const aIsString = typeof a === "string";
        const bIsString = typeof b === "string";
        if (aIsObject && bIsObject) {
          result[key] = { ...a, ...b };
        } else if (aIsObject && bIsString) {
          const parsedStyle = cssToStyleObj$1(b);
          result[key] = { ...a, ...parsedStyle };
        } else if (aIsString && bIsObject) {
          const parsedStyle = cssToStyleObj$1(a);
          result[key] = { ...parsedStyle, ...b };
        } else if (aIsString && bIsString) {
          const parsedStyleA = cssToStyleObj$1(a);
          const parsedStyleB = cssToStyleObj$1(b);
          result[key] = { ...parsedStyleA, ...parsedStyleB };
        } else if (aIsObject) {
          result[key] = a;
        } else if (bIsObject) {
          result[key] = b;
        } else if (aIsString) {
          result[key] = a;
        } else if (bIsString) {
          result[key] = b;
        }
      } else {
        result[key] = b !== void 0 ? b : a;
      }
    }
    for (const key of Object.getOwnPropertySymbols(props)) {
      const a = result[key];
      const b = props[key];
      result[key] = b !== void 0 ? b : a;
    }
  }
  if (typeof result.style === "object") {
    result.style = styleToString$1(result.style).replaceAll("\n", " ");
  }
  if (result.hidden === false) {
    result.hidden = void 0;
    delete result.hidden;
  }
  if (result.disabled === false) {
    result.disabled = void 0;
    delete result.disabled;
  }
  return result;
}
function afterSleep(ms, cb) {
  return setTimeout(cb, ms);
}
function isFunction$1(value) {
  return typeof value === "function";
}
function get$2(value) {
  if (isFunction$1(value)) {
    return value();
  }
  return value;
}
class ElementSize {
  // no need to use `$state` here since we are using createSubscriber
  #size = { width: 0, height: 0 };
  #observed = false;
  #options;
  #node;
  #window;
  // we use a derived here to extract the width so that if the width doesn't change we don't get a state update
  // which we would get if we would just use a getter since the version of the subscriber will be changing
  #width = derived(() => {
    this.#subscribe()?.();
    return this.getSize().width;
  });
  // we use a derived here to extract the height so that if the height doesn't change we don't get a state update
  // which we would get if we would just use a getter since the version of the subscriber will be changing
  #height = derived(() => {
    this.#subscribe()?.();
    return this.getSize().height;
  });
  // we need to use a derived here because the class will be created before the node is bound to the ref
  #subscribe = derived(() => {
    const node$ = get$2(this.#node);
    if (!node$) return;
    return createSubscriber();
  });
  constructor(node, options = { box: "border-box" }) {
    this.#window = options.window ?? defaultWindow$3;
    this.#options = options;
    this.#node = node;
    this.#size = { width: 0, height: 0 };
  }
  calculateSize() {
    const element2 = get$2(this.#node);
    if (!element2 || !this.#window) {
      return;
    }
    const offsetWidth = element2.offsetWidth;
    const offsetHeight = element2.offsetHeight;
    if (this.#options.box === "border-box") {
      return { width: offsetWidth, height: offsetHeight };
    }
    const style = this.#window.getComputedStyle(element2);
    const paddingWidth = parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
    const paddingHeight = parseFloat(style.paddingTop) + parseFloat(style.paddingBottom);
    const borderWidth = parseFloat(style.borderLeftWidth) + parseFloat(style.borderRightWidth);
    const borderHeight = parseFloat(style.borderTopWidth) + parseFloat(style.borderBottomWidth);
    const contentWidth = offsetWidth - paddingWidth - borderWidth;
    const contentHeight = offsetHeight - paddingHeight - borderHeight;
    return { width: contentWidth, height: contentHeight };
  }
  getSize() {
    return this.#observed ? this.#size : this.calculateSize() ?? this.#size;
  }
  get current() {
    this.#subscribe()?.();
    return this.getSize();
  }
  get width() {
    return this.#width();
  }
  get height() {
    return this.#height();
  }
}
const ARROW_DOWN = "ArrowDown";
const ARROW_LEFT = "ArrowLeft";
const ARROW_RIGHT = "ArrowRight";
const ARROW_UP = "ArrowUp";
const END = "End";
const ENTER = "Enter";
const ESCAPE = "Escape";
const HOME = "Home";
const PAGE_DOWN = "PageDown";
const PAGE_UP = "PageUp";
const SPACE = " ";
const TAB = "Tab";
function getElemDirection(elem) {
  const style = window.getComputedStyle(elem);
  const direction = style.getPropertyValue("direction");
  return direction;
}
function getNextKey(dir = "ltr", orientation = "horizontal") {
  return {
    horizontal: dir === "rtl" ? ARROW_LEFT : ARROW_RIGHT,
    vertical: ARROW_DOWN
  }[orientation];
}
function getPrevKey(dir = "ltr", orientation = "horizontal") {
  return {
    horizontal: dir === "rtl" ? ARROW_RIGHT : ARROW_LEFT,
    vertical: ARROW_UP
  }[orientation];
}
function getDirectionalKeys(dir = "ltr", orientation = "horizontal") {
  if (!["ltr", "rtl"].includes(dir))
    dir = "ltr";
  if (!["horizontal", "vertical"].includes(orientation))
    orientation = "horizontal";
  return {
    nextKey: getNextKey(dir, orientation),
    prevKey: getPrevKey(dir, orientation)
  };
}
class RovingFocusGroup {
  #opts;
  #currentTabStopId = box$1(null);
  constructor(opts) {
    this.#opts = opts;
  }
  getCandidateNodes() {
    return [];
  }
  focusFirstCandidate() {
    const items = this.getCandidateNodes();
    if (!items.length)
      return;
    items[0]?.focus();
  }
  handleKeydown(node, e, both = false) {
    const rootNode = this.#opts.rootNode.current;
    if (!rootNode || !node)
      return;
    const items = this.getCandidateNodes();
    if (!items.length)
      return;
    const currentIndex = items.indexOf(node);
    const dir = getElemDirection(rootNode);
    const { nextKey, prevKey } = getDirectionalKeys(dir, this.#opts.orientation.current);
    const loop = this.#opts.loop.current;
    const keyToIndex = {
      [nextKey]: currentIndex + 1,
      [prevKey]: currentIndex - 1,
      [HOME]: 0,
      [END]: items.length - 1
    };
    if (both) {
      const altNextKey = nextKey === ARROW_DOWN ? ARROW_RIGHT : ARROW_DOWN;
      const altPrevKey = prevKey === ARROW_UP ? ARROW_LEFT : ARROW_UP;
      keyToIndex[altNextKey] = currentIndex + 1;
      keyToIndex[altPrevKey] = currentIndex - 1;
    }
    let itemIndex = keyToIndex[e.key];
    if (itemIndex === void 0)
      return;
    e.preventDefault();
    if (itemIndex < 0 && loop) {
      itemIndex = items.length - 1;
    } else if (itemIndex === items.length && loop) {
      itemIndex = 0;
    }
    const itemToFocus = items[itemIndex];
    if (!itemToFocus)
      return;
    itemToFocus.focus();
    this.#currentTabStopId.current = itemToFocus.id;
    this.#opts.onCandidateFocus?.(itemToFocus);
    return itemToFocus;
  }
  getTabIndex(node) {
    const items = this.getCandidateNodes();
    const anyActive = this.#currentTabStopId.current !== null;
    if (node && !anyActive && items[0] === node) {
      this.#currentTabStopId.current = node.id;
      return 0;
    } else if (node?.id === this.#currentTabStopId.current) {
      return 0;
    }
    return -1;
  }
  setCurrentTabStopId(id) {
    this.#currentTabStopId.current = id;
  }
  focusCurrentTabStop() {
    const currentTabStopId = this.#currentTabStopId.current;
    if (!currentTabStopId)
      return;
    const currentTabStop = this.#opts.rootNode.current?.querySelector(`#${currentTabStopId}`);
    if (!currentTabStop || !isHTMLElement$1(currentTabStop))
      return;
    currentTabStop.focus();
  }
}
function noop$1() {
}
function createId(prefixOrUid, uid) {
  return `bits-${prefixOrUid}`;
}
const BitsConfigContext = new Context$1("BitsConfig");
function getBitsConfig() {
  const fallback = new BitsConfigState(null, {});
  return BitsConfigContext.getOr(fallback).opts;
}
class BitsConfigState {
  opts;
  constructor(parent, opts) {
    const resolveConfigOption = createConfigResolver(parent, opts);
    this.opts = {
      defaultPortalTo: resolveConfigOption((config) => config.defaultPortalTo),
      defaultLocale: resolveConfigOption((config) => config.defaultLocale)
    };
  }
}
function createConfigResolver(parent, currentOpts) {
  return (getter) => {
    const configOption = boxWith$1(() => {
      const value = getter(currentOpts)?.current;
      if (value !== void 0)
        return value;
      if (parent === null)
        return void 0;
      return getter(parent.opts)?.current;
    });
    return configOption;
  };
}
function createPropResolver(configOption, fallback) {
  return (getProp) => {
    const config = getBitsConfig();
    return boxWith$1(() => {
      const propValue = getProp();
      if (propValue !== void 0)
        return propValue;
      const option = configOption(config).current;
      if (option !== void 0)
        return option;
      return fallback;
    });
  };
}
const resolvePortalToProp = createPropResolver((config) => config.defaultPortalTo, "body");
function Portal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { to: toProp, children, disabled } = $$props;
    const to = resolvePortalToProp(() => toProp);
    getAllContexts();
    let target = getTarget();
    function getTarget() {
      if (!isBrowser$1 || disabled) return null;
      let localTarget = null;
      if (typeof to.current === "string") {
        const target2 = document.querySelector(to.current);
        localTarget = target2;
      } else {
        localTarget = to.current;
      }
      return localTarget;
    }
    let instance;
    function unmountInstance() {
      if (instance) {
        unmount();
        instance = null;
      }
    }
    watch$2([() => target, () => disabled], ([target2, disabled2]) => {
      if (!target2 || disabled2) {
        unmountInstance();
        return;
      }
      instance = mount();
      return () => {
        unmountInstance();
      };
    });
    if (disabled) {
      $$renderer2.push("<!--[-->");
      children?.($$renderer2);
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
class CustomEventDispatcher {
  eventName;
  options;
  constructor(eventName, options = { bubbles: true, cancelable: true }) {
    this.eventName = eventName;
    this.options = options;
  }
  createEvent(detail) {
    return new CustomEvent(this.eventName, {
      ...this.options,
      detail
    });
  }
  dispatch(element2, detail) {
    const event = this.createEvent(detail);
    element2.dispatchEvent(event);
    return event;
  }
  listen(element2, callback, options) {
    const handler = (event) => {
      callback(event);
    };
    return on(element2, this.eventName, handler, options);
  }
}
function debounce$1(fn, wait = 500) {
  let timeout = null;
  const debounced = (...args) => {
    if (timeout !== null) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(() => {
      fn(...args);
    }, wait);
  };
  debounced.destroy = () => {
    if (timeout !== null) {
      clearTimeout(timeout);
      timeout = null;
    }
  };
  return debounced;
}
function isOrContainsTarget(node, target) {
  return node === target || node.contains(target);
}
function getOwnerDocument(el) {
  return el?.ownerDocument ?? document;
}
function isClickTrulyOutside(event, contentNode) {
  const { clientX, clientY } = event;
  const rect = contentNode.getBoundingClientRect();
  return clientX < rect.left || clientX > rect.right || clientY < rect.top || clientY > rect.bottom;
}
const SELECTION_KEYS = [ENTER, SPACE];
const FIRST_KEYS = [ARROW_DOWN, PAGE_UP, HOME];
const LAST_KEYS = [ARROW_UP, PAGE_DOWN, END];
const FIRST_LAST_KEYS = [...FIRST_KEYS, ...LAST_KEYS];
const SUB_OPEN_KEYS = {
  ltr: [...SELECTION_KEYS, ARROW_RIGHT],
  rtl: [...SELECTION_KEYS, ARROW_LEFT]
};
const SUB_CLOSE_KEYS = {
  ltr: [ARROW_LEFT],
  rtl: [ARROW_RIGHT]
};
function isIndeterminate(checked) {
  return checked === "indeterminate";
}
function getCheckedState(checked) {
  return isIndeterminate(checked) ? "indeterminate" : checked ? "checked" : "unchecked";
}
function isMouseEvent$1(event) {
  return event.pointerType === "mouse";
}
function focus(element2, { select = false } = {}) {
  if (!element2 || !element2.focus)
    return;
  const doc = getDocument$1(element2);
  if (doc.activeElement === element2)
    return;
  const previouslyFocusedElement = doc.activeElement;
  element2.focus({ preventScroll: true });
  if (element2 !== previouslyFocusedElement && isSelectableInput(element2) && select) {
    element2.select();
  }
}
function focusFirst(candidates, { select = false } = {}, getActiveElement2) {
  const previouslyFocusedElement = getActiveElement2();
  for (const candidate of candidates) {
    focus(candidate, { select });
    if (getActiveElement2() !== previouslyFocusedElement)
      return true;
  }
}
let isUsingKeyboard = false;
class IsUsingKeyboard {
  static _refs = 0;
  // Reference counting to avoid multiple listeners.
  static _cleanup;
  constructor() {
  }
  get current() {
    return isUsingKeyboard;
  }
  set current(value) {
    isUsingKeyboard = value;
  }
}
function getTabbableOptions() {
  return {
    getShadowRoot: true,
    displayCheck: (
      // JSDOM does not support the `tabbable` library. To solve this we can
      // check if `ResizeObserver` is a real function (not polyfilled), which
      // determines if the current environment is JSDOM-like.
      typeof ResizeObserver === "function" && ResizeObserver.toString().includes("[native code]") ? "full" : "none"
    )
  };
}
function getTabbableFrom(currentNode, direction) {
  if (!isTabbable(currentNode, getTabbableOptions())) {
    return getTabbableFromFocusable(currentNode, direction);
  }
  const doc = getDocument$1(currentNode);
  const allTabbable = tabbable(doc.body, getTabbableOptions());
  if (direction === "prev")
    allTabbable.reverse();
  const activeIndex = allTabbable.indexOf(currentNode);
  if (activeIndex === -1)
    return doc.body;
  const nextTabbableElements = allTabbable.slice(activeIndex + 1);
  return nextTabbableElements[0];
}
function getTabbableFromFocusable(currentNode, direction) {
  const doc = getDocument$1(currentNode);
  if (!isFocusable(currentNode, getTabbableOptions()))
    return doc.body;
  const allFocusable = focusable(doc.body, getTabbableOptions());
  if (direction === "prev")
    allFocusable.reverse();
  const activeIndex = allFocusable.indexOf(currentNode);
  if (activeIndex === -1)
    return doc.body;
  const nextFocusableElements = allFocusable.slice(activeIndex + 1);
  return nextFocusableElements.find((node) => isTabbable(node, getTabbableOptions())) ?? doc.body;
}
function getNextMatch(values, search, currentMatch) {
  const lowerSearch = search.toLowerCase();
  if (lowerSearch.endsWith(" ")) {
    const searchWithoutSpace = lowerSearch.slice(0, -1);
    const matchesWithoutSpace = values.filter((value) => value.toLowerCase().startsWith(searchWithoutSpace));
    if (matchesWithoutSpace.length <= 1) {
      return getNextMatch(values, searchWithoutSpace, currentMatch);
    }
    const currentMatchLowercase = currentMatch?.toLowerCase();
    if (currentMatchLowercase && currentMatchLowercase.startsWith(searchWithoutSpace) && currentMatchLowercase.charAt(searchWithoutSpace.length) === " " && search.trim() === searchWithoutSpace) {
      return currentMatch;
    }
    const spacedMatches = values.filter((value) => value.toLowerCase().startsWith(lowerSearch));
    if (spacedMatches.length > 0) {
      const currentMatchIndex2 = currentMatch ? values.indexOf(currentMatch) : -1;
      let wrappedMatches = wrapArray(spacedMatches, Math.max(currentMatchIndex2, 0));
      const nextMatch2 = wrappedMatches.find((match) => match !== currentMatch);
      return nextMatch2 || currentMatch;
    }
  }
  const isRepeated = search.length > 1 && Array.from(search).every((char) => char === search[0]);
  const normalizedSearch = isRepeated ? search[0] : search;
  const normalizedLowerSearch = normalizedSearch.toLowerCase();
  const currentMatchIndex = currentMatch ? values.indexOf(currentMatch) : -1;
  let wrappedValues = wrapArray(values, Math.max(currentMatchIndex, 0));
  const excludeCurrentMatch = normalizedSearch.length === 1;
  if (excludeCurrentMatch)
    wrappedValues = wrappedValues.filter((v) => v !== currentMatch);
  const nextMatch = wrappedValues.find((value) => value?.toLowerCase().startsWith(normalizedLowerSearch));
  return nextMatch !== currentMatch ? nextMatch : void 0;
}
function wrapArray(array, startIndex) {
  return array.map((_, index) => array[(startIndex + index) % array.length]);
}
const defaultOptions = { afterMs: 1e4, onChange: noop$1 };
function boxAutoReset(defaultValue, options) {
  const { afterMs, onChange, getWindow: getWindow2 } = { ...defaultOptions, ...options };
  let timeout = null;
  let value = defaultValue;
  function resetAfter() {
    return getWindow2().setTimeout(
      () => {
        value = defaultValue;
        onChange?.(defaultValue);
      },
      afterMs
    );
  }
  return boxWith$1(() => value, (v) => {
    value = v;
    onChange?.(v);
    if (timeout) getWindow2().clearTimeout(timeout);
    timeout = resetAfter();
  });
}
class DOMTypeahead {
  #opts;
  #search;
  #onMatch = derived(() => {
    if (this.#opts.onMatch) return this.#opts.onMatch;
    return (node) => node.focus();
  });
  #getCurrentItem = derived(() => {
    if (this.#opts.getCurrentItem) return this.#opts.getCurrentItem;
    return this.#opts.getActiveElement;
  });
  constructor(opts) {
    this.#opts = opts;
    this.#search = boxAutoReset("", { afterMs: 1e3, getWindow: opts.getWindow });
    this.handleTypeaheadSearch = this.handleTypeaheadSearch.bind(this);
    this.resetTypeahead = this.resetTypeahead.bind(this);
  }
  handleTypeaheadSearch(key, candidates) {
    if (!candidates.length) return;
    this.#search.current = this.#search.current + key;
    const currentItem = this.#getCurrentItem()();
    const currentMatch = candidates.find((item) => item === currentItem)?.textContent?.trim() ?? "";
    const values = candidates.map((item) => item.textContent?.trim() ?? "");
    const nextMatch = getNextMatch(values, this.#search.current, currentMatch);
    const newItem = candidates.find((item) => item.textContent?.trim() === nextMatch);
    if (newItem) this.#onMatch()(newItem);
    return newItem;
  }
  resetTypeahead() {
    this.#search.current = "";
  }
  get search() {
    return this.#search.current;
  }
}
class GraceArea {
  #opts;
  #enabled;
  #isPointerInTransit;
  #pointerGraceArea = null;
  constructor(opts) {
    this.#opts = opts;
    this.#enabled = derived(() => this.#opts.enabled());
    this.#isPointerInTransit = boxAutoReset(false, {
      afterMs: opts.transitTimeout ?? 300,
      onChange: (value) => {
        if (!this.#enabled()) return;
        this.#opts.setIsPointerInTransit?.(value);
      },
      getWindow: () => getWindow(this.#opts.triggerNode())
    });
    watch$2([opts.triggerNode, opts.contentNode, opts.enabled], ([triggerNode, contentNode, enabled]) => {
      if (!triggerNode || !contentNode || !enabled) return;
      const handleTriggerLeave = (e) => {
        this.#createGraceArea(e, contentNode);
      };
      const handleContentLeave = (e) => {
        this.#createGraceArea(e, triggerNode);
      };
      return executeCallbacks$1(on(triggerNode, "pointerleave", handleTriggerLeave), on(contentNode, "pointerleave", handleContentLeave));
    });
    watch$2(() => this.#pointerGraceArea, () => {
      const handleTrackPointerGrace = (e) => {
        if (!this.#pointerGraceArea) return;
        const target = e.target;
        if (!isElement(target)) return;
        const pointerPosition = { x: e.clientX, y: e.clientY };
        const hasEnteredTarget = opts.triggerNode()?.contains(target) || opts.contentNode()?.contains(target);
        const isPointerOutsideGraceArea = !isPointInPolygon(pointerPosition, this.#pointerGraceArea);
        if (hasEnteredTarget) {
          this.#removeGraceArea();
        } else if (isPointerOutsideGraceArea) {
          this.#removeGraceArea();
          opts.onPointerExit();
        }
      };
      const doc = getDocument$1(opts.triggerNode() ?? opts.contentNode());
      if (!doc) return;
      return on(doc, "pointermove", handleTrackPointerGrace);
    });
  }
  #removeGraceArea() {
    this.#pointerGraceArea = null;
    this.#isPointerInTransit.current = false;
  }
  #createGraceArea(e, hoverTarget) {
    const currentTarget = e.currentTarget;
    if (!isHTMLElement$1(currentTarget)) return;
    const exitPoint = { x: e.clientX, y: e.clientY };
    const exitSide = getExitSideFromRect(exitPoint, currentTarget.getBoundingClientRect());
    const paddedExitPoints = getPaddedExitPoints(exitPoint, exitSide);
    const hoverTargetPoints = getPointsFromRect(hoverTarget.getBoundingClientRect());
    const graceArea = getHull([...paddedExitPoints, ...hoverTargetPoints]);
    this.#pointerGraceArea = graceArea;
    this.#isPointerInTransit.current = true;
  }
}
function getExitSideFromRect(point, rect) {
  const top = Math.abs(rect.top - point.y);
  const bottom = Math.abs(rect.bottom - point.y);
  const right = Math.abs(rect.right - point.x);
  const left = Math.abs(rect.left - point.x);
  switch (Math.min(top, bottom, right, left)) {
    case left:
      return "left";
    case right:
      return "right";
    case top:
      return "top";
    case bottom:
      return "bottom";
    default:
      throw new Error("unreachable");
  }
}
function getPaddedExitPoints(exitPoint, exitSide, padding = 5) {
  const tipPadding = padding * 1.5;
  switch (exitSide) {
    case "top":
      return [
        { x: exitPoint.x - padding, y: exitPoint.y + padding },
        { x: exitPoint.x, y: exitPoint.y - tipPadding },
        { x: exitPoint.x + padding, y: exitPoint.y + padding }
      ];
    case "bottom":
      return [
        { x: exitPoint.x - padding, y: exitPoint.y - padding },
        { x: exitPoint.x, y: exitPoint.y + tipPadding },
        { x: exitPoint.x + padding, y: exitPoint.y - padding }
      ];
    case "left":
      return [
        { x: exitPoint.x + padding, y: exitPoint.y - padding },
        { x: exitPoint.x - tipPadding, y: exitPoint.y },
        { x: exitPoint.x + padding, y: exitPoint.y + padding }
      ];
    case "right":
      return [
        { x: exitPoint.x - padding, y: exitPoint.y - padding },
        { x: exitPoint.x + tipPadding, y: exitPoint.y },
        { x: exitPoint.x - padding, y: exitPoint.y + padding }
      ];
  }
}
function getPointsFromRect(rect) {
  const { top, right, bottom, left } = rect;
  return [
    { x: left, y: top },
    { x: right, y: top },
    { x: right, y: bottom },
    { x: left, y: bottom }
  ];
}
function isPointInPolygon(point, polygon) {
  const { x, y } = point;
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].x;
    const yi = polygon[i].y;
    const xj = polygon[j].x;
    const yj = polygon[j].y;
    const intersect = yi > y !== yj > y && x < (xj - xi) * (y - yi) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}
function getHull(points) {
  const newPoints = points.slice();
  newPoints.sort((a, b) => {
    if (a.x < b.x) return -1;
    else if (a.x > b.x) return 1;
    else if (a.y < b.y) return -1;
    else if (a.y > b.y) return 1;
    else return 0;
  });
  return getHullPresorted(newPoints);
}
function getHullPresorted(points) {
  if (points.length <= 1) return points.slice();
  const upperHull = [];
  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    while (upperHull.length >= 2) {
      const q = upperHull[upperHull.length - 1];
      const r = upperHull[upperHull.length - 2];
      if ((q.x - r.x) * (p.y - r.y) >= (q.y - r.y) * (p.x - r.x)) upperHull.pop();
      else break;
    }
    upperHull.push(p);
  }
  upperHull.pop();
  const lowerHull = [];
  for (let i = points.length - 1; i >= 0; i--) {
    const p = points[i];
    while (lowerHull.length >= 2) {
      const q = lowerHull[lowerHull.length - 1];
      const r = lowerHull[lowerHull.length - 2];
      if ((q.x - r.x) * (p.y - r.y) >= (q.y - r.y) * (p.x - r.x)) lowerHull.pop();
      else break;
    }
    lowerHull.push(p);
  }
  lowerHull.pop();
  if (upperHull.length === 1 && lowerHull.length === 1 && upperHull[0].x === lowerHull[0].x && upperHull[0].y === lowerHull[0].y) return upperHull;
  else return upperHull.concat(lowerHull);
}
const CONTEXT_MENU_TRIGGER_ATTR = "data-context-menu-trigger";
const CONTEXT_MENU_CONTENT_ATTR = "data-context-menu-content";
const MenuRootContext = new Context$1("Menu.Root");
const MenuMenuContext = new Context$1("Menu.Root | Menu.Sub");
const MenuContentContext = new Context$1("Menu.Content");
const MenuGroupContext = new Context$1("Menu.Group | Menu.RadioGroup");
const MenuRadioGroupContext = new Context$1("Menu.RadioGroup");
const MenuOpenEvent = new CustomEventDispatcher("bitsmenuopen", { bubbles: false, cancelable: true });
const menuAttrs = createBitsAttrs({
  component: "menu",
  parts: [
    "trigger",
    "content",
    "sub-trigger",
    "item",
    "group",
    "group-heading",
    "checkbox-group",
    "checkbox-item",
    "radio-group",
    "radio-item",
    "separator",
    "sub-content",
    "arrow"
  ]
});
class MenuRootState {
  static create(opts) {
    const root = new MenuRootState(opts);
    return MenuRootContext.set(root);
  }
  opts;
  isUsingKeyboard = new IsUsingKeyboard();
  ignoreCloseAutoFocus = false;
  isPointerInTransit = false;
  constructor(opts) {
    this.opts = opts;
  }
  getBitsAttr = (part) => {
    return menuAttrs.getAttr(part, this.opts.variant.current);
  };
}
class MenuMenuState {
  static create(opts, root) {
    return MenuMenuContext.set(new MenuMenuState(opts, root, null));
  }
  opts;
  root;
  parentMenu;
  contentId = boxWith$1(() => "");
  contentNode = null;
  contentPresence;
  triggerNode = null;
  constructor(opts, root, parentMenu) {
    this.opts = opts;
    this.root = root;
    this.parentMenu = parentMenu;
    this.contentPresence = new PresenceManager({
      ref: boxWith$1(() => this.contentNode),
      open: this.opts.open,
      onComplete: () => {
        this.opts.onOpenChangeComplete.current(this.opts.open.current);
      }
    });
    if (parentMenu) {
      watch$2(() => parentMenu.opts.open.current, () => {
        if (parentMenu.opts.open.current) return;
        this.opts.open.current = false;
      });
    }
  }
  toggleOpen() {
    this.opts.open.current = !this.opts.open.current;
  }
  onOpen() {
    this.opts.open.current = true;
  }
  onClose() {
    this.opts.open.current = false;
  }
}
class MenuContentState {
  static create(opts) {
    return MenuContentContext.set(new MenuContentState(opts, MenuMenuContext.get()));
  }
  opts;
  parentMenu;
  rovingFocusGroup;
  domContext;
  attachment;
  search = "";
  #timer = 0;
  #handleTypeaheadSearch;
  mounted = false;
  #isSub;
  constructor(opts, parentMenu) {
    this.opts = opts;
    this.parentMenu = parentMenu;
    this.domContext = new DOMContext$1(opts.ref);
    this.attachment = attachRef$1(this.opts.ref, (v) => {
      if (this.parentMenu.contentNode !== v) {
        this.parentMenu.contentNode = v;
      }
    });
    parentMenu.contentId = opts.id;
    this.#isSub = opts.isSub ?? false;
    this.onkeydown = this.onkeydown.bind(this);
    this.onblur = this.onblur.bind(this);
    this.onfocus = this.onfocus.bind(this);
    this.handleInteractOutside = this.handleInteractOutside.bind(this);
    new GraceArea({
      contentNode: () => this.parentMenu.contentNode,
      triggerNode: () => this.parentMenu.triggerNode,
      enabled: () => this.parentMenu.opts.open.current && Boolean(this.parentMenu.triggerNode?.hasAttribute(this.parentMenu.root.getBitsAttr("sub-trigger"))),
      onPointerExit: () => {
        this.parentMenu.opts.open.current = false;
      },
      setIsPointerInTransit: (value) => {
        this.parentMenu.root.isPointerInTransit = value;
      }
    });
    this.#handleTypeaheadSearch = new DOMTypeahead({
      getActiveElement: () => this.domContext.getActiveElement(),
      getWindow: () => this.domContext.getWindow()
    }).handleTypeaheadSearch;
    this.rovingFocusGroup = new RovingFocusGroup({
      rootNode: boxWith$1(() => this.parentMenu.contentNode),
      candidateAttr: this.parentMenu.root.getBitsAttr("item"),
      loop: this.opts.loop,
      orientation: boxWith$1(() => "vertical")
    });
    watch$2(() => this.parentMenu.contentNode, (contentNode) => {
      if (!contentNode) return;
      const handler = () => {
        afterTick$1(() => {
          if (!this.parentMenu.root.isUsingKeyboard.current) return;
          this.rovingFocusGroup.focusFirstCandidate();
        });
      };
      return MenuOpenEvent.listen(contentNode, handler);
    });
  }
  #getCandidateNodes() {
    const node = this.parentMenu.contentNode;
    if (!node) return [];
    const candidates = Array.from(node.querySelectorAll(`[${this.parentMenu.root.getBitsAttr("item")}]:not([data-disabled])`));
    return candidates;
  }
  #isPointerMovingToSubmenu() {
    return this.parentMenu.root.isPointerInTransit;
  }
  onCloseAutoFocus = (e) => {
    this.opts.onCloseAutoFocus.current?.(e);
    if (e.defaultPrevented || this.#isSub) return;
    if (this.parentMenu.triggerNode && isTabbable(this.parentMenu.triggerNode)) {
      e.preventDefault();
      this.parentMenu.triggerNode.focus();
    }
  };
  handleTabKeyDown(e) {
    let rootMenu = this.parentMenu;
    while (rootMenu.parentMenu !== null) {
      rootMenu = rootMenu.parentMenu;
    }
    if (!rootMenu.triggerNode) return;
    e.preventDefault();
    const nodeToFocus = getTabbableFrom(rootMenu.triggerNode, e.shiftKey ? "prev" : "next");
    if (nodeToFocus) {
      this.parentMenu.root.ignoreCloseAutoFocus = true;
      rootMenu.onClose();
      afterTick$1(() => {
        nodeToFocus.focus();
        afterTick$1(() => {
          this.parentMenu.root.ignoreCloseAutoFocus = false;
        });
      });
    } else {
      this.domContext.getDocument().body.focus();
    }
  }
  onkeydown(e) {
    if (e.defaultPrevented) return;
    if (e.key === TAB) {
      this.handleTabKeyDown(e);
      return;
    }
    const target = e.target;
    const currentTarget = e.currentTarget;
    if (!isHTMLElement$1(target) || !isHTMLElement$1(currentTarget)) return;
    const isKeydownInside = target.closest(`[${this.parentMenu.root.getBitsAttr("content")}]`)?.id === this.parentMenu.contentId.current;
    const isModifierKey = e.ctrlKey || e.altKey || e.metaKey;
    const isCharacterKey = e.key.length === 1;
    const kbdFocusedEl = this.rovingFocusGroup.handleKeydown(target, e);
    if (kbdFocusedEl) return;
    if (e.code === "Space") return;
    const candidateNodes = this.#getCandidateNodes();
    if (isKeydownInside) {
      if (!isModifierKey && isCharacterKey) {
        this.#handleTypeaheadSearch(e.key, candidateNodes);
      }
    }
    if (e.target?.id !== this.parentMenu.contentId.current) return;
    if (!FIRST_LAST_KEYS.includes(e.key)) return;
    e.preventDefault();
    if (LAST_KEYS.includes(e.key)) {
      candidateNodes.reverse();
    }
    focusFirst(candidateNodes, { select: false }, () => this.domContext.getActiveElement());
  }
  onblur(e) {
    if (!isElement(e.currentTarget)) return;
    if (!isElement(e.target)) return;
    if (!e.currentTarget.contains?.(e.target)) {
      this.domContext.getWindow().clearTimeout(this.#timer);
      this.search = "";
    }
  }
  onfocus(_) {
    if (!this.parentMenu.root.isUsingKeyboard.current) return;
    afterTick$1(() => this.rovingFocusGroup.focusFirstCandidate());
  }
  onItemEnter() {
    return this.#isPointerMovingToSubmenu();
  }
  onItemLeave(e) {
    if (e.currentTarget.hasAttribute(this.parentMenu.root.getBitsAttr("sub-trigger"))) return;
    if (this.#isPointerMovingToSubmenu() || this.parentMenu.root.isUsingKeyboard.current) return;
    const contentNode = this.parentMenu.contentNode;
    contentNode?.focus();
    this.rovingFocusGroup.setCurrentTabStopId("");
  }
  onTriggerLeave() {
    if (this.#isPointerMovingToSubmenu()) return true;
    return false;
  }
  handleInteractOutside(e) {
    if (!isElementOrSVGElement(e.target)) return;
    const triggerId = this.parentMenu.triggerNode?.id;
    if (e.target.id === triggerId) {
      e.preventDefault();
      return;
    }
    if (e.target.closest(`#${triggerId}`)) {
      e.preventDefault();
    }
  }
  get shouldRender() {
    return this.parentMenu.contentPresence.shouldRender;
  }
  #snippetProps = derived(() => ({ open: this.parentMenu.opts.open.current }));
  get snippetProps() {
    return this.#snippetProps();
  }
  set snippetProps($$value) {
    return this.#snippetProps($$value);
  }
  #props = derived(() => ({
    id: this.opts.id.current,
    role: "menu",
    "aria-orientation": "vertical",
    [this.parentMenu.root.getBitsAttr("content")]: "",
    "data-state": getDataOpenClosed(this.parentMenu.opts.open.current),
    onkeydown: this.onkeydown,
    onblur: this.onblur,
    onfocus: this.onfocus,
    dir: this.parentMenu.root.opts.dir.current,
    style: { pointerEvents: "auto", contain: "layout style paint" },
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
  popperProps = { onCloseAutoFocus: (e) => this.onCloseAutoFocus(e) };
}
class MenuItemSharedState {
  opts;
  content;
  attachment;
  #isFocused = false;
  constructor(opts, content) {
    this.opts = opts;
    this.content = content;
    this.attachment = attachRef$1(this.opts.ref);
    this.onpointermove = this.onpointermove.bind(this);
    this.onpointerleave = this.onpointerleave.bind(this);
    this.onfocus = this.onfocus.bind(this);
    this.onblur = this.onblur.bind(this);
  }
  onpointermove(e) {
    if (e.defaultPrevented) return;
    if (!isMouseEvent$1(e)) return;
    if (this.opts.disabled.current) {
      this.content.onItemLeave(e);
    } else {
      const defaultPrevented = this.content.onItemEnter();
      if (defaultPrevented) return;
      const item = e.currentTarget;
      if (!isHTMLElement$1(item)) return;
      item.focus();
    }
  }
  onpointerleave(e) {
    if (e.defaultPrevented) return;
    if (!isMouseEvent$1(e)) return;
    this.content.onItemLeave(e);
  }
  onfocus(e) {
    afterTick$1(() => {
      if (e.defaultPrevented || this.opts.disabled.current) return;
      this.#isFocused = true;
    });
  }
  onblur(e) {
    afterTick$1(() => {
      if (e.defaultPrevented) return;
      this.#isFocused = false;
    });
  }
  #props = derived(() => ({
    id: this.opts.id.current,
    tabindex: -1,
    role: "menuitem",
    "aria-disabled": boolToStr(this.opts.disabled.current),
    "data-disabled": boolToEmptyStrOrUndef(this.opts.disabled.current),
    "data-highlighted": this.#isFocused ? "" : void 0,
    [this.content.parentMenu.root.getBitsAttr("item")]: "",
    //
    onpointermove: this.onpointermove,
    onpointerleave: this.onpointerleave,
    onfocus: this.onfocus,
    onblur: this.onblur,
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class MenuItemState {
  static create(opts) {
    const item = new MenuItemSharedState(opts, MenuContentContext.get());
    return new MenuItemState(opts, item);
  }
  opts;
  item;
  root;
  #isPointerDown = false;
  constructor(opts, item) {
    this.opts = opts;
    this.item = item;
    this.root = item.content.parentMenu.root;
    this.onkeydown = this.onkeydown.bind(this);
    this.onclick = this.onclick.bind(this);
    this.onpointerdown = this.onpointerdown.bind(this);
    this.onpointerup = this.onpointerup.bind(this);
  }
  #handleSelect() {
    if (this.item.opts.disabled.current) return;
    const selectEvent = new CustomEvent("menuitemselect", { bubbles: true, cancelable: true });
    this.opts.onSelect.current(selectEvent);
    if (selectEvent.defaultPrevented) {
      this.item.content.parentMenu.root.isUsingKeyboard.current = false;
      return;
    }
    if (this.opts.closeOnSelect.current) {
      this.item.content.parentMenu.root.opts.onClose();
    }
  }
  onkeydown(e) {
    const isTypingAhead = this.item.content.search !== "";
    if (this.item.opts.disabled.current || isTypingAhead && e.key === SPACE) return;
    if (SELECTION_KEYS.includes(e.key)) {
      if (!isHTMLElement$1(e.currentTarget)) return;
      e.currentTarget.click();
      e.preventDefault();
    }
  }
  onclick(_) {
    if (this.item.opts.disabled.current) return;
    this.#handleSelect();
  }
  onpointerup(e) {
    if (e.defaultPrevented) return;
    if (!this.#isPointerDown) {
      if (!isHTMLElement$1(e.currentTarget)) return;
      e.currentTarget?.click();
    }
  }
  onpointerdown(_) {
    this.#isPointerDown = true;
  }
  #props = derived(() => mergeProps$1(this.item.props, {
    onclick: this.onclick,
    onpointerdown: this.onpointerdown,
    onpointerup: this.onpointerup,
    onkeydown: this.onkeydown
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class MenuSubTriggerState {
  static create(opts) {
    const content = MenuContentContext.get();
    const item = new MenuItemSharedState(opts, content);
    const submenu = MenuMenuContext.get();
    return new MenuSubTriggerState(opts, item, content, submenu);
  }
  opts;
  item;
  content;
  submenu;
  attachment;
  #openTimer = null;
  constructor(opts, item, content, submenu) {
    this.opts = opts;
    this.item = item;
    this.content = content;
    this.submenu = submenu;
    this.attachment = attachRef$1(this.opts.ref, (v) => this.submenu.triggerNode = v);
    this.onpointerleave = this.onpointerleave.bind(this);
    this.onpointermove = this.onpointermove.bind(this);
    this.onkeydown = this.onkeydown.bind(this);
    this.onclick = this.onclick.bind(this);
  }
  #clearOpenTimer() {
    if (this.#openTimer === null) return;
    this.content.domContext.getWindow().clearTimeout(this.#openTimer);
    this.#openTimer = null;
  }
  onpointermove(e) {
    if (!isMouseEvent$1(e)) return;
    if (!this.item.opts.disabled.current && !this.submenu.opts.open.current && !this.#openTimer && !this.content.parentMenu.root.isPointerInTransit) {
      this.#openTimer = this.content.domContext.setTimeout(
        () => {
          this.submenu.onOpen();
          this.#clearOpenTimer();
        },
        this.opts.openDelay.current
      );
    }
  }
  onpointerleave(e) {
    if (!isMouseEvent$1(e)) return;
    this.#clearOpenTimer();
  }
  onkeydown(e) {
    const isTypingAhead = this.content.search !== "";
    if (this.item.opts.disabled.current || isTypingAhead && e.key === SPACE) return;
    if (SUB_OPEN_KEYS[this.submenu.root.opts.dir.current].includes(e.key)) {
      e.currentTarget.click();
      e.preventDefault();
    }
  }
  onclick(e) {
    if (this.item.opts.disabled.current) return;
    if (!isHTMLElement$1(e.currentTarget)) return;
    e.currentTarget.focus();
    const selectEvent = new CustomEvent("menusubtriggerselect", { bubbles: true, cancelable: true });
    this.opts.onSelect.current(selectEvent);
    if (!this.submenu.opts.open.current) {
      this.submenu.onOpen();
      afterTick$1(() => {
        const contentNode = this.submenu.contentNode;
        if (!contentNode) return;
        MenuOpenEvent.dispatch(contentNode);
      });
    }
  }
  #props = derived(() => mergeProps$1(
    {
      "aria-haspopup": "menu",
      "aria-expanded": boolToStr(this.submenu.opts.open.current),
      "data-state": getDataOpenClosed(this.submenu.opts.open.current),
      "aria-controls": this.submenu.opts.open.current ? this.submenu.contentId.current : void 0,
      [this.submenu.root.getBitsAttr("sub-trigger")]: "",
      onclick: this.onclick,
      onpointermove: this.onpointermove,
      onpointerleave: this.onpointerleave,
      onkeydown: this.onkeydown,
      ...this.attachment
    },
    this.item.props
  ));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class MenuSeparatorState {
  static create(opts) {
    return new MenuSeparatorState(opts, MenuRootContext.get());
  }
  opts;
  root;
  attachment;
  constructor(opts, root) {
    this.opts = opts;
    this.root = root;
    this.attachment = attachRef$1(this.opts.ref);
  }
  #props = derived(() => ({
    id: this.opts.id.current,
    role: "group",
    [this.root.getBitsAttr("separator")]: "",
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class MenuRadioGroupState {
  static create(opts) {
    return MenuGroupContext.set(MenuRadioGroupContext.set(new MenuRadioGroupState(opts, MenuContentContext.get())));
  }
  opts;
  content;
  attachment;
  groupHeadingId = null;
  root;
  constructor(opts, content) {
    this.opts = opts;
    this.content = content;
    this.root = content.parentMenu.root;
    this.attachment = attachRef$1(this.opts.ref);
  }
  setValue(v) {
    this.opts.value.current = v;
  }
  #props = derived(() => ({
    id: this.opts.id.current,
    [this.root.getBitsAttr("radio-group")]: "",
    role: "group",
    "aria-labelledby": this.groupHeadingId,
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class MenuRadioItemState {
  static create(opts) {
    const radioGroup = MenuRadioGroupContext.get();
    const sharedItem = new MenuItemSharedState(opts, radioGroup.content);
    const item = new MenuItemState(opts, sharedItem);
    return new MenuRadioItemState(opts, item, radioGroup);
  }
  opts;
  item;
  group;
  attachment;
  #isChecked = derived(() => this.group.opts.value.current === this.opts.value.current);
  get isChecked() {
    return this.#isChecked();
  }
  set isChecked($$value) {
    return this.#isChecked($$value);
  }
  constructor(opts, item, group) {
    this.opts = opts;
    this.item = item;
    this.group = group;
    this.attachment = attachRef$1(this.opts.ref);
  }
  selectValue() {
    this.group.setValue(this.opts.value.current);
  }
  #props = derived(() => ({
    [this.group.root.getBitsAttr("radio-item")]: "",
    ...this.item.props,
    role: "menuitemradio",
    "aria-checked": getAriaChecked(this.isChecked),
    "data-state": getCheckedState(this.isChecked),
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class DropdownMenuTriggerState {
  static create(opts) {
    return new DropdownMenuTriggerState(opts, MenuMenuContext.get());
  }
  opts;
  parentMenu;
  attachment;
  constructor(opts, parentMenu) {
    this.opts = opts;
    this.parentMenu = parentMenu;
    this.attachment = attachRef$1(this.opts.ref, (v) => this.parentMenu.triggerNode = v);
  }
  onclick = (e) => {
    if (this.opts.disabled.current || e.detail !== 0) return;
    this.parentMenu.toggleOpen();
    e.preventDefault();
  };
  onpointerdown = (e) => {
    if (this.opts.disabled.current) return;
    if (e.pointerType === "touch") return e.preventDefault();
    if (e.button === 0 && e.ctrlKey === false) {
      this.parentMenu.toggleOpen();
      if (!this.parentMenu.opts.open.current) e.preventDefault();
    }
  };
  onpointerup = (e) => {
    if (this.opts.disabled.current) return;
    if (e.pointerType === "touch") {
      e.preventDefault();
      this.parentMenu.toggleOpen();
    }
  };
  onkeydown = (e) => {
    if (this.opts.disabled.current) return;
    if (e.key === SPACE || e.key === ENTER) {
      this.parentMenu.toggleOpen();
      e.preventDefault();
      return;
    }
    if (e.key === ARROW_DOWN) {
      this.parentMenu.onOpen();
      e.preventDefault();
    }
  };
  #ariaControls = derived(() => {
    if (this.parentMenu.opts.open.current && this.parentMenu.contentId.current) return this.parentMenu.contentId.current;
    return void 0;
  });
  #props = derived(() => ({
    id: this.opts.id.current,
    disabled: this.opts.disabled.current,
    "aria-haspopup": "menu",
    "aria-expanded": boolToStr(this.parentMenu.opts.open.current),
    "aria-controls": this.#ariaControls(),
    "data-disabled": boolToEmptyStrOrUndef(this.opts.disabled.current),
    "data-state": getDataOpenClosed(this.parentMenu.opts.open.current),
    [this.parentMenu.root.getBitsAttr("trigger")]: "",
    //
    onclick: this.onclick,
    onpointerdown: this.onpointerdown,
    onpointerup: this.onpointerup,
    onkeydown: this.onkeydown,
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class ContextMenuTriggerState {
  static create(opts) {
    return new ContextMenuTriggerState(opts, MenuMenuContext.get());
  }
  opts;
  parentMenu;
  attachment;
  #point = { x: 0, y: 0 };
  virtualElement = simpleBox({
    getBoundingClientRect: () => DOMRect.fromRect({ width: 0, height: 0, ...this.#point })
  });
  #longPressTimer = null;
  constructor(opts, parentMenu) {
    this.opts = opts;
    this.parentMenu = parentMenu;
    this.attachment = attachRef$1(this.opts.ref, (v) => this.parentMenu.triggerNode = v);
    this.oncontextmenu = this.oncontextmenu.bind(this);
    this.onpointerdown = this.onpointerdown.bind(this);
    this.onpointermove = this.onpointermove.bind(this);
    this.onpointercancel = this.onpointercancel.bind(this);
    this.onpointerup = this.onpointerup.bind(this);
    watch$2(() => this.#point, (point) => {
      this.virtualElement.current = {
        getBoundingClientRect: () => DOMRect.fromRect({ width: 0, height: 0, ...point })
      };
    });
    watch$2(() => this.opts.disabled.current, (isDisabled) => {
      if (isDisabled) {
        this.#clearLongPressTimer();
      }
    });
  }
  #clearLongPressTimer() {
    if (this.#longPressTimer === null) return;
    getWindow(this.opts.ref.current).clearTimeout(this.#longPressTimer);
  }
  #handleOpen(e) {
    this.#point = { x: e.clientX, y: e.clientY };
    this.parentMenu.onOpen();
  }
  oncontextmenu(e) {
    if (e.defaultPrevented || this.opts.disabled.current) return;
    this.#clearLongPressTimer();
    this.#handleOpen(e);
    e.preventDefault();
    this.parentMenu.contentNode?.focus();
  }
  onpointerdown(e) {
    if (this.opts.disabled.current || isMouseEvent$1(e)) return;
    this.#clearLongPressTimer();
    this.#longPressTimer = getWindow(this.opts.ref.current).setTimeout(() => this.#handleOpen(e), 700);
  }
  onpointermove(e) {
    if (this.opts.disabled.current || isMouseEvent$1(e)) return;
    this.#clearLongPressTimer();
  }
  onpointercancel(e) {
    if (this.opts.disabled.current || isMouseEvent$1(e)) return;
    this.#clearLongPressTimer();
  }
  onpointerup(e) {
    if (this.opts.disabled.current || isMouseEvent$1(e)) return;
    this.#clearLongPressTimer();
  }
  #props = derived(() => ({
    id: this.opts.id.current,
    disabled: this.opts.disabled.current,
    "data-disabled": boolToEmptyStrOrUndef(this.opts.disabled.current),
    "data-state": getDataOpenClosed(this.parentMenu.opts.open.current),
    [CONTEXT_MENU_TRIGGER_ATTR]: "",
    tabindex: -1,
    //
    onpointerdown: this.onpointerdown,
    onpointermove: this.onpointermove,
    onpointercancel: this.onpointercancel,
    onpointerup: this.onpointerup,
    oncontextmenu: this.oncontextmenu,
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class MenuSubmenuState {
  static create(opts) {
    const menu = MenuMenuContext.get();
    return MenuMenuContext.set(new MenuMenuState(opts, menu.root, menu));
  }
}
globalThis.bitsDismissableLayers ??= /* @__PURE__ */ new Map();
class DismissibleLayerState {
  static create(opts) {
    return new DismissibleLayerState(opts);
  }
  opts;
  #interactOutsideProp;
  #behaviorType;
  #interceptedEvents = { pointerdown: false };
  #isResponsibleLayer = false;
  #isFocusInsideDOMTree = false;
  #documentObj = void 0;
  #onFocusOutside;
  #unsubClickListener = noop$1;
  constructor(opts) {
    this.opts = opts;
    this.#behaviorType = opts.interactOutsideBehavior;
    this.#interactOutsideProp = opts.onInteractOutside;
    this.#onFocusOutside = opts.onFocusOutside;
    let unsubEvents = noop$1;
    const cleanup = () => {
      this.#resetState();
      globalThis.bitsDismissableLayers.delete(this);
      this.#handleInteractOutside.destroy();
      unsubEvents();
    };
    watch$2([() => this.opts.enabled.current, () => this.opts.ref.current], () => {
      if (!this.opts.enabled.current || !this.opts.ref.current) return;
      afterSleep(1, () => {
        if (!this.opts.ref.current) return;
        globalThis.bitsDismissableLayers.set(this, this.#behaviorType);
        unsubEvents();
        unsubEvents = this.#addEventListeners();
      });
      return cleanup;
    });
  }
  #handleFocus = (event) => {
    if (event.defaultPrevented) return;
    if (!this.opts.ref.current) return;
    afterTick$1(() => {
      if (!this.opts.ref.current || this.#isTargetWithinLayer(event.target)) return;
      if (event.target && !this.#isFocusInsideDOMTree) {
        this.#onFocusOutside.current?.(event);
      }
    });
  };
  #addEventListeners() {
    return executeCallbacks$1(
      /**
       * CAPTURE INTERACTION START
       * mark interaction-start event as intercepted.
       * mark responsible layer during interaction start
       * to avoid checking if is responsible layer during interaction end
       * when a new floating element may have been opened.
       */
      on(this.#documentObj, "pointerdown", executeCallbacks$1(this.#markInterceptedEvent, this.#markResponsibleLayer), { capture: true }),
      /**
       * BUBBLE INTERACTION START
       * Mark interaction-start event as non-intercepted. Debounce `onInteractOutsideStart`
       * to avoid prematurely checking if other events were intercepted.
       */
      on(this.#documentObj, "pointerdown", executeCallbacks$1(this.#markNonInterceptedEvent, this.#handleInteractOutside)),
      /**
       * HANDLE FOCUS OUTSIDE
       */
      on(this.#documentObj, "focusin", this.#handleFocus)
    );
  }
  #handleDismiss = (e) => {
    let event = e;
    if (event.defaultPrevented) {
      event = createWrappedEvent(e);
    }
    this.#interactOutsideProp.current(e);
  };
  #handleInteractOutside = debounce$1(
    (e) => {
      if (!this.opts.ref.current) {
        this.#unsubClickListener();
        return;
      }
      const isEventValid = this.opts.isValidEvent.current(e, this.opts.ref.current) || isValidEvent(e, this.opts.ref.current);
      if (!this.#isResponsibleLayer || this.#isAnyEventIntercepted() || !isEventValid) {
        this.#unsubClickListener();
        return;
      }
      let event = e;
      if (event.defaultPrevented) {
        event = createWrappedEvent(event);
      }
      if (this.#behaviorType.current !== "close" && this.#behaviorType.current !== "defer-otherwise-close") {
        this.#unsubClickListener();
        return;
      }
      if (e.pointerType === "touch") {
        this.#unsubClickListener();
        this.#unsubClickListener = on(this.#documentObj, "click", this.#handleDismiss, { once: true });
      } else {
        this.#interactOutsideProp.current(event);
      }
    },
    10
  );
  #markInterceptedEvent = (e) => {
    this.#interceptedEvents[e.type] = true;
  };
  #markNonInterceptedEvent = (e) => {
    this.#interceptedEvents[e.type] = false;
  };
  #markResponsibleLayer = () => {
    if (!this.opts.ref.current) return;
    this.#isResponsibleLayer = isResponsibleLayer(this.opts.ref.current);
  };
  #isTargetWithinLayer = (target) => {
    if (!this.opts.ref.current) return false;
    return isOrContainsTarget(this.opts.ref.current, target);
  };
  #resetState = debounce$1(
    () => {
      for (const eventType in this.#interceptedEvents) {
        this.#interceptedEvents[eventType] = false;
      }
      this.#isResponsibleLayer = false;
    },
    20
  );
  #isAnyEventIntercepted() {
    const i = Object.values(this.#interceptedEvents).some(Boolean);
    return i;
  }
  #onfocuscapture = () => {
    this.#isFocusInsideDOMTree = true;
  };
  #onblurcapture = () => {
    this.#isFocusInsideDOMTree = false;
  };
  props = {
    onfocuscapture: this.#onfocuscapture,
    onblurcapture: this.#onblurcapture
  };
}
function getTopMostDismissableLayer(layersArr = [...globalThis.bitsDismissableLayers]) {
  return layersArr.findLast(([_, { current: behaviorType }]) => behaviorType === "close" || behaviorType === "ignore");
}
function isResponsibleLayer(node) {
  const layersArr = [...globalThis.bitsDismissableLayers];
  const topMostLayer = getTopMostDismissableLayer(layersArr);
  if (topMostLayer) return topMostLayer[0].opts.ref.current === node;
  const [firstLayerNode] = layersArr[0];
  return firstLayerNode.opts.ref.current === node;
}
function isValidEvent(e, node) {
  const target = e.target;
  if (!isElementOrSVGElement(target)) return false;
  const targetIsContextMenuTrigger = Boolean(target.closest(`[${CONTEXT_MENU_TRIGGER_ATTR}]`));
  if ("button" in e && e.button > 0 && !targetIsContextMenuTrigger) return false;
  if ("button" in e && e.button === 0 && targetIsContextMenuTrigger) return true;
  const nodeIsContextMenu = Boolean(node.closest(`[${CONTEXT_MENU_CONTENT_ATTR}]`));
  if (targetIsContextMenuTrigger && nodeIsContextMenu) return false;
  const ownerDocument = getOwnerDocument(target);
  const isValid = ownerDocument.documentElement.contains(target) && !isOrContainsTarget(node, target) && isClickTrulyOutside(e, node);
  return isValid;
}
function createWrappedEvent(e) {
  const capturedCurrentTarget = e.currentTarget;
  const capturedTarget = e.target;
  let newEvent;
  if (e instanceof PointerEvent) {
    newEvent = new PointerEvent(e.type, e);
  } else {
    newEvent = new PointerEvent("pointerdown", e);
  }
  let isPrevented = false;
  const wrappedEvent = new Proxy(newEvent, {
    get: (target, prop) => {
      if (prop === "currentTarget") {
        return capturedCurrentTarget;
      }
      if (prop === "target") {
        return capturedTarget;
      }
      if (prop === "preventDefault") {
        return () => {
          isPrevented = true;
          if (typeof target.preventDefault === "function") {
            target.preventDefault();
          }
        };
      }
      if (prop === "defaultPrevented") {
        return isPrevented;
      }
      if (prop in target) {
        return target[prop];
      }
      return e[prop];
    }
  });
  return wrappedEvent;
}
function Dismissible_layer($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      interactOutsideBehavior = "close",
      onInteractOutside = noop$1,
      onFocusOutside = noop$1,
      id,
      children,
      enabled,
      isValidEvent: isValidEvent2 = () => false,
      ref
    } = $$props;
    const dismissibleLayerState = DismissibleLayerState.create({
      id: boxWith$1(() => id),
      interactOutsideBehavior: boxWith$1(() => interactOutsideBehavior),
      onInteractOutside: boxWith$1(() => onInteractOutside),
      enabled: boxWith$1(() => enabled),
      onFocusOutside: boxWith$1(() => onFocusOutside),
      isValidEvent: boxWith$1(() => isValidEvent2),
      ref
    });
    children?.($$renderer2, { props: dismissibleLayerState.props });
    $$renderer2.push(`<!---->`);
  });
}
globalThis.bitsEscapeLayers ??= /* @__PURE__ */ new Map();
class EscapeLayerState {
  static create(opts) {
    return new EscapeLayerState(opts);
  }
  opts;
  domContext;
  constructor(opts) {
    this.opts = opts;
    this.domContext = new DOMContext$1(this.opts.ref);
    let unsubEvents = noop$1;
    watch$2(() => opts.enabled.current, (enabled) => {
      if (enabled) {
        globalThis.bitsEscapeLayers.set(this, opts.escapeKeydownBehavior);
        unsubEvents = this.#addEventListener();
      }
      return () => {
        unsubEvents();
        globalThis.bitsEscapeLayers.delete(this);
      };
    });
  }
  #addEventListener = () => {
    return on(this.domContext.getDocument(), "keydown", this.#onkeydown, { passive: false });
  };
  #onkeydown = (e) => {
    if (e.key !== ESCAPE || !isResponsibleEscapeLayer(this)) return;
    const clonedEvent = new KeyboardEvent(e.type, e);
    e.preventDefault();
    const behaviorType = this.opts.escapeKeydownBehavior.current;
    if (behaviorType !== "close" && behaviorType !== "defer-otherwise-close") return;
    this.opts.onEscapeKeydown.current(clonedEvent);
  };
}
function isResponsibleEscapeLayer(instance) {
  const layersArr = [...globalThis.bitsEscapeLayers];
  const topMostLayer = layersArr.findLast(([_, { current: behaviorType }]) => behaviorType === "close" || behaviorType === "ignore");
  if (topMostLayer) return topMostLayer[0] === instance;
  const [firstLayerNode] = layersArr[0];
  return firstLayerNode === instance;
}
function Escape_layer($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      escapeKeydownBehavior = "close",
      onEscapeKeydown = noop$1,
      children,
      enabled,
      ref
    } = $$props;
    EscapeLayerState.create({
      escapeKeydownBehavior: boxWith$1(() => escapeKeydownBehavior),
      onEscapeKeydown: boxWith$1(() => onEscapeKeydown),
      enabled: boxWith$1(() => enabled),
      ref
    });
    children?.($$renderer2);
    $$renderer2.push(`<!---->`);
  });
}
class FocusScopeManager {
  static instance;
  #scopeStack = simpleBox([]);
  #focusHistory = /* @__PURE__ */ new WeakMap();
  #preFocusHistory = /* @__PURE__ */ new WeakMap();
  static getInstance() {
    if (!this.instance) {
      this.instance = new FocusScopeManager();
    }
    return this.instance;
  }
  register(scope) {
    const current = this.getActive();
    if (current && current !== scope) {
      current.pause();
    }
    const activeElement = document.activeElement;
    if (activeElement && activeElement !== document.body) {
      this.#preFocusHistory.set(scope, activeElement);
    }
    this.#scopeStack.current = this.#scopeStack.current.filter((s) => s !== scope);
    this.#scopeStack.current.unshift(scope);
  }
  unregister(scope) {
    this.#scopeStack.current = this.#scopeStack.current.filter((s) => s !== scope);
    const next = this.getActive();
    if (next) {
      next.resume();
    }
  }
  getActive() {
    return this.#scopeStack.current[0];
  }
  setFocusMemory(scope, element2) {
    this.#focusHistory.set(scope, element2);
  }
  getFocusMemory(scope) {
    return this.#focusHistory.get(scope);
  }
  isActiveScope(scope) {
    return this.getActive() === scope;
  }
  setPreFocusMemory(scope, element2) {
    this.#preFocusHistory.set(scope, element2);
  }
  getPreFocusMemory(scope) {
    return this.#preFocusHistory.get(scope);
  }
  clearPreFocusMemory(scope) {
    this.#preFocusHistory.delete(scope);
  }
}
class FocusScope {
  #paused = false;
  #container = null;
  #manager = FocusScopeManager.getInstance();
  #cleanupFns = [];
  #opts;
  constructor(opts) {
    this.#opts = opts;
  }
  get paused() {
    return this.#paused;
  }
  pause() {
    this.#paused = true;
  }
  resume() {
    this.#paused = false;
  }
  #cleanup() {
    for (const fn of this.#cleanupFns) {
      fn();
    }
    this.#cleanupFns = [];
  }
  mount(container) {
    if (this.#container) {
      this.unmount();
    }
    this.#container = container;
    this.#manager.register(this);
    this.#setupEventListeners();
    this.#handleOpenAutoFocus();
  }
  unmount() {
    if (!this.#container) return;
    this.#cleanup();
    this.#handleCloseAutoFocus();
    this.#manager.unregister(this);
    this.#manager.clearPreFocusMemory(this);
    this.#container = null;
  }
  #handleOpenAutoFocus() {
    if (!this.#container) return;
    const event = new CustomEvent("focusScope.onOpenAutoFocus", { bubbles: false, cancelable: true });
    this.#opts.onOpenAutoFocus.current(event);
    if (!event.defaultPrevented) {
      requestAnimationFrame(() => {
        if (!this.#container) return;
        const firstTabbable = this.#getFirstTabbable();
        if (firstTabbable) {
          firstTabbable.focus();
          this.#manager.setFocusMemory(this, firstTabbable);
        } else {
          this.#container.focus();
        }
      });
    }
  }
  #handleCloseAutoFocus() {
    const event = new CustomEvent("focusScope.onCloseAutoFocus", { bubbles: false, cancelable: true });
    this.#opts.onCloseAutoFocus.current?.(event);
    if (!event.defaultPrevented) {
      const preFocusedElement = this.#manager.getPreFocusMemory(this);
      if (preFocusedElement && document.contains(preFocusedElement)) {
        try {
          preFocusedElement.focus();
        } catch {
          document.body.focus();
        }
      }
    }
  }
  #setupEventListeners() {
    if (!this.#container || !this.#opts.trap.current) return;
    const container = this.#container;
    const doc = container.ownerDocument;
    const handleFocus = (e) => {
      if (this.#paused || !this.#manager.isActiveScope(this)) return;
      const target = e.target;
      if (!target) return;
      const isInside = container.contains(target);
      if (isInside) {
        this.#manager.setFocusMemory(this, target);
      } else {
        const lastFocused = this.#manager.getFocusMemory(this);
        if (lastFocused && container.contains(lastFocused) && isFocusable(lastFocused)) {
          e.preventDefault();
          lastFocused.focus();
        } else {
          const firstTabbable = this.#getFirstTabbable();
          const firstFocusable = this.#getAllFocusables()[0];
          (firstTabbable || firstFocusable || container).focus();
        }
      }
    };
    const handleKeydown = (e) => {
      if (!this.#opts.loop || this.#paused || e.key !== "Tab") return;
      if (!this.#manager.isActiveScope(this)) return;
      const tabbables = this.#getTabbables();
      if (tabbables.length === 0) return;
      const first = tabbables[0];
      const last = tabbables[tabbables.length - 1];
      if (!e.shiftKey && doc.activeElement === last) {
        e.preventDefault();
        first.focus();
      } else if (e.shiftKey && doc.activeElement === first) {
        e.preventDefault();
        last.focus();
      }
    };
    this.#cleanupFns.push(on(doc, "focusin", handleFocus, { capture: true }), on(container, "keydown", handleKeydown));
    const observer = new MutationObserver(() => {
      const lastFocused = this.#manager.getFocusMemory(this);
      if (lastFocused && !container.contains(lastFocused)) {
        const firstTabbable = this.#getFirstTabbable();
        const firstFocusable = this.#getAllFocusables()[0];
        const elementToFocus = firstTabbable || firstFocusable;
        if (elementToFocus) {
          elementToFocus.focus();
          this.#manager.setFocusMemory(this, elementToFocus);
        } else {
          container.focus();
        }
      }
    });
    observer.observe(container, { childList: true, subtree: true });
    this.#cleanupFns.push(() => observer.disconnect());
  }
  #getTabbables() {
    if (!this.#container) return [];
    return tabbable(this.#container, { includeContainer: false, getShadowRoot: true });
  }
  #getFirstTabbable() {
    const tabbables = this.#getTabbables();
    return tabbables[0] || null;
  }
  #getAllFocusables() {
    if (!this.#container) return [];
    return focusable(this.#container, { includeContainer: false, getShadowRoot: true });
  }
  static use(opts) {
    let scope = null;
    watch$2([() => opts.ref.current, () => opts.enabled.current], ([ref, enabled]) => {
      if (ref && enabled) {
        if (!scope) {
          scope = new FocusScope(opts);
        }
        scope.mount(ref);
      } else if (scope) {
        scope.unmount();
        scope = null;
      }
    });
    return {
      get props() {
        return { tabindex: -1 };
      }
    };
  }
}
function Focus_scope($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      enabled = false,
      trapFocus = false,
      loop = false,
      onCloseAutoFocus = noop$1,
      onOpenAutoFocus = noop$1,
      focusScope,
      ref
    } = $$props;
    const focusScopeState = FocusScope.use({
      enabled: boxWith$1(() => enabled),
      trap: boxWith$1(() => trapFocus),
      loop,
      onCloseAutoFocus: boxWith$1(() => onCloseAutoFocus),
      onOpenAutoFocus: boxWith$1(() => onOpenAutoFocus),
      ref
    });
    focusScope?.($$renderer2, { props: focusScopeState.props });
    $$renderer2.push(`<!---->`);
  });
}
globalThis.bitsTextSelectionLayers ??= /* @__PURE__ */ new Map();
class TextSelectionLayerState {
  static create(opts) {
    return new TextSelectionLayerState(opts);
  }
  opts;
  domContext;
  #unsubSelectionLock = noop$1;
  constructor(opts) {
    this.opts = opts;
    this.domContext = new DOMContext$1(opts.ref);
    let unsubEvents = noop$1;
    watch$2(() => this.opts.enabled.current, (isEnabled) => {
      if (isEnabled) {
        globalThis.bitsTextSelectionLayers.set(this, this.opts.enabled);
        unsubEvents();
        unsubEvents = this.#addEventListeners();
      }
      return () => {
        unsubEvents();
        this.#resetSelectionLock();
        globalThis.bitsTextSelectionLayers.delete(this);
      };
    });
  }
  #addEventListeners() {
    return executeCallbacks$1(on(this.domContext.getDocument(), "pointerdown", this.#pointerdown), on(this.domContext.getDocument(), "pointerup", composeHandlers$1(this.#resetSelectionLock, this.opts.onPointerUp.current)));
  }
  #pointerdown = (e) => {
    const node = this.opts.ref.current;
    const target = e.target;
    if (!isHTMLElement$1(node) || !isHTMLElement$1(target) || !this.opts.enabled.current) return;
    if (!isHighestLayer(this) || !contains(node, target)) return;
    this.opts.onPointerDown.current(e);
    if (e.defaultPrevented) return;
    this.#unsubSelectionLock = preventTextSelectionOverflow(node, this.domContext.getDocument().body);
  };
  #resetSelectionLock = () => {
    this.#unsubSelectionLock();
    this.#unsubSelectionLock = noop$1;
  };
}
const getUserSelect = (node) => node.style.userSelect || node.style.webkitUserSelect;
function preventTextSelectionOverflow(node, body) {
  const originalBodyUserSelect = getUserSelect(body);
  const originalNodeUserSelect = getUserSelect(node);
  setUserSelect(body, "none");
  setUserSelect(node, "text");
  return () => {
    setUserSelect(body, originalBodyUserSelect);
    setUserSelect(node, originalNodeUserSelect);
  };
}
function setUserSelect(node, value) {
  node.style.userSelect = value;
  node.style.webkitUserSelect = value;
}
function isHighestLayer(instance) {
  const layersArr = [...globalThis.bitsTextSelectionLayers];
  if (!layersArr.length) return false;
  const highestLayer = layersArr.at(-1);
  if (!highestLayer) return false;
  return highestLayer[0] === instance;
}
function Text_selection_layer($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      preventOverflowTextSelection = true,
      onPointerDown = noop$1,
      onPointerUp = noop$1,
      id,
      children,
      enabled,
      ref
    } = $$props;
    TextSelectionLayerState.create({
      id: boxWith$1(() => id),
      onPointerDown: boxWith$1(() => onPointerDown),
      onPointerUp: boxWith$1(() => onPointerUp),
      enabled: boxWith$1(() => enabled && preventOverflowTextSelection),
      ref
    });
    children?.($$renderer2);
    $$renderer2.push(`<!---->`);
  });
}
globalThis.bitsIdCounter ??= { current: 0 };
function useId(prefix = "bits") {
  globalThis.bitsIdCounter.current++;
  return `${prefix}-${globalThis.bitsIdCounter.current}`;
}
class SharedState {
  #factory;
  #subscribers = 0;
  #state;
  #scope;
  constructor(factory) {
    this.#factory = factory;
  }
  #dispose() {
    this.#subscribers -= 1;
    if (this.#scope && this.#subscribers <= 0) {
      this.#scope();
      this.#state = void 0;
      this.#scope = void 0;
    }
  }
  get(...args) {
    this.#subscribers += 1;
    if (this.#state === void 0) {
      this.#scope = () => {
      };
    }
    return this.#state;
  }
}
const lockMap = new SvelteMap();
let initialBodyStyle = null;
let cleanupTimeoutId = null;
let isInCleanupTransition = false;
const anyLocked = boxWith$1(() => {
  for (const value of lockMap.values()) {
    if (value) return true;
  }
  return false;
});
let cleanupScheduledAt = null;
const bodyLockStackCount = new SharedState(() => {
  function resetBodyStyle() {
    return;
  }
  function cancelPendingCleanup() {
    if (cleanupTimeoutId === null) return;
    window.clearTimeout(cleanupTimeoutId);
    cleanupTimeoutId = null;
  }
  function scheduleCleanupIfNoNewLocks(delay, callback) {
    cancelPendingCleanup();
    isInCleanupTransition = true;
    cleanupScheduledAt = Date.now();
    const currentCleanupId = cleanupScheduledAt;
    const cleanupFn = () => {
      cleanupTimeoutId = null;
      if (cleanupScheduledAt !== currentCleanupId) return;
      if (!isAnyLocked(lockMap)) {
        isInCleanupTransition = false;
        callback();
      } else {
        isInCleanupTransition = false;
      }
    };
    const actualDelay = delay === null ? 24 : delay;
    cleanupTimeoutId = window.setTimeout(cleanupFn, actualDelay);
  }
  function ensureInitialStyleCaptured() {
    if (initialBodyStyle === null && lockMap.size === 0 && !isInCleanupTransition) {
      initialBodyStyle = document.body.getAttribute("style");
    }
  }
  watch$2(() => anyLocked.current, () => {
    if (!anyLocked.current) return;
    ensureInitialStyleCaptured();
    isInCleanupTransition = false;
    const htmlStyle = getComputedStyle(document.documentElement);
    const bodyStyle = getComputedStyle(document.body);
    const hasStableGutter = htmlStyle.scrollbarGutter?.includes("stable") || bodyStyle.scrollbarGutter?.includes("stable");
    const verticalScrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
    const paddingRight = Number.parseInt(bodyStyle.paddingRight ?? "0", 10);
    const config = {
      padding: paddingRight + verticalScrollbarWidth,
      margin: Number.parseInt(bodyStyle.marginRight ?? "0", 10)
    };
    if (verticalScrollbarWidth > 0 && !hasStableGutter) {
      document.body.style.paddingRight = `${config.padding}px`;
      document.body.style.marginRight = `${config.margin}px`;
      document.body.style.setProperty("--scrollbar-width", `${verticalScrollbarWidth}px`);
    }
    document.body.style.overflow = "hidden";
    if (isIOS) {
      on(
        document,
        "touchmove",
        (e) => {
          if (e.target !== document.documentElement) return;
          if (e.touches.length > 1) return;
          e.preventDefault();
        },
        { passive: false }
      );
    }
    afterTick$1(() => {
      document.body.style.pointerEvents = "none";
      document.body.style.overflow = "hidden";
    });
  });
  return {
    get lockMap() {
      return lockMap;
    },
    resetBodyStyle,
    scheduleCleanupIfNoNewLocks,
    cancelPendingCleanup,
    ensureInitialStyleCaptured
  };
});
class BodyScrollLock {
  #id = useId();
  #initialState;
  #restoreScrollDelay = () => null;
  #countState;
  locked;
  constructor(initialState, restoreScrollDelay = () => null) {
    this.#initialState = initialState;
    this.#restoreScrollDelay = restoreScrollDelay;
    this.#countState = bodyLockStackCount.get();
    if (!this.#countState) return;
    this.#countState.cancelPendingCleanup();
    this.#countState.ensureInitialStyleCaptured();
    this.#countState.lockMap.set(this.#id, this.#initialState ?? false);
    this.locked = boxWith$1(() => this.#countState.lockMap.get(this.#id) ?? false, (v) => this.#countState.lockMap.set(this.#id, v));
  }
}
function isAnyLocked(map) {
  for (const [_, value] of map) {
    if (value) return true;
  }
  return false;
}
function Scroll_lock($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { preventScroll = true, restoreScrollDelay = null } = $$props;
    if (preventScroll) {
      new BodyScrollLock(preventScroll, () => restoreScrollDelay);
    }
  });
}
const collapsibleAttrs = createBitsAttrs({
  component: "collapsible",
  parts: ["root", "content", "trigger"]
});
const CollapsibleRootContext = new Context$1("Collapsible.Root");
class CollapsibleRootState {
  static create(opts) {
    return CollapsibleRootContext.set(new CollapsibleRootState(opts));
  }
  opts;
  attachment;
  contentNode = null;
  contentPresence;
  contentId = void 0;
  constructor(opts) {
    this.opts = opts;
    this.toggleOpen = this.toggleOpen.bind(this);
    this.attachment = attachRef$1(this.opts.ref);
    this.contentPresence = new PresenceManager({
      ref: boxWith$1(() => this.contentNode),
      open: this.opts.open,
      onComplete: () => {
        this.opts.onOpenChangeComplete.current(this.opts.open.current);
      }
    });
  }
  toggleOpen() {
    this.opts.open.current = !this.opts.open.current;
  }
  #props = derived(() => ({
    id: this.opts.id.current,
    "data-state": getDataOpenClosed(this.opts.open.current),
    "data-disabled": boolToEmptyStrOrUndef(this.opts.disabled.current),
    [collapsibleAttrs.root]: "",
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class CollapsibleContentState {
  static create(opts) {
    return new CollapsibleContentState(opts, CollapsibleRootContext.get());
  }
  opts;
  root;
  attachment;
  #present = derived(() => {
    if (this.opts.hiddenUntilFound.current) return this.root.opts.open.current;
    return this.opts.forceMount.current || this.root.opts.open.current;
  });
  get present() {
    return this.#present();
  }
  set present($$value) {
    return this.#present($$value);
  }
  #originalStyles;
  #isMountAnimationPrevented = false;
  #width = 0;
  #height = 0;
  constructor(opts, root) {
    this.opts = opts;
    this.root = root;
    this.#isMountAnimationPrevented = root.opts.open.current;
    this.root.contentId = this.opts.id.current;
    this.attachment = attachRef$1(this.opts.ref, (v) => this.root.contentNode = v);
    watch$2.pre(() => this.opts.id.current, (id) => {
      this.root.contentId = id;
    });
    watch$2.pre(
      [
        () => this.opts.ref.current,
        () => this.opts.hiddenUntilFound.current
      ],
      ([node, hiddenUntilFound]) => {
        if (!node || !hiddenUntilFound) return;
        const handleBeforeMatch = () => {
          if (this.root.opts.open.current) return;
          requestAnimationFrame(() => {
            this.root.opts.open.current = true;
          });
        };
        return on(node, "beforematch", handleBeforeMatch);
      }
    );
    watch$2([() => this.opts.ref.current, () => this.present], ([node]) => {
      if (!node) return;
      afterTick$1(() => {
        if (!this.opts.ref.current) return;
        this.#originalStyles = this.#originalStyles || {
          transitionDuration: node.style.transitionDuration,
          animationName: node.style.animationName
        };
        node.style.transitionDuration = "0s";
        node.style.animationName = "none";
        const rect = node.getBoundingClientRect();
        this.#height = rect.height;
        this.#width = rect.width;
        if (!this.#isMountAnimationPrevented) {
          const { animationName, transitionDuration } = this.#originalStyles;
          node.style.transitionDuration = transitionDuration;
          node.style.animationName = animationName;
        }
      });
    });
  }
  get shouldRender() {
    return this.root.contentPresence.shouldRender;
  }
  #snippetProps = derived(() => ({ open: this.root.opts.open.current }));
  get snippetProps() {
    return this.#snippetProps();
  }
  set snippetProps($$value) {
    return this.#snippetProps($$value);
  }
  #props = derived(() => ({
    id: this.opts.id.current,
    style: {
      "--bits-collapsible-content-height": this.#height ? `${this.#height}px` : void 0,
      "--bits-collapsible-content-width": this.#width ? `${this.#width}px` : void 0
    },
    hidden: this.opts.hiddenUntilFound.current && !this.root.opts.open.current ? "until-found" : void 0,
    "data-state": getDataOpenClosed(this.root.opts.open.current),
    "data-disabled": boolToEmptyStrOrUndef(this.root.opts.disabled.current),
    [collapsibleAttrs.content]: "",
    ...this.opts.hiddenUntilFound.current && !this.shouldRender ? {} : {
      hidden: this.opts.hiddenUntilFound.current ? !this.shouldRender : this.opts.forceMount.current ? void 0 : !this.shouldRender
    },
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class CollapsibleTriggerState {
  static create(opts) {
    return new CollapsibleTriggerState(opts, CollapsibleRootContext.get());
  }
  opts;
  root;
  attachment;
  #isDisabled = derived(() => this.opts.disabled.current || this.root.opts.disabled.current);
  constructor(opts, root) {
    this.opts = opts;
    this.root = root;
    this.attachment = attachRef$1(this.opts.ref);
    this.onclick = this.onclick.bind(this);
    this.onkeydown = this.onkeydown.bind(this);
  }
  onclick(e) {
    if (this.#isDisabled()) return;
    if (e.button !== 0) return e.preventDefault();
    this.root.toggleOpen();
  }
  onkeydown(e) {
    if (this.#isDisabled()) return;
    if (e.key === SPACE || e.key === ENTER) {
      e.preventDefault();
      this.root.toggleOpen();
    }
  }
  #props = derived(() => ({
    id: this.opts.id.current,
    type: "button",
    disabled: this.#isDisabled(),
    "aria-controls": this.root.contentId,
    "aria-expanded": boolToStr(this.root.opts.open.current),
    "data-state": getDataOpenClosed(this.root.opts.open.current),
    "data-disabled": boolToEmptyStrOrUndef(this.#isDisabled()),
    [collapsibleAttrs.trigger]: "",
    //
    onclick: this.onclick,
    onkeydown: this.onkeydown,
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
function Collapsible$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      children,
      child,
      id = createId(uid),
      ref = null,
      open = false,
      disabled = false,
      onOpenChange = noop$1,
      onOpenChangeComplete = noop$1,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const rootState = CollapsibleRootState.create({
      open: boxWith$1(() => open, (v) => {
        open = v;
        onOpenChange(v);
      }),
      disabled: boxWith$1(() => disabled),
      id: boxWith$1(() => id),
      ref: boxWith$1(() => ref, (v) => ref = v),
      onOpenChangeComplete: boxWith$1(() => onOpenChangeComplete)
    });
    const mergedProps = mergeProps$1(restProps, rootState.props);
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { props: mergedProps });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attributes({ ...mergedProps })}>`);
      children?.($$renderer2);
      $$renderer2.push(`<!----></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref, open });
  });
}
function Collapsible_content$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      child,
      ref = null,
      forceMount = false,
      hiddenUntilFound = false,
      children,
      id = createId(uid),
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const contentState = CollapsibleContentState.create({
      id: boxWith$1(() => id),
      forceMount: boxWith$1(() => forceMount),
      hiddenUntilFound: boxWith$1(() => hiddenUntilFound),
      ref: boxWith$1(() => ref, (v) => ref = v)
    });
    const mergedProps = mergeProps$1(restProps, contentState.props);
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { ...contentState.snippetProps, props: mergedProps });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attributes({ ...mergedProps })}>`);
      children?.($$renderer2);
      $$renderer2.push(`<!----></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref });
  });
}
function Collapsible_trigger$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      children,
      child,
      ref = null,
      id = createId(uid),
      disabled = false,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const triggerState = CollapsibleTriggerState.create({
      id: boxWith$1(() => id),
      ref: boxWith$1(() => ref, (v) => ref = v),
      disabled: boxWith$1(() => disabled)
    });
    const mergedProps = mergeProps$1(restProps, triggerState.props);
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { props: mergedProps });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<button${attributes({ ...mergedProps })}>`);
      children?.($$renderer2);
      $$renderer2.push(`<!----></button>`);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref });
  });
}
function get$1(valueOrGetValue) {
  return typeof valueOrGetValue === "function" ? valueOrGetValue() : valueOrGetValue;
}
function getDPR(element2) {
  if (typeof window === "undefined") return 1;
  const win = element2.ownerDocument.defaultView || window;
  return win.devicePixelRatio || 1;
}
function roundByDPR(element2, value) {
  const dpr = getDPR(element2);
  return Math.round(value * dpr) / dpr;
}
function getFloatingContentCSSVars(name) {
  return {
    [`--bits-${name}-content-transform-origin`]: `var(--bits-floating-transform-origin)`,
    [`--bits-${name}-content-available-width`]: `var(--bits-floating-available-width)`,
    [`--bits-${name}-content-available-height`]: `var(--bits-floating-available-height)`,
    [`--bits-${name}-anchor-width`]: `var(--bits-floating-anchor-width)`,
    [`--bits-${name}-anchor-height`]: `var(--bits-floating-anchor-height)`
  };
}
function useFloating(options) {
  const openOption = get$1(options.open) ?? true;
  const middlewareOption = get$1(options.middleware);
  const transformOption = get$1(options.transform) ?? true;
  const placementOption = get$1(options.placement) ?? "bottom";
  const strategyOption = get$1(options.strategy) ?? "absolute";
  const sideOffsetOption = get$1(options.sideOffset) ?? 0;
  const alignOffsetOption = get$1(options.alignOffset) ?? 0;
  const reference = options.reference;
  let x = 0;
  let y = 0;
  const floating = simpleBox(null);
  let strategy = strategyOption;
  let placement = placementOption;
  let middlewareData = {};
  let isPositioned = false;
  const floatingStyles = (() => {
    const xVal = floating.current ? roundByDPR(floating.current, x) : x;
    const yVal = floating.current ? roundByDPR(floating.current, y) : y;
    if (transformOption) {
      return {
        position: strategy,
        left: "0",
        top: "0",
        transform: `translate(${xVal}px, ${yVal}px)`,
        ...floating.current && getDPR(floating.current) >= 1.5 && { willChange: "transform" }
      };
    }
    return { position: strategy, left: `${xVal}px`, top: `${yVal}px` };
  })();
  function update() {
    if (reference.current === null || floating.current === null) return;
    computePosition(reference.current, floating.current, {
      middleware: middlewareOption,
      placement: placementOption,
      strategy: strategyOption
    }).then((position) => {
      if (!openOption && x !== 0 && y !== 0) {
        const maxExpectedOffset = Math.max(Math.abs(sideOffsetOption), Math.abs(alignOffsetOption), 15);
        if (position.x <= maxExpectedOffset && position.y <= maxExpectedOffset) return;
      }
      x = position.x;
      y = position.y;
      strategy = position.strategy;
      placement = position.placement;
      middlewareData = position.middlewareData;
      isPositioned = true;
    });
  }
  return {
    floating,
    reference,
    get strategy() {
      return strategy;
    },
    get placement() {
      return placement;
    },
    get middlewareData() {
      return middlewareData;
    },
    get isPositioned() {
      return isPositioned;
    },
    get floatingStyles() {
      return floatingStyles;
    },
    get update() {
      return update;
    }
  };
}
const OPPOSITE_SIDE = { top: "bottom", right: "left", bottom: "top", left: "right" };
const FloatingRootContext = new Context$1("Floating.Root");
const FloatingContentContext = new Context$1("Floating.Content");
const FloatingTooltipRootContext = new Context$1("Floating.Root");
class FloatingRootState {
  static create(tooltip = false) {
    return tooltip ? FloatingTooltipRootContext.set(new FloatingRootState()) : FloatingRootContext.set(new FloatingRootState());
  }
  anchorNode = simpleBox(null);
  customAnchorNode = simpleBox(null);
  triggerNode = simpleBox(null);
  constructor() {
  }
}
class FloatingContentState {
  static create(opts, tooltip = false) {
    return tooltip ? FloatingContentContext.set(new FloatingContentState(opts, FloatingTooltipRootContext.get())) : FloatingContentContext.set(new FloatingContentState(opts, FloatingRootContext.get()));
  }
  opts;
  root;
  // nodes
  contentRef = simpleBox(null);
  wrapperRef = simpleBox(null);
  arrowRef = simpleBox(null);
  contentAttachment = attachRef$1(this.contentRef);
  wrapperAttachment = attachRef$1(this.wrapperRef);
  arrowAttachment = attachRef$1(this.arrowRef);
  // ids
  arrowId = simpleBox(useId());
  #transformedStyle = derived(() => {
    if (typeof this.opts.style === "string") return cssToStyleObj$1(this.opts.style);
    if (!this.opts.style) return {};
  });
  #updatePositionStrategy = void 0;
  #arrowSize = new ElementSize(() => this.arrowRef.current ?? void 0);
  #arrowWidth = derived(() => this.#arrowSize?.width ?? 0);
  #arrowHeight = derived(() => this.#arrowSize?.height ?? 0);
  #desiredPlacement = derived(() => this.opts.side?.current + (this.opts.align.current !== "center" ? `-${this.opts.align.current}` : ""));
  #boundary = derived(() => Array.isArray(this.opts.collisionBoundary.current) ? this.opts.collisionBoundary.current : [this.opts.collisionBoundary.current]);
  #hasExplicitBoundaries = derived(() => this.#boundary().length > 0);
  get hasExplicitBoundaries() {
    return this.#hasExplicitBoundaries();
  }
  set hasExplicitBoundaries($$value) {
    return this.#hasExplicitBoundaries($$value);
  }
  #detectOverflowOptions = derived(() => ({
    padding: this.opts.collisionPadding.current,
    boundary: this.#boundary().filter(isNotNull),
    altBoundary: this.hasExplicitBoundaries
  }));
  get detectOverflowOptions() {
    return this.#detectOverflowOptions();
  }
  set detectOverflowOptions($$value) {
    return this.#detectOverflowOptions($$value);
  }
  #availableWidth = void 0;
  #availableHeight = void 0;
  #anchorWidth = void 0;
  #anchorHeight = void 0;
  #middleware = derived(() => [
    offset({
      mainAxis: this.opts.sideOffset.current + this.#arrowHeight(),
      alignmentAxis: this.opts.alignOffset.current
    }),
    this.opts.avoidCollisions.current && shift({
      mainAxis: true,
      crossAxis: false,
      limiter: this.opts.sticky.current === "partial" ? limitShift() : void 0,
      ...this.detectOverflowOptions
    }),
    this.opts.avoidCollisions.current && flip({ ...this.detectOverflowOptions }),
    size({
      ...this.detectOverflowOptions,
      apply: ({ rects, availableWidth, availableHeight }) => {
        const { width: anchorWidth, height: anchorHeight } = rects.reference;
        this.#availableWidth = availableWidth;
        this.#availableHeight = availableHeight;
        this.#anchorWidth = anchorWidth;
        this.#anchorHeight = anchorHeight;
      }
    }),
    this.arrowRef.current && arrow({
      element: this.arrowRef.current,
      padding: this.opts.arrowPadding.current
    }),
    transformOrigin({
      arrowWidth: this.#arrowWidth(),
      arrowHeight: this.#arrowHeight()
    }),
    this.opts.hideWhenDetached.current && hide({ strategy: "referenceHidden", ...this.detectOverflowOptions })
  ].filter(Boolean));
  get middleware() {
    return this.#middleware();
  }
  set middleware($$value) {
    return this.#middleware($$value);
  }
  floating;
  #placedSide = derived(() => getSideFromPlacement(this.floating.placement));
  get placedSide() {
    return this.#placedSide();
  }
  set placedSide($$value) {
    return this.#placedSide($$value);
  }
  #placedAlign = derived(() => getAlignFromPlacement(this.floating.placement));
  get placedAlign() {
    return this.#placedAlign();
  }
  set placedAlign($$value) {
    return this.#placedAlign($$value);
  }
  #arrowX = derived(() => this.floating.middlewareData.arrow?.x ?? 0);
  get arrowX() {
    return this.#arrowX();
  }
  set arrowX($$value) {
    return this.#arrowX($$value);
  }
  #arrowY = derived(() => this.floating.middlewareData.arrow?.y ?? 0);
  get arrowY() {
    return this.#arrowY();
  }
  set arrowY($$value) {
    return this.#arrowY($$value);
  }
  #cannotCenterArrow = derived(() => this.floating.middlewareData.arrow?.centerOffset !== 0);
  get cannotCenterArrow() {
    return this.#cannotCenterArrow();
  }
  set cannotCenterArrow($$value) {
    return this.#cannotCenterArrow($$value);
  }
  contentZIndex;
  #arrowBaseSide = derived(() => OPPOSITE_SIDE[this.placedSide]);
  get arrowBaseSide() {
    return this.#arrowBaseSide();
  }
  set arrowBaseSide($$value) {
    return this.#arrowBaseSide($$value);
  }
  #wrapperProps = derived(() => ({
    id: this.opts.wrapperId.current,
    "data-bits-floating-content-wrapper": "",
    style: {
      ...this.floating.floatingStyles,
      transform: this.floating.isPositioned ? this.floating.floatingStyles.transform : "translate(0, -200%)",
      minWidth: "max-content",
      zIndex: this.contentZIndex,
      "--bits-floating-transform-origin": `${this.floating.middlewareData.transformOrigin?.x} ${this.floating.middlewareData.transformOrigin?.y}`,
      "--bits-floating-available-width": `${this.#availableWidth}px`,
      "--bits-floating-available-height": `${this.#availableHeight}px`,
      "--bits-floating-anchor-width": `${this.#anchorWidth}px`,
      "--bits-floating-anchor-height": `${this.#anchorHeight}px`,
      ...this.floating.middlewareData.hide?.referenceHidden && { visibility: "hidden", "pointer-events": "none" },
      ...this.#transformedStyle()
    },
    dir: this.opts.dir.current,
    ...this.wrapperAttachment
  }));
  get wrapperProps() {
    return this.#wrapperProps();
  }
  set wrapperProps($$value) {
    return this.#wrapperProps($$value);
  }
  #props = derived(() => ({
    "data-side": this.placedSide,
    "data-align": this.placedAlign,
    style: styleToString$1({ ...this.#transformedStyle() }),
    ...this.contentAttachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
  #arrowStyle = derived(() => ({
    position: "absolute",
    left: this.arrowX ? `${this.arrowX}px` : void 0,
    top: this.arrowY ? `${this.arrowY}px` : void 0,
    [this.arrowBaseSide]: 0,
    "transform-origin": { top: "", right: "0 0", bottom: "center 0", left: "100% 0" }[this.placedSide],
    transform: {
      top: "translateY(100%)",
      right: "translateY(50%) rotate(90deg) translateX(-50%)",
      bottom: "rotate(180deg)",
      left: "translateY(50%) rotate(-90deg) translateX(50%)"
    }[this.placedSide],
    visibility: this.cannotCenterArrow ? "hidden" : void 0
  }));
  get arrowStyle() {
    return this.#arrowStyle();
  }
  set arrowStyle($$value) {
    return this.#arrowStyle($$value);
  }
  constructor(opts, root) {
    this.opts = opts;
    this.root = root;
    if (opts.customAnchor) {
      this.root.customAnchorNode.current = opts.customAnchor.current;
    }
    watch$2(() => opts.customAnchor.current, (customAnchor) => {
      this.root.customAnchorNode.current = customAnchor;
    });
    this.floating = useFloating({
      strategy: () => this.opts.strategy.current,
      placement: () => this.#desiredPlacement(),
      middleware: () => this.middleware,
      reference: this.root.anchorNode,
      open: () => this.opts.enabled.current,
      sideOffset: () => this.opts.sideOffset.current,
      alignOffset: () => this.opts.alignOffset.current
    });
    watch$2(() => this.contentRef.current, (contentNode) => {
      if (!contentNode) return;
      const win = getWindow(contentNode);
      this.contentZIndex = win.getComputedStyle(contentNode).zIndex;
    });
  }
}
class FloatingArrowState {
  static create(opts) {
    return new FloatingArrowState(opts, FloatingContentContext.get());
  }
  opts;
  content;
  constructor(opts, content) {
    this.opts = opts;
    this.content = content;
  }
  #props = derived(() => ({
    id: this.opts.id.current,
    style: this.content.arrowStyle,
    "data-side": this.content.placedSide,
    ...this.content.arrowAttachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class FloatingAnchorState {
  static create(opts, tooltip = false) {
    return tooltip ? new FloatingAnchorState(opts, FloatingTooltipRootContext.get()) : new FloatingAnchorState(opts, FloatingRootContext.get());
  }
  opts;
  root;
  constructor(opts, root) {
    this.opts = opts;
    this.root = root;
    if (opts.virtualEl && opts.virtualEl.current) {
      root.triggerNode = boxFrom$1(opts.virtualEl.current);
    } else {
      root.triggerNode = opts.ref;
    }
  }
}
function transformOrigin(options) {
  return {
    name: "transformOrigin",
    options,
    fn(data) {
      const { placement, rects, middlewareData } = data;
      const cannotCenterArrow = middlewareData.arrow?.centerOffset !== 0;
      const isArrowHidden = cannotCenterArrow;
      const arrowWidth = isArrowHidden ? 0 : options.arrowWidth;
      const arrowHeight = isArrowHidden ? 0 : options.arrowHeight;
      const [placedSide, placedAlign] = getSideAndAlignFromPlacement(placement);
      const noArrowAlign = { start: "0%", center: "50%", end: "100%" }[placedAlign];
      const arrowXCenter = (middlewareData.arrow?.x ?? 0) + arrowWidth / 2;
      const arrowYCenter = (middlewareData.arrow?.y ?? 0) + arrowHeight / 2;
      let x = "";
      let y = "";
      if (placedSide === "bottom") {
        x = isArrowHidden ? noArrowAlign : `${arrowXCenter}px`;
        y = `${-arrowHeight}px`;
      } else if (placedSide === "top") {
        x = isArrowHidden ? noArrowAlign : `${arrowXCenter}px`;
        y = `${rects.floating.height + arrowHeight}px`;
      } else if (placedSide === "right") {
        x = `${-arrowHeight}px`;
        y = isArrowHidden ? noArrowAlign : `${arrowYCenter}px`;
      } else if (placedSide === "left") {
        x = `${rects.floating.width + arrowHeight}px`;
        y = isArrowHidden ? noArrowAlign : `${arrowYCenter}px`;
      }
      return { data: { x, y } };
    }
  };
}
function getSideAndAlignFromPlacement(placement) {
  const [side, align = "center"] = placement.split("-");
  return [side, align];
}
function getSideFromPlacement(placement) {
  return getSideAndAlignFromPlacement(placement)[0];
}
function getAlignFromPlacement(placement) {
  return getSideAndAlignFromPlacement(placement)[1];
}
function Floating_layer($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { children, tooltip = false } = $$props;
    FloatingRootState.create(tooltip);
    children?.($$renderer2);
    $$renderer2.push(`<!---->`);
  });
}
function Floating_layer_anchor($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { id, children, virtualEl, ref, tooltip = false } = $$props;
    FloatingAnchorState.create(
      {
        id: boxWith$1(() => id),
        virtualEl: boxWith$1(() => virtualEl),
        ref
      },
      tooltip
    );
    children?.($$renderer2);
    $$renderer2.push(`<!---->`);
  });
}
function Arrow($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      id = useId(),
      children,
      child,
      width = 10,
      height = 5,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const mergedProps = mergeProps$1(restProps, { id });
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { props: mergedProps });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<span${attributes({ ...mergedProps })}>`);
      if (children) {
        $$renderer2.push("<!--[-->");
        children?.($$renderer2);
        $$renderer2.push(`<!---->`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<svg${attr("width", width)}${attr("height", height)} viewBox="0 0 30 10" preserveAspectRatio="none" data-arrow=""><polygon points="0,0 30,0 15,10" fill="currentColor"></polygon></svg>`);
      }
      $$renderer2.push(`<!--]--></span>`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function Floating_layer_arrow($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { id = useId(), ref = null, $$slots, $$events, ...restProps } = $$props;
    const arrowState = FloatingArrowState.create({
      id: boxWith$1(() => id),
      ref: boxWith$1(() => ref, (v) => ref = v)
    });
    const mergedProps = mergeProps$1(restProps, arrowState.props);
    Arrow($$renderer2, spread_props([mergedProps]));
    bind_props($$props, { ref });
  });
}
function Floating_layer_content($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      content,
      side = "bottom",
      sideOffset = 0,
      align = "center",
      alignOffset = 0,
      id,
      arrowPadding = 0,
      avoidCollisions = true,
      collisionBoundary = [],
      collisionPadding = 0,
      hideWhenDetached = false,
      onPlaced = () => {
      },
      sticky = "partial",
      updatePositionStrategy = "optimized",
      strategy = "fixed",
      dir = "ltr",
      style = {},
      wrapperId = useId(),
      customAnchor = null,
      enabled,
      tooltip = false
    } = $$props;
    const contentState = FloatingContentState.create(
      {
        side: boxWith$1(() => side),
        sideOffset: boxWith$1(() => sideOffset),
        align: boxWith$1(() => align),
        alignOffset: boxWith$1(() => alignOffset),
        id: boxWith$1(() => id),
        arrowPadding: boxWith$1(() => arrowPadding),
        avoidCollisions: boxWith$1(() => avoidCollisions),
        collisionBoundary: boxWith$1(() => collisionBoundary),
        collisionPadding: boxWith$1(() => collisionPadding),
        hideWhenDetached: boxWith$1(() => hideWhenDetached),
        onPlaced: boxWith$1(() => onPlaced),
        sticky: boxWith$1(() => sticky),
        updatePositionStrategy: boxWith$1(() => updatePositionStrategy),
        strategy: boxWith$1(() => strategy),
        dir: boxWith$1(() => dir),
        style: boxWith$1(() => style),
        enabled: boxWith$1(() => enabled),
        wrapperId: boxWith$1(() => wrapperId),
        customAnchor: boxWith$1(() => customAnchor)
      },
      tooltip
    );
    const mergedProps = mergeProps$1(contentState.wrapperProps, { style: { pointerEvents: "auto" } });
    content?.($$renderer2, { props: contentState.props, wrapperProps: mergedProps });
    $$renderer2.push(`<!---->`);
  });
}
function Floating_layer_content_static($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { content } = $$props;
    content?.($$renderer2, { props: {}, wrapperProps: {} });
    $$renderer2.push(`<!---->`);
  });
}
function Popper_content($$renderer, $$props) {
  let {
    content,
    isStatic = false,
    onPlaced,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  if (isStatic) {
    $$renderer.push("<!--[-->");
    Floating_layer_content_static($$renderer, { content });
  } else {
    $$renderer.push("<!--[!-->");
    Floating_layer_content($$renderer, spread_props([{ content, onPlaced }, restProps]));
  }
  $$renderer.push(`<!--]-->`);
}
function Popper_layer_inner($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      popper,
      onEscapeKeydown,
      escapeKeydownBehavior,
      preventOverflowTextSelection,
      id,
      onPointerDown,
      onPointerUp,
      side,
      sideOffset,
      align,
      alignOffset,
      arrowPadding,
      avoidCollisions,
      collisionBoundary,
      collisionPadding,
      sticky,
      hideWhenDetached,
      updatePositionStrategy,
      strategy,
      dir,
      preventScroll,
      wrapperId,
      style,
      onPlaced,
      onInteractOutside,
      onCloseAutoFocus,
      onOpenAutoFocus,
      onFocusOutside,
      interactOutsideBehavior = "close",
      loop,
      trapFocus = true,
      isValidEvent: isValidEvent2 = () => false,
      customAnchor = null,
      isStatic = false,
      enabled,
      ref,
      tooltip = false,
      contentPointerEvents = "auto",
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    {
      let content = function($$renderer3, { props: floatingProps, wrapperProps }) {
        if (restProps.forceMount && enabled) {
          $$renderer3.push("<!--[-->");
          Scroll_lock($$renderer3, { preventScroll });
        } else if (!restProps.forceMount) {
          $$renderer3.push("<!--[1-->");
          Scroll_lock($$renderer3, { preventScroll });
        } else {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]--> `);
        {
          let focusScope = function($$renderer4, { props: focusScopeProps }) {
            Escape_layer($$renderer4, {
              onEscapeKeydown,
              escapeKeydownBehavior,
              enabled,
              ref,
              children: ($$renderer5) => {
                {
                  let children = function($$renderer6, { props: dismissibleProps }) {
                    Text_selection_layer($$renderer6, {
                      id,
                      preventOverflowTextSelection,
                      onPointerDown,
                      onPointerUp,
                      enabled,
                      ref,
                      children: ($$renderer7) => {
                        popper?.($$renderer7, {
                          props: mergeProps$1(restProps, floatingProps, dismissibleProps, focusScopeProps, { style: { pointerEvents: contentPointerEvents } }),
                          wrapperProps
                        });
                        $$renderer7.push(`<!---->`);
                      }
                    });
                  };
                  Dismissible_layer($$renderer5, {
                    id,
                    onInteractOutside,
                    onFocusOutside,
                    interactOutsideBehavior,
                    isValidEvent: isValidEvent2,
                    enabled,
                    ref,
                    children
                  });
                }
              }
            });
          };
          Focus_scope($$renderer3, {
            onOpenAutoFocus,
            onCloseAutoFocus,
            loop,
            enabled,
            trapFocus,
            forceMount: restProps.forceMount,
            ref,
            focusScope
          });
        }
        $$renderer3.push(`<!---->`);
      };
      Popper_content($$renderer2, {
        isStatic,
        id,
        side,
        sideOffset,
        align,
        alignOffset,
        arrowPadding,
        avoidCollisions,
        collisionBoundary,
        collisionPadding,
        sticky,
        hideWhenDetached,
        updatePositionStrategy,
        strategy,
        dir,
        wrapperId,
        style,
        onPlaced,
        customAnchor,
        enabled,
        tooltip,
        content,
        $$slots: { content: true }
      });
    }
  });
}
function Popper_layer($$renderer, $$props) {
  let {
    popper,
    open,
    onEscapeKeydown,
    escapeKeydownBehavior,
    preventOverflowTextSelection,
    id,
    onPointerDown,
    onPointerUp,
    side,
    sideOffset,
    align,
    alignOffset,
    arrowPadding,
    avoidCollisions,
    collisionBoundary,
    collisionPadding,
    sticky,
    hideWhenDetached,
    updatePositionStrategy,
    strategy,
    dir,
    preventScroll,
    wrapperId,
    style,
    onPlaced,
    onInteractOutside,
    onCloseAutoFocus,
    onOpenAutoFocus,
    onFocusOutside,
    interactOutsideBehavior = "close",
    loop,
    trapFocus = true,
    isValidEvent: isValidEvent2 = () => false,
    customAnchor = null,
    isStatic = false,
    ref,
    shouldRender,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  if (shouldRender) {
    $$renderer.push("<!--[-->");
    Popper_layer_inner($$renderer, spread_props([
      {
        popper,
        onEscapeKeydown,
        escapeKeydownBehavior,
        preventOverflowTextSelection,
        id,
        onPointerDown,
        onPointerUp,
        side,
        sideOffset,
        align,
        alignOffset,
        arrowPadding,
        avoidCollisions,
        collisionBoundary,
        collisionPadding,
        sticky,
        hideWhenDetached,
        updatePositionStrategy,
        strategy,
        dir,
        preventScroll,
        wrapperId,
        style,
        onPlaced,
        customAnchor,
        isStatic,
        enabled: open,
        onInteractOutside,
        onCloseAutoFocus,
        onOpenAutoFocus,
        interactOutsideBehavior,
        loop,
        trapFocus,
        isValidEvent: isValidEvent2,
        onFocusOutside,
        forceMount: false,
        ref
      },
      restProps
    ]));
  } else {
    $$renderer.push("<!--[!-->");
  }
  $$renderer.push(`<!--]-->`);
}
function Popper_layer_force_mount($$renderer, $$props) {
  let {
    popper,
    onEscapeKeydown,
    escapeKeydownBehavior,
    preventOverflowTextSelection,
    id,
    onPointerDown,
    onPointerUp,
    side,
    sideOffset,
    align,
    alignOffset,
    arrowPadding,
    avoidCollisions,
    collisionBoundary,
    collisionPadding,
    sticky,
    hideWhenDetached,
    updatePositionStrategy,
    strategy,
    dir,
    preventScroll,
    wrapperId,
    style,
    onPlaced,
    onInteractOutside,
    onCloseAutoFocus,
    onOpenAutoFocus,
    onFocusOutside,
    interactOutsideBehavior = "close",
    loop,
    trapFocus = true,
    isValidEvent: isValidEvent2 = () => false,
    customAnchor = null,
    isStatic = false,
    enabled,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  Popper_layer_inner($$renderer, spread_props([
    {
      popper,
      onEscapeKeydown,
      escapeKeydownBehavior,
      preventOverflowTextSelection,
      id,
      onPointerDown,
      onPointerUp,
      side,
      sideOffset,
      align,
      alignOffset,
      arrowPadding,
      avoidCollisions,
      collisionBoundary,
      collisionPadding,
      sticky,
      hideWhenDetached,
      updatePositionStrategy,
      strategy,
      dir,
      preventScroll,
      wrapperId,
      style,
      onPlaced,
      customAnchor,
      isStatic,
      enabled,
      onInteractOutside,
      onCloseAutoFocus,
      onOpenAutoFocus,
      interactOutsideBehavior,
      loop,
      trapFocus,
      isValidEvent: isValidEvent2,
      onFocusOutside
    },
    restProps,
    { forceMount: true }
  ]));
}
function Context_menu$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      open = false,
      dir = "ltr",
      onOpenChange = noop$1,
      onOpenChangeComplete = noop$1,
      children
    } = $$props;
    const root = MenuRootState.create({
      variant: boxWith$1(() => "context-menu"),
      dir: boxWith$1(() => dir),
      onClose: () => {
        open = false;
        onOpenChange?.(false);
      }
    });
    MenuMenuState.create(
      {
        open: boxWith$1(() => open, (v) => {
          open = v;
          onOpenChange(v);
        }),
        onOpenChangeComplete: boxWith$1(() => onOpenChangeComplete)
      },
      root
    );
    Floating_layer($$renderer2, {
      children: ($$renderer3) => {
        children?.($$renderer3);
        $$renderer3.push(`<!---->`);
      }
    });
    bind_props($$props, { open });
  });
}
function Menu_sub($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      open = false,
      onOpenChange = noop$1,
      onOpenChangeComplete = noop$1,
      children
    } = $$props;
    MenuSubmenuState.create({
      open: boxWith$1(() => open, (v) => {
        open = v;
        onOpenChange?.(v);
      }),
      onOpenChangeComplete: boxWith$1(() => onOpenChangeComplete)
    });
    Floating_layer($$renderer2, {
      children: ($$renderer3) => {
        children?.($$renderer3);
        $$renderer3.push(`<!---->`);
      }
    });
    bind_props($$props, { open });
  });
}
function Menu_item($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      child,
      children,
      ref = null,
      id = createId(uid),
      disabled = false,
      onSelect = noop$1,
      closeOnSelect = true,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const itemState = MenuItemState.create({
      id: boxWith$1(() => id),
      disabled: boxWith$1(() => disabled),
      onSelect: boxWith$1(() => onSelect),
      ref: boxWith$1(() => ref, (v) => ref = v),
      closeOnSelect: boxWith$1(() => closeOnSelect)
    });
    const mergedProps = mergeProps$1(restProps, itemState.props);
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { props: mergedProps });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attributes({ ...mergedProps })}>`);
      children?.($$renderer2);
      $$renderer2.push(`<!----></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref });
  });
}
function Context_menu_content$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      id = useId(),
      child,
      children,
      ref = null,
      loop = true,
      onInteractOutside = noop$1,
      onCloseAutoFocus = noop$1,
      onOpenAutoFocus = noop$1,
      preventScroll = true,
      side = "right",
      sideOffset = 2,
      align = "start",
      // we need to explicitly pass this prop to the PopperLayer to override
      // the default menu behavior of handling outside interactions on the trigger
      onEscapeKeydown = noop$1,
      forceMount = false,
      trapFocus = false,
      style,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const contentState = MenuContentState.create({
      id: boxWith$1(() => id),
      loop: boxWith$1(() => loop),
      ref: boxWith$1(() => ref, (v) => ref = v),
      onCloseAutoFocus: boxWith$1(() => onCloseAutoFocus)
    });
    const mergedProps = mergeProps$1(restProps, contentState.props, {
      side,
      sideOffset,
      align,
      onOpenAutoFocus,
      isValidEvent: isValidEvent2,
      trapFocus,
      loop,
      id,
      ref: contentState.opts.ref,
      preventScroll,
      onInteractOutside: handleInteractOutside,
      onEscapeKeydown: handleEscapeKeydown,
      shouldRender: contentState.shouldRender
    });
    function handleInteractOutside(e) {
      onInteractOutside(e);
      if (e.defaultPrevented) return;
      if (e.target && e.target instanceof Element) {
        const subContentSelector = `[${contentState.parentMenu.root.getBitsAttr("sub-content")}]`;
        if (e.target.closest(subContentSelector)) return;
      }
      contentState.parentMenu.onClose();
    }
    function handleEscapeKeydown(e) {
      onEscapeKeydown(e);
      if (e.defaultPrevented) return;
      contentState.parentMenu.onClose();
    }
    function isValidEvent2(e) {
      if ("button" in e && e.button === 2) {
        const target = e.target;
        if (!target) return false;
        const isAnotherContextTrigger = target.closest(`[${CONTEXT_MENU_TRIGGER_ATTR}]`) !== contentState.parentMenu.triggerNode;
        return isAnotherContextTrigger;
      }
      return false;
    }
    if (forceMount) {
      $$renderer2.push("<!--[-->");
      {
        let popper = function($$renderer3, { props, wrapperProps }) {
          const finalProps = mergeProps$1(props, { style: getFloatingContentCSSVars("context-menu") }, { style });
          if (child) {
            $$renderer3.push("<!--[-->");
            child($$renderer3, {
              props: finalProps,
              wrapperProps,
              ...contentState.snippetProps
            });
            $$renderer3.push(`<!---->`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div${attributes({ ...wrapperProps })}><div${attributes({ ...finalProps })}>`);
            children?.($$renderer3);
            $$renderer3.push(`<!----></div></div>`);
          }
          $$renderer3.push(`<!--]-->`);
        };
        Popper_layer_force_mount($$renderer2, spread_props([
          mergedProps,
          contentState.popperProps,
          {
            enabled: contentState.parentMenu.opts.open.current,
            popper,
            $$slots: { popper: true }
          }
        ]));
      }
    } else if (!forceMount) {
      $$renderer2.push("<!--[1-->");
      {
        let popper = function($$renderer3, { props, wrapperProps }) {
          const finalProps = mergeProps$1(props, { style: getFloatingContentCSSVars("context-menu") }, { style });
          if (child) {
            $$renderer3.push("<!--[-->");
            child($$renderer3, {
              props: finalProps,
              wrapperProps,
              ...contentState.snippetProps
            });
            $$renderer3.push(`<!---->`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div${attributes({ ...wrapperProps })}><div${attributes({ ...finalProps })}>`);
            children?.($$renderer3);
            $$renderer3.push(`<!----></div></div>`);
          }
          $$renderer3.push(`<!--]-->`);
        };
        Popper_layer($$renderer2, spread_props([
          mergedProps,
          contentState.popperProps,
          {
            open: contentState.parentMenu.opts.open.current,
            popper,
            $$slots: { popper: true }
          }
        ]));
      }
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref });
  });
}
function Context_menu_trigger$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      id = useId(),
      ref = null,
      child,
      children,
      disabled = false,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const triggerState = ContextMenuTriggerState.create({
      id: boxWith$1(() => id),
      disabled: boxWith$1(() => disabled),
      ref: boxWith$1(() => ref, (v) => ref = v)
    });
    const mergedProps = mergeProps$1(restProps, triggerState.props, { style: { pointerEvents: "auto" } }, { style: restProps.style, tabindex: restProps.tabindex });
    $$renderer2.push("<!---->");
    Floating_layer_anchor?.($$renderer2, {
      id,
      virtualEl: triggerState.virtualElement,
      ref: triggerState.opts.ref,
      children: ($$renderer3) => {
        if (child) {
          $$renderer3.push("<!--[-->");
          child($$renderer3, { props: mergedProps });
          $$renderer3.push(`<!---->`);
        } else {
          $$renderer3.push("<!--[!-->");
          $$renderer3.push(`<div${attributes({ ...mergedProps })}>`);
          children?.($$renderer3);
          $$renderer3.push(`<!----></div>`);
        }
        $$renderer3.push(`<!--]-->`);
      }
    });
    $$renderer2.push(`<!---->`);
    bind_props($$props, { ref });
  });
}
function Menu_radio_item($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      children,
      child,
      ref = null,
      value,
      onSelect = noop$1,
      id = createId(uid),
      disabled = false,
      closeOnSelect = true,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const radioItemState = MenuRadioItemState.create({
      value: boxWith$1(() => value),
      id: boxWith$1(() => id),
      disabled: boxWith$1(() => disabled),
      onSelect: boxWith$1(() => handleSelect),
      ref: boxWith$1(() => ref, (v) => ref = v),
      closeOnSelect: boxWith$1(() => closeOnSelect)
    });
    function handleSelect(e) {
      onSelect(e);
      if (e.defaultPrevented) return;
      radioItemState.selectValue();
    }
    const mergedProps = mergeProps$1(restProps, radioItemState.props);
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { props: mergedProps, checked: radioItemState.isChecked });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attributes({ ...mergedProps })}>`);
      children?.($$renderer2, { checked: radioItemState.isChecked });
      $$renderer2.push(`<!----></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref });
  });
}
function Menu_separator($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      ref = null,
      id = createId(uid),
      child,
      children,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const separatorState = MenuSeparatorState.create({
      id: boxWith$1(() => id),
      ref: boxWith$1(() => ref, (v) => ref = v)
    });
    const mergedProps = mergeProps$1(restProps, separatorState.props);
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { props: mergedProps });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attributes({ ...mergedProps })}>`);
      children?.($$renderer2);
      $$renderer2.push(`<!----></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref });
  });
}
function Menu_radio_group($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      id = createId(uid),
      children,
      child,
      ref = null,
      value = "",
      onValueChange = noop$1,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const radioGroupState = MenuRadioGroupState.create({
      value: boxWith$1(() => value, (v) => {
        value = v;
        onValueChange(v);
      }),
      ref: boxWith$1(() => ref, (v) => ref = v),
      id: boxWith$1(() => id)
    });
    const mergedProps = mergeProps$1(restProps, radioGroupState.props);
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { props: mergedProps });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attributes({ ...mergedProps })}>`);
      children?.($$renderer2);
      $$renderer2.push(`<!----></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref, value });
  });
}
function Menu_sub_content($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      id = createId(uid),
      ref = null,
      children,
      child,
      loop = true,
      onInteractOutside = noop$1,
      forceMount = false,
      onEscapeKeydown = noop$1,
      interactOutsideBehavior = "defer-otherwise-close",
      escapeKeydownBehavior = "defer-otherwise-close",
      onOpenAutoFocus: onOpenAutoFocusProp = noop$1,
      onCloseAutoFocus: onCloseAutoFocusProp = noop$1,
      onFocusOutside = noop$1,
      side = "right",
      trapFocus = false,
      style,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const subContentState = MenuContentState.create({
      id: boxWith$1(() => id),
      loop: boxWith$1(() => loop),
      ref: boxWith$1(() => ref, (v) => ref = v),
      isSub: true,
      onCloseAutoFocus: boxWith$1(() => handleCloseAutoFocus)
    });
    function onkeydown(e) {
      const isKeyDownInside = e.currentTarget.contains(e.target);
      const isCloseKey = SUB_CLOSE_KEYS[subContentState.parentMenu.root.opts.dir.current].includes(e.key);
      if (isKeyDownInside && isCloseKey) {
        subContentState.parentMenu.onClose();
        const triggerNode = subContentState.parentMenu.triggerNode;
        triggerNode?.focus();
        e.preventDefault();
      }
    }
    const dataAttr = subContentState.parentMenu.root.getBitsAttr("sub-content");
    const mergedProps = mergeProps$1(restProps, subContentState.props, { side, onkeydown, [dataAttr]: "" });
    function handleOpenAutoFocus(e) {
      onOpenAutoFocusProp(e);
      if (e.defaultPrevented) return;
      e.preventDefault();
      if (subContentState.parentMenu.root.isUsingKeyboard && subContentState.parentMenu.contentNode) {
        MenuOpenEvent.dispatch(subContentState.parentMenu.contentNode);
      }
    }
    function handleCloseAutoFocus(e) {
      onCloseAutoFocusProp(e);
      if (e.defaultPrevented) return;
      e.preventDefault();
    }
    function handleInteractOutside(e) {
      onInteractOutside(e);
      if (e.defaultPrevented) return;
      subContentState.parentMenu.onClose();
    }
    function handleEscapeKeydown(e) {
      onEscapeKeydown(e);
      if (e.defaultPrevented) return;
      subContentState.parentMenu.onClose();
    }
    function handleOnFocusOutside(e) {
      onFocusOutside(e);
      if (e.defaultPrevented) return;
      if (!isHTMLElement$1(e.target)) return;
      if (e.target.id !== subContentState.parentMenu.triggerNode?.id) {
        subContentState.parentMenu.onClose();
      }
    }
    if (forceMount) {
      $$renderer2.push("<!--[-->");
      {
        let popper = function($$renderer3, { props, wrapperProps }) {
          const finalProps = mergeProps$1(props, mergedProps, { style: getFloatingContentCSSVars("menu") }, { style });
          if (child) {
            $$renderer3.push("<!--[-->");
            child($$renderer3, {
              props: finalProps,
              wrapperProps,
              ...subContentState.snippetProps
            });
            $$renderer3.push(`<!---->`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div${attributes({ ...wrapperProps })}><div${attributes({ ...finalProps })}>`);
            children?.($$renderer3);
            $$renderer3.push(`<!----></div></div>`);
          }
          $$renderer3.push(`<!--]-->`);
        };
        Popper_layer_force_mount($$renderer2, spread_props([
          mergedProps,
          {
            ref: subContentState.opts.ref,
            interactOutsideBehavior,
            escapeKeydownBehavior,
            onOpenAutoFocus: handleOpenAutoFocus,
            enabled: subContentState.parentMenu.opts.open.current,
            onInteractOutside: handleInteractOutside,
            onEscapeKeydown: handleEscapeKeydown,
            onFocusOutside: handleOnFocusOutside,
            preventScroll: false,
            loop,
            trapFocus,
            shouldRender: subContentState.shouldRender,
            popper,
            $$slots: { popper: true }
          }
        ]));
      }
    } else if (!forceMount) {
      $$renderer2.push("<!--[1-->");
      {
        let popper = function($$renderer3, { props, wrapperProps }) {
          const finalProps = mergeProps$1(props, mergedProps, { style: getFloatingContentCSSVars("menu") }, { style });
          if (child) {
            $$renderer3.push("<!--[-->");
            child($$renderer3, {
              props: finalProps,
              wrapperProps,
              ...subContentState.snippetProps
            });
            $$renderer3.push(`<!---->`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div${attributes({ ...wrapperProps })}><div${attributes({ ...finalProps })}>`);
            children?.($$renderer3);
            $$renderer3.push(`<!----></div></div>`);
          }
          $$renderer3.push(`<!--]-->`);
        };
        Popper_layer($$renderer2, spread_props([
          mergedProps,
          {
            ref: subContentState.opts.ref,
            interactOutsideBehavior,
            escapeKeydownBehavior,
            onCloseAutoFocus: handleCloseAutoFocus,
            onOpenAutoFocus: handleOpenAutoFocus,
            open: subContentState.parentMenu.opts.open.current,
            onInteractOutside: handleInteractOutside,
            onEscapeKeydown: handleEscapeKeydown,
            onFocusOutside: handleOnFocusOutside,
            preventScroll: false,
            loop,
            trapFocus,
            shouldRender: subContentState.shouldRender,
            popper,
            $$slots: { popper: true }
          }
        ]));
      }
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref });
  });
}
function Menu_sub_trigger($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      id = createId(uid),
      disabled = false,
      ref = null,
      children,
      child,
      onSelect = noop$1,
      openDelay = 100,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const subTriggerState = MenuSubTriggerState.create({
      disabled: boxWith$1(() => disabled),
      onSelect: boxWith$1(() => onSelect),
      id: boxWith$1(() => id),
      ref: boxWith$1(() => ref, (v) => ref = v),
      openDelay: boxWith$1(() => openDelay)
    });
    const mergedProps = mergeProps$1(restProps, subTriggerState.props);
    Floating_layer_anchor($$renderer2, {
      id,
      ref: subTriggerState.opts.ref,
      children: ($$renderer3) => {
        if (child) {
          $$renderer3.push("<!--[-->");
          child($$renderer3, { props: mergedProps });
          $$renderer3.push(`<!---->`);
        } else {
          $$renderer3.push("<!--[!-->");
          $$renderer3.push(`<div${attributes({ ...mergedProps })}>`);
          children?.($$renderer3);
          $$renderer3.push(`<!----></div>`);
        }
        $$renderer3.push(`<!--]-->`);
      }
    });
    bind_props($$props, { ref });
  });
}
function Menu($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      open = false,
      dir = "ltr",
      onOpenChange = noop$1,
      onOpenChangeComplete = noop$1,
      _internal_variant: variant = "dropdown-menu",
      children
    } = $$props;
    const root = MenuRootState.create({
      variant: boxWith$1(() => variant),
      dir: boxWith$1(() => dir),
      onClose: () => {
        open = false;
        onOpenChange(false);
      }
    });
    MenuMenuState.create(
      {
        open: boxWith$1(() => open, (v) => {
          open = v;
          onOpenChange(v);
        }),
        onOpenChangeComplete: boxWith$1(() => onOpenChangeComplete)
      },
      root
    );
    Floating_layer($$renderer2, {
      children: ($$renderer3) => {
        children?.($$renderer3);
        $$renderer3.push(`<!---->`);
      }
    });
    bind_props($$props, { open });
  });
}
function Dropdown_menu_content$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      id = createId(uid),
      child,
      children,
      ref = null,
      loop = true,
      onInteractOutside = noop$1,
      onEscapeKeydown = noop$1,
      onCloseAutoFocus = noop$1,
      forceMount = false,
      trapFocus = false,
      style,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const contentState = MenuContentState.create({
      id: boxWith$1(() => id),
      loop: boxWith$1(() => loop),
      ref: boxWith$1(() => ref, (v) => ref = v),
      onCloseAutoFocus: boxWith$1(() => onCloseAutoFocus)
    });
    const mergedProps = mergeProps$1(restProps, contentState.props);
    function handleInteractOutside(e) {
      contentState.handleInteractOutside(e);
      if (e.defaultPrevented) return;
      onInteractOutside(e);
      if (e.defaultPrevented) return;
      if (e.target && e.target instanceof Element) {
        const subContentSelector = `[${contentState.parentMenu.root.getBitsAttr("sub-content")}]`;
        if (e.target.closest(subContentSelector)) return;
      }
      contentState.parentMenu.onClose();
    }
    function handleEscapeKeydown(e) {
      onEscapeKeydown(e);
      if (e.defaultPrevented) return;
      contentState.parentMenu.onClose();
    }
    if (forceMount) {
      $$renderer2.push("<!--[-->");
      {
        let popper = function($$renderer3, { props, wrapperProps }) {
          const finalProps = mergeProps$1(props, { style: getFloatingContentCSSVars("dropdown-menu") }, { style });
          if (child) {
            $$renderer3.push("<!--[-->");
            child($$renderer3, {
              props: finalProps,
              wrapperProps,
              ...contentState.snippetProps
            });
            $$renderer3.push(`<!---->`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div${attributes({ ...wrapperProps })}><div${attributes({ ...finalProps })}>`);
            children?.($$renderer3);
            $$renderer3.push(`<!----></div></div>`);
          }
          $$renderer3.push(`<!--]-->`);
        };
        Popper_layer_force_mount($$renderer2, spread_props([
          mergedProps,
          contentState.popperProps,
          {
            ref: contentState.opts.ref,
            enabled: contentState.parentMenu.opts.open.current,
            onInteractOutside: handleInteractOutside,
            onEscapeKeydown: handleEscapeKeydown,
            trapFocus,
            loop,
            forceMount: true,
            id,
            shouldRender: contentState.shouldRender,
            popper,
            $$slots: { popper: true }
          }
        ]));
      }
    } else if (!forceMount) {
      $$renderer2.push("<!--[1-->");
      {
        let popper = function($$renderer3, { props, wrapperProps }) {
          const finalProps = mergeProps$1(props, { style: getFloatingContentCSSVars("dropdown-menu") }, { style });
          if (child) {
            $$renderer3.push("<!--[-->");
            child($$renderer3, {
              props: finalProps,
              wrapperProps,
              ...contentState.snippetProps
            });
            $$renderer3.push(`<!---->`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div${attributes({ ...wrapperProps })}><div${attributes({ ...finalProps })}>`);
            children?.($$renderer3);
            $$renderer3.push(`<!----></div></div>`);
          }
          $$renderer3.push(`<!--]-->`);
        };
        Popper_layer($$renderer2, spread_props([
          mergedProps,
          contentState.popperProps,
          {
            ref: contentState.opts.ref,
            open: contentState.parentMenu.opts.open.current,
            onInteractOutside: handleInteractOutside,
            onEscapeKeydown: handleEscapeKeydown,
            trapFocus,
            loop,
            forceMount: false,
            id,
            shouldRender: contentState.shouldRender,
            popper,
            $$slots: { popper: true }
          }
        ]));
      }
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref });
  });
}
function Menu_trigger($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      id = createId(uid),
      ref = null,
      child,
      children,
      disabled = false,
      type = "button",
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const triggerState = DropdownMenuTriggerState.create({
      id: boxWith$1(() => id),
      disabled: boxWith$1(() => disabled ?? false),
      ref: boxWith$1(() => ref, (v) => ref = v)
    });
    const mergedProps = mergeProps$1(restProps, triggerState.props, { type });
    Floating_layer_anchor($$renderer2, {
      id,
      ref: triggerState.opts.ref,
      children: ($$renderer3) => {
        if (child) {
          $$renderer3.push("<!--[-->");
          child($$renderer3, { props: mergedProps });
          $$renderer3.push(`<!---->`);
        } else {
          $$renderer3.push("<!--[!-->");
          $$renderer3.push(`<button${attributes({ ...mergedProps })}>`);
          children?.($$renderer3);
          $$renderer3.push(`<!----></button>`);
        }
        $$renderer3.push(`<!--]-->`);
      }
    });
    bind_props($$props, { ref });
  });
}
function Tooltip$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      open = false,
      onOpenChange = noop$1,
      onOpenChangeComplete = noop$1,
      disabled,
      delayDuration,
      disableCloseOnTriggerClick,
      disableHoverableContent,
      ignoreNonKeyboardFocus,
      children
    } = $$props;
    TooltipRootState.create({
      open: boxWith$1(() => open, (v) => {
        open = v;
        onOpenChange(v);
      }),
      delayDuration: boxWith$1(() => delayDuration),
      disableCloseOnTriggerClick: boxWith$1(() => disableCloseOnTriggerClick),
      disableHoverableContent: boxWith$1(() => disableHoverableContent),
      ignoreNonKeyboardFocus: boxWith$1(() => ignoreNonKeyboardFocus),
      disabled: boxWith$1(() => disabled),
      onOpenChangeComplete: boxWith$1(() => onOpenChangeComplete)
    });
    Floating_layer($$renderer2, {
      tooltip: true,
      children: ($$renderer3) => {
        children?.($$renderer3);
        $$renderer3.push(`<!---->`);
      }
    });
    bind_props($$props, { open });
  });
}
function Tooltip_content$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      children,
      child,
      id = createId(uid),
      ref = null,
      side = "top",
      sideOffset = 0,
      align = "center",
      avoidCollisions = true,
      arrowPadding = 0,
      sticky = "partial",
      strategy,
      hideWhenDetached = false,
      collisionPadding = 0,
      onInteractOutside = noop$1,
      onEscapeKeydown = noop$1,
      forceMount = false,
      style,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const contentState = TooltipContentState.create({
      id: boxWith$1(() => id),
      ref: boxWith$1(() => ref, (v) => ref = v),
      onInteractOutside: boxWith$1(() => onInteractOutside),
      onEscapeKeydown: boxWith$1(() => onEscapeKeydown)
    });
    const floatingProps = {
      side,
      sideOffset,
      align,
      avoidCollisions,
      arrowPadding,
      sticky,
      hideWhenDetached,
      collisionPadding,
      strategy
    };
    const mergedProps = mergeProps$1(restProps, floatingProps, contentState.props);
    if (forceMount) {
      $$renderer2.push("<!--[-->");
      {
        let popper = function($$renderer3, { props, wrapperProps }) {
          const finalProps = mergeProps$1(props, { style: getFloatingContentCSSVars("tooltip") }, { style });
          if (child) {
            $$renderer3.push("<!--[-->");
            child($$renderer3, {
              props: finalProps,
              wrapperProps,
              ...contentState.snippetProps
            });
            $$renderer3.push(`<!---->`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div${attributes({ ...wrapperProps })}><div${attributes({ ...finalProps })}>`);
            children?.($$renderer3);
            $$renderer3.push(`<!----></div></div>`);
          }
          $$renderer3.push(`<!--]-->`);
        };
        Popper_layer_force_mount($$renderer2, spread_props([
          mergedProps,
          contentState.popperProps,
          {
            enabled: contentState.root.opts.open.current,
            id,
            trapFocus: false,
            loop: false,
            preventScroll: false,
            forceMount: true,
            ref: contentState.opts.ref,
            tooltip: true,
            shouldRender: contentState.shouldRender,
            contentPointerEvents: contentState.root.disableHoverableContent ? "none" : "auto",
            popper,
            $$slots: { popper: true }
          }
        ]));
      }
    } else if (!forceMount) {
      $$renderer2.push("<!--[1-->");
      {
        let popper = function($$renderer3, { props, wrapperProps }) {
          const finalProps = mergeProps$1(props, { style: getFloatingContentCSSVars("tooltip") }, { style });
          if (child) {
            $$renderer3.push("<!--[-->");
            child($$renderer3, {
              props: finalProps,
              wrapperProps,
              ...contentState.snippetProps
            });
            $$renderer3.push(`<!---->`);
          } else {
            $$renderer3.push("<!--[!-->");
            $$renderer3.push(`<div${attributes({ ...wrapperProps })}><div${attributes({ ...finalProps })}>`);
            children?.($$renderer3);
            $$renderer3.push(`<!----></div></div>`);
          }
          $$renderer3.push(`<!--]-->`);
        };
        Popper_layer($$renderer2, spread_props([
          mergedProps,
          contentState.popperProps,
          {
            open: contentState.root.opts.open.current,
            id,
            trapFocus: false,
            loop: false,
            preventScroll: false,
            forceMount: false,
            ref: contentState.opts.ref,
            tooltip: true,
            shouldRender: contentState.shouldRender,
            contentPointerEvents: contentState.root.disableHoverableContent ? "none" : "auto",
            popper,
            $$slots: { popper: true }
          }
        ]));
      }
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref });
  });
}
function Tooltip_trigger$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      children,
      child,
      id = createId(uid),
      disabled = false,
      type = "button",
      tabindex = 0,
      ref = null,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const triggerState = TooltipTriggerState.create({
      id: boxWith$1(() => id),
      disabled: boxWith$1(() => disabled ?? false),
      tabindex: boxWith$1(() => tabindex ?? 0),
      ref: boxWith$1(() => ref, (v) => ref = v)
    });
    const mergedProps = mergeProps$1(restProps, triggerState.props, { type });
    Floating_layer_anchor($$renderer2, {
      id,
      ref: triggerState.opts.ref,
      tooltip: true,
      children: ($$renderer3) => {
        if (child) {
          $$renderer3.push("<!--[-->");
          child($$renderer3, { props: mergedProps });
          $$renderer3.push(`<!---->`);
        } else {
          $$renderer3.push("<!--[!-->");
          $$renderer3.push(`<button${attributes({ ...mergedProps })}>`);
          children?.($$renderer3);
          $$renderer3.push(`<!----></button>`);
        }
        $$renderer3.push(`<!--]-->`);
      }
    });
    bind_props($$props, { ref });
  });
}
function Tooltip_arrow($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { ref = null, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      Floating_layer_arrow($$renderer3, spread_props([
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Tooltip($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { open = false, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Tooltip$1?.($$renderer3, spread_props([
        restProps,
        {
          get open() {
            return open;
          },
          set open($$value) {
            open = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { open });
  });
}
function Tooltip_trigger($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { ref = null, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Tooltip_trigger$1?.($$renderer3, spread_props([
        { "data-slot": "tooltip-trigger" },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Tooltip_portal($$renderer, $$props) {
  let { $$slots, $$events, ...restProps } = $$props;
  $$renderer.push("<!---->");
  Portal?.($$renderer, spread_props([restProps]));
  $$renderer.push(`<!---->`);
}
function Tooltip_content($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      class: className,
      sideOffset = 0,
      side = "top",
      children,
      arrowClasses,
      portalProps,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      Tooltip_portal($$renderer3, spread_props([
        portalProps,
        {
          children: ($$renderer4) => {
            $$renderer4.push("<!---->");
            Tooltip_content$1?.($$renderer4, spread_props([
              {
                "data-slot": "tooltip-content",
                sideOffset,
                side,
                class: cn$1("bg-foreground text-background animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-end-2 data-[side=right]:slide-in-from-start-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit origin-(--bits-tooltip-content-transform-origin) rounded-md px-3 py-1.5 text-xs text-balance", className)
              },
              restProps,
              {
                get ref() {
                  return ref;
                },
                set ref($$value) {
                  ref = $$value;
                  $$settled = false;
                },
                children: ($$renderer5) => {
                  children?.($$renderer5);
                  $$renderer5.push(`<!----> `);
                  $$renderer5.push("<!---->");
                  {
                    let child = function($$renderer6, { props }) {
                      $$renderer6.push(`<div${attributes({
                        class: clsx$1(cn$1("bg-foreground z-50 size-2.5 rotate-45 rounded-[2px]", "data-[side=top]:translate-x-1/2 data-[side=top]:translate-y-[calc(-50%_+_2px)]", "data-[side=bottom]:-translate-x-1/2 data-[side=bottom]:-translate-y-[calc(-50%_+_1px)]", "data-[side=right]:translate-x-[calc(50%_+_2px)] data-[side=right]:translate-y-1/2", "data-[side=left]:-translate-y-[calc(50%_-_3px)]", arrowClasses)),
                        ...props
                      })}></div>`);
                    };
                    Tooltip_arrow?.($$renderer5, { child, $$slots: { child: true } });
                  }
                  $$renderer5.push(`<!---->`);
                },
                $$slots: { default: true }
              }
            ]));
            $$renderer4.push(`<!---->`);
          },
          $$slots: { default: true }
        }
      ]));
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function isFunction(value) {
  return typeof value === "function";
}
function isObject(value) {
  return value !== null && typeof value === "object";
}
const CLASS_VALUE_PRIMITIVE_TYPES = ["string", "number", "bigint", "boolean"];
function isClassValue(value) {
  if (value === null || value === void 0)
    return true;
  if (CLASS_VALUE_PRIMITIVE_TYPES.includes(typeof value))
    return true;
  if (Array.isArray(value))
    return value.every((item) => isClassValue(item));
  if (typeof value === "object") {
    if (Object.getPrototypeOf(value) !== Object.prototype)
      return false;
    return true;
  }
  return false;
}
const BoxSymbol = /* @__PURE__ */ Symbol("box");
const isWritableSymbol = /* @__PURE__ */ Symbol("is-writable");
function isBox(value) {
  return isObject(value) && BoxSymbol in value;
}
function isWritableBox(value) {
  return box.isBox(value) && isWritableSymbol in value;
}
function box(initialValue) {
  let current = initialValue;
  return {
    [BoxSymbol]: true,
    [isWritableSymbol]: true,
    get current() {
      return current;
    },
    set current(v) {
      current = v;
    }
  };
}
function boxWith(getter, setter) {
  const derived2 = getter();
  if (setter) {
    return {
      [BoxSymbol]: true,
      [isWritableSymbol]: true,
      get current() {
        return derived2;
      },
      set current(v) {
        setter(v);
      }
    };
  }
  return {
    [BoxSymbol]: true,
    get current() {
      return getter();
    }
  };
}
function boxFrom(value) {
  if (box.isBox(value)) return value;
  if (isFunction(value)) return box.with(value);
  return box(value);
}
function boxFlatten(boxes) {
  return Object.entries(boxes).reduce(
    (acc, [key, b]) => {
      if (!box.isBox(b)) {
        return Object.assign(acc, { [key]: b });
      }
      if (box.isWritableBox(b)) {
        Object.defineProperty(acc, key, {
          get() {
            return b.current;
          },
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          set(v) {
            b.current = v;
          }
        });
      } else {
        Object.defineProperty(acc, key, {
          get() {
            return b.current;
          }
        });
      }
      return acc;
    },
    {}
  );
}
function toReadonlyBox(b) {
  if (!box.isWritableBox(b)) return b;
  return {
    [BoxSymbol]: true,
    get current() {
      return b.current;
    }
  };
}
box.from = boxFrom;
box.with = boxWith;
box.flatten = boxFlatten;
box.readonly = toReadonlyBox;
box.isBox = isBox;
box.isWritableBox = isWritableBox;
function composeHandlers(...handlers) {
  return function(e) {
    for (const handler of handlers) {
      if (!handler)
        continue;
      if (e.defaultPrevented)
        return;
      if (typeof handler === "function") {
        handler.call(this, e);
      } else {
        handler.current?.call(this, e);
      }
    }
  };
}
const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char))
    return void 0;
  return char !== char.toLowerCase();
}
function splitByCase(str) {
  const parts = [];
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = STR_SPLITTERS.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function pascalCase(str) {
  if (!str)
    return "";
  return splitByCase(str).map((p) => upperFirst(p)).join("");
}
function camelCase(str) {
  return lowerFirst(pascalCase(str || ""));
}
function upperFirst(str) {
  return str ? str[0].toUpperCase() + str.slice(1) : "";
}
function lowerFirst(str) {
  return str ? str[0].toLowerCase() + str.slice(1) : "";
}
function cssToStyleObj(css) {
  if (!css)
    return {};
  const styleObj = {};
  function iterator(name, value) {
    if (name.startsWith("-moz-") || name.startsWith("-webkit-") || name.startsWith("-ms-") || name.startsWith("-o-")) {
      styleObj[pascalCase(name)] = value;
      return;
    }
    if (name.startsWith("--")) {
      styleObj[name] = value;
      return;
    }
    styleObj[camelCase(name)] = value;
  }
  parse(css, iterator);
  return styleObj;
}
function executeCallbacks(...callbacks) {
  return (...args) => {
    for (const callback of callbacks) {
      if (typeof callback === "function") {
        callback(...args);
      }
    }
  };
}
function addEventListener(target, event, handler, options) {
  const events = Array.isArray(event) ? event : [event];
  events.forEach((_event) => target.addEventListener(_event, handler, options));
  return () => {
    events.forEach((_event) => target.removeEventListener(_event, handler, options));
  };
}
function createParser(matcher, replacer) {
  const regex = RegExp(matcher, "g");
  return (str) => {
    if (typeof str !== "string") {
      throw new TypeError(`expected an argument of type string, but got ${typeof str}`);
    }
    if (!str.match(regex))
      return str;
    return str.replace(regex, replacer);
  };
}
const camelToKebab = createParser(/[A-Z]/, (match) => `-${match.toLowerCase()}`);
function styleToCSS(styleObj) {
  if (!styleObj || typeof styleObj !== "object" || Array.isArray(styleObj)) {
    throw new TypeError(`expected an argument of type object, but got ${typeof styleObj}`);
  }
  return Object.keys(styleObj).map((property) => `${camelToKebab(property)}: ${styleObj[property]};`).join("\n");
}
function styleToString(style = {}) {
  return styleToCSS(style).replace("\n", " ");
}
const srOnlyStyles = {
  position: "absolute",
  width: "1px",
  height: "1px",
  padding: "0",
  margin: "-1px",
  overflow: "hidden",
  clip: "rect(0, 0, 0, 0)",
  whiteSpace: "nowrap",
  borderWidth: "0",
  transform: "translateX(-100%)"
};
styleToString(srOnlyStyles);
const EVENT_LIST = [
  "onabort",
  "onanimationcancel",
  "onanimationend",
  "onanimationiteration",
  "onanimationstart",
  "onauxclick",
  "onbeforeinput",
  "onbeforetoggle",
  "onblur",
  "oncancel",
  "oncanplay",
  "oncanplaythrough",
  "onchange",
  "onclick",
  "onclose",
  "oncompositionend",
  "oncompositionstart",
  "oncompositionupdate",
  "oncontextlost",
  "oncontextmenu",
  "oncontextrestored",
  "oncopy",
  "oncuechange",
  "oncut",
  "ondblclick",
  "ondrag",
  "ondragend",
  "ondragenter",
  "ondragleave",
  "ondragover",
  "ondragstart",
  "ondrop",
  "ondurationchange",
  "onemptied",
  "onended",
  "onerror",
  "onfocus",
  "onfocusin",
  "onfocusout",
  "onformdata",
  "ongotpointercapture",
  "oninput",
  "oninvalid",
  "onkeydown",
  "onkeypress",
  "onkeyup",
  "onload",
  "onloadeddata",
  "onloadedmetadata",
  "onloadstart",
  "onlostpointercapture",
  "onmousedown",
  "onmouseenter",
  "onmouseleave",
  "onmousemove",
  "onmouseout",
  "onmouseover",
  "onmouseup",
  "onpaste",
  "onpause",
  "onplay",
  "onplaying",
  "onpointercancel",
  "onpointerdown",
  "onpointerenter",
  "onpointerleave",
  "onpointermove",
  "onpointerout",
  "onpointerover",
  "onpointerup",
  "onprogress",
  "onratechange",
  "onreset",
  "onresize",
  "onscroll",
  "onscrollend",
  "onsecuritypolicyviolation",
  "onseeked",
  "onseeking",
  "onselect",
  "onselectionchange",
  "onselectstart",
  "onslotchange",
  "onstalled",
  "onsubmit",
  "onsuspend",
  "ontimeupdate",
  "ontoggle",
  "ontouchcancel",
  "ontouchend",
  "ontouchmove",
  "ontouchstart",
  "ontransitioncancel",
  "ontransitionend",
  "ontransitionrun",
  "ontransitionstart",
  "onvolumechange",
  "onwaiting",
  "onwebkitanimationend",
  "onwebkitanimationiteration",
  "onwebkitanimationstart",
  "onwebkittransitionend",
  "onwheel"
];
const EVENT_LIST_SET = new Set(EVENT_LIST);
function isEventHandler(key) {
  return EVENT_LIST_SET.has(key);
}
function mergeProps(...args) {
  const result = { ...args[0] };
  for (let i = 1; i < args.length; i++) {
    const props = args[i];
    if (!props)
      continue;
    for (const key of Object.keys(props)) {
      const a = result[key];
      const b = props[key];
      const aIsFunction = typeof a === "function";
      const bIsFunction = typeof b === "function";
      if (aIsFunction && typeof bIsFunction && isEventHandler(key)) {
        const aHandler = a;
        const bHandler = b;
        result[key] = composeHandlers(aHandler, bHandler);
      } else if (aIsFunction && bIsFunction) {
        result[key] = executeCallbacks(a, b);
      } else if (key === "class") {
        const aIsClassValue = isClassValue(a);
        const bIsClassValue = isClassValue(b);
        if (aIsClassValue && bIsClassValue) {
          result[key] = clsx(a, b);
        } else if (aIsClassValue) {
          result[key] = clsx(a);
        } else if (bIsClassValue) {
          result[key] = clsx(b);
        }
      } else if (key === "style") {
        const aIsObject = typeof a === "object";
        const bIsObject = typeof b === "object";
        const aIsString = typeof a === "string";
        const bIsString = typeof b === "string";
        if (aIsObject && bIsObject) {
          result[key] = { ...a, ...b };
        } else if (aIsObject && bIsString) {
          const parsedStyle = cssToStyleObj(b);
          result[key] = { ...a, ...parsedStyle };
        } else if (aIsString && bIsObject) {
          const parsedStyle = cssToStyleObj(a);
          result[key] = { ...parsedStyle, ...b };
        } else if (aIsString && bIsString) {
          const parsedStyleA = cssToStyleObj(a);
          const parsedStyleB = cssToStyleObj(b);
          result[key] = { ...parsedStyleA, ...parsedStyleB };
        } else if (aIsObject) {
          result[key] = a;
        } else if (bIsObject) {
          result[key] = b;
        } else if (aIsString) {
          result[key] = a;
        } else if (bIsString) {
          result[key] = b;
        }
      } else {
        result[key] = b !== void 0 ? b : a;
      }
    }
    for (const key of Object.getOwnPropertySymbols(props)) {
      const a = result[key];
      const b = props[key];
      result[key] = b !== void 0 ? b : a;
    }
  }
  if (typeof result.style === "object") {
    result.style = styleToString(result.style).replaceAll("\n", " ");
  }
  if (result.hidden !== true) {
    result.hidden = void 0;
    delete result.hidden;
  }
  if (result.disabled !== true) {
    result.disabled = void 0;
    delete result.disabled;
  }
  return result;
}
const defaultWindow$2 = void 0;
function getActiveElement$3(document2) {
  let activeElement = document2.activeElement;
  while (activeElement?.shadowRoot) {
    const node = activeElement.shadowRoot.activeElement;
    if (node === activeElement)
      break;
    else
      activeElement = node;
  }
  return activeElement;
}
let ActiveElement$2 = class ActiveElement {
  #document;
  #subscribe;
  constructor(options = {}) {
    const { window: window2 = defaultWindow$2, document: document2 = window2?.document } = options;
    if (window2 === void 0) return;
    this.#document = document2;
    this.#subscribe = createSubscriber();
  }
  get current() {
    this.#subscribe?.();
    if (!this.#document) return null;
    return getActiveElement$3(this.#document);
  }
};
new ActiveElement$2();
function afterTick(fn) {
  tick().then(fn);
}
const DOCUMENT_NODE = 9;
function isDocument(node) {
  return isObject(node) && node.nodeType === DOCUMENT_NODE;
}
function isWindow(node) {
  return isObject(node) && node.constructor?.name === "VisualViewport";
}
function getDocument(node) {
  if (isDocument(node))
    return node;
  if (isWindow(node))
    return node.document;
  return node?.ownerDocument ?? document;
}
function getActiveElement$2(rootNode) {
  let activeElement = rootNode.activeElement;
  while (activeElement?.shadowRoot) {
    const el = activeElement.shadowRoot.activeElement;
    if (el === activeElement)
      break;
    else
      activeElement = el;
  }
  return activeElement;
}
class DOMContext {
  element;
  #root = derived(() => {
    if (!this.element.current) return document;
    const rootNode = this.element.current.getRootNode() ?? document;
    return rootNode;
  });
  get root() {
    return this.#root();
  }
  set root($$value) {
    return this.#root($$value);
  }
  constructor(element2) {
    if (typeof element2 === "function") {
      this.element = box.with(element2);
    } else {
      this.element = element2;
    }
  }
  getDocument = () => {
    return getDocument(this.root);
  };
  getWindow = () => {
    return this.getDocument().defaultView ?? window;
  };
  getActiveElement = () => {
    return getActiveElement$2(this.root);
  };
  isActiveElement = (node) => {
    return node === this.getActiveElement();
  };
  getElementById(id) {
    return this.root.getElementById(id);
  }
  querySelector = (selector) => {
    if (!this.root) return null;
    return this.root.querySelector(selector);
  };
  querySelectorAll = (selector) => {
    if (!this.root) return [];
    return this.root.querySelectorAll(selector);
  };
  setTimeout = (callback, delay) => {
    return this.getWindow().setTimeout(callback, delay);
  };
  clearTimeout = (timeoutId) => {
    return this.getWindow().clearTimeout(timeoutId);
  };
}
function attachRef(ref, onChange) {
  return {
    [createAttachmentKey()]: (node) => {
      if (box.isBox(ref)) {
        ref.current = node;
        run(() => onChange?.(node));
        return () => {
          if ("isConnected" in node && node.isConnected)
            return;
          ref.current = null;
        };
      }
      ref(node);
      run(() => onChange?.(node));
      return () => {
        if ("isConnected" in node && node.isConnected)
          return;
        ref(null);
      };
    }
  };
}
function calculateAriaValues({ layout, panesArray, pivotIndices }) {
  let currentMinSize = 0;
  let currentMaxSize = 100;
  let totalMinSize = 0;
  let totalMaxSize = 0;
  const firstIndex = pivotIndices[0];
  for (let i = 0; i < panesArray.length; i++) {
    const constraints = panesArray[i].constraints;
    const { maxSize = 100, minSize = 0 } = constraints;
    if (i === firstIndex) {
      currentMinSize = minSize;
      currentMaxSize = maxSize;
    } else {
      totalMinSize += minSize;
      totalMaxSize += maxSize;
    }
  }
  const valueMax = Math.min(currentMaxSize, 100 - totalMinSize);
  const valueMin = Math.max(currentMinSize, 100 - totalMaxSize);
  const valueNow = layout[firstIndex];
  return {
    valueMax,
    valueMin,
    valueNow
  };
}
function assert(expectedCondition, message = "Assertion failed!") {
  if (!expectedCondition) {
    console.error(message);
    throw new Error(message);
  }
}
const LOCAL_STORAGE_DEBOUNCE_INTERVAL = 100;
const PRECISION = 10;
function areNumbersAlmostEqual(actual, expected, fractionDigits = PRECISION) {
  return compareNumbersWithTolerance(actual, expected, fractionDigits) === 0;
}
function compareNumbersWithTolerance(actual, expected, fractionDigits = PRECISION) {
  const roundedActual = roundTo(actual, fractionDigits);
  const roundedExpected = roundTo(expected, fractionDigits);
  return Math.sign(roundedActual - roundedExpected);
}
function areArraysEqual(arrA, arrB) {
  if (arrA.length !== arrB.length)
    return false;
  for (let index = 0; index < arrA.length; index++) {
    if (arrA[index] !== arrB[index])
      return false;
  }
  return true;
}
function roundTo(value, decimals) {
  return Number.parseFloat(value.toFixed(decimals));
}
const isBrowser = typeof document !== "undefined";
function isHTMLElement(element2) {
  return element2 instanceof HTMLElement;
}
function isKeyDown(event) {
  return event.type === "keydown";
}
function isMouseEvent(event) {
  return event.type.startsWith("mouse");
}
function isTouchEvent(event) {
  return event.type.startsWith("touch");
}
function resizePane({ paneConstraints: paneConstraintsArray, paneIndex, initialSize }) {
  const paneConstraints = paneConstraintsArray[paneIndex];
  assert(paneConstraints != null, "Pane constraints should not be null.");
  const { collapsedSize = 0, collapsible, maxSize = 100, minSize = 0 } = paneConstraints;
  let newSize = initialSize;
  if (compareNumbersWithTolerance(newSize, minSize) < 0) {
    newSize = getAdjustedSizeForCollapsible(newSize, collapsible, collapsedSize, minSize);
  }
  newSize = Math.min(maxSize, newSize);
  return Number.parseFloat(newSize.toFixed(PRECISION));
}
function getAdjustedSizeForCollapsible(size2, collapsible, collapsedSize, minSize) {
  if (!collapsible)
    return minSize;
  const halfwayPoint = (collapsedSize + minSize) / 2;
  return compareNumbersWithTolerance(size2, halfwayPoint) < 0 ? collapsedSize : minSize;
}
function noop() {
}
function updateResizeHandleAriaValues({ groupId, layout, panesArray, domContext }) {
  const resizeHandleElements = getResizeHandleElementsForGroup(groupId, domContext);
  for (let index = 0; index < panesArray.length - 1; index++) {
    const { valueMax, valueMin, valueNow } = calculateAriaValues({
      layout,
      panesArray,
      pivotIndices: [index, index + 1]
    });
    const resizeHandleEl = resizeHandleElements[index];
    if (isHTMLElement(resizeHandleEl)) {
      const paneData = panesArray[index];
      resizeHandleEl.setAttribute("aria-controls", paneData.opts.id.current);
      resizeHandleEl.setAttribute("aria-valuemax", `${Math.round(valueMax)}`);
      resizeHandleEl.setAttribute("aria-valuemin", `${Math.round(valueMin)}`);
      resizeHandleEl.setAttribute("aria-valuenow", valueNow != null ? `${Math.round(valueNow)}` : "");
    }
  }
  return () => {
    for (const el of resizeHandleElements) {
      el.removeAttribute("aria-controls");
      el.removeAttribute("aria-valuemax");
      el.removeAttribute("aria-valuemin");
      el.removeAttribute("aria-valuenow");
    }
  };
}
function getResizeHandleElementsForGroup(groupId, domContext) {
  if (!isBrowser)
    return [];
  return Array.from(domContext.querySelectorAll(`[data-pane-resizer-id][data-pane-group-id="${groupId}"]`));
}
function getResizeHandleElementIndex({ groupId, id, domContext }) {
  if (!isBrowser)
    return null;
  const handles = getResizeHandleElementsForGroup(groupId, domContext);
  const index = handles.findIndex((handle) => handle.getAttribute("data-pane-resizer-id") === id);
  return index ?? null;
}
function getPivotIndices({ groupId, dragHandleId, domContext }) {
  const index = getResizeHandleElementIndex({
    groupId,
    id: dragHandleId,
    domContext
  });
  return index != null ? [index, index + 1] : [-1, -1];
}
function paneDataHelper(panesArray, pane, layout) {
  const paneConstraintsArray = panesArray.map((paneData) => paneData.constraints);
  const paneIndex = findPaneDataIndex(panesArray, pane);
  const paneConstraints = paneConstraintsArray[paneIndex];
  const isLastPane = paneIndex === panesArray.length - 1;
  const pivotIndices = isLastPane ? [paneIndex - 1, paneIndex] : [paneIndex, paneIndex + 1];
  const paneSize = layout[paneIndex];
  return {
    ...paneConstraints,
    paneSize,
    pivotIndices
  };
}
function findPaneDataIndex(panesArray, pane) {
  return panesArray.findIndex((prevPaneData) => prevPaneData.opts.id.current === pane.opts.id.current);
}
function callPaneCallbacks(panesArray, layout, paneIdToLastNotifiedSizeMap) {
  for (let index = 0; index < layout.length; index++) {
    const size2 = layout[index];
    const paneData = panesArray[index];
    assert(paneData);
    const { collapsedSize = 0, collapsible } = paneData.constraints;
    const lastNotifiedSize = paneIdToLastNotifiedSizeMap[paneData.opts.id.current];
    if (!(lastNotifiedSize == null || size2 !== lastNotifiedSize))
      continue;
    paneIdToLastNotifiedSizeMap[paneData.opts.id.current] = size2;
    const { onCollapse, onExpand, onResize } = paneData.callbacks;
    onResize?.(size2, lastNotifiedSize);
    if (collapsible && (onCollapse || onExpand)) {
      if (onExpand && (lastNotifiedSize == null || lastNotifiedSize === collapsedSize) && size2 !== collapsedSize) {
        onExpand();
      }
      if (onCollapse && (lastNotifiedSize == null || lastNotifiedSize !== collapsedSize) && size2 === collapsedSize) {
        onCollapse();
      }
    }
  }
}
function getUnsafeDefaultLayout({ panesArray }) {
  const layout = Array(panesArray.length);
  const paneConstraintsArray = panesArray.map((paneData) => paneData.constraints);
  let numPanesWithSizes = 0;
  let remainingSize = 100;
  for (let index = 0; index < panesArray.length; index++) {
    const paneConstraints = paneConstraintsArray[index];
    assert(paneConstraints);
    const { defaultSize } = paneConstraints;
    if (defaultSize != null) {
      numPanesWithSizes++;
      layout[index] = defaultSize;
      remainingSize -= defaultSize;
    }
  }
  for (let index = 0; index < panesArray.length; index++) {
    const paneConstraints = paneConstraintsArray[index];
    assert(paneConstraints);
    const { defaultSize } = paneConstraints;
    if (defaultSize != null) {
      continue;
    }
    const numRemainingPanes = panesArray.length - numPanesWithSizes;
    const size2 = remainingSize / numRemainingPanes;
    numPanesWithSizes++;
    layout[index] = size2;
    remainingSize -= size2;
  }
  return layout;
}
function validatePaneGroupLayout({ layout: prevLayout, paneConstraints }) {
  const nextLayout = [...prevLayout];
  const nextLayoutTotalSize = nextLayout.reduce((accumulated, current) => accumulated + current, 0);
  if (nextLayout.length !== paneConstraints.length) {
    throw new Error(`Invalid ${paneConstraints.length} pane layout: ${nextLayout.map((size2) => `${size2}%`).join(", ")}`);
  } else if (!areNumbersAlmostEqual(nextLayoutTotalSize, 100)) {
    for (let index = 0; index < paneConstraints.length; index++) {
      const unsafeSize = nextLayout[index];
      assert(unsafeSize != null);
      const safeSize = 100 / nextLayoutTotalSize * unsafeSize;
      nextLayout[index] = safeSize;
    }
  }
  let remainingSize = 0;
  for (let index = 0; index < paneConstraints.length; index++) {
    const unsafeSize = nextLayout[index];
    assert(unsafeSize != null);
    const safeSize = resizePane({
      paneConstraints,
      paneIndex: index,
      initialSize: unsafeSize
    });
    if (unsafeSize !== safeSize) {
      remainingSize += unsafeSize - safeSize;
      nextLayout[index] = safeSize;
    }
  }
  if (!areNumbersAlmostEqual(remainingSize, 0)) {
    for (let index = 0; index < paneConstraints.length; index++) {
      const prevSize = nextLayout[index];
      assert(prevSize != null);
      const unsafeSize = prevSize + remainingSize;
      const safeSize = resizePane({
        paneConstraints,
        paneIndex: index,
        initialSize: unsafeSize
      });
      if (prevSize !== safeSize) {
        remainingSize -= safeSize - prevSize;
        nextLayout[index] = safeSize;
        if (areNumbersAlmostEqual(remainingSize, 0)) {
          break;
        }
      }
    }
  }
  return nextLayout;
}
function getPaneGroupElement(id, domContext) {
  if (!isBrowser)
    return null;
  const element2 = domContext.querySelector(`[data-pane-group][data-pane-group-id="${id}"]`);
  if (element2)
    return element2;
  return null;
}
function getResizeHandleElement(id, domContext) {
  if (!isBrowser)
    return null;
  const element2 = domContext.querySelector(`[data-pane-resizer-id="${id}"]`);
  if (element2)
    return element2;
  return null;
}
function getDragOffsetPercentage({ event, dragHandleId, dir, initialDragState, domContext }) {
  const isHorizontal = dir === "horizontal";
  const handleElement = getResizeHandleElement(dragHandleId, domContext);
  assert(handleElement);
  const groupId = handleElement.getAttribute("data-pane-group-id");
  assert(groupId);
  const { initialCursorPosition } = initialDragState;
  const cursorPosition = getResizeEventCursorPosition(dir, event);
  const groupElement = getPaneGroupElement(groupId, domContext);
  assert(groupElement);
  const groupRect = groupElement.getBoundingClientRect();
  const groupSizeInPixels = isHorizontal ? groupRect.width : groupRect.height;
  const offsetPixels = cursorPosition - initialCursorPosition;
  const offsetPercentage = offsetPixels / groupSizeInPixels * 100;
  return offsetPercentage;
}
function getDeltaPercentage({ event, dragHandleId, dir, initialDragState, keyboardResizeBy, domContext }) {
  if (isKeyDown(event)) {
    const isHorizontal = dir === "horizontal";
    let delta = 0;
    if (event.shiftKey) {
      delta = 100;
    } else if (keyboardResizeBy != null) {
      delta = keyboardResizeBy;
    } else {
      delta = 10;
    }
    let movement = 0;
    switch (event.key) {
      case "ArrowDown":
        movement = isHorizontal ? 0 : delta;
        break;
      case "ArrowLeft":
        movement = isHorizontal ? -delta : 0;
        break;
      case "ArrowRight":
        movement = isHorizontal ? delta : 0;
        break;
      case "ArrowUp":
        movement = isHorizontal ? 0 : -delta;
        break;
      case "End":
        movement = 100;
        break;
      case "Home":
        movement = -100;
        break;
    }
    return movement;
  } else {
    if (initialDragState == null)
      return 0;
    return getDragOffsetPercentage({
      event,
      dragHandleId,
      dir,
      initialDragState,
      domContext
    });
  }
}
function getResizeEventCursorPosition(dir, e) {
  const isHorizontal = dir === "horizontal";
  if (isMouseEvent(e)) {
    return isHorizontal ? e.clientX : e.clientY;
  } else if (isTouchEvent(e)) {
    const firstTouch = e.touches[0];
    assert(firstTouch);
    return isHorizontal ? firstTouch.screenX : firstTouch.screenY;
  } else {
    throw new Error(`Unsupported event type "${e.type}"`);
  }
}
function getResizeHandlePaneIds({ groupId, handleId, panesArray, domContext }) {
  const handle = getResizeHandleElement(handleId, domContext);
  const handles = getResizeHandleElementsForGroup(groupId, domContext);
  const index = handle ? handles.indexOf(handle) : -1;
  const idBefore = panesArray[index]?.opts.id.current ?? null;
  const idAfter = panesArray[index + 1]?.opts.id.current ?? null;
  return [idBefore, idAfter];
}
const defaultWindow$1 = void 0;
function getActiveElement$1(document2) {
  let activeElement = document2.activeElement;
  while (activeElement?.shadowRoot) {
    const node = activeElement.shadowRoot.activeElement;
    if (node === activeElement)
      break;
    else
      activeElement = node;
  }
  return activeElement;
}
let ActiveElement$1 = class ActiveElement2 {
  #document;
  #subscribe;
  constructor(options = {}) {
    const { window: window2 = defaultWindow$1, document: document2 = window2?.document } = options;
    if (window2 === void 0) return;
    this.#document = document2;
    this.#subscribe = createSubscriber();
  }
  get current() {
    this.#subscribe?.();
    if (!this.#document) return null;
    return getActiveElement$1(this.#document);
  }
};
new ActiveElement$1();
function runWatcher$1(sources, flush, effect, options = {}) {
  const { lazy = false } = options;
}
function watch$1(sources, effect, options) {
  runWatcher$1(sources, "post", effect, options);
}
function watchPre$1(sources, effect, options) {
  runWatcher$1(sources, "pre", effect, options);
}
watch$1.pre = watchPre$1;
class Context {
  #name;
  #key;
  /**
   * @param name The name of the context.
   * This is used for generating the context key and error messages.
   */
  constructor(name) {
    this.#name = name;
    this.#key = Symbol(name);
  }
  /**
   * The key used to get and set the context.
   *
   * It is not recommended to use this value directly.
   * Instead, use the methods provided by this class.
   */
  get key() {
    return this.#key;
  }
  /**
   * Checks whether this has been set in the context of a parent component.
   *
   * Must be called during component initialisation.
   */
  exists() {
    return hasContext(this.#key);
  }
  /**
   * Retrieves the context that belongs to the closest parent component.
   *
   * Must be called during component initialisation.
   *
   * @throws An error if the context does not exist.
   */
  get() {
    const context = getContext(this.#key);
    if (context === void 0) {
      throw new Error(`Context "${this.#name}" not found`);
    }
    return context;
  }
  /**
   * Retrieves the context that belongs to the closest parent component,
   * or the given fallback value if the context does not exist.
   *
   * Must be called during component initialisation.
   */
  getOr(fallback) {
    const context = getContext(this.#key);
    if (context === void 0) {
      return fallback;
    }
    return context;
  }
  /**
   * Associates the given value with the current component and returns it.
   *
   * Must be called during component initialisation.
   */
  set(context) {
    return setContext(this.#key, context);
  }
}
function adjustLayoutByDelta({ delta, layout: prevLayout, paneConstraints: paneConstraintsArray, pivotIndices, trigger }) {
  if (areNumbersAlmostEqual(delta, 0))
    return prevLayout;
  const nextLayout = [...prevLayout];
  const [firstPivotIndex, secondPivotIndex] = pivotIndices;
  let deltaApplied = 0;
  {
    if (trigger === "keyboard") {
      {
        const index = delta < 0 ? secondPivotIndex : firstPivotIndex;
        const paneConstraints = paneConstraintsArray[index];
        assert(paneConstraints);
        if (paneConstraints.collapsible) {
          const prevSize = prevLayout[index];
          assert(prevSize != null);
          const paneConstraints2 = paneConstraintsArray[index];
          assert(paneConstraints2);
          const { collapsedSize = 0, minSize = 0 } = paneConstraints2;
          if (areNumbersAlmostEqual(prevSize, collapsedSize)) {
            const localDelta = minSize - prevSize;
            if (compareNumbersWithTolerance(localDelta, Math.abs(delta)) > 0) {
              delta = delta < 0 ? 0 - localDelta : localDelta;
            }
          }
        }
      }
      {
        const index = delta < 0 ? firstPivotIndex : secondPivotIndex;
        const paneConstraints = paneConstraintsArray[index];
        assert(paneConstraints);
        const { collapsible } = paneConstraints;
        if (collapsible) {
          const prevSize = prevLayout[index];
          assert(prevSize != null);
          const paneConstraints2 = paneConstraintsArray[index];
          assert(paneConstraints2);
          const { collapsedSize = 0, minSize = 0 } = paneConstraints2;
          if (areNumbersAlmostEqual(prevSize, minSize)) {
            const localDelta = prevSize - collapsedSize;
            if (compareNumbersWithTolerance(localDelta, Math.abs(delta)) > 0) {
              delta = delta < 0 ? 0 - localDelta : localDelta;
            }
          }
        }
      }
    }
  }
  {
    const increment = delta < 0 ? 1 : -1;
    let index = delta < 0 ? secondPivotIndex : firstPivotIndex;
    let maxAvailableDelta = 0;
    while (true) {
      const prevSize = prevLayout[index];
      assert(prevSize != null);
      const maxSafeSize = resizePane({
        paneConstraints: paneConstraintsArray,
        paneIndex: index,
        initialSize: 100
      });
      const delta2 = maxSafeSize - prevSize;
      maxAvailableDelta += delta2;
      index += increment;
      if (index < 0 || index >= paneConstraintsArray.length) {
        break;
      }
    }
    const minAbsDelta = Math.min(Math.abs(delta), Math.abs(maxAvailableDelta));
    delta = delta < 0 ? 0 - minAbsDelta : minAbsDelta;
  }
  {
    const pivotIndex = delta < 0 ? firstPivotIndex : secondPivotIndex;
    let index = pivotIndex;
    while (index >= 0 && index < paneConstraintsArray.length) {
      const deltaRemaining = Math.abs(delta) - Math.abs(deltaApplied);
      const prevSize = prevLayout[index];
      assert(prevSize != null);
      const unsafeSize = prevSize - deltaRemaining;
      const safeSize = resizePane({
        paneConstraints: paneConstraintsArray,
        paneIndex: index,
        initialSize: unsafeSize
      });
      if (!areNumbersAlmostEqual(prevSize, safeSize)) {
        deltaApplied += prevSize - safeSize;
        nextLayout[index] = safeSize;
        if (deltaApplied.toPrecision(3).localeCompare(Math.abs(delta).toPrecision(3), void 0, {
          numeric: true
        }) >= 0) {
          break;
        }
      }
      if (delta < 0) {
        index--;
      } else {
        index++;
      }
    }
  }
  if (areNumbersAlmostEqual(deltaApplied, 0)) {
    return prevLayout;
  }
  {
    const pivotIndex = delta < 0 ? secondPivotIndex : firstPivotIndex;
    const prevSize = prevLayout[pivotIndex];
    assert(prevSize != null);
    const unsafeSize = prevSize + deltaApplied;
    const safeSize = resizePane({
      paneConstraints: paneConstraintsArray,
      paneIndex: pivotIndex,
      initialSize: unsafeSize
    });
    nextLayout[pivotIndex] = safeSize;
    if (!areNumbersAlmostEqual(safeSize, unsafeSize)) {
      let deltaRemaining = unsafeSize - safeSize;
      const pivotIndex2 = delta < 0 ? secondPivotIndex : firstPivotIndex;
      let index = pivotIndex2;
      while (index >= 0 && index < paneConstraintsArray.length) {
        const prevSize2 = nextLayout[index];
        assert(prevSize2 != null);
        const unsafeSize2 = prevSize2 + deltaRemaining;
        const safeSize2 = resizePane({
          paneConstraints: paneConstraintsArray,
          paneIndex: index,
          initialSize: unsafeSize2
        });
        if (!areNumbersAlmostEqual(prevSize2, safeSize2)) {
          deltaRemaining -= safeSize2 - prevSize2;
          nextLayout[index] = safeSize2;
        }
        if (areNumbersAlmostEqual(deltaRemaining, 0))
          break;
        delta > 0 ? index-- : index++;
      }
    }
  }
  const totalSize = nextLayout.reduce((total, size2) => size2 + total, 0);
  if (!areNumbersAlmostEqual(totalSize, 100))
    return prevLayout;
  return nextLayout;
}
let currentState = null;
let element = null;
function getCursorStyle(state) {
  switch (state) {
    case "horizontal":
      return "ew-resize";
    case "horizontal-max":
      return "w-resize";
    case "horizontal-min":
      return "e-resize";
    case "vertical":
      return "ns-resize";
    case "vertical-max":
      return "n-resize";
    case "vertical-min":
      return "s-resize";
  }
}
function resetGlobalCursorStyle() {
  if (element === null)
    return;
  document.head.removeChild(element);
  currentState = null;
  element = null;
}
function setGlobalCursorStyle(state, doc) {
  if (currentState === state)
    return;
  currentState = state;
  const style = getCursorStyle(state);
  if (element === null) {
    element = doc.createElement("style");
    doc.head.appendChild(element);
  }
  element.innerHTML = `*{cursor: ${style}!important;}`;
}
function computePaneFlexBoxStyle({ defaultSize, dragState, layout, panesArray, paneIndex, precision = 3 }) {
  const size2 = layout[paneIndex];
  let flexGrow;
  if (size2 == null) {
    flexGrow = defaultSize ?? "1";
  } else if (panesArray.length === 1) {
    flexGrow = "1";
  } else {
    flexGrow = size2.toPrecision(precision);
  }
  return {
    flexBasis: 0,
    flexGrow,
    flexShrink: 1,
    // Without this, pane sizes may be unintentionally overridden by their content
    overflow: "hidden",
    // Disable pointer events inside of a pane during resize
    // This avoid edge cases like nested iframes
    pointerEvents: dragState !== null ? "none" : void 0
  };
}
function initializeStorage(storageObject) {
  try {
    if (typeof localStorage === "undefined") {
      throw new TypeError("localStorage is not supported in this environment");
    }
    storageObject.getItem = (name) => localStorage.getItem(name);
    storageObject.setItem = (name, value) => localStorage.setItem(name, value);
  } catch (err) {
    console.error(err);
    storageObject.getItem = () => null;
    storageObject.setItem = () => {
    };
  }
}
function getPaneGroupKey(autoSaveId) {
  return `paneforge:${autoSaveId}`;
}
function getPaneKey(panes) {
  const sortedPaneIds = panes.map((pane) => {
    return pane.opts.order.current ? `${pane.opts.order.current}:${JSON.stringify(pane.constraints)}` : JSON.stringify(pane.constraints);
  }).sort().join(",");
  return sortedPaneIds;
}
function loadSerializedPaneGroupState(autoSaveId, storage) {
  try {
    const paneGroupKey = getPaneGroupKey(autoSaveId);
    const serialized = storage.getItem(paneGroupKey);
    const parsed = JSON.parse(serialized || "");
    if (typeof parsed === "object" && parsed !== null) {
      return parsed;
    }
  } catch {
  }
  return null;
}
function loadPaneGroupState(autoSaveId, panesArray, storage) {
  const state = loadSerializedPaneGroupState(autoSaveId, storage) || {};
  const paneKey = getPaneKey(panesArray);
  return state[paneKey] || null;
}
function savePaneGroupState(autoSaveId, panesArray, paneSizesBeforeCollapse, sizes, storage) {
  const paneGroupKey = getPaneGroupKey(autoSaveId);
  const paneKey = getPaneKey(panesArray);
  const state = loadSerializedPaneGroupState(autoSaveId, storage) || {};
  state[paneKey] = {
    expandToSizes: Object.fromEntries(paneSizesBeforeCollapse.entries()),
    layout: sizes
  };
  try {
    storage.setItem(paneGroupKey, JSON.stringify(state));
  } catch (error) {
    console.error(error);
  }
}
const debounceMap = {};
function debounce(callback, durationMs = 10) {
  let timeoutId = null;
  const callable = (...args) => {
    if (timeoutId !== null) {
      clearTimeout(timeoutId);
    }
    timeoutId = setTimeout(() => {
      callback(...args);
    }, durationMs);
  };
  return callable;
}
function updateStorageValues({ autoSaveId, layout, storage, panesArray, paneSizeBeforeCollapse }) {
  if (layout.length === 0 || layout.length !== panesArray.length)
    return;
  let debouncedSave = debounceMap[autoSaveId];
  if (debouncedSave == null) {
    debouncedSave = debounce(savePaneGroupState, LOCAL_STORAGE_DEBOUNCE_INTERVAL);
    debounceMap[autoSaveId] = debouncedSave;
  }
  const clonedPanesArray = [...panesArray];
  const clonedPaneSizesBeforeCollapse = new Map(paneSizeBeforeCollapse);
  debouncedSave(autoSaveId, clonedPanesArray, clonedPaneSizesBeforeCollapse, layout, storage);
}
const defaultStorage = {
  getItem: (name) => {
    initializeStorage(defaultStorage);
    return defaultStorage.getItem(name);
  },
  setItem: (name, value) => {
    initializeStorage(defaultStorage);
    defaultStorage.setItem(name, value);
  }
};
const PaneGroupContext = new Context("PaneGroup");
class PaneGroupState {
  static create(opts) {
    return PaneGroupContext.set(new PaneGroupState(opts));
  }
  opts;
  attachment;
  domContext;
  dragState = null;
  layout = [];
  panesArray = [];
  panesArrayChanged = false;
  paneIdToLastNotifiedSizeMap = {};
  paneSizeBeforeCollapseMap = /* @__PURE__ */ new Map();
  prevDelta = 0;
  constructor(opts) {
    this.opts = opts;
    this.attachment = attachRef(this.opts.ref);
    this.domContext = new DOMContext(this.opts.ref);
    watch$1(
      [
        () => this.opts.id.current,
        () => this.layout,
        () => this.panesArray
      ],
      () => {
        return updateResizeHandleAriaValues({
          groupId: this.opts.id.current,
          layout: this.layout,
          panesArray: this.panesArray,
          domContext: this.domContext
        });
      }
    );
    watch$1(
      [
        () => this.opts.autoSaveId.current,
        () => this.layout,
        () => this.opts.storage.current
      ],
      () => {
        if (!this.opts.autoSaveId.current) return;
        updateStorageValues({
          autoSaveId: this.opts.autoSaveId.current,
          layout: this.layout,
          storage: this.opts.storage.current,
          panesArray: this.panesArray,
          paneSizeBeforeCollapse: this.paneSizeBeforeCollapseMap
        });
      }
    );
    watch$1(() => this.panesArrayChanged, () => {
      if (!this.panesArrayChanged) return;
      this.panesArrayChanged = false;
      const prevLayout = this.layout;
      let unsafeLayout = null;
      if (this.opts.autoSaveId.current) {
        const state = loadPaneGroupState(this.opts.autoSaveId.current, this.panesArray, this.opts.storage.current);
        if (state) {
          this.paneSizeBeforeCollapseMap = new Map(Object.entries(state.expandToSizes));
          unsafeLayout = state.layout;
        }
      }
      if (unsafeLayout == null) {
        unsafeLayout = getUnsafeDefaultLayout({ panesArray: this.panesArray });
      }
      const nextLayout = validatePaneGroupLayout({
        layout: unsafeLayout,
        paneConstraints: this.panesArray.map((paneData) => paneData.constraints)
      });
      if (areArraysEqual(prevLayout, nextLayout)) return;
      this.layout = nextLayout;
      this.opts.onLayout.current?.(nextLayout);
      callPaneCallbacks(this.panesArray, nextLayout, this.paneIdToLastNotifiedSizeMap);
    });
  }
  setLayout = (newLayout) => {
    this.layout = newLayout;
  };
  registerResizeHandle = (dragHandleId) => {
    return (event) => {
      event.preventDefault();
      const direction = this.opts.direction.current;
      const dragState = this.dragState;
      const groupId = this.opts.id.current;
      const keyboardResizeBy = this.opts.keyboardResizeBy.current;
      const prevLayout = this.layout;
      const paneDataArray = this.panesArray;
      const { initialLayout } = dragState ?? {};
      const doc = this.domContext.getDocument();
      const pivotIndices = getPivotIndices({ groupId, dragHandleId, domContext: this.domContext });
      let delta = getDeltaPercentage({
        event,
        dragHandleId,
        dir: direction,
        initialDragState: dragState,
        keyboardResizeBy,
        domContext: this.domContext
      });
      if (delta === 0) return;
      const isHorizontal = direction === "horizontal";
      if (doc.dir === "rtl" && isHorizontal) {
        delta = -delta;
      }
      const paneConstraints = paneDataArray.map((paneData) => paneData.constraints);
      const nextLayout = adjustLayoutByDelta({
        delta,
        layout: initialLayout ?? prevLayout,
        paneConstraints,
        pivotIndices,
        trigger: isKeyDown(event) ? "keyboard" : "mouse-or-touch"
      });
      const layoutChanged = !areArraysEqual(prevLayout, nextLayout);
      if (isMouseEvent(event) || isTouchEvent(event)) {
        const prevDelta = this.prevDelta;
        if (prevDelta !== delta) {
          this.prevDelta = delta;
          if (!layoutChanged) {
            if (isHorizontal) {
              setGlobalCursorStyle(delta < 0 ? "horizontal-min" : "horizontal-max", doc);
            } else {
              setGlobalCursorStyle(delta < 0 ? "vertical-min" : "vertical-max", doc);
            }
          } else {
            setGlobalCursorStyle(isHorizontal ? "horizontal" : "vertical", doc);
          }
        }
      }
      if (layoutChanged) {
        this.setLayout(nextLayout);
        this.opts.onLayout.current?.(nextLayout);
        callPaneCallbacks(paneDataArray, nextLayout, this.paneIdToLastNotifiedSizeMap);
      }
    };
  };
  resizePane = (paneState, unsafePaneSize) => {
    const prevLayout = this.layout;
    const panesArray = this.panesArray;
    const paneConstraintsArr = panesArray.map((paneData) => paneData.constraints);
    const { paneSize, pivotIndices } = paneDataHelper(panesArray, paneState, prevLayout);
    assert(paneSize != null);
    const isLastPane = findPaneDataIndex(panesArray, paneState) === panesArray.length - 1;
    const delta = isLastPane ? paneSize - unsafePaneSize : unsafePaneSize - paneSize;
    const nextLayout = adjustLayoutByDelta({
      delta,
      layout: prevLayout,
      paneConstraints: paneConstraintsArr,
      pivotIndices,
      trigger: "imperative-api"
    });
    if (areArraysEqual(prevLayout, nextLayout)) return;
    this.setLayout(nextLayout);
    this.opts.onLayout.current?.(nextLayout);
    callPaneCallbacks(panesArray, nextLayout, this.paneIdToLastNotifiedSizeMap);
  };
  startDragging = (dragHandleId, e) => {
    const direction = this.opts.direction.current;
    const layout = this.layout;
    const handleElement = getResizeHandleElement(dragHandleId, this.domContext);
    assert(handleElement);
    const initialCursorPosition = getResizeEventCursorPosition(direction, e);
    this.dragState = {
      dragHandleId,
      dragHandleRect: handleElement.getBoundingClientRect(),
      initialCursorPosition,
      initialLayout: layout
    };
  };
  stopDragging = () => {
    resetGlobalCursorStyle();
    this.dragState = null;
  };
  isPaneCollapsed = (pane) => {
    const paneDataArray = this.panesArray;
    const layout = this.layout;
    const { collapsedSize = 0, collapsible, paneSize } = paneDataHelper(paneDataArray, pane, layout);
    if (typeof paneSize !== "number" || typeof collapsedSize !== "number") return false;
    return collapsible === true && areNumbersAlmostEqual(paneSize, collapsedSize);
  };
  expandPane = (pane) => {
    const prevLayout = this.layout;
    const paneDataArray = this.panesArray;
    if (!pane.constraints.collapsible) return;
    const paneConstraintsArray = paneDataArray.map((paneData) => paneData.constraints);
    const { collapsedSize = 0, paneSize, minSize = 0, pivotIndices } = paneDataHelper(paneDataArray, pane, prevLayout);
    if (paneSize !== collapsedSize) return;
    const prevPaneSize = this.paneSizeBeforeCollapseMap.get(pane.opts.id.current);
    const baseSize = prevPaneSize != null && prevPaneSize >= minSize ? prevPaneSize : minSize;
    const isLastPane = findPaneDataIndex(paneDataArray, pane) === paneDataArray.length - 1;
    const delta = isLastPane ? paneSize - baseSize : baseSize - paneSize;
    const nextLayout = adjustLayoutByDelta({
      delta,
      layout: prevLayout,
      paneConstraints: paneConstraintsArray,
      pivotIndices,
      trigger: "imperative-api"
    });
    if (areArraysEqual(prevLayout, nextLayout)) return;
    this.setLayout(nextLayout);
    this.opts.onLayout.current?.(nextLayout);
    callPaneCallbacks(paneDataArray, nextLayout, this.paneIdToLastNotifiedSizeMap);
  };
  collapsePane = (pane) => {
    const prevLayout = this.layout;
    const paneDataArray = this.panesArray;
    if (!pane.constraints.collapsible) return;
    const paneConstraintsArray = paneDataArray.map((paneData) => paneData.constraints);
    const { collapsedSize = 0, paneSize, pivotIndices } = paneDataHelper(paneDataArray, pane, prevLayout);
    assert(paneSize != null);
    if (paneSize === collapsedSize) return;
    this.paneSizeBeforeCollapseMap.set(pane.opts.id.current, paneSize);
    const isLastPane = findPaneDataIndex(paneDataArray, pane) === paneDataArray.length - 1;
    const delta = isLastPane ? paneSize - collapsedSize : collapsedSize - paneSize;
    const nextLayout = adjustLayoutByDelta({
      delta,
      layout: prevLayout,
      paneConstraints: paneConstraintsArray,
      pivotIndices,
      trigger: "imperative-api"
    });
    if (areArraysEqual(prevLayout, nextLayout)) return;
    this.layout = nextLayout;
    this.opts.onLayout.current?.(nextLayout);
    callPaneCallbacks(paneDataArray, nextLayout, this.paneIdToLastNotifiedSizeMap);
  };
  getPaneSize = (pane) => {
    return paneDataHelper(this.panesArray, pane, this.layout).paneSize;
  };
  getPaneStyle = (pane, defaultSize) => {
    const paneDataArray = this.panesArray;
    const layout = this.layout;
    const dragState = this.dragState;
    const paneIndex = findPaneDataIndex(paneDataArray, pane);
    return computePaneFlexBoxStyle({
      defaultSize,
      dragState,
      layout,
      panesArray: paneDataArray,
      paneIndex
    });
  };
  isPaneExpanded = (pane) => {
    const { collapsedSize = 0, collapsible, paneSize } = paneDataHelper(this.panesArray, pane, this.layout);
    return !collapsible || paneSize > collapsedSize;
  };
  registerPane = (pane) => {
    const newPaneDataArray = [...this.panesArray, pane];
    newPaneDataArray.sort((paneA, paneB) => {
      const orderA = paneA.opts.order.current;
      const orderB = paneB.opts.order.current;
      if (orderA == null && orderB == null) {
        return 0;
      } else if (orderA == null) {
        return -1;
      } else if (orderB == null) {
        return 1;
      } else {
        return orderA - orderB;
      }
    });
    this.panesArray = newPaneDataArray;
    this.panesArrayChanged = true;
    return () => {
      const paneDataArray = [...this.panesArray];
      const index = findPaneDataIndex(this.panesArray, pane);
      if (index < 0) return;
      paneDataArray.splice(index, 1);
      this.panesArray = paneDataArray;
      delete this.paneIdToLastNotifiedSizeMap[pane.opts.id.current];
      this.panesArrayChanged = true;
    };
  };
  #setResizeHandlerEventListeners = () => {
    const groupId = this.opts.id.current;
    const handles = getResizeHandleElementsForGroup(groupId, this.domContext);
    const paneDataArray = this.panesArray;
    const unsubHandlers = handles.map((handle) => {
      const handleId = handle.getAttribute("data-pane-resizer-id");
      if (!handleId) return noop;
      const [idBefore, idAfter] = getResizeHandlePaneIds({
        groupId,
        handleId,
        panesArray: paneDataArray,
        domContext: this.domContext
      });
      if (idBefore == null || idAfter == null) return noop;
      const onKeydown = (e) => {
        if (e.defaultPrevented || e.key !== "Enter") return;
        e.preventDefault();
        const paneDataArray2 = this.panesArray;
        const index = paneDataArray2.findIndex((paneData2) => paneData2.opts.id.current === idBefore);
        if (index < 0) return;
        const paneData = paneDataArray2[index];
        assert(paneData);
        const layout = this.layout;
        const size2 = layout[index];
        const { collapsedSize = 0, collapsible, minSize = 0 } = paneData.constraints;
        if (!(size2 != null && collapsible)) return;
        const nextLayout = adjustLayoutByDelta({
          delta: areNumbersAlmostEqual(size2, collapsedSize) ? minSize - size2 : collapsedSize - size2,
          layout,
          paneConstraints: paneDataArray2.map((paneData2) => paneData2.constraints),
          pivotIndices: getPivotIndices({ groupId, dragHandleId: handleId, domContext: this.domContext }),
          trigger: "keyboard"
        });
        if (layout !== nextLayout) {
          this.layout = nextLayout;
        }
      };
      const unsubListener = addEventListener(handle, "keydown", onKeydown);
      return () => {
        unsubListener();
      };
    });
    return () => {
      for (const unsub of unsubHandlers) {
        unsub();
      }
    };
  };
  #props = derived(() => ({
    id: this.opts.id.current,
    "data-pane-group": "",
    "data-direction": this.opts.direction.current,
    "data-pane-group-id": this.opts.id.current,
    style: {
      display: "flex",
      flexDirection: this.opts.direction.current === "horizontal" ? "row" : "column",
      height: "100%",
      overflow: "hidden",
      width: "100%"
    },
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
const resizeKeys = [
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "ArrowUp",
  "End",
  "Home"
];
class PaneResizerState {
  static create(opts) {
    return new PaneResizerState(opts, PaneGroupContext.get());
  }
  opts;
  #group;
  attachment;
  domContext;
  #isDragging = derived(() => this.#group.dragState?.dragHandleId === this.opts.id.current);
  #isFocused = false;
  resizeHandler = null;
  constructor(opts, group) {
    this.opts = opts;
    this.#group = group;
    this.attachment = attachRef(this.opts.ref);
    this.domContext = new DOMContext(this.opts.ref);
  }
  #startDragging = (e) => {
    e.preventDefault();
    if (this.opts.disabled.current) return;
    this.#group.startDragging(this.opts.id.current, e);
    this.opts.onDraggingChange.current(true);
  };
  #stopDraggingAndBlur = () => {
    const node = this.opts.ref.current;
    if (!node) return;
    node.blur();
    this.#group.stopDragging();
    this.opts.onDraggingChange.current(false);
  };
  #onkeydown = (e) => {
    if (this.opts.disabled.current || !this.resizeHandler || e.defaultPrevented) return;
    if (resizeKeys.includes(e.key)) {
      e.preventDefault();
      this.resizeHandler(e);
      return;
    }
    if (e.key !== "F6") return;
    e.preventDefault();
    const handles = getResizeHandleElementsForGroup(this.#group.opts.id.current, this.domContext);
    const index = getResizeHandleElementIndex({
      groupId: this.#group.opts.id.current,
      id: this.opts.id.current,
      domContext: this.domContext
    });
    if (index === null) return;
    let nextIndex = 0;
    if (e.shiftKey) {
      if (index > 0) {
        nextIndex = index - 1;
      } else {
        nextIndex = handles.length - 1;
      }
    } else {
      if (index + 1 < handles.length) {
        nextIndex = index + 1;
      } else {
        nextIndex = 0;
      }
    }
    const nextHandle = handles[nextIndex];
    nextHandle.focus();
  };
  #onblur = () => {
    this.#isFocused = false;
  };
  #onfocus = () => {
    this.#isFocused = true;
  };
  #onmousedown = (e) => {
    this.#startDragging(e);
  };
  #onmouseup = () => {
    this.#stopDraggingAndBlur();
  };
  #ontouchcancel = () => {
    this.#stopDraggingAndBlur();
  };
  #ontouchend = () => {
    this.#stopDraggingAndBlur();
  };
  #ontouchstart = (e) => {
    this.#startDragging(e);
  };
  #props = derived(() => ({
    id: this.opts.id.current,
    role: "separator",
    "data-direction": this.#group.opts.direction.current,
    "data-pane-group-id": this.#group.opts.id.current,
    "data-active": this.#isDragging() ? "pointer" : this.#isFocused ? "keyboard" : void 0,
    "data-enabled": !this.opts.disabled.current,
    "data-pane-resizer-id": this.opts.id.current,
    "data-pane-resizer": "",
    tabIndex: this.opts.tabIndex.current,
    style: {
      cursor: getCursorStyle(this.#group.opts.direction.current),
      touchAction: "none",
      userSelect: "none",
      "-webkit-user-select": "none",
      "-webkit-touch-callout": "none"
    },
    onkeydown: this.#onkeydown,
    onblur: this.#onblur,
    onfocus: this.#onfocus,
    onmousedown: this.#onmousedown,
    onmouseup: this.#onmouseup,
    ontouchcancel: this.#ontouchcancel,
    ontouchend: this.#ontouchend,
    ontouchstart: this.#ontouchstart,
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
class PaneState {
  static create(opts) {
    return new PaneState(opts, PaneGroupContext.get());
  }
  opts;
  group;
  attachment;
  domContext;
  #paneTransitionState = "";
  #callbacks = derived(() => ({
    onCollapse: this.opts.onCollapse.current,
    onExpand: this.opts.onExpand.current,
    onResize: this.opts.onResize.current
  }));
  get callbacks() {
    return this.#callbacks();
  }
  set callbacks($$value) {
    return this.#callbacks($$value);
  }
  #constraints = derived(() => ({
    collapsedSize: this.opts.collapsedSize.current,
    collapsible: this.opts.collapsible.current,
    defaultSize: this.opts.defaultSize.current,
    maxSize: this.opts.maxSize.current,
    minSize: this.opts.minSize.current
  }));
  get constraints() {
    return this.#constraints();
  }
  set constraints($$value) {
    return this.#constraints($$value);
  }
  #handleTransition = (state) => {
    this.#paneTransitionState = state;
    afterTick(() => {
      if (this.opts.ref.current) {
        const element2 = this.opts.ref.current;
        const computedStyle = getComputedStyle(element2);
        const hasTransition = computedStyle.transitionDuration !== "0s";
        if (!hasTransition) {
          this.#paneTransitionState = "";
          return;
        }
        const handleTransitionEnd = (event) => {
          if (event.propertyName === "flex-grow") {
            this.#paneTransitionState = "";
            element2.removeEventListener("transitionend", handleTransitionEnd);
          }
        };
        element2.addEventListener("transitionend", handleTransitionEnd);
      } else {
        this.#paneTransitionState = "";
      }
    });
  };
  pane = {
    collapse: () => {
      this.#handleTransition("collapsing");
      this.group.collapsePane(this);
    },
    expand: () => {
      this.#handleTransition("expanding");
      this.group.expandPane(this);
    },
    getSize: () => this.group.getPaneSize(this),
    isCollapsed: () => this.group.isPaneCollapsed(this),
    isExpanded: () => this.group.isPaneExpanded(this),
    resize: (size2) => this.group.resizePane(this, size2),
    getId: () => this.opts.id.current
  };
  constructor(opts, group) {
    this.opts = opts;
    this.group = group;
    this.attachment = attachRef(this.opts.ref);
    this.domContext = new DOMContext(this.opts.ref);
    watch$1(() => snapshot(this.constraints), () => {
      this.group.panesArrayChanged = true;
    });
  }
  #isCollapsed = derived(() => this.group.isPaneCollapsed(this));
  #paneState = derived(() => this.#paneTransitionState !== "" ? this.#paneTransitionState : this.#isCollapsed() ? "collapsed" : "expanded");
  #props = derived(() => ({
    id: this.opts.id.current,
    style: this.group.getPaneStyle(this, this.opts.defaultSize.current),
    "data-pane": "",
    "data-pane-id": this.opts.id.current,
    "data-pane-group-id": this.group.opts.id.current,
    "data-collapsed": this.#isCollapsed() ? "" : void 0,
    "data-expanded": this.#isCollapsed() ? void 0 : "",
    "data-pane-state": this.#paneState(),
    ...this.attachment
  }));
  get props() {
    return this.#props();
  }
  set props($$value) {
    return this.#props($$value);
  }
}
function Pane_group($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      autoSaveId = null,
      direction,
      id = uid,
      keyboardResizeBy = null,
      onLayoutChange = noop,
      storage = defaultStorage,
      ref = null,
      child,
      children,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const paneGroupState = PaneGroupState.create({
      id: box.with(() => id ?? uid),
      ref: box.with(() => ref, (v) => ref = v),
      autoSaveId: box.with(() => autoSaveId),
      direction: box.with(() => direction),
      keyboardResizeBy: box.with(() => keyboardResizeBy),
      onLayout: box.with(() => onLayoutChange),
      storage: box.with(() => storage)
    });
    const getLayout = () => paneGroupState.layout;
    const setLayout = paneGroupState.setLayout;
    const getId = () => paneGroupState.opts.id.current;
    const mergedProps = mergeProps(restProps, paneGroupState.props);
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { props: mergedProps });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attributes({ ...mergedProps })}>`);
      children?.($$renderer2);
      $$renderer2.push(`<!----></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref, getLayout, setLayout, getId });
  });
}
function Pane($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      id = uid,
      ref = null,
      collapsedSize,
      collapsible,
      defaultSize,
      maxSize,
      minSize,
      onCollapse = noop,
      onExpand = noop,
      onResize = noop,
      order,
      child,
      children,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const paneState = PaneState.create({
      id: box.with(() => id),
      ref: box.with(() => ref, (v) => ref = v),
      collapsedSize: box.with(() => collapsedSize),
      collapsible: box.with(() => collapsible),
      defaultSize: box.with(() => defaultSize),
      maxSize: box.with(() => maxSize),
      minSize: box.with(() => minSize),
      onCollapse: box.with(() => onCollapse),
      onExpand: box.with(() => onExpand),
      onResize: box.with(() => onResize),
      order: box.with(() => order)
    });
    const collapse = paneState.pane.collapse;
    const expand = paneState.pane.expand;
    const getSize = paneState.pane.getSize;
    const isCollapsed = paneState.pane.isCollapsed;
    const isExpanded = paneState.pane.isExpanded;
    const resize = paneState.pane.resize;
    const getId = paneState.pane.getId;
    const mergedProps = mergeProps(restProps, paneState.props);
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { props: mergedProps });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attributes({ ...mergedProps })}>`);
      children?.($$renderer2);
      $$renderer2.push(`<!----></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, {
      ref,
      collapse,
      expand,
      getSize,
      isCollapsed,
      isExpanded,
      resize,
      getId
    });
  });
}
function Pane_resizer($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const uid = props_id($$renderer2);
    let {
      id = uid,
      ref = null,
      disabled = false,
      onDraggingChange = noop,
      tabindex = 0,
      child,
      children,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const resizerState = PaneResizerState.create({
      id: box.with(() => id),
      ref: box.with(() => ref, (v) => ref = v),
      disabled: box.with(() => disabled),
      onDraggingChange: box.with(() => onDraggingChange),
      tabIndex: box.with(() => tabindex)
    });
    const mergedProps = mergeProps(restProps, resizerState.props);
    if (child) {
      $$renderer2.push("<!--[-->");
      child($$renderer2, { props: mergedProps });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attributes({ ...mergedProps })}>`);
      children?.($$renderer2);
      $$renderer2.push(`<!----></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { ref });
  });
}
function Dropdown_menu($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { open = false, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Menu?.($$renderer3, spread_props([
        restProps,
        {
          get open() {
            return open;
          },
          set open($$value) {
            open = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { open });
  });
}
const defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stroke-width": 2,
  "stroke-linecap": "round",
  "stroke-linejoin": "round"
};
const hasA11yProp = (props) => {
  for (const prop in props) {
    if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
      return true;
    }
  }
  return false;
};
function Icon($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const {
      name,
      color = "currentColor",
      size: size2 = 24,
      strokeWidth = 2,
      absoluteStrokeWidth = false,
      iconNode = [],
      children,
      $$slots,
      $$events,
      ...props
    } = $$props;
    $$renderer2.push(`<svg${attributes(
      {
        ...defaultAttributes,
        ...!children && !hasA11yProp(props) && { "aria-hidden": "true" },
        ...props,
        width: size2,
        height: size2,
        stroke: color,
        "stroke-width": absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size2) : strokeWidth,
        class: clsx$1(["lucide-icon lucide", name && `lucide-${name}`, props.class])
      },
      void 0,
      void 0,
      void 0,
      3
    )}><!--[-->`);
    const each_array = ensure_array_like(iconNode);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let [tag, attrs] = each_array[$$index];
      element$1($$renderer2, tag, () => {
        $$renderer2.push(`${attributes({ ...attrs }, void 0, void 0, void 0, 3)}`);
      });
    }
    $$renderer2.push(`<!--]-->`);
    children?.($$renderer2);
    $$renderer2.push(`<!----></svg>`);
  });
}
function Dropdown_menu_portal($$renderer, $$props) {
  let { $$slots, $$events, ...restProps } = $$props;
  $$renderer.push("<!---->");
  Portal?.($$renderer, spread_props([restProps]));
  $$renderer.push(`<!---->`);
}
function Dropdown_menu_content($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      sideOffset = 4,
      portalProps,
      class: className,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      Dropdown_menu_portal($$renderer3, spread_props([
        portalProps,
        {
          children: ($$renderer4) => {
            $$renderer4.push("<!---->");
            Dropdown_menu_content$1?.($$renderer4, spread_props([
              {
                "data-slot": "dropdown-menu-content",
                sideOffset,
                class: cn$1("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-end-2 data-[side=right]:slide-in-from-start-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--bits-dropdown-menu-content-available-height) min-w-[8rem] origin-(--bits-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md outline-none", className)
              },
              restProps,
              {
                get ref() {
                  return ref;
                },
                set ref($$value) {
                  ref = $$value;
                  $$settled = false;
                }
              }
            ]));
            $$renderer4.push(`<!---->`);
          },
          $$slots: { default: true }
        }
      ]));
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Dropdown_menu_item($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      class: className,
      inset,
      variant = "default",
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Menu_item?.($$renderer3, spread_props([
        {
          "data-slot": "dropdown-menu-item",
          "data-inset": inset,
          "data-variant": variant,
          class: cn$1("data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground data-[variant=destructive]:text-destructive data-[variant=destructive]:data-[highlighted]:bg-destructive/10 dark:data-[variant=destructive]:data-[highlighted]:bg-destructive/20 data-[variant=destructive]:data-[highlighted]:text-destructive data-[variant=destructive]:[&_svg]:!text-destructive [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:ps-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='w-'])]:w-4 [&_svg:not([class*='w-'])]:h-4", className)
        },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Dropdown_menu_label($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      class: className,
      inset,
      children,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    $$renderer2.push(`<div${attributes({
      "data-slot": "dropdown-menu-label",
      "data-inset": inset,
      class: clsx$1(cn$1("px-2 py-1.5 text-sm font-semibold data-[inset]:ps-8", className)),
      ...restProps
    })}>`);
    children?.($$renderer2);
    $$renderer2.push(`<!----></div>`);
    bind_props($$props, { ref });
  });
}
function Circle($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { $$slots, $$events, ...props } = $$props;
    const iconNode = [["circle", { "cx": "12", "cy": "12", "r": "10" }]];
    Icon($$renderer2, spread_props([
      { name: "circle" },
      /**
       * @component @name Circle
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIxMCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/circle
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      props,
      {
        iconNode,
        children: ($$renderer3) => {
          props.children?.($$renderer3);
          $$renderer3.push(`<!---->`);
        },
        $$slots: { default: true }
      }
    ]));
  });
}
function Dropdown_menu_separator($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      class: className,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Menu_separator?.($$renderer3, spread_props([
        {
          "data-slot": "dropdown-menu-separator",
          class: cn$1("bg-border -mx-1 my-1 h-px", className)
        },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Dropdown_menu_trigger($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { ref = null, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Menu_trigger?.($$renderer3, spread_props([
        { "data-slot": "dropdown-menu-trigger" },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Chevron_right($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { $$slots, $$events, ...props } = $$props;
    const iconNode = [["path", { "d": "m9 18 6-6-6-6" }]];
    Icon($$renderer2, spread_props([
      { name: "chevron-right" },
      /**
       * @component @name ChevronRight
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtOSAxOCA2LTYtNi02IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/chevron-right
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      props,
      {
        iconNode,
        children: ($$renderer3) => {
          props.children?.($$renderer3);
          $$renderer3.push(`<!---->`);
        },
        $$slots: { default: true }
      }
    ]));
  });
}
function Context_menu($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { open = false, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Context_menu$1?.($$renderer3, spread_props([
        restProps,
        {
          get open() {
            return open;
          },
          set open($$value) {
            open = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { open });
  });
}
function Context_menu_sub($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { open = false, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Menu_sub?.($$renderer3, spread_props([
        restProps,
        {
          get open() {
            return open;
          },
          set open($$value) {
            open = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { open });
  });
}
function Context_menu_portal($$renderer, $$props) {
  let { $$slots, $$events, ...restProps } = $$props;
  $$renderer.push("<!---->");
  Portal?.($$renderer, spread_props([restProps]));
  $$renderer.push(`<!---->`);
}
function Context_menu_trigger($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { ref = null, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Context_menu_trigger$1?.($$renderer3, spread_props([
        { "data-slot": "context-menu-trigger" },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Context_menu_radio_group($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { ref = null, value = "", $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Menu_radio_group?.($$renderer3, spread_props([
        { "data-slot": "context-menu-radio-group" },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          },
          get value() {
            return value;
          },
          set value($$value) {
            value = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref, value });
  });
}
function Context_menu_item($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      class: className,
      inset,
      variant = "default",
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Menu_item?.($$renderer3, spread_props([
        {
          "data-slot": "context-menu-item",
          "data-inset": inset,
          "data-variant": variant,
          class: cn$1("data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground data-[variant=destructive]:text-destructive data-[variant=destructive]:data-[highlighted]:bg-destructive/10 dark:data-[variant=destructive]:data-[highlighted]:bg-destructive/20 data-[variant=destructive]:data-[highlighted]:text-destructive data-[variant=destructive]:[&_svg]:!text-destructive [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:ps-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='w-'])]:w-4 [&_svg:not([class*='w-'])]:h-4", className)
        },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Context_menu_content($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      portalProps,
      class: className,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      Context_menu_portal($$renderer3, spread_props([
        portalProps,
        {
          children: ($$renderer4) => {
            $$renderer4.push("<!---->");
            Context_menu_content$1?.($$renderer4, spread_props([
              {
                "data-slot": "context-menu-content",
                class: cn$1("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-end-2 data-[side=right]:slide-in-from-start-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--bits-context-menu-content-available-height) min-w-[8rem] origin-(--bits-context-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md", className)
              },
              restProps,
              {
                get ref() {
                  return ref;
                },
                set ref($$value) {
                  ref = $$value;
                  $$settled = false;
                }
              }
            ]));
            $$renderer4.push(`<!---->`);
          },
          $$slots: { default: true }
        }
      ]));
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Context_menu_radio_item($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      class: className,
      children: childrenProp,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      {
        let children = function($$renderer4, { checked }) {
          $$renderer4.push(`<span class="pointer-events-none absolute start-2 flex w-3.5 h-3.5 items-center justify-center">`);
          if (checked) {
            $$renderer4.push("<!--[-->");
            Circle($$renderer4, { class: "w-2 h-2 fill-current" });
          } else {
            $$renderer4.push("<!--[!-->");
          }
          $$renderer4.push(`<!--]--></span> `);
          childrenProp?.($$renderer4, { checked });
          $$renderer4.push(`<!---->`);
        };
        Menu_radio_item?.($$renderer3, spread_props([
          {
            "data-slot": "context-menu-radio-item",
            class: cn$1("data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 ps-8 pe-2 text-sm outline-none select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='w-'])]:w-4 [&_svg:not([class*='w-'])]:h-4", className)
          },
          restProps,
          {
            get ref() {
              return ref;
            },
            set ref($$value) {
              ref = $$value;
              $$settled = false;
            },
            children,
            $$slots: { default: true }
          }
        ]));
      }
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Context_menu_separator($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      class: className,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Menu_separator?.($$renderer3, spread_props([
        {
          "data-slot": "context-menu-separator",
          class: cn$1("bg-border -mx-1 my-1 h-px", className)
        },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Context_menu_sub_content($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      class: className,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Menu_sub_content?.($$renderer3, spread_props([
        {
          "data-slot": "context-menu-sub-content",
          class: cn$1("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-end-2 data-[side=right]:slide-in-from-start-2 data-[side=top]:slide-in-from-bottom-2 z-50 min-w-[8rem] origin-(--bits-context-menu-content-transform-origin) overflow-hidden rounded-md border p-1 shadow-lg", className)
        },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Context_menu_sub_trigger($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      class: className,
      inset,
      children,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Menu_sub_trigger?.($$renderer3, spread_props([
        {
          "data-slot": "context-menu-sub-trigger",
          "data-inset": inset,
          class: cn$1("data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground [&_svg:not([class*='text-'])]:text-muted-foreground flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:ps-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='w-'])]:w-4 [&_svg:not([class*='w-'])]:h-4", className)
        },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          },
          children: ($$renderer4) => {
            children?.($$renderer4);
            $$renderer4.push(`<!----> `);
            Chevron_right($$renderer4, { class: "ms-auto" });
            $$renderer4.push(`<!---->`);
          },
          $$slots: { default: true }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Context_menu_label($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      ref = null,
      class: className,
      inset,
      children,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    $$renderer2.push(`<div${attributes({
      "data-slot": "context-menu-label",
      "data-inset": inset,
      class: clsx$1(cn$1("text-foreground px-2 py-1.5 text-sm font-medium data-[inset]:ps-8", className)),
      ...restProps
    })}>`);
    children?.($$renderer2);
    $$renderer2.push(`<!----></div>`);
    bind_props($$props, { ref });
  });
}
const settingsOpen = writable(false);
const settingsTab = writable("general");
const SETTINGS_TAB_IDS = [
  "general",
  "indexing",
  "tools",
  "agents",
  "notifications",
  "crashes",
  "about"
];
function isKnownSettingsTab(tab) {
  return SETTINGS_TAB_IDS.includes(tab);
}
const ENTER_TO_SEND_KEY = "aik-enter-to-send";
function getInitialEnterToSend() {
  if (typeof localStorage === "undefined") return true;
  const stored = localStorage.getItem(ENTER_TO_SEND_KEY);
  return stored === null ? true : stored === "true";
}
const enterToSend = writable(getInitialEnterToSend());
enterToSend.subscribe((value) => {
  if (typeof localStorage !== "undefined") {
    localStorage.setItem(ENTER_TO_SEND_KEY, String(value));
  }
});
function openSettings(tab) {
  if (isKnownSettingsTab(tab)) {
    settingsTab.set(tab);
  } else {
    settingsTab.set("general");
  }
  settingsOpen.set(true);
}
const pendingTerminalPaste = writable(null);
const pendingComposerDraft = writable(null);
function queueComposerDraft(sessionId, text) {
  if (!sessionId) return;
  const trimmed = text.trim();
  if (!trimmed) return;
  pendingComposerDraft.set({ sessionId, text: trimmed });
}
const locales = [
  "en",
  "ja",
  "zh",
  "ko",
  "pt-BR",
  "es",
  "de",
  "fr",
  "ru",
  "pl",
  "tr",
  "it",
  "th",
  "hi",
  "id",
  "vi",
  "uk",
  "nl"
];
const localeNames = {
  en: "English",
  ja: "日本語",
  zh: "中文",
  ko: "한국어",
  "pt-BR": "Português (BR)",
  es: "Español",
  de: "Deutsch",
  fr: "Français",
  ru: "Русский",
  pl: "Polski",
  tr: "Türkçe",
  it: "Italiano",
  th: "ไทย",
  hi: "हिन्दी",
  id: "Bahasa Indonesia",
  vi: "Tiếng Việt",
  uk: "Українська",
  nl: "Nederlands"
};
const translations = {
  en: {
    settings: "Settings",
    back_to_chat: "Back to chat",
    tab_general: "General",
    tab_tools: "Tool Profiles",
    tab_agents: "Agents",
    tab_notifications: "Notifications",
    tab_about: "About",
    language_heading: "Language",
    language_desc: "Choose your preferred display language.",
    general_heading: "General",
    general_desc: "Configure how chat handoff summaries are generated when continuing a conversation in another agent.",
    loading_summary_settings: "Loading summary settings...",
    summary_settings_error: "Failed to load summary settings.",
    handoff_heading: "Chat Handoff Summary",
    handoff_desc: "Used by the session context menu action Continue In....",
    provider_label: "Provider",
    provider_openrouter: "OpenRouter (AI summary)",
    provider_local: "Local fallback (deterministic)",
    provider_help: "OpenRouter summarizes the full transcript using your selected model. Local fallback is faster but less accurate.",
    openrouter_model_label: "OpenRouter Model",
    openrouter_model_help: "Use a large-context model for better handoff quality.",
    default_detail_label: "Default Detail",
    compact: "Compact",
    detailed: "Detailed",
    openrouter_missing_key: "OpenRouter provider selected, but no OpenRouter API key is configured. Continuation summaries will fall back to local mode until a key is set.",
    update_check_started: "Update check started. If an update is available, Unreal will show a notification.",
    update_check_failed: "Failed to start update check.",
    agent_chat: "Agent Chat",
    new_chat: "New chat",
    connecting_tools: "Connecting to Unreal Editor tools…",
    waiting_for_agent_connect: "Waiting for agent to connect…",
    ready_to_send: "Ready to send a message",
    agent_error_check_connection: "Agent error - check connection",
    waiting_for_agent: "Waiting for agent…",
    ask_follow_up: "Ask for follow-up changes",
    describe_task: "Describe a task or ask a question",
    mode_default: "Default",
    sessions: "Sessions",
    refresh_session_list: "Refresh session list",
    loading_sessions: "Loading sessions...",
    no_sessions_yet: "No sessions yet",
    search_sessions_placeholder: "Search sessions...",
    no_matching_sessions: "No matching sessions",
    search_in_chat: "Search in chat",
    n_of_m_matches: (params) => `${params?.n || 0} of ${params?.m || 0}`,
    no_matches: "No matches",
    retry_loading: "Retry loading",
    start_with: "Start with",
    setup_click: "Click to set up",
    api_key_needed: "API key needed",
    new_chat_agent: (params) => `New ${params?.agentName || "Chat"}`,
    about_heading: "About",
    about_desc: "Plugin information and update actions.",
    updates_heading: "Updates",
    updates_desc: "Run a manual update check without restarting the editor.",
    checking: "Checking...",
    check_for_updates: "Check for Updates",
    coming_soon: "Coming soon",
    providers_heading: "Built-in Agent Providers",
    providers_desc: "Enable multiple AI providers and configure their API keys. Models from all enabled providers appear in the model dropdown.",
    active_provider_label: "Enabled Providers",
    active_provider_desc: "Toggle providers on or off. Models from all enabled providers will appear in the chat model dropdown, grouped by provider.",
    provider_config_label: "Provider Configuration",
    provider_api_key_label: "API Key",
    provider_api_key_enter: "Enter API key...",
    provider_api_key_replace: "Enter new key to replace...",
    provider_key_set: "configured",
    provider_no_key_needed: "This provider runs locally and does not require an API key.",
    provider_base_url_label: "Base URL",
    provider_base_url_help: "Leave as default unless you need to use a proxy or custom endpoint.",
    provider_model_label: "Default Model",
    provider_model_help: "The model to use by default. You can also switch models per-session from the chat dropdown.",
    provider_active_no_key: ((params) => `${params?.name ?? "This provider"} is enabled but has no API key configured. Its models won't appear until a key is set.`),
    provider_reconnect_note: "Changes to enabled providers or API keys take effect on the next agent connection. Disconnect and reconnect the built-in agent to apply.",
    // Notifications
    notif_desc: "Control how you are notified when the agent finishes a task or needs your approval for a tool.",
    notif_permission_gate_note: "When “Only when editor is unfocused” is on, permission sounds follow the same rule as other notifications.",
    notif_when_heading: "When to Notify",
    notif_only_unfocused: "Only when editor is unfocused",
    notif_only_unfocused_desc: "Skip notifications when you are actively watching the editor.",
    notif_types_heading: "Notification Types",
    notif_toast: "Editor notification",
    notif_toast_desc: "Show a toast popup in the Unreal Editor when the agent finishes.",
    notif_flash: "Flash taskbar",
    notif_flash_desc: "Flash the editor in the taskbar or dock until you focus it.",
    notif_sound: "Play sound",
    notif_sound_desc: "Play a sound effect when the agent finishes or encounters an error.",
    notif_permission_sound: "Play sound on tool permission",
    notif_permission_sound_desc: "Play a sound when the agent needs allow/deny or Ask User (pick a SoundWave or SoundCue in Project Settings).",
    notif_permission_volume_heading: "Permission alert volume",
    notif_permission_custom_sound_set: "A custom permission alert sound asset is configured.",
    notif_volume_heading: "Sound Volume",
    notif_custom_sounds_set: "Custom success/error sounds are configured.",
    notif_sound_assets_note: "To set custom sound assets (task finish, error, or permission alert), use",
    notif_open_project_settings: "Project Settings",
    project_index_heading: "Project Index",
    project_index_desc: "Index your project for semantic search. Agents find relevant Blueprints, code, and assets by meaning - not just file names.",
    project_index_hint_small: "Recommended for larger projects. Small projects with a few Blueprints typically don't need this.",
    loading: "Loading…",
    index_ready: "Index Ready",
    indexing: "Indexing…",
    error: "Error",
    not_indexed: "Not Indexed",
    configure_and_build: "Configure settings below, then build an index",
    rebuild: "Rebuild",
    clear_index: "Clear index",
    build_index: "Build Index",
    delete_entire_index: "Delete the entire index?",
    cancel: "Cancel",
    delete: "Delete",
    rename: "Rename",
    index_mismatch_prefix: "Index was built with",
    index_mismatch_suffix: "Changing the model or dimensions requires a full rebuild - embeddings from different models can't be mixed.",
    rebuild_index: "Rebuild Index",
    clear_instead: "Clear instead",
    embedding_provider_heading: "Embedding Provider",
    embedding_provider_desc: "Any service supporting the OpenAI",
    custom_endpoint: "Custom Endpoint",
    model: "Model",
    openrouter_embedding_help: "Uses your OpenRouter API key. Gemini Embedding supports flexible dimensions up to 3072.",
    no_openrouter_key_configured: "No OpenRouter API key configured. Set one in Project Settings -> Plugins -> Agent Integration Kit.",
    endpoint_url: "Endpoint URL",
    custom_endpoint_help: "Compatible with Ollama · LM Studio · vLLM · HF TEI · LocalAI",
    api_key_optional: "API Key (optional)",
    api_key_optional_short: "(optional)",
    local_server_no_auth: "Leave empty for local servers without auth.",
    model_name: "Model Name",
    dimensions: "Dimensions",
    default_short: "default",
    dimensions_help: "Lower dimensions = faster search, less storage. 768 is a good balance.",
    index_scope_heading: "Index Scope",
    index_scope_desc: "More content = better search but longer indexing.",
    scope_blueprints_desc: "Graphs, functions, events, variables, components",
    scope_cpp_desc: "Headers and implementation files",
    scope_assets_desc: "Materials, animations, data tables, sounds",
    scope_levels_desc: "Actor hierarchy and placement data",
    scope_documents_desc: "Markdown, text, PDFs, game design docs",
    scope_config_desc: "Project .ini configuration",
    auto_index_heading: "Auto-Index",
    auto_index_desc: "Re-index incrementally when assets change.",
    auto_index_warning: "No index exists yet - build one first. Changes will be indexed automatically after that.",
    saved: "Saved",
    failed_to_start_indexing: "Failed to start indexing",
    index_cleared: "Index cleared",
    failed_to_clear_index: "Failed to clear index",
    tool_profiles_heading: "Tool Profiles",
    tool_profiles_desc: "Create profiles to control which tools agents can use, customize tool descriptions, and add custom system instructions.",
    loading_tools: "Loading tools...",
    all_tools: "All Tools",
    delete_profile: "Delete profile",
    profile_name: "Profile name",
    save: "Save",
    new_profile: "New Profile",
    profile_settings: "Profile Settings",
    customized: "customized",
    description: "Description",
    profile_description_placeholder: "Brief description of this profile's purpose",
    custom_system_instructions: "Custom System Instructions",
    custom_system_instructions_desc: "These instructions are prepended to the agent's system prompt when this profile is active. Use this to guide agent behavior, set constraints, or provide project-specific context.",
    custom_instructions_placeholder: "e.g., Always explain changes before making them. Focus on Blueprint-based solutions. Do not modify C++ code.",
    tool_override_active_one: "tool description override active",
    tool_override_active_many: "tool description overrides active",
    showing_tools_for: "Showing tools for",
    profile: "Profile",
    showing_global_tool_settings: "Showing global tool settings",
    enabled_fraction: (params) => `${params?.enabled}/${params?.total} enabled`,
    enable_all: "Enable all",
    disable_all: "Disable all",
    search_tools: "Search tools...",
    overridden: "overridden",
    custom_description_placeholder: "Custom description for this tool (leave empty to use default)",
    edit_override: "Edit override",
    override_description: "Override description",
    clear: "Clear",
    continue_in: "Continue In...",
    continue_in_terminal: "Continue in terminal",
    terminal_tab: (params) => `Terminal ${params?.n ?? 1}`,
    new_terminal: "New terminal",
    close_terminal_tab: "Close terminal",
    target_agent: "Target agent",
    using_openrouter_ai: (params) => `Using: OpenRouter AI (${params?.modelId})`,
    using_local_fallback_summary: "Using: Local fallback summary",
    no_openrouter_key_detected: "No OpenRouter key detected. Will fall back to local summary.",
    generating_summary: "Generating summary...",
    no_available_target_agents: "No available target agents",
    summary_detail: "Summary detail",
    export_as_markdown: "Export as Markdown",
    working: "Working",
    finished: "Finished",
    hide_sidebar: "Hide sidebar",
    show_sidebar: "Show sidebar",
    new_short: "New",
    send_message_to_get_started: "Send a message to get started",
    generating: "Generating",
    attach_file: "Attach file",
    loading_short: "Loading…",
    model_label: "Model",
    browse_all_models: "Browse all models...",
    effort: "Effort",
    stop_generating: "Stop generating",
    mode_label: "Mode",
    context_window: "Context window",
    context_window_desc: 'How much of the conversation the AI can "remember" right now. As it fills up, older messages get summarized to make room. This is not your plan limit.',
    used_left_pct: (params) => `${params?.used}% used (${params?.left}% left)`,
    tokens_used: (params) => `${params?.used} / ${params?.total} tokens used`,
    cached: (params) => `${params?.count} cached`,
    session_cost: "Session cost",
    last_turn_cost: (params) => `(last turn: ${params?.cost})`,
    turns: (params) => `${params?.count} turn${params?.count === 1 ? "" : "s"}`,
    source_control: "Source Control",
    view_changelists: "View Changelists",
    submit_changes: "Submit Changes",
    no_vcs: "No VCS",
    start_new_conversation: "Start a new conversation",
    choose_agent_below: "Choose an agent below to begin",
    set_up: "set up",
    configure: "configure",
    unavailable: "unavailable",
    close_model_browser: "Close model browser",
    browse_openrouter_models: "Browse OpenRouter Models",
    search_full_catalog: "Search and select from the full catalog",
    close: "Close",
    search_models_placeholder: "Search by name or model id (e.g. minimax, m1.5)",
    loading_models: "Loading models...",
    no_models_match_search: "No models match your search",
    copy: "Copy",
    cut: "Cut",
    paste: "Paste",
    select_all: "Select All"
  },
  zh: {
    settings: "设置",
    back_to_chat: "返回聊天",
    tab_general: "常规",
    tab_tools: "工具配置",
    tab_agents: "代理",
    tab_notifications: "通知",
    tab_about: "关于",
    language_heading: "语言",
    language_desc: "选择您的首选显示语言。",
    general_heading: "常规",
    general_desc: "配置在其他代理中继续对话时如何生成聊天交接摘要。",
    loading_summary_settings: "正在加载摘要设置...",
    summary_settings_error: "加载摘要设置失败。",
    handoff_heading: "聊天交接摘要",
    handoff_desc: "用于会话右键菜单中的 Continue In... 操作。",
    provider_label: "提供方",
    provider_openrouter: "OpenRouter（AI 摘要）",
    provider_local: "本地回退（确定性）",
    provider_help: "OpenRouter 使用你选择的模型总结完整对话。本地回退更快，但准确性较低。",
    openrouter_model_label: "OpenRouter 模型",
    openrouter_model_help: "使用大上下文模型可获得更好的交接质量。",
    default_detail_label: "默认详细程度",
    compact: "简洁",
    detailed: "详细",
    openrouter_missing_key: "已选择 OpenRouter，但尚未配置 OpenRouter API key。在配置 key 之前，continuation summaries 将回退到 local mode。",
    update_check_started: "已开始检查更新。如果有可用更新，Unreal 会显示通知。",
    update_check_failed: "无法开始检查更新。",
    agent_chat: "代理聊天",
    new_chat: "新聊天",
    connecting_tools: "正在连接 Unreal Editor tools…",
    waiting_for_agent_connect: "等待代理连接…",
    ready_to_send: "已准备好发送消息",
    agent_error_check_connection: "代理错误 - 请检查连接",
    waiting_for_agent: "等待代理…",
    ask_follow_up: "询问后续修改",
    describe_task: "描述任务或提出问题",
    mode_default: "默认",
    sessions: "会话",
    refresh_session_list: "刷新会话列表",
    loading_sessions: "正在加载会话...",
    no_sessions_yet: "还没有会话",
    retry_loading: "重新加载",
    start_with: "开始于",
    setup_click: "点击进行设置",
    api_key_needed: "需要 API key",
    new_chat_agent: (params) => `新建${params?.agentName || "聊天"}`
  },
  ko: {
    settings: "설정",
    back_to_chat: "채팅으로 돌아가기",
    tab_general: "일반",
    tab_tools: "도구 프로필",
    tab_agents: "에이전트",
    tab_notifications: "알림",
    tab_about: "정보",
    language_heading: "언어",
    language_desc: "표시 언어를 선택하세요.",
    general_heading: "일반",
    general_desc: "다른 에이전트에서 대화를 이어갈 때 chat handoff summary가 어떻게 생성되는지 설정합니다.",
    loading_summary_settings: "요약 설정을 불러오는 중...",
    summary_settings_error: "요약 설정을 불러오지 못했습니다.",
    handoff_heading: "채팅 인계 요약",
    handoff_desc: "세션 컨텍스트 메뉴의 Continue In... 동작에서 사용됩니다.",
    provider_label: "제공자",
    provider_openrouter: "OpenRouter (AI 요약)",
    provider_local: "로컬 대체 모드 (결정적)",
    provider_help: "OpenRouter는 선택한 모델로 전체 대화를 요약합니다. 로컬 대체 모드는 더 빠르지만 정확도는 낮습니다.",
    openrouter_model_label: "OpenRouter 모델",
    openrouter_model_help: "더 나은 handoff quality를 위해 큰 컨텍스트 모델을 사용하세요.",
    default_detail_label: "기본 상세도",
    compact: "간단",
    detailed: "자세히",
    openrouter_missing_key: "OpenRouter provider가 선택되었지만 OpenRouter API key가 설정되지 않았습니다. Key가 설정될 때까지 continuation summaries는 local mode로 fallback됩니다.",
    update_check_started: "업데이트 확인을 시작했습니다. 업데이트가 있으면 Unreal이 알림을 표시합니다.",
    update_check_failed: "업데이트 확인을 시작하지 못했습니다.",
    agent_chat: "에이전트 채팅",
    new_chat: "새 채팅",
    connecting_tools: "Unreal Editor tools에 연결 중…",
    waiting_for_agent_connect: "에이전트 연결 대기 중…",
    ready_to_send: "메시지를 보낼 준비 완료",
    agent_error_check_connection: "에이전트 오류 - 연결을 확인하세요",
    waiting_for_agent: "에이전트 대기 중…",
    ask_follow_up: "후속 변경 요청하기",
    describe_task: "작업을 설명하거나 질문하세요",
    mode_default: "기본값",
    sessions: "세션",
    refresh_session_list: "세션 목록 새로고침",
    loading_sessions: "세션을 불러오는 중...",
    no_sessions_yet: "아직 세션이 없습니다",
    retry_loading: "다시 시도",
    start_with: "시작 대상",
    setup_click: "설정하려면 클릭",
    api_key_needed: "API 키 필요",
    new_chat_agent: (params) => `새 ${params?.agentName || "채팅"}`
  },
  "pt-BR": {
    settings: "Configurações",
    back_to_chat: "Voltar ao chat",
    tab_general: "Geral",
    tab_tools: "Perfis de Ferramentas",
    tab_agents: "Agentes",
    tab_notifications: "Notificações",
    tab_about: "Sobre",
    language_heading: "Idioma",
    language_desc: "Escolha o idioma de exibição preferido.",
    general_heading: "Geral",
    general_desc: "Configure como os resumos de handoff do chat são gerados ao continuar uma conversa em outro agente.",
    loading_summary_settings: "Carregando configurações de resumo...",
    summary_settings_error: "Falha ao carregar as configurações de resumo.",
    handoff_heading: "Resumo de Handoff do Chat",
    handoff_desc: "Usado na ação Continue In... do menu de contexto da sessão.",
    provider_label: "Provedor",
    provider_openrouter: "OpenRouter (resumo por IA)",
    provider_local: "Fallback local (determinístico)",
    provider_help: "O OpenRouter resume toda a conversa usando o modelo selecionado. O fallback local é mais rápido, mas menos preciso.",
    openrouter_model_label: "Modelo OpenRouter",
    openrouter_model_help: "Use um modelo com grande contexto para melhor qualidade de handoff.",
    default_detail_label: "Detalhe padrão",
    compact: "Compacto",
    detailed: "Detalhado",
    openrouter_missing_key: "O provedor OpenRouter foi selecionado, mas nenhuma OpenRouter API key foi configurada. Os continuation summaries usarão local mode até que uma key seja definida.",
    update_check_started: "A verificação de atualização foi iniciada. Se houver atualização disponível, o Unreal mostrará uma notificação.",
    update_check_failed: "Falha ao iniciar a verificação de atualização.",
    agent_chat: "Chat do Agente",
    new_chat: "Novo chat",
    connecting_tools: "Conectando às Unreal Editor tools…",
    waiting_for_agent_connect: "Aguardando conexão do agente…",
    ready_to_send: "Pronto para enviar uma mensagem",
    agent_error_check_connection: "Erro do agente - verifique a conexão",
    waiting_for_agent: "Aguardando agente…",
    ask_follow_up: "Pedir alterações de acompanhamento",
    describe_task: "Descreva uma tarefa ou faça uma pergunta",
    mode_default: "Padrão",
    sessions: "Sessões",
    refresh_session_list: "Atualizar lista de sessões",
    loading_sessions: "Carregando sessões...",
    no_sessions_yet: "Ainda não há sessões",
    retry_loading: "Tentar novamente",
    start_with: "Começar com",
    setup_click: "Clique para configurar",
    api_key_needed: "API key necessária",
    new_chat_agent: (params) => `Novo ${params?.agentName || "chat"}`
  },
  es: {
    settings: "Configuración",
    back_to_chat: "Volver al chat",
    tab_general: "General",
    tab_tools: "Perfiles de herramientas",
    tab_agents: "Agentes",
    tab_notifications: "Notificaciones",
    tab_about: "Acerca de",
    language_heading: "Idioma",
    language_desc: "Elige tu idioma de visualización preferido.",
    general_heading: "General",
    general_desc: "Configura cómo se generan los resúmenes de handoff del chat al continuar una conversación en otro agente.",
    loading_summary_settings: "Cargando configuración de resúmenes...",
    summary_settings_error: "No se pudo cargar la configuración de resúmenes.",
    handoff_heading: "Resumen de Handoff del Chat",
    handoff_desc: "Se usa en la acción Continue In... del menú contextual de la sesión.",
    provider_label: "Proveedor",
    provider_openrouter: "OpenRouter (resumen con IA)",
    provider_local: "Fallback local (determinista)",
    provider_help: "OpenRouter resume toda la conversación usando el modelo seleccionado. El fallback local es más rápido, pero menos preciso.",
    openrouter_model_label: "Modelo de OpenRouter",
    openrouter_model_help: "Usa un modelo de gran contexto para obtener mejor calidad de handoff.",
    default_detail_label: "Detalle predeterminado",
    compact: "Compacto",
    detailed: "Detallado",
    openrouter_missing_key: "Se seleccionó el proveedor OpenRouter, pero no se configuró ninguna OpenRouter API key. Los continuation summaries usarán local mode hasta que se configure una key.",
    update_check_started: "Se inició la comprobación de actualizaciones. Si hay una actualización disponible, Unreal mostrará una notificación.",
    update_check_failed: "No se pudo iniciar la comprobación de actualizaciones.",
    agent_chat: "Chat del agente",
    new_chat: "Nuevo chat",
    connecting_tools: "Conectando con Unreal Editor tools…",
    waiting_for_agent_connect: "Esperando a que el agente se conecte…",
    ready_to_send: "Listo para enviar un mensaje",
    agent_error_check_connection: "Error del agente - revisa la conexión",
    waiting_for_agent: "Esperando al agente…",
    ask_follow_up: "Pedir cambios adicionales",
    describe_task: "Describe una tarea o haz una pregunta",
    mode_default: "Predeterminado",
    sessions: "Sesiones",
    refresh_session_list: "Actualizar lista de sesiones",
    loading_sessions: "Cargando sesiones...",
    no_sessions_yet: "Aún no hay sesiones",
    retry_loading: "Volver a intentar",
    start_with: "Comenzar con",
    setup_click: "Haz clic para configurar",
    api_key_needed: "Se necesita API key",
    new_chat_agent: (params) => `Nuevo ${params?.agentName || "chat"}`
  },
  de: {
    settings: "Einstellungen",
    back_to_chat: "Zurück zum Chat",
    tab_general: "Allgemein",
    tab_tools: "Tool-Profile",
    tab_agents: "Agenten",
    tab_notifications: "Benachrichtigungen",
    tab_about: "Info",
    language_heading: "Sprache",
    language_desc: "Bevorzugte Anzeigesprache auswählen.",
    general_heading: "Allgemein",
    general_desc: "Konfiguriere, wie Chat-Handoff-Zusammenfassungen erzeugt werden, wenn eine Unterhaltung in einem anderen Agenten fortgesetzt wird.",
    loading_summary_settings: "Zusammenfassungseinstellungen werden geladen...",
    summary_settings_error: "Zusammenfassungseinstellungen konnten nicht geladen werden.",
    handoff_heading: "Chat-Handoff-Zusammenfassung",
    handoff_desc: "Wird von der Aktion Continue In... im Sitzungs-Kontextmenü verwendet.",
    provider_label: "Anbieter",
    provider_openrouter: "OpenRouter (KI-Zusammenfassung)",
    provider_local: "Lokaler Fallback (deterministisch)",
    provider_help: "OpenRouter fasst den gesamten Verlauf mit dem gewählten Modell zusammen. Der lokale Fallback ist schneller, aber ungenauer.",
    openrouter_model_label: "OpenRouter-Modell",
    openrouter_model_help: "Verwende ein Modell mit großem Kontextfenster für bessere Handoff-Qualität.",
    default_detail_label: "Standard-Detailgrad",
    compact: "Kompakt",
    detailed: "Detailliert",
    openrouter_missing_key: "Der OpenRouter-Anbieter ist ausgewählt, aber es wurde keine OpenRouter API key konfiguriert. Continuation summaries fallen auf local mode zurück, bis eine key gesetzt ist.",
    update_check_started: "Die Update-Prüfung wurde gestartet. Wenn ein Update verfügbar ist, zeigt Unreal eine Benachrichtigung an.",
    update_check_failed: "Die Update-Prüfung konnte nicht gestartet werden.",
    agent_chat: "Agent-Chat",
    new_chat: "Neuer Chat",
    connecting_tools: "Verbindung zu Unreal Editor tools wird hergestellt…",
    waiting_for_agent_connect: "Warte auf Agent-Verbindung…",
    ready_to_send: "Bereit zum Senden einer Nachricht",
    agent_error_check_connection: "Agent-Fehler - Verbindung prüfen",
    waiting_for_agent: "Warte auf Agent…",
    ask_follow_up: "Nach Folgeänderungen fragen",
    describe_task: "Beschreibe eine Aufgabe oder stelle eine Frage",
    mode_default: "Standard",
    sessions: "Sitzungen",
    refresh_session_list: "Sitzungsliste aktualisieren",
    loading_sessions: "Sitzungen werden geladen...",
    no_sessions_yet: "Noch keine Sitzungen",
    retry_loading: "Erneut laden",
    start_with: "Starten mit",
    setup_click: "Zum Einrichten klicken",
    api_key_needed: "API key erforderlich",
    new_chat_agent: (params) => `Neuer ${params?.agentName || "Chat"}`
  },
  fr: {
    settings: "Paramètres",
    back_to_chat: "Retour au chat",
    tab_general: "Général",
    tab_tools: "Profils d’outils",
    tab_agents: "Agents",
    tab_notifications: "Notifications",
    tab_about: "À propos",
    language_heading: "Langue",
    language_desc: "Choisissez la langue d'affichage préférée.",
    general_heading: "Général",
    general_desc: "Configurez la façon dont les résumés de handoff du chat sont générés lorsque vous poursuivez une conversation dans un autre agent.",
    loading_summary_settings: "Chargement des paramètres de résumé...",
    summary_settings_error: "Impossible de charger les paramètres de résumé.",
    handoff_heading: "Résumé de Handoff du Chat",
    handoff_desc: "Utilisé par l’action Continue In... dans le menu contextuel de session.",
    provider_label: "Fournisseur",
    provider_openrouter: "OpenRouter (résumé IA)",
    provider_local: "Fallback local (déterministe)",
    provider_help: "OpenRouter résume l’ensemble de la conversation avec le modèle choisi. Le fallback local est plus rapide, mais moins précis.",
    openrouter_model_label: "Modèle OpenRouter",
    openrouter_model_help: "Utilisez un modèle à grand contexte pour une meilleure qualité de handoff.",
    default_detail_label: "Niveau de détail par défaut",
    compact: "Compact",
    detailed: "Détaillé",
    openrouter_missing_key: "Le fournisseur OpenRouter est sélectionné, mais aucune OpenRouter API key n’est configurée. Les continuation summaries utiliseront le local mode jusqu’à ce qu’une key soit définie.",
    update_check_started: "La vérification des mises à jour a démarré. Si une mise à jour est disponible, Unreal affichera une notification.",
    update_check_failed: "Impossible de démarrer la vérification des mises à jour.",
    agent_chat: "Chat Agent",
    new_chat: "Nouveau chat",
    connecting_tools: "Connexion aux Unreal Editor tools…",
    waiting_for_agent_connect: "En attente de connexion de l’agent…",
    ready_to_send: "Prêt à envoyer un message",
    agent_error_check_connection: "Erreur de l’agent - vérifiez la connexion",
    waiting_for_agent: "En attente de l’agent…",
    ask_follow_up: "Demander des modifications supplémentaires",
    describe_task: "Décrivez une tâche ou posez une question",
    mode_default: "Par défaut",
    sessions: "Sessions",
    refresh_session_list: "Actualiser la liste des sessions",
    loading_sessions: "Chargement des sessions...",
    no_sessions_yet: "Aucune session pour le moment",
    retry_loading: "Réessayer",
    start_with: "Commencer avec",
    setup_click: "Cliquez pour configurer",
    api_key_needed: "API key requise",
    new_chat_agent: (params) => `Nouveau ${params?.agentName || "chat"}`
  },
  ru: {
    settings: "Настройки",
    back_to_chat: "Назад к чату",
    tab_general: "Общие",
    tab_tools: "Профили инструментов",
    tab_agents: "Агенты",
    tab_notifications: "Уведомления",
    tab_about: "О программе",
    language_heading: "Язык",
    language_desc: "Выбери предпочитаемый язык интерфейса.",
    general_heading: "Общие",
    general_desc: "Настрой, как создаются chat handoff summary при продолжении разговора в другом агенте.",
    loading_summary_settings: "Загрузка настроек сводки...",
    summary_settings_error: "Не удалось загрузить настройки сводки.",
    handoff_heading: "Сводка передачи чата",
    handoff_desc: "Используется действием Continue In... в контекстном меню сессии.",
    provider_label: "Провайдер",
    provider_openrouter: "OpenRouter (AI-сводка)",
    provider_local: "Локальный fallback (детерминированный)",
    provider_help: "OpenRouter суммирует весь диалог с помощью выбранной модели. Локальный fallback быстрее, но менее точен.",
    openrouter_model_label: "Модель OpenRouter",
    openrouter_model_help: "Используй модель с большим контекстом для лучшего handoff quality.",
    default_detail_label: "Детализация по умолчанию",
    compact: "Кратко",
    detailed: "Подробно",
    openrouter_missing_key: "Выбран провайдер OpenRouter, но OpenRouter API key не настроен. Continuation summaries будут использовать local mode, пока не будет задана key.",
    update_check_started: "Проверка обновлений запущена. Если обновление доступно, Unreal покажет уведомление.",
    update_check_failed: "Не удалось запустить проверку обновлений.",
    agent_chat: "Чат агента",
    new_chat: "Новый чат",
    connecting_tools: "Подключение к Unreal Editor tools…",
    waiting_for_agent_connect: "Ожидание подключения агента…",
    ready_to_send: "Готово к отправке сообщения",
    agent_error_check_connection: "Ошибка агента - проверь соединение",
    waiting_for_agent: "Ожидание агента…",
    ask_follow_up: "Попросить дополнительные изменения",
    describe_task: "Опиши задачу или задай вопрос",
    mode_default: "По умолчанию",
    sessions: "Сессии",
    refresh_session_list: "Обновить список сессий",
    loading_sessions: "Загрузка сессий...",
    no_sessions_yet: "Сессий пока нет",
    retry_loading: "Повторить загрузку",
    start_with: "Начать с",
    setup_click: "Нажмите для настройки",
    api_key_needed: "Требуется API key",
    new_chat_agent: (params) => `Новый ${params?.agentName || "чат"}`
  },
  pl: {
    settings: "Ustawienia",
    back_to_chat: "Powrót do czatu",
    tab_general: "Ogólne",
    tab_tools: "Profile narzędzi",
    tab_agents: "Agenci",
    tab_notifications: "Powiadomienia",
    tab_about: "O programie",
    language_heading: "Język",
    language_desc: "Wybierz preferowany język wyświetlania.",
    general_heading: "Ogólne",
    general_desc: "Skonfiguruj sposób generowania chat handoff summary podczas kontynuowania rozmowy w innym agencie.",
    loading_summary_settings: "Ładowanie ustawień podsumowania...",
    summary_settings_error: "Nie udało się załadować ustawień podsumowania.",
    handoff_heading: "Podsumowanie przekazania czatu",
    handoff_desc: "Używane przez akcję Continue In... w menu kontekstowym sesji.",
    provider_label: "Dostawca",
    provider_openrouter: "OpenRouter (podsumowanie AI)",
    provider_local: "Lokalny fallback (deterministyczny)",
    provider_help: "OpenRouter streszcza całą rozmowę przy użyciu wybranego modelu. Lokalny fallback jest szybszy, ale mniej dokładny.",
    openrouter_model_label: "Model OpenRouter",
    openrouter_model_help: "Użyj modelu z dużym kontekstem, aby uzyskać lepszą jakość handoff.",
    default_detail_label: "Domyślny poziom szczegółów",
    compact: "Kompaktowe",
    detailed: "Szczegółowe",
    openrouter_missing_key: "Wybrano dostawcę OpenRouter, ale nie skonfigurowano OpenRouter API key. Continuation summaries będą używać local mode, dopóki key nie zostanie ustawiony.",
    update_check_started: "Rozpoczęto sprawdzanie aktualizacji. Jeśli aktualizacja jest dostępna, Unreal pokaże powiadomienie.",
    update_check_failed: "Nie udało się rozpocząć sprawdzania aktualizacji.",
    agent_chat: "Czat agenta",
    new_chat: "Nowy czat",
    connecting_tools: "Łączenie z Unreal Editor tools…",
    waiting_for_agent_connect: "Oczekiwanie na połączenie agenta…",
    ready_to_send: "Gotowe do wysłania wiadomości",
    agent_error_check_connection: "Błąd agenta - sprawdź połączenie",
    waiting_for_agent: "Oczekiwanie na agenta…",
    ask_follow_up: "Poproś o dalsze zmiany",
    describe_task: "Opisz zadanie lub zadaj pytanie",
    mode_default: "Domyślny",
    sessions: "Sesje",
    refresh_session_list: "Odśwież listę sesji",
    loading_sessions: "Ładowanie sesji...",
    no_sessions_yet: "Brak sesji",
    retry_loading: "Spróbuj ponownie",
    start_with: "Rozpocznij z",
    setup_click: "Kliknij, aby skonfigurować",
    api_key_needed: "Wymagany API key",
    new_chat_agent: (params) => `Nowy ${params?.agentName || "czat"}`
  },
  tr: {
    settings: "Ayarlar",
    back_to_chat: "Sohbete dön",
    tab_general: "Genel",
    tab_tools: "Araç Profilleri",
    tab_agents: "Ajanlar",
    tab_notifications: "Bildirimler",
    tab_about: "Hakkında",
    language_heading: "Dil",
    language_desc: "Tercih ettiğiniz görüntüleme dilini seçin.",
    general_heading: "Genel",
    general_desc: "Bir konuşmayı başka bir ajanda sürdürürken chat handoff summary oluşturulmasını yapılandırın.",
    loading_summary_settings: "Özet ayarları yükleniyor...",
    summary_settings_error: "Özet ayarları yüklenemedi.",
    handoff_heading: "Sohbet Devir Özeti",
    handoff_desc: "Oturum bağlam menüsündeki Continue In... eylemi tarafından kullanılır.",
    provider_label: "Sağlayıcı",
    provider_openrouter: "OpenRouter (AI özeti)",
    provider_local: "Yerel fallback (deterministik)",
    provider_help: "OpenRouter, seçtiğiniz modeli kullanarak tüm konuşmayı özetler. Yerel fallback daha hızlıdır ancak daha az doğrudur.",
    openrouter_model_label: "OpenRouter Modeli",
    openrouter_model_help: "Daha iyi handoff quality için geniş bağlamlı bir model kullanın.",
    default_detail_label: "Varsayılan Ayrıntı",
    compact: "Kısa",
    detailed: "Ayrıntılı",
    openrouter_missing_key: "OpenRouter sağlayıcısı seçildi ancak OpenRouter API key yapılandırılmadı. Bir key ayarlanana kadar continuation summaries local mode kullanır.",
    update_check_started: "Güncelleme kontrolü başlatıldı. Bir güncelleme varsa Unreal bildirim gösterecek.",
    update_check_failed: "Güncelleme kontrolü başlatılamadı.",
    agent_chat: "Ajan Sohbeti",
    new_chat: "Yeni sohbet",
    connecting_tools: "Unreal Editor tools ile bağlantı kuruluyor…",
    waiting_for_agent_connect: "Ajanın bağlanması bekleniyor…",
    ready_to_send: "Mesaj göndermeye hazır",
    agent_error_check_connection: "Ajan hatası - bağlantıyı kontrol et",
    waiting_for_agent: "Ajan bekleniyor…",
    ask_follow_up: "Devam değişiklikleri iste",
    describe_task: "Bir görev tanımlayın veya soru sorun",
    mode_default: "Varsayılan",
    sessions: "Oturumlar",
    refresh_session_list: "Oturum listesini yenile",
    loading_sessions: "Oturumlar yükleniyor...",
    no_sessions_yet: "Henüz oturum yok",
    retry_loading: "Yeniden dene",
    start_with: "Şununla başla",
    setup_click: "Kurmak için tıklayın",
    api_key_needed: "API key gerekli",
    new_chat_agent: (params) => `Yeni ${params?.agentName || "sohbet"}`
  },
  it: {
    settings: "Impostazioni",
    back_to_chat: "Torna alla chat",
    tab_general: "Generale",
    tab_tools: "Profili strumenti",
    tab_agents: "Agenti",
    tab_notifications: "Notifiche",
    tab_about: "Informazioni",
    language_heading: "Lingua",
    language_desc: "Scegli la lingua di visualizzazione preferita.",
    general_heading: "Generale",
    general_desc: "Configura come vengono generati i chat handoff summary quando continui una conversazione in un altro agente.",
    loading_summary_settings: "Caricamento delle impostazioni del riepilogo...",
    summary_settings_error: "Impossibile caricare le impostazioni del riepilogo.",
    handoff_heading: "Riepilogo di Handoff della Chat",
    handoff_desc: "Usato dall’azione Continue In... nel menu contestuale della sessione.",
    provider_label: "Provider",
    provider_openrouter: "OpenRouter (riepilogo AI)",
    provider_local: "Fallback locale (deterministico)",
    provider_help: "OpenRouter riassume l’intera conversazione usando il modello selezionato. Il fallback locale è più veloce ma meno accurato.",
    openrouter_model_label: "Modello OpenRouter",
    openrouter_model_help: "Usa un modello con contesto ampio per una migliore qualità di handoff.",
    default_detail_label: "Dettaglio predefinito",
    compact: "Compatto",
    detailed: "Dettagliato",
    openrouter_missing_key: "È stato selezionato il provider OpenRouter, ma non è configurata alcuna OpenRouter API key. I continuation summaries useranno local mode finché non verrà impostata una key.",
    update_check_started: "Controllo aggiornamenti avviato. Se è disponibile un aggiornamento, Unreal mostrerà una notifica.",
    update_check_failed: "Impossibile avviare il controllo aggiornamenti.",
    agent_chat: "Chat Agente",
    new_chat: "Nuova chat",
    connecting_tools: "Connessione alle Unreal Editor tools…",
    waiting_for_agent_connect: "In attesa della connessione dell’agente…",
    ready_to_send: "Pronto per inviare un messaggio",
    agent_error_check_connection: "Errore agente - controlla la connessione",
    waiting_for_agent: "In attesa dell’agente…",
    ask_follow_up: "Chiedi modifiche successive",
    describe_task: "Descrivi un’attività o fai una domanda",
    mode_default: "Predefinito",
    sessions: "Sessioni",
    refresh_session_list: "Aggiorna elenco sessioni",
    loading_sessions: "Caricamento sessioni...",
    no_sessions_yet: "Nessuna sessione",
    retry_loading: "Riprova",
    start_with: "Inizia con",
    setup_click: "Fai clic per configurare",
    api_key_needed: "API key necessaria",
    new_chat_agent: (params) => `Nuova ${params?.agentName || "chat"}`
  },
  th: {
    settings: "การตั้งค่า",
    back_to_chat: "กลับไปที่แชท",
    tab_general: "ทั่วไป",
    tab_tools: "โปรไฟล์เครื่องมือ",
    tab_agents: "เอเจนต์",
    tab_notifications: "การแจ้งเตือน",
    tab_about: "เกี่ยวกับ",
    language_heading: "ภาษา",
    language_desc: "เลือกภาษาที่ต้องการแสดงผล",
    general_heading: "ทั่วไป",
    general_desc: "กำหนดวิธีสร้าง chat handoff summary เมื่อสนทนาต่อในเอเจนต์อื่น",
    loading_summary_settings: "กำลังโหลดการตั้งค่าสรุป...",
    summary_settings_error: "โหลดการตั้งค่าสรุปไม่สำเร็จ",
    handoff_heading: "สรุปการส่งต่อแชท",
    handoff_desc: "ใช้กับคำสั่ง Continue In... ในเมนูบริบทของเซสชัน",
    provider_label: "ผู้ให้บริการ",
    provider_openrouter: "OpenRouter (สรุปด้วย AI)",
    provider_local: "Local fallback (กำหนดผลลัพธ์ได้)",
    provider_help: "OpenRouter จะสรุปบทสนทนาทั้งหมดด้วยโมเดลที่เลือก Local fallback เร็วกว่าแต่แม่นยำน้อยกว่า",
    openrouter_model_label: "โมเดล OpenRouter",
    openrouter_model_help: "ใช้โมเดลที่มีบริบทยาวเพื่อคุณภาพ handoff ที่ดีกว่า",
    default_detail_label: "ระดับรายละเอียดเริ่มต้น",
    compact: "กระชับ",
    detailed: "ละเอียด",
    openrouter_missing_key: "เลือก OpenRouter provider แล้ว แต่ยังไม่ได้ตั้งค่า OpenRouter API key ดังนั้น continuation summaries จะใช้ local mode จนกว่าจะกำหนด key",
    update_check_started: "เริ่มตรวจสอบอัปเดตแล้ว หากมีอัปเดต Unreal จะแสดงการแจ้งเตือน",
    update_check_failed: "ไม่สามารถเริ่มตรวจสอบอัปเดตได้",
    agent_chat: "แชทเอเจนต์",
    new_chat: "แชทใหม่",
    connecting_tools: "กำลังเชื่อมต่อกับ Unreal Editor tools…",
    waiting_for_agent_connect: "กำลังรอเอเจนต์เชื่อมต่อ…",
    ready_to_send: "พร้อมส่งข้อความ",
    agent_error_check_connection: "เอเจนต์ผิดพลาด - ตรวจสอบการเชื่อมต่อ",
    waiting_for_agent: "กำลังรอเอเจนต์…",
    ask_follow_up: "ขอการเปลี่ยนแปลงต่อเนื่อง",
    describe_task: "อธิบายงานหรือถามคำถาม",
    mode_default: "ค่าเริ่มต้น",
    sessions: "เซสชัน",
    refresh_session_list: "รีเฟรชรายการเซสชัน",
    loading_sessions: "กำลังโหลดเซสชัน...",
    no_sessions_yet: "ยังไม่มีเซสชัน",
    retry_loading: "ลองใหม่",
    start_with: "เริ่มด้วย",
    setup_click: "คลิกเพื่อตั้งค่า",
    api_key_needed: "ต้องใช้ API key",
    new_chat_agent: (params) => `${params?.agentName || "แชท"}ใหม่`
  },
  hi: {
    settings: "सेटिंग्स",
    back_to_chat: "चैट पर वापस जाएं",
    tab_general: "सामान्य",
    tab_tools: "टूल प्रोफाइल",
    tab_agents: "एजेंट",
    tab_notifications: "सूचनाएं",
    tab_about: "जानकारी",
    language_heading: "भाषा",
    language_desc: "अपनी पसंदीदा display language चुनें।",
    general_heading: "सामान्य",
    general_desc: "जब किसी बातचीत को दूसरे एजेंट में जारी किया जाता है, तब chat handoff summary कैसे बनेगी इसे कॉन्फ़िगर करें।",
    loading_summary_settings: "समरी सेटिंग्स लोड हो रही हैं...",
    summary_settings_error: "समरी सेटिंग्स लोड नहीं हो सकीं।",
    handoff_heading: "चैट हैंडऑफ़ समरी",
    handoff_desc: "यह session context menu के Continue In... action में उपयोग होती है।",
    provider_label: "प्रदाता",
    provider_openrouter: "OpenRouter (AI समरी)",
    provider_local: "Local fallback (deterministic)",
    provider_help: "OpenRouter आपके चुने हुए मॉडल से पूरे transcript की summary बनाता है। Local fallback तेज़ है लेकिन कम सटीक है।",
    openrouter_model_label: "OpenRouter मॉडल",
    openrouter_model_help: "बेहतर handoff quality के लिए large-context model का उपयोग करें।",
    default_detail_label: "डिफ़ॉल्ट विवरण",
    compact: "संक्षिप्त",
    detailed: "विस्तृत",
    openrouter_missing_key: "OpenRouter provider चुना गया है, लेकिन OpenRouter API key कॉन्फ़िगर नहीं है। Key सेट होने तक continuation summaries local mode में fallback होंगी।",
    update_check_started: "Update check शुरू हो गया है। अगर update उपलब्ध है, तो Unreal notification दिखाएगा।",
    update_check_failed: "Update check शुरू नहीं हो सका।",
    agent_chat: "एजेंट चैट",
    new_chat: "नई चैट",
    connecting_tools: "Unreal Editor tools से कनेक्ट हो रहा है…",
    waiting_for_agent_connect: "एजेंट कनेक्ट होने की प्रतीक्षा में…",
    ready_to_send: "संदेश भेजने के लिए तैयार",
    agent_error_check_connection: "एजेंट त्रुटि - कनेक्शन जांचें",
    waiting_for_agent: "एजेंट की प्रतीक्षा में…",
    ask_follow_up: "आगे के बदलाव पूछें",
    describe_task: "कोई task बताएं या सवाल पूछें",
    mode_default: "डिफ़ॉल्ट",
    sessions: "सेशंस",
    refresh_session_list: "सेशन सूची रीफ़्रेश करें",
    loading_sessions: "सेशंस लोड हो रहे हैं...",
    no_sessions_yet: "अभी कोई सेशन नहीं है",
    retry_loading: "फिर से लोड करें",
    start_with: "इसके साथ शुरू करें",
    setup_click: "सेटअप करने के लिए क्लिक करें",
    api_key_needed: "API key चाहिए",
    new_chat_agent: (params) => `नई ${params?.agentName || "चैट"}`
  },
  id: {
    settings: "Pengaturan",
    back_to_chat: "Kembali ke chat",
    tab_general: "Umum",
    tab_tools: "Profil Alat",
    tab_agents: "Agen",
    tab_notifications: "Notifikasi",
    tab_about: "Tentang",
    language_heading: "Bahasa",
    language_desc: "Pilih bahasa tampilan yang Anda inginkan.",
    general_heading: "Umum",
    general_desc: "Atur bagaimana chat handoff summary dibuat saat melanjutkan percakapan di agen lain.",
    loading_summary_settings: "Memuat pengaturan ringkasan...",
    summary_settings_error: "Gagal memuat pengaturan ringkasan.",
    handoff_heading: "Ringkasan Handoff Chat",
    handoff_desc: "Digunakan oleh aksi Continue In... pada menu konteks sesi.",
    provider_label: "Penyedia",
    provider_openrouter: "OpenRouter (ringkasan AI)",
    provider_local: "Fallback lokal (deterministik)",
    provider_help: "OpenRouter merangkum seluruh percakapan menggunakan model yang dipilih. Fallback lokal lebih cepat tetapi kurang akurat.",
    openrouter_model_label: "Model OpenRouter",
    openrouter_model_help: "Gunakan model dengan konteks besar untuk kualitas handoff yang lebih baik.",
    default_detail_label: "Detail Default",
    compact: "Ringkas",
    detailed: "Detail",
    openrouter_missing_key: "OpenRouter provider dipilih, tetapi OpenRouter API key belum dikonfigurasi. Continuation summaries akan menggunakan local mode sampai key diatur.",
    update_check_started: "Pemeriksaan pembaruan dimulai. Jika ada pembaruan, Unreal akan menampilkan notifikasi.",
    update_check_failed: "Gagal memulai pemeriksaan pembaruan.",
    agent_chat: "Chat Agen",
    new_chat: "Chat baru",
    connecting_tools: "Menghubungkan ke Unreal Editor tools…",
    waiting_for_agent_connect: "Menunggu agen terhubung…",
    ready_to_send: "Siap mengirim pesan",
    agent_error_check_connection: "Kesalahan agen - periksa koneksi",
    waiting_for_agent: "Menunggu agen…",
    ask_follow_up: "Minta perubahan lanjutan",
    describe_task: "Jelaskan tugas atau ajukan pertanyaan",
    mode_default: "Default",
    sessions: "Sesi",
    refresh_session_list: "Segarkan daftar sesi",
    loading_sessions: "Memuat sesi...",
    no_sessions_yet: "Belum ada sesi",
    retry_loading: "Coba muat lagi",
    start_with: "Mulai dengan",
    setup_click: "Klik untuk menyiapkan",
    api_key_needed: "Perlu API key",
    new_chat_agent: (params) => `${params?.agentName || "Chat"} baru`
  },
  vi: {
    settings: "Cài đặt",
    back_to_chat: "Quay lại chat",
    tab_general: "Chung",
    tab_tools: "Hồ sơ công cụ",
    tab_agents: "Tác nhân",
    tab_notifications: "Thông báo",
    tab_about: "Giới thiệu",
    language_heading: "Ngôn ngữ",
    language_desc: "Chọn ngôn ngữ hiển thị ưa thích của bạn.",
    general_heading: "Chung",
    general_desc: "Cấu hình cách tạo chat handoff summary khi tiếp tục một cuộc trò chuyện trong tác nhân khác.",
    loading_summary_settings: "Đang tải cài đặt tóm tắt...",
    summary_settings_error: "Không thể tải cài đặt tóm tắt.",
    handoff_heading: "Tóm tắt Bàn giao Chat",
    handoff_desc: "Được dùng bởi hành động Continue In... trong menu ngữ cảnh của phiên.",
    provider_label: "Nhà cung cấp",
    provider_openrouter: "OpenRouter (tóm tắt AI)",
    provider_local: "Fallback cục bộ (xác định)",
    provider_help: "OpenRouter tóm tắt toàn bộ cuộc trò chuyện bằng mô hình bạn chọn. Fallback cục bộ nhanh hơn nhưng kém chính xác hơn.",
    openrouter_model_label: "Mô hình OpenRouter",
    openrouter_model_help: "Dùng mô hình ngữ cảnh lớn để có chất lượng handoff tốt hơn.",
    default_detail_label: "Mức chi tiết mặc định",
    compact: "Ngắn gọn",
    detailed: "Chi tiết",
    openrouter_missing_key: "Đã chọn OpenRouter provider nhưng chưa cấu hình OpenRouter API key. Continuation summaries sẽ dùng local mode cho đến khi key được đặt.",
    update_check_started: "Đã bắt đầu kiểm tra cập nhật. Nếu có bản cập nhật, Unreal sẽ hiển thị thông báo.",
    update_check_failed: "Không thể bắt đầu kiểm tra cập nhật.",
    agent_chat: "Chat Tác nhân",
    new_chat: "Chat mới",
    connecting_tools: "Đang kết nối tới Unreal Editor tools…",
    waiting_for_agent_connect: "Đang chờ tác nhân kết nối…",
    ready_to_send: "Sẵn sàng gửi tin nhắn",
    agent_error_check_connection: "Lỗi tác nhân - kiểm tra kết nối",
    waiting_for_agent: "Đang chờ tác nhân…",
    ask_follow_up: "Yêu cầu thay đổi tiếp theo",
    describe_task: "Mô tả tác vụ hoặc đặt câu hỏi",
    mode_default: "Mặc định",
    sessions: "Phiên",
    refresh_session_list: "Làm mới danh sách phiên",
    loading_sessions: "Đang tải phiên...",
    no_sessions_yet: "Chưa có phiên nào",
    retry_loading: "Tải lại",
    start_with: "Bắt đầu với",
    setup_click: "Nhấp để thiết lập",
    api_key_needed: "Cần API key",
    new_chat_agent: (params) => `${params?.agentName || "chat"} mới`
  },
  uk: {
    settings: "Налаштування",
    back_to_chat: "Повернутися до чату",
    tab_general: "Загальні",
    tab_tools: "Профілі інструментів",
    tab_agents: "Агенти",
    tab_notifications: "Сповіщення",
    tab_about: "Про програму",
    language_heading: "Мова",
    language_desc: "Оберіть бажану мову відображення.",
    general_heading: "Загальні",
    general_desc: "Налаштуйте, як генерується chat handoff summary під час продовження розмови в іншому агенті.",
    loading_summary_settings: "Завантаження налаштувань підсумку...",
    summary_settings_error: "Не вдалося завантажити налаштування підсумку.",
    handoff_heading: "Підсумок передачі чату",
    handoff_desc: "Використовується дією Continue In... у контекстному меню сесії.",
    provider_label: "Провайдер",
    provider_openrouter: "OpenRouter (AI-підсумок)",
    provider_local: "Локальний fallback (детермінований)",
    provider_help: "OpenRouter підсумовує всю розмову за допомогою вибраної моделі. Локальний fallback швидший, але менш точний.",
    openrouter_model_label: "Модель OpenRouter",
    openrouter_model_help: "Використовуйте модель із великим контекстом для кращої якості handoff.",
    default_detail_label: "Детальність за замовчуванням",
    compact: "Стисло",
    detailed: "Детально",
    openrouter_missing_key: "Вибрано провайдера OpenRouter, але OpenRouter API key не налаштовано. Continuation summaries використовуватимуть local mode, доки key не буде задано.",
    update_check_started: "Перевірку оновлень розпочато. Якщо оновлення доступне, Unreal покаже сповіщення.",
    update_check_failed: "Не вдалося розпочати перевірку оновлень.",
    agent_chat: "Чат агента",
    new_chat: "Новий чат",
    connecting_tools: "Підключення до Unreal Editor tools…",
    waiting_for_agent_connect: "Очікування підключення агента…",
    ready_to_send: "Готово до надсилання повідомлення",
    agent_error_check_connection: "Помилка агента - перевірте підключення",
    waiting_for_agent: "Очікування агента…",
    ask_follow_up: "Попросити наступні зміни",
    describe_task: "Опишіть задачу або поставте запитання",
    mode_default: "Типово",
    sessions: "Сесії",
    refresh_session_list: "Оновити список сесій",
    loading_sessions: "Завантаження сесій...",
    no_sessions_yet: "Сесій ще немає",
    retry_loading: "Спробувати ще раз",
    start_with: "Почати з",
    setup_click: "Натисніть для налаштування",
    api_key_needed: "Потрібна API key",
    new_chat_agent: (params) => `Новий ${params?.agentName || "чат"}`
  },
  nl: {
    settings: "Instellingen",
    back_to_chat: "Terug naar chat",
    tab_general: "Algemeen",
    tab_tools: "Toolprofielen",
    tab_agents: "Agenten",
    tab_notifications: "Meldingen",
    tab_about: "Over",
    language_heading: "Taal",
    language_desc: "Kies je gewenste weergavetaal.",
    general_heading: "Algemeen",
    general_desc: "Configureer hoe chat handoff summary wordt gegenereerd wanneer je een gesprek in een andere agent voortzet.",
    loading_summary_settings: "Samenvattingsinstellingen laden...",
    summary_settings_error: "Samenvattingsinstellingen laden mislukt.",
    handoff_heading: "Chat Handoff-samenvatting",
    handoff_desc: "Gebruikt door de actie Continue In... in het contextmenu van de sessie.",
    provider_label: "Provider",
    provider_openrouter: "OpenRouter (AI-samenvatting)",
    provider_local: "Lokale fallback (deterministisch)",
    provider_help: "OpenRouter vat het volledige gesprek samen met het gekozen model. Lokale fallback is sneller, maar minder nauwkeurig.",
    openrouter_model_label: "OpenRouter-model",
    openrouter_model_help: "Gebruik een model met grote context voor betere handoff-kwaliteit.",
    default_detail_label: "Standaarddetail",
    compact: "Compact",
    detailed: "Gedetailleerd",
    openrouter_missing_key: "De OpenRouter-provider is geselecteerd, maar er is geen OpenRouter API key ingesteld. Continuation summaries gebruiken local mode totdat een key is ingesteld.",
    update_check_started: "Updatecontrole gestart. Als er een update beschikbaar is, toont Unreal een melding.",
    update_check_failed: "Kon de updatecontrole niet starten.",
    agent_chat: "Agentchat",
    new_chat: "Nieuwe chat",
    connecting_tools: "Verbinden met Unreal Editor tools…",
    waiting_for_agent_connect: "Wachten op agentverbinding…",
    ready_to_send: "Klaar om een bericht te verzenden",
    agent_error_check_connection: "Agentfout - controleer de verbinding",
    waiting_for_agent: "Wachten op agent…",
    ask_follow_up: "Vraag om vervolgwijzigingen",
    describe_task: "Beschrijf een taak of stel een vraag",
    mode_default: "Standaard",
    sessions: "Sessies",
    refresh_session_list: "Sessielijst vernieuwen",
    loading_sessions: "Sessies laden...",
    no_sessions_yet: "Nog geen sessies",
    retry_loading: "Opnieuw laden",
    start_with: "Begin met",
    setup_click: "Klik om in te stellen",
    api_key_needed: "API key nodig",
    new_chat_agent: (params) => `Nieuwe ${params?.agentName || "chat"}`
  },
  ja: {
    settings: "設定",
    back_to_chat: "チャットに戻る",
    tab_general: "一般",
    tab_tools: "ツールプロファイル",
    tab_agents: "エージェント",
    tab_notifications: "通知",
    tab_about: "情報",
    language_heading: "言語",
    language_desc: "表示言語を選択してください。",
    general_heading: "一般",
    general_desc: "別のエージェントで会話を続けるときの chat handoff summary の生成方法を設定します。",
    loading_summary_settings: "サマリー設定を読み込み中...",
    summary_settings_error: "サマリー設定の読み込みに失敗しました。",
    handoff_heading: "チャット引き継ぎサマリー",
    handoff_desc: "セッションのコンテキストメニューにある Continue In... で使用されます。",
    provider_label: "プロバイダー",
    provider_openrouter: "OpenRouter (AI summary)",
    provider_local: "Local fallback (deterministic)",
    provider_help: "OpenRouter は選択したモデルで会話全体を要約します。Local fallback は高速ですが精度は低めです。",
    openrouter_model_label: "OpenRouter モデル",
    openrouter_model_help: "より良い handoff quality のために大きなコンテキスト長のモデルを使ってください。",
    default_detail_label: "既定の詳細度",
    compact: "簡潔",
    detailed: "詳細",
    openrouter_missing_key: "OpenRouter provider が選択されていますが、OpenRouter API key が設定されていません。Key が設定されるまで continuation summaries は local mode にフォールバックします。",
    update_check_started: "アップデート確認を開始しました。更新があれば Unreal に通知が表示されます。",
    update_check_failed: "アップデート確認を開始できませんでした。",
    agent_chat: "エージェントチャット",
    new_chat: "新しいチャット",
    connecting_tools: "Unreal Editor tools に接続中…",
    waiting_for_agent_connect: "エージェントの接続を待機中…",
    ready_to_send: "送信準備完了",
    agent_error_check_connection: "エージェントエラー - 接続を確認してください",
    waiting_for_agent: "エージェントを待機中…",
    ask_follow_up: "追加の変更を依頼する",
    describe_task: "タスクを説明するか質問してください",
    mode_default: "デフォルト",
    sessions: "セッション",
    refresh_session_list: "セッション一覧を更新",
    loading_sessions: "セッションを読み込み中...",
    no_sessions_yet: "まだセッションがありません",
    retry_loading: "再読み込み",
    start_with: "開始するエージェント",
    setup_click: "セットアップするにはクリック",
    api_key_needed: "API キーが必要です",
    new_chat_agent: (params) => `新しい${params?.agentName || "チャット"}`
  }
};
const STORAGE_KEY = "ui_locale";
function sanitizeLocale(value) {
  return locales.includes(value ?? "") ? value : "en";
}
function getInitialLocale() {
  if (typeof localStorage === "undefined") return "en";
  try {
    return sanitizeLocale(localStorage.getItem(STORAGE_KEY));
  } catch {
    return "en";
  }
}
const locale = writable(getInitialLocale());
locale.subscribe((value) => {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, value);
  } catch {
  }
});
function translate(currentLocale, key, params) {
  const entry = translations[currentLocale]?.[key] ?? translations.en[key] ?? key;
  return typeof entry === "function" ? entry(params) : entry;
}
const t = derived$1(locale, ($locale) => {
  return (key, params) => translate($locale, key, params);
});
function Sidebar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let searchQuery = "";
    let filteredGroupedSessions = (() => {
      const q = searchQuery.trim().toLowerCase();
      if (!q) return store_get($$store_subs ??= {}, "$groupedSessions", groupedSessions);
      return store_get($$store_subs ??= {}, "$groupedSessions", groupedSessions).map((group) => ({
        ...group,
        sessions: group.sessions.filter((s) => (s.title || "").toLowerCase().includes(q) || s.agentName.toLowerCase().includes(q))
      })).filter((group) => group.sessions.length > 0);
    })();
    let isContinuing = false;
    let continuationSummaryMode = "compact";
    let continuationProvider = "openrouter";
    let continuationModelId = "x-ai/grok-4.1-fast";
    let continuationHasOpenRouterKey = false;
    let continuationStatusMessage = "";
    let sessionActionStatusMessage = "";
    let sessionActionStatusTone = "success";
    let statusMessageTimeout = null;
    function setSessionActionStatus(message, tone) {
      sessionActionStatusMessage = message;
      sessionActionStatusTone = tone;
      if (statusMessageTimeout) {
        clearTimeout(statusMessageTimeout);
      }
      statusMessageTimeout = setTimeout(
        () => {
          sessionActionStatusMessage = "";
          statusMessageTimeout = null;
        },
        5e3
      );
    }
    async function loadContinuationSummarySettings() {
      try {
        const summarySettings = await getContinuationSummarySettings();
        continuationSummaryMode = summarySettings.defaultDetail;
        continuationProvider = summarySettings.provider;
        continuationModelId = summarySettings.modelId;
        continuationHasOpenRouterKey = summarySettings.hasOpenRouterKey;
      } catch (e) {
        console.warn("Failed to load continuation summary settings:", e);
      }
    }
    onDestroy(() => {
      if (statusMessageTimeout) {
        clearTimeout(statusMessageTimeout);
      }
    });
    async function handleSelectAgent(agent) {
      if (agent.status !== "available") {
        currentSessionId.set(null);
        enterSetup(agent);
      } else {
        setupAgent.set(null);
        selectedAgent.set(agent);
        await createNewSession(agent.name);
        loadModelsForAgent(agent.name);
      }
    }
    function getAgentForSession(agentName) {
      return store_get($$store_subs ??= {}, "$agents", agents).find((a) => a.name === agentName);
    }
    function getContinuationTargets(sourceAgentName) {
      return store_get($$store_subs ??= {}, "$agents", agents).filter((a) => a.status === "available" && a.name !== sourceAgentName);
    }
    async function handleDelete(sessionId) {
      await removeSession(sessionId);
    }
    let renamingSessionId = null;
    let renameValue = "";
    let renameInputEl = void 0;
    function startRename(sessionId, currentTitle) {
      renamingSessionId = sessionId;
      renameValue = currentTitle;
      requestAnimationFrame(() => renameInputEl?.select());
    }
    async function handleExport(sessionId) {
      try {
        let result = await exportSessionToMarkdown(sessionId);
        let errorText = (result.error || "").toLowerCase();
        const isLoadStateError = errorText.includes("not loaded in memory") || errorText.includes("still loading from acp");
        if (!result.success && !result.canceled && isLoadStateError) {
          if (store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId) !== sessionId) {
            await selectSession(sessionId);
          }
          const deadline = Date.now() + 7e3;
          while (!result.success && !result.canceled && Date.now() < deadline) {
            await new Promise((resolve) => setTimeout(resolve, 500));
            result = await exportSessionToMarkdown(sessionId);
            errorText = (result.error || "").toLowerCase();
            if (!errorText.includes("not loaded in memory") && !errorText.includes("still loading from acp")) {
              break;
            }
          }
        }
        if (result.success) {
          const pathLabel = result.savedPath ? ` to ${result.savedPath}` : "";
          setSessionActionStatus(`Exported chat${pathLabel}`, "success");
          return;
        }
        if (result.canceled) {
          return;
        }
        const errorMessage = result.error || "Failed to export session.";
        setSessionActionStatus(errorMessage, "error");
        console.warn("Failed to export session:", errorMessage);
      } catch (e) {
        setSessionActionStatus("Failed to export session.", "error");
        console.warn("Failed to export session:", e);
      }
    }
    async function handleContinueInTerminal(sessionId) {
      const result = await getSessionTerminalResumeCommand(sessionId);
      if (!result.supported || !result.command) {
        console.warn("Continue in terminal:", result.error ?? "Unsupported");
        return;
      }
      currentTab.set("terminal");
      pendingTerminalPaste.set({ line: result.command, openInNewTab: true });
    }
    async function handleContinueSession(sessionId, targetAgent) {
      if (isContinuing) return;
      isContinuing = true;
      continuationStatusMessage = "";
      try {
        await loadContinuationSummarySettings();
        const providerLabel = continuationProvider === "openrouter" ? `OpenRouter AI (${continuationModelId})` : "Local fallback summary";
        continuationStatusMessage = `Generating ${continuationSummaryMode} summary via ${providerLabel}...`;
        const draftResult = await buildContinuationDraft(sessionId, targetAgent.name, continuationSummaryMode);
        if (!draftResult.success || !draftResult.draftPrompt) {
          continuationStatusMessage = "Failed to generate summary.";
          console.warn("Failed to build continuation draft:", draftResult.error ?? "Unknown error");
          return;
        }
        const providerUsed = draftResult.providerUsed === "openrouter" ? "OpenRouter AI" : "local fallback";
        continuationStatusMessage = `Summary ready (${providerUsed}). Creating new ${targetAgent.shortName} chat...`;
        const newSessionId = await createNewSession(targetAgent.name);
        if (!newSessionId) {
          continuationStatusMessage = "Failed to create target session.";
          console.warn("Failed to create target session for continuation");
          return;
        }
        selectedAgent.set(targetAgent);
        queueComposerDraft(newSessionId, draftResult.draftPrompt);
        loadModelsForAgent(targetAgent.name);
      } catch (e) {
        continuationStatusMessage = "Unexpected error while continuing chat.";
        console.warn("Failed to continue session:", e);
      } finally {
        isContinuing = false;
      }
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push(`<aside class="flex h-full w-[280px] shrink-0 flex-col border-r border-border bg-sidebar"><div class="px-3 pt-2.5 pb-1">`);
      if (store_get($$store_subs ??= {}, "$agents", agents).length === 0) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<button class="flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-border/80 px-3 py-2.5 text-[13px] text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"><span>Set up agents in Settings</span></button>`);
      } else {
        $$renderer3.push("<!--[!-->");
        $$renderer3.push(`<div class="flex items-stretch"><button class="flex flex-1 items-center gap-2 rounded-l-lg border border-border/80 bg-secondary/50 px-3 py-1.5 text-[13px] text-sidebar-foreground transition-colors hover:bg-secondary">`);
        if (store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent)?.iconUrl) {
          $$renderer3.push("<!--[-->");
          $$renderer3.push(`<img${attr("src", store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).iconUrl)} alt="" class="h-4 w-4 shrink-0 invert opacity-70"/>`);
        } else if (store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent)) {
          $$renderer3.push("<!--[1-->");
          $$renderer3.push(`<span class="flex h-5 w-5 items-center justify-center rounded text-[9px] font-bold text-white"${attr_style(`background-color: ${stringify(store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).color)};`)}>${escape_html(store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).letter)}</span>`);
        } else {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]--> <span class="truncate">${escape_html(store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent) ? store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).shortName : "New Chat")}</span></button> `);
        $$renderer3.push("<!---->");
        Dropdown_menu?.($$renderer3, {
          children: ($$renderer4) => {
            $$renderer4.push("<!---->");
            Dropdown_menu_trigger?.($$renderer4, {
              class: "flex items-center rounded-r-lg border border-l-0 border-border/80 bg-secondary/50 px-1.5 transition-colors hover:bg-secondary",
              children: ($$renderer5) => {
                Icon$1($$renderer5, {
                  icon: ArrowDown01Icon,
                  size: 14,
                  strokeWidth: 1.5,
                  class: "text-muted-foreground"
                });
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!----> `);
            $$renderer4.push("<!---->");
            Dropdown_menu_content?.($$renderer4, {
              class: "w-[248px]",
              side: "bottom",
              align: "start",
              sideOffset: 4,
              children: ($$renderer5) => {
                $$renderer5.push("<!---->");
                Dropdown_menu_label?.($$renderer5, {
                  class: "text-[11px] text-muted-foreground",
                  children: ($$renderer6) => {
                    $$renderer6.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("start_with"))}`);
                  },
                  $$slots: { default: true }
                });
                $$renderer5.push(`<!----> <!--[-->`);
                const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$agents", agents));
                for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
                  let agent = each_array[$$index];
                  $$renderer5.push("<!---->");
                  Dropdown_menu_item?.($$renderer5, {
                    class: "flex items-center gap-2.5 px-2 py-1.5",
                    onclick: () => handleSelectAgent(agent),
                    children: ($$renderer6) => {
                      if (agent.iconUrl) {
                        $$renderer6.push("<!--[-->");
                        $$renderer6.push(`<span class="flex h-6 w-6 items-center justify-center shrink-0"${attr_style(`color: ${stringify(agent.color)};`)}><img${attr("src", agent.iconUrl)} alt="" class="h-4.5 w-4.5 invert opacity-70"/></span>`);
                      } else if (agent.iconUrl) {
                        $$renderer6.push("<!--[1-->");
                        $$renderer6.push(`<img${attr("src", agent.iconUrl)} alt="" class="h-5 w-5 shrink-0 invert opacity-70"/>`);
                      } else {
                        $$renderer6.push("<!--[!-->");
                        $$renderer6.push(`<span class="flex h-6 w-6 items-center justify-center rounded text-[9px] font-bold text-white"${attr_style(`background-color: ${stringify(agent.color)};`)}>${escape_html(agent.letter)}</span>`);
                      }
                      $$renderer6.push(`<!--]--> <div class="flex-1 min-w-0"><div class="flex items-baseline gap-1.5"><span class="text-[13px] truncate">${escape_html(agent.name)}</span> `);
                      if (agent.provider) {
                        $$renderer6.push("<!--[-->");
                        $$renderer6.push(`<span class="text-[11px] text-muted-foreground/50 shrink-0">${escape_html(agent.provider)}</span>`);
                      } else {
                        $$renderer6.push("<!--[!-->");
                      }
                      $$renderer6.push(`<!--]--></div> `);
                      if (agent.status === "not_installed") {
                        $$renderer6.push("<!--[-->");
                        $$renderer6.push(`<div class="text-[11px] text-amber-400/60 truncate">${escape_html(agent.statusMessage || store_get($$store_subs ??= {}, "$t", t)("setup_click"))}</div>`);
                      } else if (agent.status === "missing_key") {
                        $$renderer6.push("<!--[1-->");
                        $$renderer6.push(`<div class="text-[11px] text-amber-400/60 truncate">${escape_html(agent.statusMessage || store_get($$store_subs ??= {}, "$t", t)("api_key_needed"))}</div>`);
                      } else if (agent.description) {
                        $$renderer6.push("<!--[2-->");
                        $$renderer6.push(`<div class="text-[11px] text-muted-foreground/40 truncate">${escape_html(agent.description)}</div>`);
                      } else {
                        $$renderer6.push("<!--[!-->");
                      }
                      $$renderer6.push(`<!--]--></div> <span${attr_class(`h-2 w-2 shrink-0 rounded-full ${stringify(statusDotColor(agent.status))}`)}></span>`);
                    },
                    $$slots: { default: true }
                  });
                  $$renderer5.push(`<!----> `);
                  if (agent.id === "OpenRouter") {
                    $$renderer5.push("<!--[-->");
                    $$renderer5.push("<!---->");
                    Dropdown_menu_separator?.($$renderer5, {});
                    $$renderer5.push(`<!---->`);
                  } else {
                    $$renderer5.push("<!--[!-->");
                  }
                  $$renderer5.push(`<!--]-->`);
                }
                $$renderer5.push(`<!--]--> `);
                $$renderer5.push("<!---->");
                Dropdown_menu_separator?.($$renderer5, {});
                $$renderer5.push(`<!----> `);
                $$renderer5.push("<!---->");
                Dropdown_menu_item?.($$renderer5, {
                  class: "flex items-center gap-2.5 px-2 py-1.5 text-[13px] text-muted-foreground/60",
                  onclick: () => openSettings("agents"),
                  children: ($$renderer6) => {
                    $$renderer6.push(`<span class="flex h-6 w-6 items-center justify-center shrink-0 text-muted-foreground/40">+</span> <span>Browse more agents...</span>`);
                  },
                  $$slots: { default: true }
                });
                $$renderer5.push(`<!---->`);
              },
              $$slots: { default: true }
            });
            $$renderer4.push(`<!---->`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----></div>`);
      }
      $$renderer3.push(`<!--]--></div> <div class="flex items-center justify-between px-4 pt-3 pb-1"><span class="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("sessions"))}</span> <button class="flex items-center justify-center h-5 w-5 rounded text-muted-foreground/50 transition-colors hover:text-muted-foreground hover:bg-sidebar-accent/60"${attr("title", store_get($$store_subs ??= {}, "$t", t)("refresh_session_list"))}>`);
      Icon$1($$renderer3, {
        icon: ReloadIcon,
        size: 12,
        strokeWidth: 1.5,
        class: store_get($$store_subs ??= {}, "$isConnectingAgents", isConnectingAgents) ? "animate-spin" : ""
      });
      $$renderer3.push(`<!----></button></div> `);
      if (store_get($$store_subs ??= {}, "$sessions", sessions).length > 0) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="px-3 pb-1"><div class="relative"><span class="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground/40">`);
        Icon$1($$renderer3, { icon: Search01Icon, size: 12, strokeWidth: 1.5 });
        $$renderer3.push(`<!----></span> <input type="text"${attr("value", searchQuery)}${attr("placeholder", store_get($$store_subs ??= {}, "$t", t)("search_sessions_placeholder"))} spellcheck="false" class="w-full rounded-md border border-border/50 bg-secondary/30 pl-7 pr-2.5 py-1 text-[12px] text-foreground placeholder:text-muted-foreground/40 focus:border-[var(--ue-accent-muted)] focus:outline-none"/></div></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> `);
      if (sessionActionStatusMessage) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div${attr_class(`px-4 pb-1 text-[11px] ${stringify(sessionActionStatusTone === "success" ? "text-emerald-400/80" : "text-red-400/85")}`)}>${escape_html(sessionActionStatusMessage)}</div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> <div class="min-h-0 flex-1 overflow-y-auto px-2 pb-2">`);
      if (store_get($$store_subs ??= {}, "$isLoadingSessions", isLoadingSessions)) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="flex flex-col gap-0.5 pt-0.5"><!--[-->`);
        const each_array_1 = ensure_array_like(Array(4));
        for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
          each_array_1[$$index_1];
          $$renderer3.push(`<div class="flex items-center gap-2 rounded-md px-2 py-1.5 animate-pulse"><div class="h-4 w-4 shrink-0 rounded bg-muted-foreground/10"></div> <div class="flex-1 h-3.5 rounded bg-muted-foreground/10"></div> <div class="h-3 w-6 shrink-0 rounded bg-muted-foreground/10"></div></div>`);
        }
        $$renderer3.push(`<!--]--></div>`);
      } else if (store_get($$store_subs ??= {}, "$sessions", sessions).length === 0 && store_get($$store_subs ??= {}, "$isConnectingAgents", isConnectingAgents)) {
        $$renderer3.push("<!--[1-->");
        $$renderer3.push(`<div class="flex flex-col items-center justify-center gap-2 py-8 text-muted-foreground/50"><div class="animate-spin">`);
        Icon$1($$renderer3, { icon: ReloadIcon, size: 20, strokeWidth: 1.5 });
        $$renderer3.push(`<!----></div> <span class="text-[12px]">${escape_html(store_get($$store_subs ??= {}, "$t", t)("loading_sessions"))}</span></div>`);
      } else if (store_get($$store_subs ??= {}, "$sessions", sessions).length === 0) {
        $$renderer3.push("<!--[2-->");
        $$renderer3.push(`<div class="flex flex-col items-center justify-center gap-3 py-8 text-muted-foreground/50">`);
        Icon$1($$renderer3, { icon: MessageMultiple01Icon, size: 24, strokeWidth: 1.5 });
        $$renderer3.push(`<!----> <span class="text-[12px]">${escape_html(store_get($$store_subs ??= {}, "$t", t)("no_sessions_yet"))}</span> <button class="text-[11px] text-muted-foreground/60 hover:text-muted-foreground transition-colors underline underline-offset-2">${escape_html(store_get($$store_subs ??= {}, "$t", t)("retry_loading"))}</button></div>`);
      } else if (searchQuery.trim() && filteredGroupedSessions.length === 0) {
        $$renderer3.push("<!--[3-->");
        $$renderer3.push(`<div class="flex flex-col items-center justify-center gap-2 py-8 text-muted-foreground/50">`);
        Icon$1($$renderer3, { icon: Search01Icon, size: 20, strokeWidth: 1.5 });
        $$renderer3.push(`<!----> <span class="text-[12px]">${escape_html(store_get($$store_subs ??= {}, "$t", t)("no_matching_sessions"))}</span></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
        $$renderer3.push(`<!--[-->`);
        const each_array_2 = ensure_array_like(filteredGroupedSessions);
        for (let $$index_4 = 0, $$length = each_array_2.length; $$index_4 < $$length; $$index_4++) {
          let group = each_array_2[$$index_4];
          $$renderer3.push(`<div class="px-2 pt-3 pb-1 first:pt-1"><span class="text-[11px] font-medium text-muted-foreground/50">${escape_html(group.label)}</span></div> <div class="flex flex-col gap-0.5"><!--[-->`);
          const each_array_3 = ensure_array_like(group.sessions);
          for (let $$index_3 = 0, $$length2 = each_array_3.length; $$index_3 < $$length2; $$index_3++) {
            let session = each_array_3[$$index_3];
            const agent = getAgentForSession(session.agentName);
            const sessionStatus = getSessionSidebarStatus(session.sessionId, store_get($$store_subs ??= {}, "$sessionStates", sessionStates), store_get($$store_subs ??= {}, "$recentlyFinished", recentlyFinished));
            $$renderer3.push("<!---->");
            Context_menu?.($$renderer3, {
              children: ($$renderer4) => {
                $$renderer4.push("<!---->");
                Context_menu_trigger?.($$renderer4, {
                  children: ($$renderer5) => {
                    $$renderer5.push(`<button${attr_class(`flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left transition-colors ${stringify(store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId) === session.sessionId ? "bg-sidebar-accent text-sidebar-foreground" : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60")}`)}>`);
                    if (agent?.iconUrl) {
                      $$renderer5.push("<!--[-->");
                      $$renderer5.push(`<span class="flex h-4 w-4 items-center justify-center shrink-0"${attr_style(`color: ${stringify(agent.color)};`)}><img${attr("src", agent.iconUrl)} alt="" class="h-3.5 w-3.5 invert opacity-70"/></span>`);
                    } else if (agent?.iconUrl) {
                      $$renderer5.push("<!--[1-->");
                      $$renderer5.push(`<img${attr("src", agent.iconUrl)} alt="" class="h-3.5 w-3.5 shrink-0 invert opacity-70"/>`);
                    } else {
                      $$renderer5.push("<!--[!-->");
                      $$renderer5.push(`<span class="flex h-4 w-4 items-center justify-center rounded text-[7px] font-bold text-white shrink-0"${attr_style(`background-color: ${stringify(agent?.color ?? "#666")};`)}>${escape_html(agent?.letter ?? "?")}</span>`);
                    }
                    $$renderer5.push(`<!--]--> `);
                    if (renamingSessionId === session.sessionId) {
                      $$renderer5.push("<!--[-->");
                      $$renderer5.push(`<input${attr("value", renameValue)} class="flex-1 min-w-0 rounded bg-secondary px-1 py-0.5 text-[13px] text-foreground outline-none ring-1 ring-[var(--ue-accent)]/50" autofocus=""/>`);
                    } else {
                      $$renderer5.push("<!--[!-->");
                      $$renderer5.push(`<span class="flex-1 truncate text-[13px]">${escape_html(session.title || store_get($$store_subs ??= {}, "$t", t)("new_chat"))}</span>`);
                    }
                    $$renderer5.push(`<!--]--> <span class="flex items-center gap-1.5 ml-1 shrink-0">`);
                    if (store_get($$store_subs ??= {}, "$sessionsNeedingAttention", sessionsNeedingAttention).has(session.sessionId) && store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId) !== session.sessionId) {
                      $$renderer5.push("<!--[-->");
                      $$renderer5.push(`<span class="h-2 w-2 shrink-0 rounded-full bg-amber-500 animate-pulse" title="Needs permission approval"></span>`);
                    } else if (sessionStatus === "working") {
                      $$renderer5.push("<!--[1-->");
                      $$renderer5.push(`<span class="h-2 w-2 shrink-0 rounded-full bg-blue-500 animate-pulse"${attr("title", store_get($$store_subs ??= {}, "$t", t)("working"))}></span>`);
                    } else if (sessionStatus === "finished") {
                      $$renderer5.push("<!--[2-->");
                      $$renderer5.push(`<span class="h-2 w-2 shrink-0 rounded-full bg-emerald-500 transition-opacity"${attr("title", store_get($$store_subs ??= {}, "$t", t)("finished"))}></span>`);
                    } else {
                      $$renderer5.push("<!--[!-->");
                    }
                    $$renderer5.push(`<!--]--> <span class="text-[11px] text-muted-foreground">${escape_html(formatTimeAgo(session.lastModifiedAt))}</span></span></button>`);
                  },
                  $$slots: { default: true }
                });
                $$renderer4.push(`<!----> `);
                $$renderer4.push("<!---->");
                Context_menu_content?.($$renderer4, {
                  class: "w-[220px]",
                  children: ($$renderer5) => {
                    $$renderer5.push("<!---->");
                    Context_menu_item?.($$renderer5, {
                      class: "flex items-center gap-2 text-[13px]",
                      onclick: () => startRename(session.sessionId, session.title || ""),
                      children: ($$renderer6) => {
                        Icon$1($$renderer6, { icon: PencilEdit01Icon, size: 14, strokeWidth: 1.5 });
                        $$renderer6.push(`<!----> ${escape_html(store_get($$store_subs ??= {}, "$t", t)("rename"))}`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer5.push(`<!----> `);
                    $$renderer5.push("<!---->");
                    Context_menu_separator?.($$renderer5, {});
                    $$renderer5.push(`<!----> `);
                    $$renderer5.push("<!---->");
                    Context_menu_sub?.($$renderer5, {
                      children: ($$renderer6) => {
                        $$renderer6.push("<!---->");
                        Context_menu_sub_trigger?.($$renderer6, {
                          class: "text-[13px]",
                          disabled: sessionStatus === "working" || isContinuing,
                          children: ($$renderer7) => {
                            $$renderer7.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("continue_in"))}`);
                          },
                          $$slots: { default: true }
                        });
                        $$renderer6.push(`<!----> `);
                        $$renderer6.push("<!---->");
                        Context_menu_sub_content?.($$renderer6, {
                          class: "w-[240px]",
                          children: ($$renderer7) => {
                            const continuationTargets = getContinuationTargets(session.agentName);
                            $$renderer7.push("<!---->");
                            Context_menu_label?.($$renderer7, {
                              class: "text-[11px] text-muted-foreground",
                              children: ($$renderer8) => {
                                $$renderer8.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("target_agent"))}`);
                              },
                              $$slots: { default: true }
                            });
                            $$renderer7.push(`<!----> `);
                            $$renderer7.push("<!---->");
                            Context_menu_item?.($$renderer7, {
                              disabled: true,
                              class: "text-[11px] leading-relaxed",
                              children: ($$renderer8) => {
                                if (continuationProvider === "openrouter") {
                                  $$renderer8.push("<!--[-->");
                                  $$renderer8.push(`${escape_html(store_get($$store_subs ??= {}, "$t", t)("using_openrouter_ai", { modelId: continuationModelId }))}`);
                                } else {
                                  $$renderer8.push("<!--[!-->");
                                  $$renderer8.push(`${escape_html(store_get($$store_subs ??= {}, "$t", t)("using_local_fallback_summary"))}`);
                                }
                                $$renderer8.push(`<!--]-->`);
                              },
                              $$slots: { default: true }
                            });
                            $$renderer7.push(`<!----> `);
                            if (continuationProvider === "openrouter" && !continuationHasOpenRouterKey) {
                              $$renderer7.push("<!--[-->");
                              $$renderer7.push("<!---->");
                              Context_menu_item?.($$renderer7, {
                                disabled: true,
                                class: "text-[11px] text-amber-300",
                                children: ($$renderer8) => {
                                  $$renderer8.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("no_openrouter_key_detected"))}`);
                                },
                                $$slots: { default: true }
                              });
                              $$renderer7.push(`<!---->`);
                            } else {
                              $$renderer7.push("<!--[!-->");
                            }
                            $$renderer7.push(`<!--]--> `);
                            if (isContinuing) {
                              $$renderer7.push("<!--[-->");
                              $$renderer7.push("<!---->");
                              Context_menu_item?.($$renderer7, {
                                disabled: true,
                                class: "flex items-center gap-2 text-[11px]",
                                children: ($$renderer8) => {
                                  Icon$1($$renderer8, {
                                    icon: ReloadIcon,
                                    size: 12,
                                    strokeWidth: 1.5,
                                    class: "animate-spin"
                                  });
                                  $$renderer8.push(`<!----> <span class="truncate">${escape_html(continuationStatusMessage || store_get($$store_subs ??= {}, "$t", t)("generating_summary"))}</span>`);
                                },
                                $$slots: { default: true }
                              });
                              $$renderer7.push(`<!---->`);
                            } else {
                              $$renderer7.push("<!--[!-->");
                            }
                            $$renderer7.push(`<!--]--> `);
                            $$renderer7.push("<!---->");
                            Context_menu_separator?.($$renderer7, {});
                            $$renderer7.push(`<!----> `);
                            if (continuationTargets.length === 0) {
                              $$renderer7.push("<!--[-->");
                              $$renderer7.push("<!---->");
                              Context_menu_item?.($$renderer7, {
                                disabled: true,
                                class: "text-[12px]",
                                children: ($$renderer8) => {
                                  $$renderer8.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("no_available_target_agents"))}`);
                                },
                                $$slots: { default: true }
                              });
                              $$renderer7.push(`<!---->`);
                            } else {
                              $$renderer7.push("<!--[!-->");
                              $$renderer7.push(`<!--[-->`);
                              const each_array_4 = ensure_array_like(continuationTargets);
                              for (let $$index_2 = 0, $$length3 = each_array_4.length; $$index_2 < $$length3; $$index_2++) {
                                let targetAgent = each_array_4[$$index_2];
                                $$renderer7.push("<!---->");
                                Context_menu_item?.($$renderer7, {
                                  class: "flex items-center gap-2 text-[13px]",
                                  disabled: sessionStatus === "working" || isContinuing,
                                  closeOnSelect: false,
                                  onclick: () => handleContinueSession(session.sessionId, targetAgent),
                                  children: ($$renderer8) => {
                                    if (targetAgent.iconUrl) {
                                      $$renderer8.push("<!--[-->");
                                      $$renderer8.push(`<span class="flex h-4 w-4 items-center justify-center shrink-0"${attr_style(`color: ${stringify(targetAgent.color)};`)}><img${attr("src", targetAgent.iconUrl)} alt="" class="h-3 w-3 invert opacity-70"/></span>`);
                                    } else {
                                      $$renderer8.push("<!--[!-->");
                                      $$renderer8.push(`<span class="flex h-4 w-4 items-center justify-center rounded text-[7px] font-bold text-white shrink-0"${attr_style(`background-color: ${stringify(targetAgent.color)};`)}>${escape_html(targetAgent.letter)}</span>`);
                                    }
                                    $$renderer8.push(`<!--]--> <span class="truncate">${escape_html(targetAgent.name)}</span>`);
                                  },
                                  $$slots: { default: true }
                                });
                                $$renderer7.push(`<!---->`);
                              }
                              $$renderer7.push(`<!--]-->`);
                            }
                            $$renderer7.push(`<!--]--> `);
                            $$renderer7.push("<!---->");
                            Context_menu_separator?.($$renderer7, {});
                            $$renderer7.push(`<!----> `);
                            $$renderer7.push("<!---->");
                            Context_menu_label?.($$renderer7, {
                              class: "text-[11px] text-muted-foreground",
                              children: ($$renderer8) => {
                                $$renderer8.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("summary_detail"))}`);
                              },
                              $$slots: { default: true }
                            });
                            $$renderer7.push(`<!----> `);
                            $$renderer7.push("<!---->");
                            Context_menu_radio_group?.($$renderer7, {
                              get value() {
                                return continuationSummaryMode;
                              },
                              set value($$value) {
                                continuationSummaryMode = $$value;
                                $$settled = false;
                              },
                              children: ($$renderer8) => {
                                $$renderer8.push("<!---->");
                                Context_menu_radio_item?.($$renderer8, {
                                  value: "compact",
                                  class: "text-[12px]",
                                  closeOnSelect: false,
                                  children: ($$renderer9) => {
                                    $$renderer9.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("compact"))}`);
                                  },
                                  $$slots: { default: true }
                                });
                                $$renderer8.push(`<!----> `);
                                $$renderer8.push("<!---->");
                                Context_menu_radio_item?.($$renderer8, {
                                  value: "detailed",
                                  class: "text-[12px]",
                                  closeOnSelect: false,
                                  children: ($$renderer9) => {
                                    $$renderer9.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("detailed"))}`);
                                  },
                                  $$slots: { default: true }
                                });
                                $$renderer8.push(`<!---->`);
                              },
                              $$slots: { default: true }
                            });
                            $$renderer7.push(`<!---->`);
                          },
                          $$slots: { default: true }
                        });
                        $$renderer6.push(`<!---->`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer5.push(`<!----> `);
                    $$renderer5.push("<!---->");
                    Context_menu_item?.($$renderer5, {
                      class: "text-[13px]",
                      disabled: !session.terminalResumeSupported,
                      onclick: () => handleContinueInTerminal(session.sessionId),
                      children: ($$renderer6) => {
                        $$renderer6.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("continue_in_terminal"))}`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer5.push(`<!----> `);
                    $$renderer5.push("<!---->");
                    Context_menu_separator?.($$renderer5, {});
                    $$renderer5.push(`<!----> `);
                    $$renderer5.push("<!---->");
                    Context_menu_item?.($$renderer5, {
                      class: "text-[13px]",
                      disabled: sessionStatus === "working",
                      onclick: () => handleExport(session.sessionId),
                      children: ($$renderer6) => {
                        $$renderer6.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("export_as_markdown"))}`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer5.push(`<!----> `);
                    $$renderer5.push("<!---->");
                    Context_menu_separator?.($$renderer5, {});
                    $$renderer5.push(`<!----> `);
                    $$renderer5.push("<!---->");
                    Context_menu_item?.($$renderer5, {
                      class: "flex items-center gap-2 text-[13px] text-red-400 data-[highlighted]:text-red-400",
                      onclick: () => handleDelete(session.sessionId),
                      children: ($$renderer6) => {
                        Icon$1($$renderer6, { icon: Delete02Icon, size: 14, strokeWidth: 1.5 });
                        $$renderer6.push(`<!----> ${escape_html(store_get($$store_subs ??= {}, "$t", t)("delete"))}`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer5.push(`<!---->`);
                  },
                  $$slots: { default: true }
                });
                $$renderer4.push(`<!---->`);
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!---->`);
          }
          $$renderer3.push(`<!--]--></div>`);
        }
        $$renderer3.push(`<!--]-->`);
      }
      $$renderer3.push(`<!--]--></div> <div class="border-t border-border px-3 py-2 flex flex-col gap-0.5"><a href="https://discord.gg/betide" target="_blank" rel="noopener noreferrer" class="flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-[13px] text-sidebar-foreground transition-colors hover:bg-sidebar-accent"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" class="shrink-0"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.095 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.095 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"></path></svg> <span>Discord</span></a> <button class="flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-[13px] text-sidebar-foreground transition-colors hover:bg-sidebar-accent">`);
      Icon$1($$renderer3, { icon: Settings02Icon, size: 16, strokeWidth: 1.5 });
      $$renderer3.push(`<!----> <span>${escape_html(store_get($$store_subs ??= {}, "$t", t)("settings"))}</span></button></div></aside>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
class IncompleteMarkdownParser {
  plugins = [];
  state = {
    currentLine: 0,
    context: "normal",
    blockingContexts: /* @__PURE__ */ new Set(),
    lineContexts: []
  };
  setState = (state) => {
    this.state = { ...this.state, ...state };
  };
  constructor(plugins = []) {
    this.plugins = plugins;
  }
  // Main parsing methods
  parse(text) {
    if (!text || typeof text !== "string") {
      return text;
    }
    this.state = {
      currentLine: 0,
      context: "normal",
      blockingContexts: /* @__PURE__ */ new Set(),
      lineContexts: [],
      fenceInfo: void 0
    };
    let result = text;
    for (const plugin of this.plugins) {
      if (plugin.preprocess) {
        try {
          const preprocessResult = plugin.preprocess({
            text: result,
            state: this.state,
            setState: this.setState
          });
          if (typeof preprocessResult === "string") {
            result = preprocessResult;
          } else {
            result = preprocessResult.text;
            this.setState(preprocessResult.state);
          }
        } catch (error) {
          console.error(`Plugin ${plugin.name} preprocess hook failed:`, error);
        }
      }
    }
    const lines = result.split("\n");
    const processedLines = [...lines];
    for (let i = 0; i < processedLines.length; i++) {
      this.state.currentLine = i;
      let line = processedLines[i];
      for (const plugin of this.plugins) {
        const currentLineContext = this.state.lineContexts?.[i];
        const shouldSkip = currentLineContext && (plugin.skipInBlockTypes || []).some((blockType) => currentLineContext[blockType]);
        if (shouldSkip) {
          continue;
        }
        try {
          const match = plugin.pattern ? line.match(plugin.pattern) : line.match(/.*/);
          if (match && plugin.handler) {
            line = plugin.handler({
              line,
              text: line,
              match,
              state: this.state,
              setState: this.setState
            });
          }
        } catch (error) {
          console.error(`Plugin ${plugin.name} failed on line ${i}:`, error);
        }
      }
      processedLines[i] = line;
    }
    result = processedLines.join("\n");
    for (const plugin of this.plugins) {
      if (plugin.postprocess) {
        try {
          result = plugin.postprocess({ text: result, state: this.state, setState: this.setState });
        } catch (error) {
          console.error(`Plugin ${plugin.name} afterParse hook failed:`, error);
        }
      }
    }
    return result;
  }
  // Create default plugins that replicate the original handler functions
  static createDefaultPlugins() {
    return [
      // Block-level plugin that manages blocking contexts
      {
        name: "contextManager",
        preprocess: ({ text }) => {
          const lines = text.split("\n");
          let inCodeBlock = false;
          let inMathBlock = false;
          let inCenterBlock = false;
          let inRightBlock = false;
          const lineContexts = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            if (line.trim().startsWith("```") || line.trim().startsWith("~~~")) {
              inCodeBlock = !inCodeBlock;
            }
            if (line.trim().startsWith("$$") && !line.trim().includes("$$", 2)) {
              inMathBlock = !inMathBlock;
            }
            if (line.trim() === "[center]") {
              inCenterBlock = true;
            }
            if (line.trim() === "[/center]") {
              inCenterBlock = false;
            }
            if (line.trim() === "[right]") {
              inRightBlock = true;
            }
            if (line.trim() === "[/right]") {
              inRightBlock = false;
            }
            lineContexts[i] = {
              code: inCodeBlock,
              math: inMathBlock,
              center: inCenterBlock,
              right: inRightBlock
            };
          }
          const finalContexts = /* @__PURE__ */ new Set();
          if (inCodeBlock)
            finalContexts.add("code");
          if (inMathBlock)
            finalContexts.add("math");
          if (inCenterBlock)
            finalContexts.add("center");
          if (inRightBlock)
            finalContexts.add("right");
          return {
            text,
            // Don't modify text in preprocess
            state: {
              blockingContexts: finalContexts,
              lineContexts
            }
          };
        },
        postprocess: ({ text, state }) => {
          if (state.blockingContexts.has("code")) {
            return text + "\n```";
          }
          if (state.blockingContexts.has("math")) {
            return text + "\n$$";
          }
          if (state.blockingContexts.has("center")) {
            return text + "\n[/center]";
          }
          if (state.blockingContexts.has("right")) {
            return text + "\n[/right]";
          }
          return text;
        }
      },
      {
        name: "boldItalic",
        pattern: /\*\*\*/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          if (line.trim() === "***") {
            return line;
          }
          const isEndingWithTripleAsterisk = line.endsWith("***");
          const tripleAsterisks = (line.match(/\*\*\*/g) || []).length;
          if (tripleAsterisks % 2 === 1) {
            const lastTripleAsteriskIndex = line.lastIndexOf("***");
            const endOfCellOrLine = findEndOfCellOrLineContaining(line, lastTripleAsteriskIndex);
            if (isEndingWithTripleAsterisk) {
              return line.substring(0, lastTripleAsteriskIndex);
            }
            return line.substring(0, endOfCellOrLine) + "***" + line.substring(endOfCellOrLine);
          }
          return line;
        }
      },
      {
        name: "bold",
        pattern: /\*\*/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          if (line.trim() === "***") {
            return line;
          }
          const doubleAsteriskMatches = (line.match(/\*\*/g) || []).length;
          if (doubleAsteriskMatches % 2 === 1) {
            const isEndingWithDoubleAsterisk = line.endsWith("**");
            const lastDoubleAsteriskIndex = line.lastIndexOf("**");
            const endOfCellOrLine = findEndOfCellOrLineContaining(line, lastDoubleAsteriskIndex);
            if (isEndingWithDoubleAsterisk) {
              return line.substring(0, lastDoubleAsteriskIndex);
            }
            return line.substring(0, endOfCellOrLine) + "**" + line.substring(endOfCellOrLine);
          }
          return line;
        }
      },
      {
        name: "doubleUnderscoreItalic",
        pattern: /__/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          if (line.trim() === "___") {
            return line;
          }
          const underscorePairs = (line.match(/__/g) || []).length;
          if (underscorePairs % 2 === 1) {
            const isEndingWithDoubleUnderscore = line.endsWith("__");
            const lastDoubleUnderscoreIndex = line.lastIndexOf("__");
            const endOfCellOrLine = findEndOfCellOrLineContaining(line, lastDoubleUnderscoreIndex);
            if (isEndingWithDoubleUnderscore) {
              return line.substring(0, lastDoubleUnderscoreIndex);
            }
            return line.substring(0, endOfCellOrLine) + "__" + line.substring(endOfCellOrLine);
          }
          return line;
        }
      },
      {
        name: "strikethrough",
        pattern: /~~/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          const tildePairs = (line.match(/~~/g) || []).length;
          if (tildePairs % 2 === 1) {
            const isEndingWithDoubleTilde = line.endsWith("~~");
            const lastDoubleTildeIndex = line.lastIndexOf("~~");
            const endOfCellOrLine = findEndOfCellOrLineContaining(line, lastDoubleTildeIndex);
            const contentAfterTildes = line.substring(lastDoubleTildeIndex + 2, endOfCellOrLine);
            if (contentAfterTildes.trim().length > 0) {
              if (isEndingWithDoubleTilde) {
                return line.substring(0, lastDoubleTildeIndex);
              }
              return line.substring(0, endOfCellOrLine) + "~~" + line.substring(endOfCellOrLine);
            }
          }
          return line;
        }
      },
      {
        name: "singleAsteriskItalic",
        pattern: /[\s\S]*/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          if (line.trim() === "***") {
            return line;
          }
          let singleAsterisks = 0;
          for (let i = 0; i < line.length; i++) {
            if (line[i] === "*") {
              const prevChar = i > 0 ? line[i - 1] : "";
              const nextChar = i < line.length - 1 ? line[i + 1] : "";
              let lineStartIndex = i;
              for (let j = i - 1; j >= 0; j--) {
                if (line[j] === "\n") {
                  lineStartIndex = j + 1;
                  break;
                }
                if (j === 0) {
                  lineStartIndex = 0;
                  break;
                }
              }
              const beforeAsterisk = line.substring(lineStartIndex, i);
              if (beforeAsterisk.trim() === "" && (nextChar === " " || nextChar === "	")) {
                continue;
              }
              if (prevChar !== "*" && nextChar !== "*") {
                singleAsterisks++;
              }
            }
          }
          if (singleAsterisks % 2 === 1) {
            let firstSingleAsteriskIndex = -1;
            for (let i = 0; i < line.length; i++) {
              if (line[i] === "*" && line[i - 1] !== "*" && line[i + 1] !== "*") {
                const prevChar = i > 0 ? line[i - 1] : "";
                const nextChar = i < line.length - 1 ? line[i + 1] : "";
                if (/\w/.test(prevChar) && /\w/.test(nextChar))
                  continue;
                if (/\w/.test(prevChar) && !/\s/.test(prevChar))
                  continue;
                firstSingleAsteriskIndex = i;
                break;
              }
            }
            if (firstSingleAsteriskIndex !== -1) {
              const endOfCellOrLine = findEndOfCellOrLineContaining(line, firstSingleAsteriskIndex);
              return line.substring(0, endOfCellOrLine) + "*" + line.substring(endOfCellOrLine);
            }
          }
          return line;
        }
      },
      {
        name: "inlineCode",
        skipInBlockTypes: ["code", "math"],
        pattern: /`/,
        handler: ({ line }) => {
          let singleBacktickCount = 0;
          for (let i = 0; i < line.length; i++) {
            if (line[i] === "`") {
              const isTripleStart = line.substring(i, i + 3) === "```";
              const isTripleMiddle = i > 0 && line.substring(i - 1, i + 2) === "```";
              const isTripleEnd = i > 1 && line.substring(i - 2, i + 1) === "```";
              const isPartOfTriple = isTripleStart || isTripleMiddle || isTripleEnd;
              if (!isPartOfTriple) {
                singleBacktickCount++;
              }
            }
          }
          const tripleBackticks = (line.match(/```/g) || []).length;
          const hasCompleteBlock = tripleBackticks > 0 && tripleBackticks % 2 === 0 && line.includes("\n");
          if (singleBacktickCount % 2 === 1 && !hasCompleteBlock) {
            const lastBacktickIndex = line.lastIndexOf("`");
            const endOfCellOrLine = findEndOfCellOrLineContaining(line, lastBacktickIndex);
            const contentAfterBacktick = line.substring(lastBacktickIndex + 1, endOfCellOrLine);
            if (contentAfterBacktick.trim().length > 0 && !contentAfterBacktick.includes("|")) {
              return line.substring(0, endOfCellOrLine) + "`" + line.substring(endOfCellOrLine);
            }
          }
          return line;
        }
      },
      {
        name: "singleUnderscoreItalic",
        pattern: /[\s\S]*/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          let singleUnderscores = 0;
          for (let i = 0; i < line.length; i++) {
            if (line[i] === "_") {
              const prevChar = i > 0 ? line[i - 1] : "";
              const nextChar = i < line.length - 1 ? line[i + 1] : "";
              if (prevChar === "\\")
                continue;
              if (isWithinMathBlock(line, i))
                continue;
              if (prevChar && nextChar && /[\p{L}\p{N}_]/u.test(prevChar) && /[\p{L}\p{N}_]/u.test(nextChar)) {
                continue;
              }
              if (prevChar !== "_" && nextChar !== "_") {
                singleUnderscores++;
              }
            }
          }
          if (singleUnderscores % 2 === 1) {
            let firstSingleUnderscoreIndex = -1;
            for (let i = 0; i < line.length; i++) {
              if (line[i] === "_" && line[i - 1] !== "_" && line[i + 1] !== "_" && line[i - 1] !== "\\" && !isWithinMathBlock(line, i)) {
                const prevChar = i > 0 ? line[i - 1] : "";
                const nextChar = i < line.length - 1 ? line[i + 1] : "";
                if (prevChar && nextChar && /[\p{L}\p{N}_]/u.test(prevChar) && /[\p{L}\p{N}_]/u.test(nextChar)) {
                  continue;
                }
                firstSingleUnderscoreIndex = i;
                break;
              }
            }
            if (firstSingleUnderscoreIndex !== -1) {
              const endOfCellOrLine = findEndOfCellOrLineContaining(line, firstSingleUnderscoreIndex);
              return line.substring(0, endOfCellOrLine) + "_" + line.substring(endOfCellOrLine);
            }
          }
          return line;
        }
      },
      {
        name: "subscript",
        pattern: /~/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          let singleTildes = 0;
          for (let i = 0; i < line.length; i++) {
            if (line[i] === "~") {
              const prevChar = i > 0 ? line[i - 1] : "";
              const nextChar = i < line.length - 1 ? line[i + 1] : "";
              if (prevChar === "\\")
                continue;
              if (prevChar !== "~" && nextChar !== "~")
                singleTildes++;
            }
          }
          if (singleTildes % 2 === 1) {
            const lastTildeIndex = line.lastIndexOf("~");
            if (lastTildeIndex !== -1 && !isWithinMathBlock(line, lastTildeIndex)) {
              const endOfCellOrLine = findEndOfCellOrLineContaining(line, lastTildeIndex);
              const contentAfterTilde = line.substring(lastTildeIndex + 1, endOfCellOrLine);
              if (contentAfterTilde.trim().length > 0) {
                return line.substring(0, endOfCellOrLine) + "~" + line.substring(endOfCellOrLine);
              }
            }
          }
          return line;
        }
      },
      {
        name: "inlineCitation",
        pattern: /\[/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          let unclosedBrackets = 0;
          for (let i = 0; i < line.length; i++) {
            if (line[i] === "[" && (i === 0 || line[i - 1] !== "\\")) {
              const restOfLine = line.substring(i + 1);
              const closingIndex = restOfLine.indexOf("]");
              if (closingIndex === -1) {
                unclosedBrackets++;
              }
            }
          }
          if (unclosedBrackets % 2 === 1) {
            const endOfCellOrLine = findEndOfCellOrLineContaining(line, line.length - 1);
            return line.substring(0, endOfCellOrLine) + "]" + line.substring(endOfCellOrLine);
          }
          return line;
        }
      },
      {
        name: "footnoteRef",
        pattern: /\[\^[^\]\s,]*/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          if (!line.includes("]")) {
            return line.replace(/\[\^[^\]\s,]*/, "[^streamdown:footnote]");
          }
          return line;
        }
      },
      {
        name: "superscript",
        pattern: /\^/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          let singleCarets = 0;
          for (let i = 0; i < line.length; i++) {
            if (line[i] === "^") {
              const prevChar = i > 0 ? line[i - 1] : "";
              if (prevChar === "\\")
                continue;
              if (!isWithinFootnoteRef(line, i))
                singleCarets++;
            }
          }
          if (singleCarets % 2 === 1) {
            const lastCaretIndex = line.lastIndexOf("^");
            if (lastCaretIndex !== -1 && !isWithinMathBlock(line, lastCaretIndex) && !isWithinFootnoteRef(line, lastCaretIndex)) {
              const endOfCellOrLine = findEndOfCellOrLineContaining(line, lastCaretIndex);
              const contentAfterCaret = line.substring(lastCaretIndex + 1, endOfCellOrLine);
              if (contentAfterCaret.trim().length > 0) {
                return line.substring(0, endOfCellOrLine) + "^" + line.substring(endOfCellOrLine);
              }
            }
          }
          return line;
        }
      },
      {
        name: "inlineMath",
        pattern: /\$/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          let singleDollars = 0;
          for (let i = 0; i < line.length; i++) {
            if (line[i] === "$") {
              const prevChar = i > 0 ? line[i - 1] : "";
              const nextChar = i < line.length - 1 ? line[i + 1] : "";
              if (prevChar === "\\")
                continue;
              if (prevChar === "$" || nextChar === "$")
                continue;
              if (nextChar && /\d/.test(nextChar))
                continue;
              singleDollars++;
            }
          }
          if (singleDollars % 2 === 1) {
            let lastDollarIndex = -1;
            for (let i = line.length - 1; i >= 0; i--) {
              if (line[i] === "$") {
                const prevChar = i > 0 ? line[i - 1] : "";
                const nextChar = i < line.length - 1 ? line[i + 1] : "";
                if (prevChar !== "\\" && prevChar !== "$" && nextChar !== "$" && nextChar !== "" && !/\d/.test(nextChar)) {
                  lastDollarIndex = i;
                  break;
                }
              }
            }
            if (lastDollarIndex !== -1) {
              const endOfCellOrLine = findEndOfCellOrLineContaining(line, lastDollarIndex);
              return line.substring(0, endOfCellOrLine) + "$" + line.substring(endOfCellOrLine);
            }
          }
          return line;
        }
      },
      {
        name: "blockMath",
        pattern: /\$\$/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          if (line.trim() === "$$")
            return line;
          const dollarPairs = (line.match(/\$\$/g) || []).length;
          if (dollarPairs % 2 === 0)
            return line;
          const firstDollarIndex = line.indexOf("$$");
          const hasNewlineAfterStart = line.indexOf("\n", firstDollarIndex) !== -1;
          if (!hasNewlineAfterStart) {
            return line + "$$";
          }
          return line;
        }
      },
      {
        name: "descriptionList",
        pattern: /^(\s*):/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          const colonMatch = line.match(/^(\s*):(.+)$/);
          if (colonMatch) {
            const [, indent, content] = colonMatch;
            if (!content.includes(":")) {
              const endOfCellOrLine = findEndOfCellOrLineContaining(line, line.length - 1);
              return line.substring(0, endOfCellOrLine) + ":" + line.substring(endOfCellOrLine);
            }
          }
          return line;
        }
      },
      {
        name: "linksAndImages",
        pattern: /(!?\[.*)$/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line }) => {
          const urlMatch = line.match(/(!?\[[^\]]*\]\()([^)]*?)$/);
          if (urlMatch) {
            const url = urlMatch[2];
            if (url.length > 0) {
              let isIncomplete = true;
              if (url && url.length >= 4) {
                if (url.startsWith("http://") && url.length >= 12 || url.startsWith("https://") && url.length >= 13) {
                  let domain = url;
                  if (url.startsWith("http://"))
                    domain = url.substring(7);
                  else if (url.startsWith("https://"))
                    domain = url.substring(8);
                  domain = domain.split("/")[0].split("?")[0].split("#")[0];
                  const domainParts = domain.split(".");
                  if (domainParts.length >= 2) {
                    const extension = domainParts[domainParts.length - 1];
                    if (extension.length >= 2 && /^[a-zA-Z]+$/.test(extension)) {
                      isIncomplete = false;
                    }
                  }
                }
              }
              if (isIncomplete) {
                const marker = urlMatch[1].startsWith("!") ? "streamdown:incomplete-image" : "streamdown:incomplete-link";
                return line.replace(url, marker) + ")";
              } else {
                return line + ")";
              }
            } else {
              const marker = urlMatch[1].startsWith("!") ? "streamdown:incomplete-image" : "streamdown:incomplete-link";
              return line + marker + ")";
            }
          }
          const linkMatch = line.match(/(!?\[)([^\]]*?)$/);
          if (linkMatch && !line.includes("](")) {
            const [, openBracket, linkTextWithPossibleBoundary] = linkMatch;
            const bracketIndex = line.lastIndexOf(openBracket);
            const endOfCellOrLine = findEndOfCellOrLineContaining(line, bracketIndex);
            const linkText = linkTextWithPossibleBoundary.replace(/[\s|]+$/, "");
            const marker = openBracket.startsWith("!") ? "streamdown:incomplete-image" : "streamdown:incomplete-link";
            const includeBoundary = endOfCellOrLine < line.length && line[endOfCellOrLine] === "|";
            const incompleteEnd = includeBoundary ? endOfCellOrLine + 1 : endOfCellOrLine;
            const incompletePart = line.substring(bracketIndex, incompleteEnd);
            const completedPart = openBracket + linkText + "](" + marker + ")" + (includeBoundary ? "|" : "");
            return line.replace(incompletePart, completedPart);
          }
          return line;
        }
      },
      {
        name: "alignmentBlocks",
        pattern: /^(\s*\[(center|right)\])$/,
        skipInBlockTypes: ["code", "math"],
        handler: ({ line, state }) => {
          const alignMatch = line.match(/^(\s*\[(center|right)\])$/);
          if (alignMatch) {
            const indent = alignMatch[1].length - alignMatch[1].trim().length;
            const alignType = alignMatch[2];
            return line + "\n" + " ".repeat(indent) + "[/" + alignType + "]";
          }
          return line;
        }
      },
      {
        name: "mdx",
        skipInBlockTypes: ["code", "math", "center", "right"],
        preprocess: ({ text }) => {
          const lines = text.split("\n");
          const openTags = [];
          let mdxLineStates = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            let inMdx = false;
            let incompletePositions = [];
            let searchPos = 0;
            while (searchPos < line.length) {
              const tagStart = line.indexOf("<", searchPos);
              if (tagStart === -1 || tagStart >= line.length - 1)
                break;
              const nextChar = line[tagStart + 1];
              if (!/[A-Z]/.test(nextChar)) {
                searchPos = tagStart + 1;
                continue;
              }
              const selfClosingMatch = line.substring(tagStart).match(/^<([A-Z][a-zA-Z0-9]*)((?:\s+\w+=(?:"[^"]*"|{[^}]*}))*)\s*\/>/);
              if (selfClosingMatch) {
                searchPos = tagStart + selfClosingMatch[0].length;
                continue;
              }
              const completeMatch = line.substring(tagStart).match(/^<([A-Z][a-zA-Z0-9]*)((?:\s+\w+=(?:"[^"]*"|{[^}]*}))*)\s*>.*?<\/\1>/);
              if (completeMatch) {
                searchPos = tagStart + completeMatch[0].length;
                continue;
              }
              const openTagMatch = line.substring(tagStart).match(/^<([A-Z][a-zA-Z0-9]*)((?:\s+\w+=(?:"[^"]*"|{[^}]*}))*)\s*>/);
              if (openTagMatch) {
                const tagName = openTagMatch[1];
                openTags.push({ tagName, lineIndex: i });
                inMdx = true;
                searchPos = tagStart + openTagMatch[0].length;
                continue;
              }
              const incompleteSelfClosing = line.substring(tagStart).match(/^<([A-Z][a-zA-Z0-9]*)[^>]*\/$/);
              if (incompleteSelfClosing) {
                incompletePositions.push(tagStart);
                break;
              }
              const incompleteTag = line.substring(tagStart).match(/^<([A-Z][a-zA-Z0-9]*)(?:\s+[^>]*)?$/);
              if (incompleteTag) {
                incompletePositions.push(tagStart);
                break;
              }
              searchPos = tagStart + 1;
            }
            const closeTagMatches = line.matchAll(/<\/([A-Z][a-zA-Z0-9]*)>/g);
            for (const closeMatch of closeTagMatches) {
              const tagName = closeMatch[1];
              const openIndex = openTags.findIndex((t2) => t2.tagName === tagName);
              if (openIndex !== -1) {
                openTags.splice(openIndex, 1);
              }
            }
            mdxLineStates[i] = { inMdx, incompletePositions };
          }
          return {
            text,
            state: {
              mdxUnclosedTags: openTags,
              mdxLineStates
            }
          };
        },
        handler: ({ line, state }) => {
          const lineStates = state.mdxLineStates || [];
          const currentState2 = lineStates[state.currentLine];
          if (currentState2?.incompletePositions && currentState2.incompletePositions.length > 0) {
            let result = line;
            for (let i = currentState2.incompletePositions.length - 1; i >= 0; i--) {
              const pos = currentState2.incompletePositions[i];
              const before = result.substring(0, pos);
              result = before;
            }
            return result;
          }
          return line;
        },
        postprocess: ({ text, state }) => {
          const unclosedTags = state.mdxUnclosedTags || [];
          if (unclosedTags.length > 0) {
            let result = text;
            for (let i = unclosedTags.length - 1; i >= 0; i--) {
              result += `
</${unclosedTags[i].tagName}>`;
            }
            return result;
          }
          return text;
        }
      }
    ];
  }
}
const defaultPlugins = IncompleteMarkdownParser.createDefaultPlugins();
const defaultParser = new IncompleteMarkdownParser(defaultPlugins);
const parseIncompleteMarkdown = (text) => {
  if (!text || typeof text !== "string") {
    return text;
  }
  return defaultParser.parse(text);
};
const findEndOfCellOrLineContaining = (text, position) => {
  let endPos = position;
  while (endPos < text.length && text[endPos] !== "\n" && text[endPos] !== "|") {
    endPos++;
  }
  return endPos;
};
const isWithinMathBlock = (text, position) => {
  let inInlineMath = false;
  let inBlockMath = false;
  for (let i = 0; i < text.length && i < position; i++) {
    if (text[i] === "\\" && text[i + 1] === "$") {
      i++;
      continue;
    }
    if (text[i] === "$") {
      if (text[i + 1] === "$") {
        inBlockMath = !inBlockMath;
        i++;
        inInlineMath = false;
      } else if (!inBlockMath) {
        inInlineMath = !inInlineMath;
      }
    }
  }
  return inInlineMath || inBlockMath;
};
const isWithinFootnoteRef = (text, position) => {
  let openBracketPos = -1;
  let caretPos = -1;
  for (let i = position; i >= 0; i--) {
    if (text[i] === "]")
      return false;
    if (text[i] === "^" && caretPos === -1)
      caretPos = i;
    if (text[i] === "[") {
      openBracketPos = i;
      break;
    }
  }
  if (openBracketPos !== -1 && caretPos === openBracketPos + 1 && position >= caretPos) {
    for (let i = position + 1; i < text.length; i++) {
      if (text[i] === "]")
        return true;
      if (text[i] === "[" || text[i] === "\n")
        break;
    }
  }
  return false;
};
const bind$1 = (ref, props) => {
  const descriptors = Object.getOwnPropertyDescriptors(props);
  for (const key in descriptors) {
    Object.defineProperty(ref, key, descriptors[key]);
  }
};
class StreamdownContext {
  footnotes = { refs: /* @__PURE__ */ new Map(), footnotes: /* @__PURE__ */ new Map() };
  isMounted = false;
  get animationTextStyle() {
    return getContext("POPOVER") ? void 0 : this.animation.enabled ? `animation-name: sd-${this.animation.type};
animation-duration: ${this.animation.duration}ms;
animation-timing-function: ${this.animation.timingFunction};
animation-iteration-count: 1;
animation-fill-mode: forwards;
white-space: pre-wrap;
display: inline-block;
text-decoration: inherit;` : void 0;
  }
  get animationBlockStyle() {
    return getContext("POPOVER") ? void 0 : this.animation.enabled ? `animation-name: sd-${this.animation.type};
animation-duration: ${this.animation.duration}ms;
animation-timing-function: ${this.animation.timingFunction};
animation-iteration-count: 1;
animation-fill-mode: forwards;` : void 0;
  }
  constructor(props) {
    bind$1(this, props);
    setContext("streamdown", this);
    if (this.animation.animateOnMount) {
      this.isMounted = true;
    }
  }
}
const useStreamdown = () => {
  const context = getContext("streamdown");
  if (!context) {
    throw new Error("Streamdown context not found");
  }
  return context;
};
const parseUrl = (url, defaultOrigin) => {
  if (typeof url !== "string")
    return null;
  try {
    const urlObject = new URL(url);
    return urlObject;
  } catch (error) {
    if (defaultOrigin) {
      try {
        const urlObject = new URL(url, defaultOrigin);
        return urlObject;
      } catch (error2) {
        return null;
      }
    }
    return null;
  }
};
const isPathRelativeUrl = (url) => {
  if (typeof url !== "string")
    return false;
  return url.startsWith("/");
};
const transformUrl = (url, allowedPrefixes, defaultOrigin) => {
  if (!url)
    return null;
  const parsedUrl = parseUrl(url, defaultOrigin);
  if (!parsedUrl)
    return null;
  const inputWasRelative = isPathRelativeUrl(url);
  const urlString = parseUrl(url);
  if (urlString && allowedPrefixes.some((prefix) => {
    const parsedPrefix = parseUrl(prefix);
    if (!parsedPrefix) {
      return false;
    }
    if (parsedPrefix.origin !== urlString.origin) {
      return false;
    }
    return urlString.href.startsWith(parsedPrefix.href);
  })) {
    if (inputWasRelative) {
      return urlString.pathname + urlString.search + urlString.hash;
    }
    return urlString.href;
  }
  if (allowedPrefixes.includes("*")) {
    if (parsedUrl.protocol !== "https:" && parsedUrl.protocol !== "http:") {
      return null;
    }
    const inputWasRelative2 = isPathRelativeUrl(url);
    if (parsedUrl) {
      if (inputWasRelative2) {
        return parsedUrl.pathname + parsedUrl.search + parsedUrl.hash;
      }
      return parsedUrl.href;
    }
  }
  return null;
};
function Slot($$renderer, $$props) {
  let { children, render, props } = $$props;
  if (render) {
    $$renderer.push("<!--[-->");
    render($$renderer, props);
    $$renderer.push(`<!---->`);
  } else {
    $$renderer.push("<!--[!-->");
    children($$renderer);
    $$renderer.push(`<!---->`);
  }
  $$renderer.push(`<!--]-->`);
}
function Link($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const streamdown = useStreamdown();
    const { children, token, id } = $$props;
    const isRelativeUrl = isPathRelativeUrl(token.href);
    const transformedUrl = transformUrl(token.href, streamdown.allowedLinkPrefixes ?? [], streamdown.defaultOrigin);
    if (transformedUrl || token.href === "streamdown:incomplete-link" || isRelativeUrl) {
      $$renderer2.push("<!--[-->");
      Slot($$renderer2, {
        props: {
          href: transformedUrl,
          target: "_blank",
          rel: "noopener noreferrer",
          title: token.title,
          children,
          token
        },
        render: streamdown.snippets.link,
        children: ($$renderer3) => {
          $$renderer3.push(`<a${attributes({
            "data-streamdown-link": id,
            class: clsx$1(streamdown.theme.link.base),
            ...isRelativeUrl ? { href: token.href } : {
              href: transformedUrl,
              target: "_blank",
              rel: "noopener noreferrer"
            }
          })}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></a>`);
        }
      });
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<span${attr("data-streamdown-link-blocked", id)}${attr_class(clsx$1(streamdown.theme.link.blocked))}${attr("title", token.title ? `Blocked URL: ${token.href}` : void 0)}>`);
      children($$renderer2);
      $$renderer2.push(`<!----> [blocked]</span>`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function Image($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const streamdown = useStreamdown();
    const { children, token, id } = $$props;
    const isRelativeUrl = isPathRelativeUrl(token.href);
    const transformedUrl = transformUrl(token.href, streamdown.allowedImagePrefixes ?? [], streamdown.defaultOrigin);
    if (token.href !== "streamdown:incomplete-image") {
      $$renderer2.push("<!--[-->");
      if (transformedUrl || isRelativeUrl) {
        $$renderer2.push("<!--[-->");
        Slot($$renderer2, {
          props: {
            src: isRelativeUrl ? token.href : transformedUrl,
            alt: token.text,
            children,
            token
          },
          render: streamdown.snippets.image,
          children: ($$renderer3) => {
            $$renderer3.push(`<span${attr("data-streamdown-image", id)}${attr_style(streamdown.isMounted ? streamdown.animationBlockStyle : "")}${attr_class(clsx$1(streamdown.theme.image.base))}><img${attr_class(clsx$1(streamdown.theme.image.image))}${attr("src", isRelativeUrl ? token.href : transformedUrl)}${attr("alt", token.text)}/></span>`);
          }
        });
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<span${attr("data-streamdown-image-blocked", id)} class="inline-block rounded bg-gray-200 px-3 py-1 text-sm text-gray-600 dark:bg-gray-700 dark:text-gray-400"${attr("title", `Blocked URL: ${token.href}`)}>[Image blocked: ${escape_html(token.text || "No description")}]</span>`);
      }
      $$renderer2.push(`<!--]-->`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function Alert($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const icons = {
      note: `<circle cx="12" cy="12" r="10" /><path d="M12 16v-4" /><path d="M12 8h.01" />`,
      caution: `<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>`,
      important: `<path
		d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"
	/><path d="M7 11h10" /><path d="M7 15h6" /><path d="M7 7h8" />`,
      tip: `<path
		d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"
	/><path d="M9 18h6" /><path d="M10 22h4" />`,
      warning: `<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" /><path
		d="M12 9v4"
	/><path d="M12 17h.01" />`
    };
    const streamdown = useStreamdown();
    const { children, token, id } = $$props;
    function icon($$renderer3) {
      $$renderer3.push(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"${attr_class(clsx$1(streamdown.theme.alert.icon))}>${html(icons[token.variant])}</svg>`);
    }
    Slot($$renderer2, {
      props: { children, token },
      render: streamdown.snippets.alert,
      children: ($$renderer3) => {
        $$renderer3.push(`<div${attr("data-streamdown-alert", id)}${attr_style(streamdown.isMounted ? streamdown.animationBlockStyle : "")}${attr_class(`${streamdown.theme.alert.base} ${streamdown.theme.alert[token.variant]}`)}><div data-alert-title=""${attr_class(clsx$1(streamdown.theme.alert.title))}>`);
        (streamdown.icons?.[token.variant] || icon)($$renderer3);
        $$renderer3.push(`<!----> ${escape_html(streamdown.translations?.alert?.[token.variant] || token.variant)}</div> `);
        children($$renderer3);
        $$renderer3.push(`<!----></div>`);
      }
    });
  });
}
class Popover {
  isOpen = false;
  content;
  reference;
  constructor() {
    setContext("POPOVER", true);
  }
  place = async (node) => {
    const middleware = [
      hide(),
      offset(10),
      shift({ mainAxis: true }),
      autoPlacement({
        allowedPlacements: [
          "top",
          "top-end",
          "top-start",
          "bottom",
          "bottom-end",
          "bottom-start"
        ]
      })
    ];
    const { x, y, strategy, placement, middlewareData } = await computePosition(this.reference, node, { strategy: "fixed", middleware });
    Object.assign(node.style, { position: strategy, left: `${x}px`, top: `${y}px` });
  };
  popoverAttachment = (node) => {
    this.content = node;
    void this.place(node);
    const off = autoUpdate(this.reference, node, () => this.place(node));
    return () => {
      off();
    };
  };
}
function FootnoteRef($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const id = props_id($$renderer2);
    const streamdown = useStreamdown();
    const { token } = $$props;
    const popover = new Popover();
    if (popover.isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<dialog${attr("data-streamdown-footnote-popover", id)}${attr("id", "footnote-popover-" + id)} aria-modal="false" open=""${attr_class(clsx$1(streamdown.theme.components.popover))}>`);
      Slot($$renderer2, {
        props: { token, isOpen: popover.isOpen },
        render: streamdown.snippets.footnotePopover,
        children: ($$renderer3) => {
          $$renderer3.push(`<!--[-->`);
          const each_array = ensure_array_like(token.content.lines);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let line = each_array[$$index];
            Block($$renderer3, { block: line });
          }
          $$renderer3.push(`<!--]-->`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></dialog>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (token.label !== "streamdown:footnote") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<button${attr("data-streamdown-footnote-ref", id)}${attr_style(streamdown.animationBlockStyle)}${attr_class(clsx$1(streamdown.theme.footnoteRef.base))}${attr("aria-expanded", popover.isOpen)} aria-haspopup="dialog"${attr("aria-controls", "footnote-popover-" + id)}>${escape_html(token.label.replace("^", ""))}</button>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
const bind = (ref, props) => {
  const descriptors = Object.getOwnPropertyDescriptors(props);
  for (const key in descriptors) {
    Object.defineProperty(ref, key, descriptors[key]);
  }
};
class StepperState {
  activeStep = 0;
  destinationOffset = 0;
  stepAnimation;
  offsets = [];
  stepHeights = [];
  stepContainer = null;
  isAnimating = false;
  constructor(props) {
    bind(this, props);
  }
  translate = () => {
    if (this.destinationOffset !== this.offsets[this.activeStep] && this.stepContainer) {
      this.destinationOffset = this.offsets[this.activeStep];
      this.stepAnimation?.cancel();
      this.stepAnimation = this.stepContainer.animate({ transform: `translateX(-${this.offsets[this.activeStep]}px)` }, this.keyFramesOptions);
      this.stepAnimation.onfinish = () => {
        this.stepAnimation = void 0;
      };
    }
  };
  setActiveStep = (i) => () => {
    if (!this.canGoToStep(i) || !this.stepContainer) return;
    const previousStep = this.stepContainer.children[this.activeStep];
    const nextStep = this.stepContainer.children[i];
    if (!previousStep || !nextStep) return;
    this.activeStep = i;
    this.translate();
    previousStep.animate({ opacity: `0` }, this.keyFramesOptions);
    nextStep.animate({ opacity: `1` }, this.keyFramesOptions);
  };
  scroller = (node) => {
    const onScroll = (e) => {
      e.preventDefault();
      node.scrollTo(0, 0);
    };
    node.addEventListener("scroll", onScroll);
    node.scrollTo(0, 0);
    const steps = node.querySelectorAll("[data-step]");
    const setOffsets = () => {
      steps.forEach((step, i) => {
        this.offsets[i] = step.offsetLeft;
        this.translate();
      });
    };
    const resizeObserver = new ResizeObserver(setOffsets);
    resizeObserver.observe(node);
    setOffsets();
    return {
      destroy: () => {
        resizeObserver.unobserve(node);
        node.removeEventListener("scroll", onScroll);
        this.activeStep = 0;
        this.offsets = [];
        this.destinationOffset = 0;
      }
    };
  };
  next = () => {
    if (this.activeStep < this.items.length - 1) {
      this.setActiveStep(this.activeStep + 1)();
    }
  };
  previous = () => {
    if (this.activeStep > 0) {
      this.setActiveStep(this.activeStep - 1)();
    }
  };
  goTo = (i) => {
    if (this.canGoToStep(i)) {
      this.setActiveStep(i)();
    }
  };
  get canGoNext() {
    return this.activeStep < this.items.length - 1;
  }
  get canGoPrevious() {
    return this.activeStep > 0;
  }
  canGoToStep = (targetStep) => {
    return targetStep >= 0 && targetStep < this.items.length;
  };
}
const get = (obj, path) => {
  if (!obj)
    return null;
  const keys = path.split(".");
  if (keys.length === 1) {
    return obj[path];
  }
  let value = obj;
  for (const key of keys) {
    if (value == null)
      return null;
    if (Array.isArray(value)) {
      const index = Number(key);
      if (isNaN(index) || index < 0 || index >= value.length)
        return null;
      value = value[index];
    } else {
      value = value[key];
    }
  }
  return value;
};
const copyIcon = createRawSnippet(() => {
  return {
    render: () => {
      return `
            <svg
	xmlns="http://www.w3.org/2000/svg"
	width="100%"
	height="100%"
	viewBox="0 0 24 24"
	fill="none"
	stroke="currentColor"
	stroke-width="2"
	stroke-linecap="round"
	stroke-linejoin="round"
	><rect width="8" height="4" x="8" y="2" rx="1" ry="1" /><path
		d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"
	/></svg>
            `;
    }
  };
});
const downloadIcon = createRawSnippet(() => {
  return {
    render: () => {
      return `<svg
		xmlns="http://www.w3.org/2000/svg"
		width="100%"
		height="100%"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		stroke-width="2"
		stroke-linecap="round"
		stroke-linejoin="round"
		><path d="M12 15V3" /><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><path
			d="m7 10 5 5 5-5"
		/></svg
	>`;
    }
  };
});
const checkIcon = createRawSnippet(() => {
  return {
    render: () => {
      return `
            <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
            `;
    }
  };
});
const chevronRight = createRawSnippet(() => {
  return {
    render: () => `
			<svg
				xmlns="http://www.w3.org/2000/svg"
				width="100%"
				height="100%"
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="2"
				stroke-linecap="round"
				stroke-linejoin="round"
			>
				<path d="m9 18 6-6-6-6" />
			</svg>
		`
  };
});
const chevronLeft = createRawSnippet(() => {
  return {
    render: () => `
			<svg
				xmlns="http://www.w3.org/2000/svg"
				width="100%"
				height="100%"
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="2"
				stroke-linecap="round"
				stroke-linejoin="round"
			>
				<path d="m15 18-6-6 6-6" />
			</svg>
		`
  };
});
function Citation($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const id = props_id($$renderer2);
    const { token } = $$props;
    const streamdown = useStreamdown();
    const popover = new Popover();
    const citationWithSources = (() => {
      return token.keys.reduce(
        (acc, key) => {
          const source = get(streamdown.sources, key);
          const safeUrl = (url) => {
            if (url == null) return null;
            try {
              return new URL(url);
            } catch (error) {
              return null;
            }
          };
          if (source) {
            const url = safeUrl(source.url ?? source.href ?? source.link ?? source.source);
            acc.push({
              key,
              title: source.title ?? source.name ?? source.author ?? null,
              url,
              host: url ? url.host.replace("www.", "") : null,
              favicon: url ? `https://www.google.com/s2/favicons?domain=${url.hostname}&sz=128` : null,
              content: source.content ?? source.text ?? source.summary ?? source.excerpt ?? null,
              source
            });
          }
          return acc;
        },
        []
      );
    })();
    const stepper = new StepperState({
      get items() {
        return citationWithSources;
      },
      keyFramesOptions: { duration: 200, easing: "ease-in-out", fill: "forwards" }
    });
    function listView($$renderer3) {
      $$renderer3.push(`<div${attr_class(clsx$1(streamdown.theme.inlineCitation.list.base))}><!--[-->`);
      const each_array = ensure_array_like(citationWithSources);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let { favicon, key, source, title, url } = each_array[$$index];
        Slot($$renderer3, {
          render: streamdown.snippets.inlineCitationContent,
          props: { source, key, token },
          children: ($$renderer4) => {
            $$renderer4.push(`<a${attr_class(clsx$1(streamdown.theme.inlineCitation.list.item))}${attr("href", url?.toString())} target="_blank" rel="noopener noreferrer">`);
            if (title) {
              $$renderer4.push("<!--[-->");
              $$renderer4.push(`<span${attr_class(clsx$1(streamdown.theme.inlineCitation.list.title))}>${escape_html(title)}</span>`);
            } else {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--> `);
            if (url) {
              $$renderer4.push("<!--[-->");
              $$renderer4.push(`<span${attr_class(clsx$1(streamdown.theme.inlineCitation.list.url))}>`);
              if (favicon) {
                $$renderer4.push("<!--[-->");
                $$renderer4.push(`<img${attr("src", favicon)}${attr("alt", title || url.host)}${attr_class(clsx$1(streamdown.theme.inlineCitation.list.favicon))}/>`);
              } else {
                $$renderer4.push("<!--[!-->");
              }
              $$renderer4.push(`<!--]--> ${escape_html(url.host)}${escape_html(url.pathname === "/" ? "" : url.pathname)}</span>`);
            } else {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--></a>`);
          }
        });
      }
      $$renderer3.push(`<!--]--></div>`);
    }
    function carouselView($$renderer3) {
      if (citationWithSources.length > 1) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div${attr_class(clsx$1(streamdown.theme.inlineCitation.carousel.header))}><div${attr_class(clsx$1(streamdown.theme.inlineCitation.carousel.stepCounter))}>${escape_html(stepper.activeStep + 1)}
				/ ${escape_html(citationWithSources.length)}</div> <div${attr_class(clsx$1(streamdown.theme.inlineCitation.carousel.buttons))}><button${attr("disabled", !stepper.canGoPrevious, true)}${attr_class(clsx$1(streamdown.theme.components.button))}>`);
        (streamdown.icons?.chevronLeft || chevronLeft)($$renderer3);
        $$renderer3.push(`<!----></button> <button${attr("disabled", !stepper.canGoNext, true)}${attr_class(clsx$1(streamdown.theme.components.button))}>`);
        (streamdown.icons?.chevronRight || chevronRight)($$renderer3);
        $$renderer3.push(`<!----></button></div></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> <div${attr("aria-label", `Citations-$${stringify(id)}`)}${attr_style("", {
        height: Number.isFinite(stepper.stepHeights[stepper.activeStep]) ? `${stepper.stepHeights[stepper.activeStep]}px` : "auto",
        overflow: "hidden",
        position: "relative",
        "transition-duration": "200ms",
        "transition-timing-function": "ease-in-out"
      })}><div${attr_style("", {
        display: "grid",
        "transition-duration": `${200}ms`,
        width: "100%",
        "grid-template-columns": `repeat(${stringify(citationWithSources.length)}, 100%)`
      })}><!--[-->`);
      const each_array_1 = ensure_array_like(citationWithSources);
      for (let index = 0, $$length = each_array_1.length; index < $$length; index++) {
        let { favicon, key, source, title, url, content } = each_array_1[index];
        $$renderer3.push(`<div${attr("data-step", index)}${attr("tabindex", stepper.activeStep === index ? 0 : -1)}${attr("inert", stepper.activeStep !== index, true)} role="tabpanel"${attr("aria-label", `Citation-$${stringify(id)}`)}${attr_style("", { height: "fit-content", width: "100%", "flex-grow": "1" })}>`);
        Slot($$renderer3, {
          render: streamdown.snippets.inlineCitationContent,
          props: { source, key, token },
          children: ($$renderer4) => {
            if (url || title) {
              $$renderer4.push("<!--[-->");
              $$renderer4.push(`<div class="mb-4">`);
              if (title) {
                $$renderer4.push("<!--[-->");
                $$renderer4.push(`<div${attr_class(clsx$1(streamdown.theme.inlineCitation.carousel.title))}>${escape_html(title)}</div>`);
              } else {
                $$renderer4.push("<!--[!-->");
              }
              $$renderer4.push(`<!--]--> `);
              if (url) {
                $$renderer4.push("<!--[-->");
                $$renderer4.push(`<a${attr("href", url.toString())} target="_blank" rel="noopener noreferrer"${attr_class(clsx$1(streamdown.theme.inlineCitation.carousel.url))}>`);
                if (favicon) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<img${attr("src", favicon)}${attr("alt", title || url.host)}${attr_class(clsx$1(streamdown.theme.inlineCitation.carousel.favicon))}/>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> ${escape_html(url.host)}${escape_html(url.pathname === "/" ? "" : url.pathname)}</a>`);
              } else {
                $$renderer4.push("<!--[!-->");
              }
              $$renderer4.push(`<!--]--></div>`);
            } else {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--> `);
            if (content) {
              $$renderer4.push("<!--[-->");
              Block($$renderer4, { block: content });
            } else {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]-->`);
          }
        });
        $$renderer3.push(`<!----></div>`);
      }
      $$renderer3.push(`<!--]--></div></div>`);
    }
    if (popover.isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<dialog${attr("data-streamdown-citation-popover", id)}${attr("id", "citation-popover-" + id)} aria-modal="false" open=""${attr_class(`${streamdown.theme.components.popover}`)}${attr_style("", { "max-width": "400px" })}>`);
      Slot($$renderer2, {
        props: { token, isOpen: popover.isOpen },
        render: streamdown.snippets.inlineCitationPopover,
        children: ($$renderer3) => {
          if (streamdown.inlineCitationsMode === "carousel") {
            $$renderer3.push("<!--[-->");
            carouselView($$renderer3);
          } else {
            $$renderer3.push("<!--[!-->");
            listView($$renderer3);
          }
          $$renderer3.push(`<!--]-->`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></dialog>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->  `);
    if (citationWithSources.length > 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<button${attr("data-streamdown-citation-preview", id)}${attr_style(streamdown.animationBlockStyle)}${attr_class(clsx$1(streamdown.theme.inlineCitation.preview))}${attr("aria-expanded", popover.isOpen)} aria-haspopup="dialog"${attr("aria-controls", "citation-popover-" + id)}>`);
      Slot($$renderer2, {
        render: streamdown.snippets.inlineCitationPreview,
        props: { token },
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->${escape_html(citationWithSources[0]?.url?.host ?? citationWithSources[0]?.title ?? citationWithSources[0]?.key)}
			${escape_html(citationWithSources.length > 1 ? ` +${citationWithSources.length - 1}` : "")}`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></button>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
  });
}
const useCopy = (opts) => {
  let isCopied = false;
  let timeoutId;
  const copy = async () => {
    if (typeof window === "undefined" || !navigator?.clipboard?.writeText) {
      console.error("Clipboard API not available");
      return;
    }
    try {
      if (!isCopied) {
        await navigator.clipboard.writeText(opts.content);
        isCopied = true;
        if (timeoutId) clearTimeout(timeoutId);
        timeoutId = window.setTimeout(
          () => {
            isCopied = false;
          },
          opts.timeout ?? 2e3
        );
      }
    } catch (error) {
      console.error("Failed to copy to clipboard:", error);
    }
  };
  onDestroy(() => {
    if (timeoutId) clearTimeout(timeoutId);
  });
  return {
    get isCopied() {
      return isCopied;
    },
    copy
  };
};
function TableDownload($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { token } = $$props;
    const streamdown = useStreamdown();
    const popover = new Popover();
    let copyValue = token.raw;
    const copy = useCopy({
      get content() {
        return copyValue;
      }
    });
    if (popover.isOpen) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<dialog id="table-download-popover" aria-modal="false" open=""${attr_class(clsx$1(streamdown.theme.components.popover))}${attr_style("", {
        width: "fit-content !important",
        "min-width": "fit-content !important"
      })}><!--[-->`);
      const each_array = ensure_array_like(["Markdown", "HTML", "CSV"]);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let type = each_array[$$index];
        $$renderer2.push(`<button style="width: 100%; text-align: left; justify-content: flex-start; padding: 1rem 1rem; margin: 0.2rem 0;"${attr_class(clsx$1(streamdown.theme.components.button))}>${escape_html(type)}</button>`);
      }
      $$renderer2.push(`<!--]--></dialog>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <div data-streamdown-table-download="" class="right-0 ml-auto flex items-center justify-end gap-2 p-1"><!--[-->`);
    const each_array_1 = ensure_array_like(["download", "copy"]);
    for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
      let mode = each_array_1[$$index_1];
      $$renderer2.push(`<button${attr_class(clsx$1(streamdown.theme.components.button))}${attr("title", mode === "download" ? "Download table" : "Copy table")}>`);
      if (mode === "download") {
        $$renderer2.push("<!--[-->");
        (streamdown.icons?.download || downloadIcon)($$renderer2);
        $$renderer2.push(`<!---->`);
      } else if (copy.isCopied) {
        $$renderer2.push("<!--[1-->");
        (streamdown.icons?.check || checkIcon)($$renderer2);
        $$renderer2.push(`<!---->`);
      } else {
        $$renderer2.push("<!--[!-->");
        (streamdown.icons?.copy || copyIcon)($$renderer2);
        $$renderer2.push(`<!---->`);
      }
      $$renderer2.push(`<!--]--></button>`);
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function CodeFallback($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const { token, id } = $$props;
    const streamdown = useStreamdown();
    $$renderer2.push(`<div${attr("data-streamdown-code", id)}${attr_style(streamdown.isMounted ? streamdown.animationBlockStyle : "")}${attr_class(clsx$1(streamdown.theme.code.base))}><div${attr_class(clsx$1(streamdown.theme.code.header))}><span${attr_class(clsx$1(streamdown.theme.code.language))}>${escape_html(token.lang)}</span></div> <div style="height: fit-content; width: 100%;"${attr_class(clsx$1(streamdown.theme.code.container))}><pre${attr_class(clsx$1(streamdown.theme.code.pre))}><code><!--[-->`);
    const each_array = ensure_array_like(token.text.split("\n"));
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let line = each_array[$$index];
      $$renderer2.push(`<span${attr_class(clsx$1(streamdown.theme.code.line))}><span${attr_style(streamdown.isMounted ? streamdown.animationTextStyle : "")}>${escape_html(line.trim().length > 0 ? line : "​")}</span></span>`);
    }
    $$renderer2.push(`<!--]--></code></pre></div></div>`);
  });
}
function MermaidFallback($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const { token, id } = $$props;
    const streamdown = useStreamdown();
    $$renderer2.push(`<div${attr("data-streamdown-mermaid", id)}><div${attr_style(streamdown.isMounted ? streamdown.animationBlockStyle : "")}${attr_class(clsx$1(streamdown.theme.code.base))}><div${attr_class(clsx$1(streamdown.theme.code.header))}><span${attr_class(clsx$1(streamdown.theme.code.language))}>mermaid</span></div> <div style="height: fit-content; width: 100%;"${attr_class(clsx$1(streamdown.theme.code.container))}><pre${attr_class(clsx$1(streamdown.theme.code.pre))}><code><!--[-->`);
    const each_array = ensure_array_like(token.text.split("\n"));
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let line = each_array[$$index];
      $$renderer2.push(`<span${attr_class(clsx$1(streamdown.theme.code.line))}><span${attr_style(streamdown.isMounted ? streamdown.animationTextStyle : "")}>${escape_html(line.trim().length > 0 ? line : "​")}</span></span>`);
    }
    $$renderer2.push(`<!--]--></code></pre></div></div></div>`);
  });
}
function MathFallback($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const { token, id } = $$props;
    const streamdown = useStreamdown();
    if (token.isInline) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span${attr("data-streamdown-inline-math", id)}${attr_style(streamdown.isMounted ? streamdown.animationBlockStyle : "")}${attr_class(clsx$1(streamdown.theme.math.inline))}><code>${escape_html(token.text)}</code></span>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attr("data-streamdown-block-math", id)}${attr_style(streamdown.isMounted ? streamdown.animationBlockStyle : "", { height: "fit-content", width: "100%" })}><div class="overflow-x-auto"><pre${attr_class(clsx$1(streamdown.theme.math.block))}><code>${escape_html(token.text)}</code></pre></div></div>`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function Element$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const id = props_id($$renderer2);
    let { token, children } = $$props;
    const streamdown = useStreamdown();
    const CodeComponent = streamdown.components?.code ?? CodeFallback;
    const MermaidComponent = streamdown.components?.mermaid ?? MermaidFallback;
    const MathComponent = streamdown.components?.math ?? MathFallback;
    const style = streamdown.isMounted ? streamdown.animationBlockStyle : "";
    if (token.type === "heading") {
      $$renderer2.push("<!--[-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.heading,
        children: ($$renderer3) => {
          if (token.depth === 1) {
            $$renderer3.push("<!--[-->");
            $$renderer3.push(`<h1${attr("data-streamdown-heading-1", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme[`h${token.depth}`].base))}>`);
            children($$renderer3);
            $$renderer3.push(`<!----></h1>`);
          } else if (token.depth === 2) {
            $$renderer3.push("<!--[1-->");
            $$renderer3.push(`<h2${attr("data-streamdown-heading-2", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme[`h${token.depth}`].base))}>`);
            children($$renderer3);
            $$renderer3.push(`<!----></h2>`);
          } else if (token.depth === 3) {
            $$renderer3.push("<!--[2-->");
            $$renderer3.push(`<h3${attr("data-streamdown-heading-3", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme[`h${token.depth}`].base))}>`);
            children($$renderer3);
            $$renderer3.push(`<!----></h3>`);
          } else if (token.depth === 4) {
            $$renderer3.push("<!--[3-->");
            $$renderer3.push(`<h4${attr("data-streamdown-heading-4", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme[`h${token.depth}`].base))}>`);
            children($$renderer3);
            $$renderer3.push(`<!----></h4>`);
          } else if (token.depth === 5) {
            $$renderer3.push("<!--[4-->");
            $$renderer3.push(`<h5${attr("data-streamdown-heading-5", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme[`h${token.depth}`].base))}>`);
            children($$renderer3);
            $$renderer3.push(`<!----></h5>`);
          } else if (token.depth === 6) {
            $$renderer3.push("<!--[5-->");
            $$renderer3.push(`<h6${attr("data-streamdown-heading-6", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme[`h${token.depth}`].base))}>`);
            children($$renderer3);
            $$renderer3.push(`<!----></h6>`);
          } else {
            $$renderer3.push("<!--[!-->");
          }
          $$renderer3.push(`<!--]-->`);
        }
      });
    } else if (token.type === "paragraph") {
      $$renderer2.push("<!--[1-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.paragraph,
        children: ($$renderer3) => {
          $$renderer3.push(`<p${attr("data-streamdown-paragraph", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme.paragraph.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></p>`);
        }
      });
    } else if (token.type === "blockquote") {
      $$renderer2.push("<!--[2-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.blockquote,
        children: ($$renderer3) => {
          $$renderer3.push(`<blockquote${attr("data-streamdown-blockquote", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme.blockquote.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></blockquote>`);
        }
      });
    } else if (token.type === "code" && token.lang === "mermaid") {
      $$renderer2.push("<!--[3-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.code,
        children: ($$renderer3) => {
          $$renderer3.push("<!---->");
          MermaidComponent?.($$renderer3, { id, token });
          $$renderer3.push(`<!---->`);
        }
      });
    } else if (token.type === "code") {
      $$renderer2.push("<!--[4-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.code,
        children: ($$renderer3) => {
          $$renderer3.push("<!---->");
          CodeComponent?.($$renderer3, { id, token });
          $$renderer3.push(`<!---->`);
        }
      });
    } else if (token.type === "codespan") {
      $$renderer2.push("<!--[5-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.codespan,
        children: ($$renderer3) => {
          $$renderer3.push(`<code${attr("data-streamdown-codespan", id)}${attr_class(clsx$1(streamdown.theme.codespan.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></code>`);
        }
      });
    } else if (token.type === "list") {
      $$renderer2.push("<!--[6-->");
      if (token.ordered) {
        $$renderer2.push("<!--[-->");
        Slot($$renderer2, {
          props: { children, token },
          render: streamdown.snippets.ol,
          children: ($$renderer3) => {
            $$renderer3.push(`<ol${attr("data-streamdown-ol", id)}${attr_class(clsx$1(streamdown.theme.ol.base))}${attr_style("", { "list-style-type": token.listType })}>`);
            children($$renderer3);
            $$renderer3.push(`<!----></ol>`);
          }
        });
      } else {
        $$renderer2.push("<!--[!-->");
        Slot($$renderer2, {
          props: { children, token },
          render: streamdown.snippets.ul,
          children: ($$renderer3) => {
            $$renderer3.push(`<ul${attr("data-streamdown-ul", id)}${attr_class(clsx$1(streamdown.theme.ul.base))}>`);
            children($$renderer3);
            $$renderer3.push(`<!----></ul>`);
          }
        });
      }
      $$renderer2.push(`<!--]-->`);
    } else if (token.type === "list_item") {
      $$renderer2.push("<!--[7-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.li,
        children: ($$renderer3) => {
          $$renderer3.push(`<li${attributes(
            {
              "data-streamdown-li": id,
              style,
              ...token.value && !token.task ? { value: token.value } : {},
              class: clsx$1(streamdown.theme.li.base)
            },
            void 0,
            void 0,
            { "list-style-type": token.task ? "none" : void 0 }
          )}>`);
          if (token.task) {
            $$renderer3.push("<!--[-->");
            $$renderer3.push(`<input disabled="" type="checkbox"${attr("checked", token.checked, true)}${attr_class(clsx$1(streamdown.theme.li.checkbox))}/>`);
          } else {
            $$renderer3.push("<!--[!-->");
          }
          $$renderer3.push(`<!--]--> `);
          children($$renderer3);
          $$renderer3.push(`<!----></li>`);
        }
      });
    } else if (token.type === "table") {
      $$renderer2.push("<!--[8-->");
      Slot($$renderer2, {
        props: { token, children },
        render: streamdown.snippets.table,
        children: ($$renderer3) => {
          if (streamdown.controls.table) {
            $$renderer3.push("<!--[-->");
            TableDownload($$renderer3, { token });
          } else {
            $$renderer3.push("<!--[!-->");
          }
          $$renderer3.push(`<!--]--> <div${attr("data-streamdown-table", id)}${attr_style(style, { "overscroll-behavior-x": "none" })}${attr_class(`${streamdown.theme.table.base} group`)}><table${attr_class(clsx$1(streamdown.theme.table.table))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></table></div>`);
        }
      });
    } else if (token.type === "thead") {
      $$renderer2.push("<!--[9-->");
      Slot($$renderer2, {
        props: { token, children },
        render: streamdown.snippets.thead,
        children: ($$renderer3) => {
          $$renderer3.push(`<thead${attr("data-streamdown-thead", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme.thead.base))}>`);
          children?.($$renderer3);
          $$renderer3.push(`<!----></thead>`);
        }
      });
    } else if (token.type === "tbody") {
      $$renderer2.push("<!--[10-->");
      Slot($$renderer2, {
        props: { token, children },
        render: streamdown.snippets.tbody,
        children: ($$renderer3) => {
          $$renderer3.push(`<tbody${attr("data-streamdown-tbody", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme.tbody.base))}>`);
          children?.($$renderer3);
          $$renderer3.push(`<!----></tbody>`);
        }
      });
    } else if (token.type === "tfoot") {
      $$renderer2.push("<!--[11-->");
      Slot($$renderer2, {
        props: { token, children },
        render: streamdown.snippets.tfoot,
        children: ($$renderer3) => {
          $$renderer3.push(`<tfoot${attr("data-streamdown-tfoot", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme.tfoot.base))}>`);
          children?.($$renderer3);
          $$renderer3.push(`<!----></tfoot>`);
        }
      });
    } else if (token.type === "tr") {
      $$renderer2.push("<!--[12-->");
      Slot($$renderer2, {
        props: { token, children },
        render: streamdown.snippets.tr,
        children: ($$renderer3) => {
          $$renderer3.push(`<tr${attr("data-streamdown-tr", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme.tr.base))}>`);
          children?.($$renderer3);
          $$renderer3.push(`<!----></tr>`);
        }
      });
    } else if (token.type === "td") {
      $$renderer2.push("<!--[13-->");
      if (token.rowspan > 0) {
        $$renderer2.push("<!--[-->");
        Slot($$renderer2, {
          props: { children, token },
          render: streamdown.snippets.td,
          children: ($$renderer3) => {
            $$renderer3.push(`<td${attributes({
              style,
              "data-streamdown-td": id,
              class: clsx$1(streamdown.theme.td.base),
              ...token.colspan > 1 ? { colspan: token.colspan } : {},
              ...token.rowspan > 1 ? { rowspan: token.rowspan } : {},
              ...token.align && ["left", "center", "right", "justify", "char"].includes(token.align) ? { align: token.align } : { align: "left" }
            })}>`);
            children?.($$renderer3);
            $$renderer3.push(`<!----></td>`);
          }
        });
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]-->`);
    } else if (token.type === "th") {
      $$renderer2.push("<!--[14-->");
      if (token.rowspan > 0) {
        $$renderer2.push("<!--[-->");
        Slot($$renderer2, {
          props: { children, token },
          render: streamdown.snippets.th,
          children: ($$renderer3) => {
            $$renderer3.push(`<th${attributes({
              style,
              "data-streamdown-th": id,
              class: clsx$1(streamdown.theme.th.base),
              ...token.colspan > 1 ? { colspan: token.colspan } : {},
              ...token.rowspan > 1 ? { rowspan: token.rowspan } : {},
              ...token.align && ["left", "center", "right", "justify", "char"].includes(token.align) ? { align: token.align } : { align: "left" }
            })}>`);
            children?.($$renderer3);
            $$renderer3.push(`<!----></th>`);
          }
        });
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]-->`);
    } else if (token.type === "image") {
      $$renderer2.push("<!--[15-->");
      Image($$renderer2, { id, token, children });
    } else if (token.type === "link") {
      $$renderer2.push("<!--[16-->");
      Link($$renderer2, { id, token, children });
    } else if (token.type === "sub") {
      $$renderer2.push("<!--[17-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.sub,
        children: ($$renderer3) => {
          $$renderer3.push(`<sub${attr("data-streamdown-sub", id)}${attr_class(clsx$1(streamdown.theme.sub.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></sub>`);
        }
      });
    } else if (token.type === "sup") {
      $$renderer2.push("<!--[18-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.sup,
        children: ($$renderer3) => {
          $$renderer3.push(`<sup${attr("data-streamdown-sup", id)}${attr_class(clsx$1(streamdown.theme.sup.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></sup>`);
        }
      });
    } else if (token.type === "strong") {
      $$renderer2.push("<!--[19-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.strong,
        children: ($$renderer3) => {
          $$renderer3.push(`<strong${attr("data-streamdown-strong", id)}${attr_class(clsx$1(streamdown.theme.strong.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></strong>`);
        }
      });
    } else if (token.type === "em") {
      $$renderer2.push("<!--[20-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.em,
        children: ($$renderer3) => {
          $$renderer3.push(`<em${attr("data-streamdown-em", id)}${attr_class(clsx$1(streamdown.theme.em.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></em>`);
        }
      });
    } else if (token.type === "del") {
      $$renderer2.push("<!--[21-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.del,
        children: ($$renderer3) => {
          $$renderer3.push(`<del${attr("data-streamdown-del", id)}${attr_class(clsx$1(streamdown.theme.del.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></del>`);
        }
      });
    } else if (token.type === "hr") {
      $$renderer2.push("<!--[22-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.hr,
        children: ($$renderer3) => {
          $$renderer3.push(`<hr${attr("data-streamdown-hr", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme.hr.base))}/>`);
        }
      });
    } else if (token.type === "br") {
      $$renderer2.push("<!--[23-->");
      $$renderer2.push(`<br${attr("data-streamdown-br", id)}/>`);
    } else if (token.type === "math") {
      $$renderer2.push("<!--[24-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.math,
        children: ($$renderer3) => {
          $$renderer3.push("<!---->");
          MathComponent?.($$renderer3, { id, token });
          $$renderer3.push(`<!---->`);
        }
      });
    } else if (token.type === "alert") {
      $$renderer2.push("<!--[25-->");
      Alert($$renderer2, { id, token, children });
    } else if (token.type === "footnoteRef") {
      $$renderer2.push("<!--[26-->");
      Slot($$renderer2, {
        props: { token },
        render: streamdown.snippets.footnoteRef,
        children: ($$renderer3) => {
          FootnoteRef($$renderer3, { token });
        }
      });
    } else if (token.type === "inline-citations") {
      $$renderer2.push("<!--[27-->");
      Slot($$renderer2, {
        props: { token },
        render: streamdown.snippets.inlineCitation,
        children: ($$renderer3) => {
          Citation($$renderer3, { token });
        }
      });
    } else if (token.type === "footnote") {
      $$renderer2.push("<!--[28-->");
    } else if (token.type === "descriptionList") {
      $$renderer2.push("<!--[29-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.descriptionList,
        children: ($$renderer3) => {
          $$renderer3.push(`<dl${attr("data-streamdown-description-list", id)}${attr_style(streamdown.animationBlockStyle)}${attr_class(clsx$1(streamdown.theme.descriptionList.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></dl>`);
        }
      });
    } else if (token.type === "description") {
      $$renderer2.push("<!--[30-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.description,
        children: ($$renderer3) => {
          children($$renderer3);
          $$renderer3.push(`<!---->`);
        }
      });
    } else if (token.type === "descriptionTerm") {
      $$renderer2.push("<!--[31-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.descriptionTerm,
        children: ($$renderer3) => {
          $$renderer3.push(`<dt${attr("data-streamdown-description-term", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme.descriptionTerm.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></dt>`);
        }
      });
    } else if (token.type === "descriptionDetail") {
      $$renderer2.push("<!--[32-->");
      Slot($$renderer2, {
        props: { children, token },
        render: streamdown.snippets.descriptionDetail,
        children: ($$renderer3) => {
          $$renderer3.push(`<dd${attr("data-streamdown-description-detail", id)}${attr_style(style)}${attr_class(clsx$1(streamdown.theme.descriptionDetail.base))}>`);
          children($$renderer3);
          $$renderer3.push(`<!----></dd>`);
        }
      });
    } else if (token.type === "def") {
      $$renderer2.push("<!--[33-->");
    } else if (token.type === "escape") {
      $$renderer2.push("<!--[34-->");
    } else if (token.type === "space") {
      $$renderer2.push("<!--[35-->");
    } else if (token.type === "text") {
      $$renderer2.push("<!--[36-->");
      children($$renderer2);
      $$renderer2.push(`<!---->`);
    } else if (token.type === "html") {
      $$renderer2.push("<!--[37-->");
      if (streamdown.renderHtml) {
        $$renderer2.push("<!--[-->");
        const content = typeof streamdown.renderHtml === "function" ? streamdown.renderHtml(token) : token.raw;
        $$renderer2.push(`${html(content)}`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]-->`);
    } else if (token.type === "mdx") {
      $$renderer2.push("<!--[38-->");
      const Component = streamdown.mdxComponents?.[token.tagName];
      if (Component) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push("<!---->");
        Component?.($$renderer2, { token, children, props: token.attributes });
        $$renderer2.push(`<!---->`);
      } else {
        $$renderer2.push("<!--[!-->");
        Slot($$renderer2, {
          props: { token, children, props: token.attributes },
          render: streamdown.snippets.mdx,
          children: ($$renderer3) => {
            children($$renderer3);
            $$renderer3.push(`<!---->`);
          }
        });
      }
      $$renderer2.push(`<!--]-->`);
    } else {
      $$renderer2.push("<!--[!-->");
      streamdown.children?.($$renderer2, { token, children, streamdown });
      $$renderer2.push(`<!---->`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
const variants = ["note", "tip", "important", "warning", "caution"];
function createSyntaxPattern(type) {
  return `^\\s*[\\*_]*\\[!${type.toUpperCase()}\\][\\*_]*\\s*`;
}
const defaultLexer$1 = new Lexer({ gfm: true });
const defaultTokenizer = defaultLexer$1.options.tokenizer;
const markedAlert = {
  name: "alert",
  level: "block",
  tokenizer(src) {
    const cap = defaultTokenizer.rules.block.blockquote.exec(src);
    if (cap) {
      const blockquoteToken = defaultTokenizer.blockquote(src);
      blockquoteToken && processAlertToken(blockquoteToken, this.lexer.options.tokenizer);
      return blockquoteToken;
    }
  }
};
function processAlertToken(token, tokenizer) {
  const matchedVariant = variants.find((type) => new RegExp(createSyntaxPattern(type), "i").test("text" in token && token.text || ""));
  if (!matchedVariant) {
    Object.assign(token, {
      tokens: token.tokens.map((token2) => {
        return tokenizer.lexer.blockTokens(token2.raw, [])[0];
      }).filter(Boolean)
    });
    return;
  }
  const alertPattern = new RegExp(`[\\*_]*\\[!${matchedVariant.toUpperCase()}\\][\\*_]*`, "g");
  const tokens = token.tokens.map((token2) => {
    let cleanedRaw = token2.raw;
    cleanedRaw = cleanedRaw.replaceAll(alertPattern, "").trim();
    return tokenizer.lexer.blockTokens(cleanedRaw, [])[0];
  }).filter(Boolean);
  Object.assign(token, {
    type: "alert",
    variant: matchedVariant,
    tokens,
    text: token.text.replace(alertPattern, "").trim()
  });
}
const footnoteRegex = /^\[\^([^\]\n]+)\]:(?:[ \t]+|\n|$)([^\n]*(?:\n(?:[ \t]+[^\n]*)?)*)/;
const footnoteRefRegex = /^\[\^([^\]\n]+)\]/;
const footNoteLastLineRegex = /^[ \t]*?[>\-*][ ]|[`]{3,}$|^[ \t]*?[|].+[|]$/;
const safeGetContext = () => {
  try {
    return getContext("streamdown");
  } catch (e) {
    return null;
  }
};
function markedFootnote() {
  const ensureMaps = (tokenizer) => {
    const streamdown = safeGetContext();
    if (!streamdown) {
      if (!tokenizer.lexer.hasFootnotes) {
        tokenizer.lexer.footnotes = {
          refs: /* @__PURE__ */ new Map(),
          footnotes: /* @__PURE__ */ new Map()
        };
        tokenizer.lexer.hasFootnotes = true;
      }
      return tokenizer.lexer.footnotes;
    } else {
      return streamdown.footnotes;
    }
  };
  return [
    {
      name: "footnote",
      level: "block",
      tokenizer(src) {
        const maps = ensureMaps(this);
        const match = footnoteRegex.exec(src);
        if (match) {
          const [raw, label, text = ""] = match;
          let content = text.split("\n").reduce((acc, curr) => {
            return acc + "\n" + curr.replace(/^[ \t]+/, "");
          }, "");
          const contentLastLine = content.trimEnd().split("\n").pop();
          content += // add lines after list, blockquote, codefence, and table
          contentLastLine && footNoteLastLineRegex.test(contentLastLine) ? "\n\n" : "";
          const lines = content.split("\n");
          const token = {
            type: "footnote",
            raw,
            label,
            lines,
            tokens: []
          };
          maps.footnotes.set(label, token);
          const ref = maps.refs.get(label);
          if (ref) {
            ref.content = token;
          }
          return token;
        }
      }
    },
    {
      name: "footnoteRef",
      level: "inline",
      tokenizer(src) {
        const maps = ensureMaps(this);
        const match = footnoteRefRegex.exec(src);
        if (match) {
          const [raw, label] = match;
          const footnote = maps.footnotes.get(label);
          const token = {
            type: "footnoteRef",
            raw,
            label,
            content: footnote || {
              type: "footnote",
              raw,
              label,
              lines: [],
              tokens: []
            }
          };
          maps.refs.set(label, token);
          return token;
        }
      }
    }
  ];
}
const blockRule = /^(\$\$)(?:\n((?:\\[\s\S]|[^\\])+?)\n\1(?:\n|$)|([^$\n]+?)\1(?=\s|$|$))/;
const inlineRule = /^(\${1,2})(?!\$)((?:[^$\n]|\\\$)*?)\1(?!\d)/;
const currencyPatterns = {
  // Simple price patterns: $123, $123.45, $1,234.56
  simplePrice: /^\d{1,3}(?:,\d{3})*(?:\.\d{2})?$/,
  // Multiple prices or numbers: "123, 456", "123.45, 678.90", "123 or 456"
  multipleNumbers: /^\d+(?:[.,]\d+)*(?:\s*[,;]\s*\d+(?:[.,]\d+)*)+$/,
  // Price ranges: "123-456", "123 - 456", "123 to 456"
  priceRange: /^\d+(?:\.\d{2})?\s*(?:-|to|or)\s*\d+(?:\.\d{2})?$/i,
  // Common currency words nearby (check surrounding context)
  currencyContext: /(?:price|cost|dollar|euro|pound|yen|currency|pay|buy|sell|expensive|cheap)/i
};
const markedMath = [
  {
    name: "math",
    level: "block",
    tokenizer(src) {
      const match = src.match(blockRule);
      if (match) {
        const content = (match[2] || match[3]).trim();
        return {
          type: "math",
          isInline: false,
          displayMode: true,
          raw: match[0],
          text: content
        };
      }
    }
  },
  {
    name: "math",
    level: "inline",
    start(src) {
      let index = 0;
      let searchSrc = src;
      while (searchSrc) {
        const dollarIndex = searchSrc.indexOf("$");
        if (dollarIndex === -1) {
          return;
        }
        const currentIndex = index + dollarIndex;
        const possibleMath = src.substring(currentIndex);
        if (possibleMath.match(inlineRule)) {
          const match = possibleMath.match(inlineRule);
          if (match) {
            const content = match[2];
            const dollarCount = match[1];
            if (dollarCount === "$" && isCurrencyPattern(content, src, currentIndex)) {
              index += dollarIndex + 1;
              searchSrc = src.substring(index);
              continue;
            }
            return currentIndex;
          }
        }
        index += dollarIndex + 1;
        searchSrc = src.substring(index);
      }
    },
    tokenizer(src) {
      const match = src.match(inlineRule);
      if (match) {
        const content = match[2];
        const dollarCount = match[1];
        const isDisplayMode = dollarCount === "$$";
        if (dollarCount === "$" && isCurrencyPattern(content, src, 0)) {
          return;
        }
        return {
          type: "math",
          isInline: true,
          // Inline tokenizer always produces inline math
          displayMode: isDisplayMode,
          // $$ = display mode styling, $ = inline styling
          raw: match[0],
          text: content.trim()
        };
      }
    }
  }
];
function isCurrencyPattern(content, fullSrc, dollarIndex) {
  const trimmedContent = content.trim();
  if (currencyPatterns.simplePrice.test(trimmedContent)) {
    return true;
  }
  if (currencyPatterns.multipleNumbers.test(trimmedContent)) {
    return true;
  }
  if (currencyPatterns.priceRange.test(trimmedContent)) {
    return true;
  }
  const contextStart = Math.max(0, dollarIndex - 50);
  const contextEnd = Math.min(fullSrc.length, dollarIndex + content.length + 50);
  const context = fullSrc.substring(contextStart, contextEnd);
  if (currencyPatterns.currencyContext.test(context)) {
    if (/^\d+(?:[.,]\d+)*$/.test(trimmedContent)) {
      return true;
    }
  }
  if (/^\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?$/.test(trimmedContent)) {
    return true;
  }
  return false;
}
const subRule = /^~([^~\s](?:[^~]*[^~\s])?)~/;
const supRule = /^\^([^\^\s](?:[^\^]*[^\^\s])?)\^/;
const markedSub = {
  name: "sub",
  level: "inline",
  start(src) {
    const i = src.indexOf("~");
    return i === -1 ? void 0 : i;
  },
  tokenizer(src) {
    const match = src.match(subRule);
    if (match) {
      return {
        type: "sub",
        raw: match[0],
        text: match[1],
        tokens: this.lexer.inlineTokens(match[1])
      };
    }
  }
};
const markedSup = {
  name: "sup",
  level: "inline",
  start(src) {
    const i = src.indexOf("^");
    return i === -1 ? void 0 : i;
  },
  tokenizer(src) {
    const match = src.match(supRule);
    if (match) {
      return {
        type: "sup",
        raw: match[0],
        text: match[1],
        tokens: this.lexer.inlineTokens(match[1])
      };
    }
  }
};
function letterToInt(letter) {
  return letter.toLowerCase().charCodeAt(0) - 96;
}
const romanMap = {
  I: 1,
  V: 5,
  X: 10,
  L: 50,
  C: 100,
  D: 500,
  M: 1e3
};
function romanToInt(roman) {
  roman = roman.toUpperCase();
  let total = 0;
  for (let i = 0; i < roman.length; i++) {
    const current = romanMap[roman[i]];
    const next = romanMap[roman[i + 1]];
    total += next && current < next ? -current : current;
  }
  return total;
}
const romanUpper = "(?:C|XC|L?X{0,3}(?:IX|IV|V?I{0,3}))";
const romanLower = "(?:c|xc|l?x{0,3}(?:ix|iv|v?i{0,3}))";
const bulletPattern = `(?:[*+-]|(?:\\d{1,9}|[a-zA-Z]|${romanUpper}|${romanLower})[.)])`;
const rule = `^( {0,3}${bulletPattern})([ \\t][^\\n]*|[ \\t])?(?:\\n|$)`;
function finalizeList(list, lexer) {
  if (list.tokens.length === 0)
    return;
  const lastItem = list.tokens[list.tokens.length - 1];
  lastItem.raw = lastItem.raw.trimEnd();
  lastItem.text = lastItem.text.trimEnd();
  list.raw = list.raw.trimEnd();
  for (const item of list.tokens) {
    lexer.state.top = false;
    item.tokens = lexer.blockTokens(item.text, []);
  }
  if (list.loose) {
    for (const item of list.tokens) {
      item.loose = true;
    }
  }
}
function escapeForRegex(s) {
  return s.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&");
}
const markedList = {
  name: "list",
  level: "block",
  tokenizer(src) {
    let cap = new RegExp(rule).exec(src);
    if (!cap)
      return void 0;
    const bullet = cap[1].trim();
    const isOrdered = bullet !== "*" && bullet !== "-" && bullet !== "+";
    let bull;
    let type = "";
    let expectedValue = null;
    if (isOrdered) {
      if (bullet.match(new RegExp(`^${romanUpper}[.)]$`))) {
        type = "upper-roman";
        bull = `${romanUpper}\\${bullet.slice(-1)}`;
      } else if (bullet.match(new RegExp(`^${romanLower}[.)]$`))) {
        type = "lower-roman";
        bull = `${romanLower}\\${bullet.slice(-1)}`;
      } else if (bullet.match(/^[a-z][.)]$/)) {
        type = "lower-alpha";
        bull = `[a-z]\\${bullet.slice(-1)}`;
      } else if (bullet.match(/^[A-Z][.)]$/)) {
        type = "upper-alpha";
        bull = `[A-Z]\\${bullet.slice(-1)}`;
      } else {
        type = "decimal";
        bull = `\\d{1,9}\\${bullet.slice(-1)}`;
      }
    } else {
      bull = this.lexer.options.pedantic ? bullet : "[*+-]";
      bull = this.lexer.options.pedantic ? escapeForRegex(bullet) : "[*+-]";
    }
    const list = {
      type: "list",
      raw: "",
      ordered: isOrdered,
      listType: isOrdered ? type : null,
      loose: false,
      start: void 0,
      // Will be set when first item is processed
      tokens: []
    };
    const itemRegex = new RegExp(`^( {0,3}${bull})([	 ][^\\n]*|[	 ])?(?:\\n|$)`);
    let endsWithBlankLine = false;
    while (src) {
      let raw = "";
      let itemContents = "";
      let endEarly = false;
      if (!(cap = itemRegex.exec(src)))
        break;
      raw = cap[0];
      const bullet2 = cap[1].trim();
      src = src.substring(raw.length);
      const line = cap[2] ? cap[2].split("\n", 1)[0].replace(/^\t+/, (t2) => " ".repeat(4 * t2.length)) : "";
      const nextLine = src.split("\n", 1)[0];
      const blankLine = !line.trim();
      let indent = 0;
      if (this.lexer.options.pedantic) {
        indent = 2;
        itemContents = line.trimStart();
      } else if (blankLine) {
        indent = cap[1].length + 1;
      } else {
        indent = cap[2].search(/[^ ]/);
        indent = indent > 4 ? 1 : indent;
        itemContents = line.slice(indent);
        indent += cap[1].length;
      }
      if (blankLine && /^[ \t]*$/.test(nextLine)) {
        raw += nextLine + "\n";
        src = src.substring(nextLine.length + 1);
        endEarly = true;
      }
      if (!endEarly) {
        const nextBulletRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:[*+-]|(?:\\d{1,9}|[a-zA-Z]|${romanUpper}|${romanLower})[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`);
        const hrRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`);
        const fencesBeginRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:\`\`\`|~~~)`);
        const headingBeginRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}#`);
        const htmlBeginRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}<[a-z].*>`, "i");
        while (src) {
          const rawLine = src.split("\n", 1)[0];
          const nextLineWithoutTabs = rawLine.replace(/\t/g, "    ");
          if (fencesBeginRegex.test(nextLineWithoutTabs) || headingBeginRegex.test(nextLineWithoutTabs) || htmlBeginRegex.test(nextLineWithoutTabs) || nextBulletRegex.test(nextLineWithoutTabs) || hrRegex.test(nextLineWithoutTabs))
            break;
          if (nextLineWithoutTabs.search(/[^ ]/) >= indent || !nextLineWithoutTabs.trim()) {
            itemContents += "\n" + nextLineWithoutTabs.slice(indent);
          } else {
            itemContents += "\n" + nextLineWithoutTabs;
          }
          raw += rawLine + "\n";
          src = src.substring(rawLine.length + 1);
        }
      }
      if (!list.loose) {
        if (endsWithBlankLine) {
          list.loose = true;
        } else if (/\n[ \t]*\n[ \t]*$/.test(raw)) {
          endsWithBlankLine = true;
        }
      }
      let isTask = null;
      let isChecked = false;
      if (this.lexer.options.gfm) {
        isTask = /^\[[ xX]] /.exec(itemContents);
        if (isTask) {
          isChecked = isTask[0] !== "[ ] ";
          itemContents = itemContents.replace(/^\[[ xX]] +/, "");
        }
      }
      let value = null;
      if (!isOrdered) ;
      else if (type === "decimal") {
        value = parseInt(bullet2.slice(0, -1), 10);
      } else if (type === "lower-alpha" || type === "upper-alpha") {
        value = letterToInt(bullet2.slice(0, -1));
      } else if (type === "lower-roman" || type === "upper-roman") {
        value = romanToInt(bullet2.slice(0, -1));
      }
      let skipped = false;
      if (isOrdered) {
        if (expectedValue === null) {
          expectedValue = value ?? 1;
          list.start = expectedValue;
        } else {
          skipped = value !== null && value !== expectedValue;
          expectedValue += 1;
        }
      }
      list.tokens.push({
        type: "list_item",
        raw,
        task: !!isTask,
        checked: isChecked,
        loose: false,
        text: itemContents,
        value,
        skipped,
        tokens: []
      });
      list.raw += raw;
    }
    if (list.tokens.length === 0)
      return void 0;
    finalizeList(list, this.lexer);
    return list;
  }
};
const markedBr = {
  name: "br",
  level: "inline",
  tokenizer(src) {
    const match = src.match(/^<br\s*\/?>/i);
    if (match) {
      return {
        type: "br",
        raw: match[0]
      };
    }
    return void 0;
  }
};
const markedHr = {
  name: "hr",
  level: "block",
  tokenizer(src) {
    const match = src.match(/^[ \t]*(-[ \t]*-[ \t]*-+|_[ \t]*_[ \t]*_+|\*[ \t]*\*[ \t]*\*+)[ \t]*(?:\n|$)/);
    if (match) {
      const raw = match[0].replace(/\n$/, "");
      return {
        type: "hr",
        raw
      };
    }
    return void 0;
  }
};
const DEFAULT_OPTIONS = {
  maxColspan: null
};
function splitRow(src) {
  const out = [];
  let buf = "";
  let esc = false;
  let inCode = false;
  let fence = 0;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (esc) {
      buf += ch;
      esc = false;
      continue;
    }
    if (ch === "\\") {
      esc = true;
      buf += ch;
      continue;
    }
    if (ch === "`") {
      let run2 = 1;
      while (i + run2 < src.length && src[i + run2] === "`")
        run2++;
      if (!inCode) {
        inCode = true;
        fence = run2;
      } else if (run2 >= fence) {
        inCode = false;
        fence = 0;
      }
      buf += src.slice(i, i + run2);
      i += run2 - 1;
      continue;
    }
    if (ch === "|" && !inCode) {
      let consecutivePipes = 1;
      while (i + consecutivePipes < src.length && src[i + consecutivePipes] === "|") {
        consecutivePipes++;
      }
      if (consecutivePipes > 1) {
        out.push(buf.trim() + "\0COLSPAN:" + consecutivePipes);
        i += consecutivePipes - 1;
      } else {
        out.push(buf.trim());
      }
      buf = "";
      continue;
    }
    buf += ch;
  }
  out.push(buf.trim());
  return out;
}
const splitCells = (tableRow, count, prevRow = null, maxColspan2 = null) => {
  const cells = splitRow(tableRow);
  if (cells.length > 0 && !cells[0])
    cells.shift();
  if (cells.length > 0 && !cells[cells.length - 1])
    cells.pop();
  return processSpans(cells, count, prevRow || [], maxColspan2);
};
const processSpans = (cells, count, prevRow = [], maxColspan2 = null) => {
  let numCols = 0;
  let i, j, trimmedCell, prevCell;
  const processedCells = [];
  const colspanCells = /* @__PURE__ */ new Map();
  let cellIndex = 0;
  const mergedIndices = /* @__PURE__ */ new Set();
  for (i = 0; i < cells.length; i++) {
    if (mergedIndices.has(i))
      continue;
    trimmedCell = cells[i];
    let colspan = 1;
    if (trimmedCell.includes("\0COLSPAN:")) {
      const parts = trimmedCell.split("\0COLSPAN:");
      trimmedCell = parts[0];
      colspan = parseInt(parts[1], 10);
    } else if (!trimmedCell.trim()) {
      let run2 = 1, k = i + 1;
      while (k < cells.length && !cells[k].trim()) {
        run2++;
        mergedIndices.add(k++);
      }
      if (processedCells.length) {
        const target = processedCells[processedCells.length - 1];
        const allowed = maxColspan2 != null ? Math.min(run2, Math.max(0, maxColspan2 - target.colspan)) : run2;
        target.colspan += allowed;
        numCols += allowed;
        continue;
      } else {
        colspan = maxColspan2 != null ? Math.min(run2, maxColspan2) : run2;
      }
    }
    if (maxColspan2 !== null && colspan > maxColspan2)
      colspan = maxColspan2;
    processedCells[cellIndex] = {
      rowspan: 1,
      colspan,
      text: trimmedCell.trim().replace(/\\\|/g, "|"),
      position: numCols
    };
    numCols += processedCells[cellIndex].colspan;
    cellIndex++;
  }
  for (i = 0; i < processedCells.length; i++) {
    const cell = processedCells[i];
    let cellText = cell.text;
    const isRowspanIndicator = cellText.slice(-1) === "^" && !cellText.match(/\^[^^\n\r]+\^$/);
    if (isRowspanIndicator && prevRow.length > 0) {
      cell.text = cellText.slice(0, -1).trim();
      cellText = cell.text;
      let targetFound = false;
      const startPosition = cell.position || 0;
      const endPosition = startPosition + cell.colspan - 1;
      for (j = 0; j < prevRow.length; j++) {
        prevCell = prevRow[j];
        const prevStartPosition = prevCell.position || 0;
        const prevEndPosition = prevStartPosition + prevCell.colspan - 1;
        if (startPosition >= prevStartPosition && startPosition <= prevEndPosition || endPosition >= prevStartPosition && endPosition <= prevEndPosition || prevStartPosition >= startPosition && prevEndPosition <= endPosition) {
          if (cell.colspan > 1 && prevCell.colspan > 1) {
            if (cell.colspan === prevCell.colspan && cell.position === prevCell.position) {
              cell.rowSpanTarget = prevCell.rowSpanTarget ?? prevCell;
              const textToAppend = cell.text.slice(0, -1).trim();
              const targetText = cell.rowSpanTarget.text.trim();
              if (textToAppend && textToAppend !== targetText && !targetText.includes(textToAppend)) {
                cell.rowSpanTarget.text = targetText + (targetText ? " " : "") + textToAppend;
              }
              cell.rowSpanTarget.rowspan += 1;
              cell.rowspan = 0;
              targetFound = true;
              break;
            } else {
              const key = `${cell.position}-${cell.colspan}`;
              colspanCells.set(key, {
                original: prevCell,
                newCell: cell
              });
            }
          } else {
            cell.rowSpanTarget = prevCell.rowSpanTarget ?? prevCell;
            const textToAppend = cell.text.slice(0, -1).trim();
            const targetText = cell.rowSpanTarget.text.trim();
            if (textToAppend && textToAppend !== targetText && !targetText.includes(textToAppend)) {
              cell.rowSpanTarget.text = targetText + (targetText ? " " : "") + textToAppend;
            }
            cell.rowSpanTarget.rowspan += 1;
            cell.rowspan = 0;
            targetFound = true;
            break;
          }
        }
      }
      if (!targetFound && cell.rowspan > 0) {
        if (isRowspanIndicator) {
          cell.text = cell.text.slice(0, -1);
        }
      }
    }
  }
  colspanCells.forEach((spanData) => {
    const { original, newCell } = spanData;
    if (original && newCell) {
      newCell.complexRowSpan = true;
      newCell.relatedCell = original;
    }
  });
  return normalizeColumnCount(processedCells, count, numCols);
};
const normalizeColumnCount = (cells, count, numCols) => {
  if (count === null)
    return cells;
  if (numCols > count) {
    let currentColCount = 0;
    const cellsToKeep = [];
    for (const cell of cells) {
      if (currentColCount + cell.colspan <= count) {
        cellsToKeep.push(cell);
        currentColCount += cell.colspan;
      } else if (currentColCount < count) {
        const adjustedCell = { ...cell };
        adjustedCell.colspan = count - currentColCount;
        cellsToKeep.push(adjustedCell);
        currentColCount = count;
      } else {
        break;
      }
    }
    return cellsToKeep;
  } else {
    while (numCols < count) {
      cells.push({
        colspan: 1,
        rowspan: 1,
        text: "",
        position: numCols
      });
      numCols += 1;
    }
  }
  return cells;
};
function processAlignment(alignRow) {
  const alignment = [];
  for (let i = 0; i < alignRow.length; i++) {
    if (/^ *-+: *$/.test(alignRow[i])) {
      alignment[i] = "right";
    } else if (/^ *:-+: *$/.test(alignRow[i])) {
      alignment[i] = "center";
    } else if (/^ *:-+ *$/.test(alignRow[i])) {
      alignment[i] = "left";
    } else {
      alignment[i] = null;
    }
  }
  return alignment;
}
function workingCellToTH(cell, align) {
  return {
    type: "th",
    rowspan: cell.rowspan,
    colspan: cell.colspan,
    text: cell.text,
    position: cell.position,
    tokens: cell.tokens,
    rowSpanTarget: cell.rowSpanTarget,
    complexRowSpan: cell.complexRowSpan,
    relatedCell: cell.relatedCell,
    align
  };
}
function workingCellToTD(cell, align) {
  return {
    type: "td",
    rowspan: cell.rowspan,
    colspan: cell.colspan,
    text: cell.text,
    position: cell.position,
    tokens: cell.tokens,
    rowSpanTarget: cell.rowSpanTarget,
    complexRowSpan: cell.complexRowSpan,
    relatedCell: cell.relatedCell,
    align
  };
}
function processRows(headerRows, bodyRows, alignment, colCount, lexer, maxColspan2, detectFooter) {
  const tokens = [];
  const processedHeaderRows = [];
  for (let i = 0; i < headerRows.length; i++) {
    const prevRow = i > 0 ? processedHeaderRows[i - 1] : null;
    processedHeaderRows[i] = splitCells(headerRows[i], colCount, prevRow, maxColspan2);
  }
  if (processedHeaderRows.length > 0) {
    const theadRows = processedHeaderRows.map((row) => ({
      type: "tr",
      tokens: row.map((cell) => {
        const cellAlignment = cell.position !== void 0 ? alignment[cell.position] : null;
        const th = workingCellToTH(cell, cellAlignment);
        th.tokens = lexer.inline(th.text, th.tokens);
        return th;
      })
    }));
    tokens.push({
      type: "thead",
      tokens: theadRows
    });
  }
  if (bodyRows.length > 0) {
    const processedBodyRows = [];
    for (let i = 0; i < bodyRows.length; i++) {
      const prevRow = i > 0 ? processedBodyRows[i - 1] : processedHeaderRows[processedHeaderRows.length - 1];
      processedBodyRows[i] = splitCells(bodyRows[i], colCount, prevRow, maxColspan2);
    }
    let tbodyRows = processedBodyRows;
    let tfootRows = [];
    if (detectFooter && processedBodyRows.length > 0) {
      const lastRowIndex = processedBodyRows.length - 1;
      tfootRows = [processedBodyRows[lastRowIndex]];
      tbodyRows = processedBodyRows.slice(0, lastRowIndex);
    }
    if (tbodyRows.length > 0) {
      const tbodyRowTokens = tbodyRows.map((row) => ({
        type: "tr",
        tokens: row.map((cell) => {
          const cellAlignment = cell.position !== void 0 ? alignment[cell.position] : null;
          const td = workingCellToTD(cell, cellAlignment);
          td.tokens = lexer.inline(td.text, td.tokens);
          return td;
        })
      }));
      tokens.push({
        type: "tbody",
        tokens: tbodyRowTokens
      });
    }
    if (tfootRows.length > 0) {
      const tfootRowTokens = tfootRows.map((row) => ({
        type: "tr",
        tokens: row.map((cell) => {
          const cellAlignment = cell.position !== void 0 ? alignment[cell.position] : null;
          const td = workingCellToTD(cell, cellAlignment);
          td.tokens = lexer.inline(td.text, td.tokens);
          return td;
        })
      }));
      tokens.push({
        type: "tfoot",
        tokens: tfootRowTokens
      });
    }
  }
  return tokens;
}
const { maxColspan } = DEFAULT_OPTIONS;
const markedTable = {
  name: "table",
  level: "block",
  start(src) {
    let match = src.match(/^\n *([^\n ].*\|.*)\n/);
    if (match)
      return match.index;
    match = src.match(/^\n *(\|.*\|)\n/);
    if (match)
      return match.index;
    return void 0;
  },
  tokenizer(src) {
    let regex = new RegExp("^([^\\n ].*\\|.*\\n(?: *[^\\s].*\\n)*?) {0,3}(?:\\| *)?(:?-+:? *(?:\\| *:?-+:? *)*)(?:\\| *)?(?:\\n((?:(?! *\\n| {0,3}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)| {0,3}#{1,6} | {0,3}>| {4}[^\\n]| {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n| {0,3}(?:[*+-]|1[.)]) |<\\/?(?:address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul)(?: +|\\n|\\/?>)|<(?:script|pre|style|textarea|!--)).*(?:\\n|$))*)\\n*|$)");
    let cap = regex.exec(src);
    let hasHeaderAlignment = true;
    if (!cap) {
      regex = /^(\|.*\|(?:\n\|.*\|)*)/;
      cap = regex.exec(src);
      hasHeaderAlignment = false;
    }
    if (!cap)
      return void 0;
    let allTableContent = cap[1];
    if (cap[2])
      allTableContent += "\n" + cap[2];
    if (cap[3])
      allTableContent += "\n" + cap[3];
    const allRows = allTableContent.replace(/\n$/, "").split("\n");
    let headerRows = [];
    let bodyRows = [];
    let alignRow = [];
    let alignment = [];
    let colCount = 0;
    if (hasHeaderAlignment) {
      let headerEndIndex = -1;
      for (let i = 0; i < allRows.length; i++) {
        const row = allRows[i].trim();
        const isAlignment = /^ *(\| *)?:?-+:? *(\| *:?-+:? *)*(\| *)?$/.test(row);
        if (isAlignment) {
          headerEndIndex = i;
          alignRow = row.replace(/^ *\| *| *\| *$/g, "").split(/ *\| */);
          break;
        }
      }
      if (headerEndIndex === -1) {
        bodyRows = allRows;
        colCount = bodyRows[0].split("|").filter((cell) => cell.trim() !== "").length;
        alignment = new Array(colCount).fill(null);
      } else {
        headerRows = allRows.slice(0, headerEndIndex).filter((row) => row.trim() !== "");
        bodyRows = headerEndIndex + 1 < allRows.length ? allRows.slice(headerEndIndex + 1) : [];
        colCount = alignRow.length;
        if (colCount === 0)
          return void 0;
        alignment = processAlignment(alignRow);
      }
    } else {
      bodyRows = allRows;
      const firstRowCells = bodyRows[0].split("|").filter((cell) => cell.trim() !== "");
      colCount = firstRowCells.length;
      alignment = new Array(colCount).fill(null);
    }
    let shouldDetectFooter = false;
    let processedBodyRows = bodyRows;
    if (hasHeaderAlignment && bodyRows.length > 0) {
      for (let i = bodyRows.length - 1; i >= 0; i--) {
        const row = bodyRows[i];
        if (/^ *\| *:?-+:? *(\| *:?-+:? *)*\| *$/.test(row)) {
          shouldDetectFooter = true;
          processedBodyRows = bodyRows.slice(0, i).concat(bodyRows.slice(i + 1));
          break;
        }
      }
    }
    const tokens = processRows(headerRows, processedBodyRows, alignment, colCount, this.lexer, maxColspan, shouldDetectFooter);
    const item = {
      type: "table",
      tokens,
      raw: cap[0],
      align: alignment
    };
    return item;
  }
};
const markedDl = {
  name: "descriptionList",
  level: "block",
  // Is this a block-level or inline-level tokenizer?
  tokenizer(src) {
    const rule2 = /^(?:[ \t]*:[^:\n]+:[ \t]?[^\n]*(?:\n|$))+/;
    const match = rule2.exec(src);
    if (match) {
      const text = match[0].trim();
      const tokens = [];
      const lines = text.split("\n");
      for (const line of lines) {
        const lineMatch = /^\s*:([^:\n]+):([^:\n]*)(?:\n|$)/.exec(line);
        if (lineMatch) {
          const term = lineMatch[1].trim();
          const detail = lineMatch[2].trim();
          tokens.push({
            type: "description",
            raw: lineMatch[0],
            tokens: [
              {
                type: "descriptionTerm",
                raw: term,
                tokens: this.lexer.inlineTokens(term)
              },
              {
                type: "descriptionDetail",
                raw: detail,
                tokens: this.lexer.inlineTokens(detail)
              }
            ]
          });
        }
      }
      const token = {
        type: "descriptionList",
        raw: match[0],
        text,
        tokens
      };
      return token;
    }
  }
};
const markedAlign = {
  name: "align",
  level: "block",
  tokenizer(src) {
    const centerMatch = src.match(/^\[center\]\n([\s\S]*?)\n\[\/center\]/);
    const rightMatch = src.match(/^\[right\]\n([\s\S]*?)\n\[\/right\]/);
    if (centerMatch) {
      const text = centerMatch[1];
      const raw = centerMatch[0];
      const tokens = this.lexer.blockTokens(text, []);
      return {
        type: "align",
        align: "center",
        raw,
        text,
        tokens
      };
    }
    if (rightMatch) {
      const text = rightMatch[1];
      const raw = rightMatch[0];
      const tokens = this.lexer.blockTokens(text, []);
      return {
        type: "align",
        align: "right",
        raw,
        text,
        tokens
      };
    }
    return void 0;
  }
};
const markedCitations = {
  name: "citations",
  level: "inline",
  start(src) {
    return src.indexOf("[") === -1 ? -1 : 0;
  },
  tokenizer(src) {
    const match = src.match(/^\[[^\]]+\](?:\s+\[[^\]]+\])*/);
    if (match) {
      const firstClosingBracketIndex = src.indexOf("]");
      if (firstClosingBracketIndex !== -1 && src[firstClosingBracketIndex + 1] === "[") {
        return void 0;
      }
      const remainingSrc = src.slice(match[0].length);
      if (remainingSrc.match(/^\s*\(/)) {
        return void 0;
      }
      const citations = match[0].match(/\[([^\]]+)\]/g);
      if (citations) {
        const validCitations = citations.filter((citation) => {
          const content = citation.slice(1, -1).trim();
          return content !== "" && content !== "x" && content !== "X";
        });
        if (validCitations.length > 0) {
          const keys = validCitations.flatMap((citation) => {
            const content = citation.slice(1, -1).trim();
            return content.split(/[\s,;]+/).filter((key) => key.length > 0);
          });
          const uniqueKeys = Array.from(new Set(keys.map((key) => key.trim()).filter((key) => key.length > 0)));
          return {
            type: "inline-citations",
            keys: uniqueKeys,
            text: match[0],
            raw: match[0]
          };
        }
      }
    }
  }
};
const defaultLexer = new Lexer({ gfm: true });
defaultLexer.options.tokenizer;
function parseAttributes(attributeString) {
  const attributes2 = {};
  const attrPattern = /(\w+)=(?:"([^"]*)"|{([^}]*)})/g;
  let match;
  while ((match = attrPattern.exec(attributeString)) !== null) {
    const [, name, stringValue, expressionValue] = match;
    if (stringValue !== void 0) {
      attributes2[name] = stringValue;
    } else if (expressionValue !== void 0) {
      const trimmed = expressionValue.trim();
      if (/^-?\d+(\.\d+)?$/.test(trimmed)) {
        attributes2[name] = parseFloat(trimmed);
      } else if (trimmed === "true") {
        attributes2[name] = true;
      } else if (trimmed === "false") {
        attributes2[name] = false;
      } else {
        attributes2[name] = trimmed;
      }
    }
  }
  return attributes2;
}
const markedMdx = {
  name: "mdx",
  level: "block",
  applyInBlockParsing: true,
  tokenizer(src) {
    const selfClosingMatch = src.match(/^<([A-Z][a-zA-Z0-9]*)((?:\s+\w+=(?:"[^"]*"|{[^}]*}))*)\s*\/>/);
    if (selfClosingMatch) {
      const [raw, tagName, attributeString] = selfClosingMatch;
      const attributes2 = parseAttributes(attributeString);
      return {
        type: "mdx",
        raw,
        tagName,
        attributes: attributes2,
        selfClosing: true
      };
    }
    const openTagMatch = src.match(/^<([A-Z][a-zA-Z0-9]*)((?:\s+\w+=(?:"[^"]*"|{[^}]*}))*)\s*>/);
    if (openTagMatch) {
      const [openTag, tagName, attributeString] = openTagMatch;
      const attributes2 = parseAttributes(attributeString);
      const closingTag = `</${tagName}>`;
      const escapedTagName = tagName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const openTagPattern = new RegExp(`<${escapedTagName}(?:\\s|>)`, "g");
      const closeTagPattern = new RegExp(`</${escapedTagName}>`, "g");
      let depth = 1;
      let searchPos = openTag.length;
      let closingIndex = -1;
      while (depth > 0 && searchPos < src.length) {
        openTagPattern.lastIndex = searchPos;
        closeTagPattern.lastIndex = searchPos;
        const nextOpen = openTagPattern.exec(src);
        const nextClose = closeTagPattern.exec(src);
        if (!nextClose)
          break;
        if (nextOpen && nextOpen.index < nextClose.index) {
          const tagStart = nextOpen.index;
          const tagEndPos = src.indexOf(">", tagStart);
          if (tagEndPos !== -1) {
            const fullTag = src.substring(tagStart, tagEndPos + 1);
            const isSelfClosing = fullTag.trimEnd().endsWith("/>");
            if (!isSelfClosing) {
              depth++;
            }
          }
          searchPos = openTagPattern.lastIndex;
        } else {
          depth--;
          if (depth === 0) {
            closingIndex = nextClose.index;
          }
          searchPos = closeTagPattern.lastIndex;
        }
      }
      if (closingIndex !== -1) {
        const contentStart = openTag.length;
        const content = src.substring(contentStart, closingIndex);
        const raw = src.substring(0, closingIndex + closingTag.length);
        const tokens = content.trim() ? this.lexer.blockTokens(content.trim(), []) : [];
        return {
          type: "mdx",
          raw,
          tagName,
          attributes: attributes2,
          selfClosing: false,
          tokens,
          text: content
        };
      }
    }
    return void 0;
  }
};
const parseExtensions = (...extensions) => {
  const options = {
    gfm: true,
    extensions: {
      block: [],
      inline: [],
      childTokens: {},
      renderers: {},
      startBlock: [],
      startInline: []
    }
  };
  extensions.forEach(({ level, name, tokenizer, ...rest }) => {
    if ("start" in rest && rest.start) {
      if (level === "block") {
        options.extensions.startBlock.push(rest.start);
      } else {
        options.extensions.startInline.push(rest.start);
      }
    }
    if (tokenizer) {
      if (level === "block") {
        options.extensions.block.push(tokenizer);
      } else {
        options.extensions.inline.push(tokenizer);
      }
    }
  });
  return options;
};
const lex = (markdown, extensions = []) => {
  return new Lexer(parseExtensions(markedHr, markedTable, ...markedFootnote(), markedAlert, ...markedMath, markedSub, markedSup, markedList, markedBr, markedDl, markedAlign, markedCitations, markedMdx, ...extensions)).lex(markdown).filter((token) => token.type !== "space" && token.type !== "footnote");
};
const parseBlocks = (markdown, extensions = []) => {
  const blockLexer = new Lexer(parseExtensions(markedHr, ...markedFootnote(), markedDl, markedTable, markedAlign, markedMdx, ...extensions.filter(({ level, applyInBlockParsing }) => level === "block" && applyInBlockParsing)));
  return blockLexer.blockTokens(markdown, []).reduce((acc, block) => {
    if (block.type === "space" || block.type === "footnote") {
      return acc;
    } else {
      acc.push(block.raw);
    }
    return acc;
  }, []);
};
function AnimatedText($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { text } = $$props;
    const streamdown = useStreamdown();
    const tokenizeNewContent = (text2) => {
      if (!text2) return [];
      let splitRegex;
      if (streamdown.animation.tokenize === "word") {
        splitRegex = /(\s+)/;
      } else {
        splitRegex = /(.)/;
      }
      return text2.split(splitRegex).filter((token) => token.length > 0);
    };
    const tokens = tokenizeNewContent(text);
    if (streamdown.isMounted) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<!--[-->`);
      const each_array = ensure_array_like(tokens);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let token = each_array[$$index];
        $$renderer2.push(`<span${attr_style(streamdown.animationTextStyle)}>${escape_html(token)}</span>`);
      }
      $$renderer2.push(`<!--]-->`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`${escape_html(text)}`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function Block($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { block, static: isStatic = false } = $$props;
    const streamdown = useStreamdown();
    const tokens = lex(isStatic ? block : parseIncompleteMarkdown(block.trim()), streamdown.extensions);
    const insidePopover = getContext("POPOVER");
    function renderChildren($$renderer3, tokens2) {
      $$renderer3.push(`<!--[-->`);
      const each_array = ensure_array_like(tokens2);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let token = each_array[$$index];
        if (token) {
          $$renderer3.push("<!--[-->");
          const children = token?.tokens || [];
          const isTextOnlyNode = children.length === 0;
          Element$1($$renderer3, {
            token,
            children: ($$renderer4) => {
              if (isTextOnlyNode) {
                $$renderer4.push("<!--[-->");
                if (streamdown.animation.enabled && !insidePopover && !isStatic) {
                  $$renderer4.push("<!--[-->");
                  AnimatedText($$renderer4, { text: "text" in token ? token.text || "" : "" });
                } else {
                  $$renderer4.push("<!--[!-->");
                  $$renderer4.push(`${escape_html("text" in token ? token.text : "")}`);
                }
                $$renderer4.push(`<!--]-->`);
              } else {
                $$renderer4.push("<!--[!-->");
                renderChildren($$renderer4, children);
              }
              $$renderer4.push(`<!--]-->`);
            }
          });
        } else {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]-->`);
      }
      $$renderer3.push(`<!--]-->`);
    }
    renderChildren($$renderer2, tokens);
  });
}
const cn = (...inputs) => twMerge(clsx(inputs));
const theme = {
  link: {
    base: "text-blue-600 font-medium underline wrap-anywhere hover:text-blue-600/80",
    blocked: "text-gray-500"
  },
  h1: {
    base: "mt-6 mb-2 text-3xl font-semibold"
  },
  h2: {
    base: "mt-6 mb-2 text-2xl font-semibold"
  },
  h3: {
    base: "mt-6 mb-2 text-xl font-semibold"
  },
  h4: {
    base: "mt-6 mb-2 text-lg font-semibold"
  },
  h5: {
    base: "mt-6 mb-2 text-base font-semibold"
  },
  h6: {
    base: "mt-6 mb-2 text-sm font-semibold"
  },
  paragraph: {
    base: ""
  },
  ul: {
    base: "ml-4 list-inside list-disc whitespace-normal"
  },
  ol: {
    base: "ml-4 list-inside whitespace-normal"
  },
  li: {
    base: "py-1 marker:hidden",
    checkbox: " mr-2"
  },
  code: {
    base: "my-4 w-full overflow-hidden rounded-xl border border-gray-200 flex flex-col",
    container: " relative overflow-visible bg-gray-100 p-2 font-mono text-sm ",
    header: "flex items-center justify-between bg-gray-100/80 p-2	 text-gray-600 text-xs",
    buttons: "flex items-center gap-2",
    language: "ml-1 font-mono lowercase",
    skeleton: "block rounded-md font-mono text-transparent bg-gray-200 scale-y-90 animate-pulse whitespace-nowrap",
    pre: "overflow-x-auto font-mono p-0 bg-gray-100/40",
    line: "block"
  },
  codespan: {
    base: "bg-gray-100 rounded px-1.5 py-0.5 font-mono text-[0.9em]"
  },
  image: {
    base: "group relative my-4  mx-auto w-fit block",
    image: "max-w-full rounded-lg"
  },
  blockquote: {
    base: "border-gray-600/30 text-gray-600 my-4 border-l-4 pl-4 italic"
  },
  alert: {
    base: " relative my-4 border-l-4 p-4",
    title: "text-sm font-semibold flex items-center gap-2 mb-2 capitalize",
    icon: "size-5",
    note: "[&>[data-alert-title]]:text-blue-600 border-blue-600 stroke-blue-600",
    tip: "[&>[data-alert-title]]:text-green-600 border-green-600 stroke-green-600",
    warning: "[&>[data-alert-title]]:text-yellow-600 border-yellow-600 stroke-yellow-600",
    caution: "[&>[data-alert-title]]:text-red-600 border-red-600 stroke-red-600",
    important: "[&>[data-alert-title]]:text-purple-600 border-purple-600 stroke-purple-600"
  },
  table: {
    base: "overflow-x-auto max-w-full my-4 border border-gray-200 rounded-lg",
    table: "w-full border-collapse min-w-full"
  },
  thead: {
    base: "bg-gray-200/80"
  },
  tbody: {
    base: ""
  },
  tfoot: {
    base: "bg-gray-100/50 border-t border-gray-300"
  },
  tr: {
    base: "border-gray-200 border-b hover:bg-gray-100/50 transition-colors"
  },
  td: {
    base: "px-4 py-3 text-sm min-w-[200px] max-w-[400px] break-words"
  },
  th: {
    base: "px-4 py-3 text-sm text-foreground min-w-[200px] max-w-[400px] break-words"
  },
  sup: {
    base: "text-sm"
  },
  sub: {
    base: "text-sm"
  },
  hr: {
    base: "border-gray-200 my-6"
  },
  strong: {
    base: "font-semibold"
  },
  mermaid: {
    base: "group relative my-4 h-auto rounded-xl border border-gray-200 bg-white overflow-hidden items-center min-h-[500px]",
    icon: "size-5",
    buttons: "absolute right-1 top-1 flex h-fit w-fit items-center gap-1"
  },
  math: {
    block: "",
    inline: ""
  },
  br: {
    base: ""
  },
  em: {
    base: "italic"
  },
  del: {
    base: "text-gray-600"
  },
  footnoteRef: {
    base: "text-gray-600 px-1 py-0.5 rounded-md bg-gray-100/80"
  },
  descriptionList: {
    base: "my-4 space-y-2"
  },
  descriptionTerm: {
    base: "font-semibold text-gray-900 border-l-2 border-gray-200 pl-4"
  },
  descriptionDetail: {
    base: "text-gray-700 ml-4 leading-relaxed"
  },
  inlineCitation: {
    preview: "text-sm text-muted-foreground bg-muted rounded-md px-2 py-0.5 cursor-pointer inline-flex border border-border hover:bg-muted/50 outline-none focus:ring-1 focus:ring-primary",
    carousel: {
      header: "flex items-center justify-between",
      stepCounter: "h-fit text-xs font-semibold text-muted-foreground tabular-nums",
      buttons: "flex w-fit items-center justify-end gap-2",
      title: "mb-2 line-clamp-2 font-semibold",
      url: "flex items-center gap-2 text-sm text-muted-foreground",
      favicon: "h-4 w-4 rounded"
    },
    list: {
      base: "grid gap-2",
      item: "grid gap-1 hover:bg-muted rounded-md p-2",
      title: "line-clamp-1 font-semibold text-sm",
      url: "flex items-center gap-2 text-xs text-muted-foreground",
      favicon: "h-3 w-3 rounded"
    }
  },
  components: {
    button: "disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer p-1 text-gray-600 transition-all hover:text-gray-900 rounded hover:bg-gray-100 w-6 h-6",
    popover: "min-w-[250px] max-w-md  fixed z-[1000] max-h-md overflow-y-auto rounded-lg bg-white p-4 shadow"
  }
};
const shadcnTheme = {
  link: {
    base: "text-primary wrap-anywhere  font-medium underline hover:text-primary/80",
    blocked: "text-muted-foreground"
  },
  h1: {
    base: "mt-6 mb-2 text-3xl font-semibold text-foreground"
  },
  h2: {
    base: "mt-6 mb-2 text-2xl font-semibold text-foreground"
  },
  h3: {
    base: "mt-6 mb-2 text-xl font-semibold text-foreground"
  },
  h4: {
    base: "mt-6 mb-2 text-lg font-semibold text-foreground"
  },
  h5: {
    base: "mt-6 mb-2 text-base font-semibold text-foreground"
  },
  h6: {
    base: "mt-6 mb-2 text-sm font-semibold text-foreground"
  },
  paragraph: {
    base: "text-foreground"
  },
  ul: {
    base: "ml-4 list-inside list-disc whitespace-normal text-foreground"
  },
  ol: {
    base: "ml-4 list-inside whitespace-normal text-foreground"
  },
  li: {
    base: "py-1",
    checkbox: " mr-2"
  },
  code: {
    base: "my-4 w-full overflow-hidden rounded-lg border border-border flex flex-col",
    container: "relative overflow-visible bg-muted p-2 font-mono text-sm",
    header: "flex items-center justify-between bg-muted/80 px-2 py-1 text-muted-foreground text-xs",
    buttons: "flex items-center gap-2",
    language: "ml-1 font-mono lowercase",
    skeleton: "block rounded-md font-mono text-transparent bg-border/80 scale-y-90 w-fit animate-pulse whitespace-nowrap",
    pre: "overflow-x-auto font-mono p-0 bg-muted/40",
    line: "block "
  },
  codespan: {
    base: "bg-muted rounded px-1.5 py-0.5 font-mono text-foreground text-[0.9em]"
  },
  image: {
    base: "group relative my-4 mx-auto w-fit block",
    image: "max-w-full rounded-lg"
  },
  blockquote: {
    base: "border-muted-foreground/30 text-muted-foreground my-4 border-l-4 pl-4 italic"
  },
  alert: {
    base: "relative my-4 border-l-4 p-4 bg-card",
    title: "text-sm font-semibold flex items-center gap-2 mb-2 capitalize",
    icon: "size-5",
    note: "[&>[data-alert-title]]:text-blue-600 border-blue-600 stroke-blue-600",
    tip: "[&>[data-alert-title]]:text-green-600 border-green-600 stroke-green-600",
    warning: "[&>[data-alert-title]]:text-yellow-600 border-yellow-600 stroke-yellow-600",
    caution: "[&>[data-alert-title]]:text-destructive border-destructive stroke-destructive",
    important: "[&>[data-alert-title]]:text-purple-600 border-purple-600 stroke-purple-600"
  },
  table: {
    base: "overflow-x-auto max-w-full my-4 rounded-lg border border-border",
    table: "w-full border-collapse min-w-full"
  },
  thead: {
    base: "bg-muted/80"
  },
  tbody: {
    base: ""
  },
  tfoot: {
    base: "bg-muted/50 border-t border-border"
  },
  tr: {
    base: "border-border border-b hover:bg-muted/50 transition-colors"
  },
  td: {
    base: "px-4 py-3 text-sm text-foreground min-w-[200px] max-w-[400px] break-words"
  },
  th: {
    base: "px-4 py-3 text-sm text-foreground min-w-[200px] max-w-[400px] break-words"
  },
  sup: {
    base: "text-sm"
  },
  sub: {
    base: "text-sm"
  },
  hr: {
    base: "border-border my-6"
  },
  strong: {
    base: "font-semibold text-foreground"
  },
  mermaid: {
    base: "group relative my-4 h-auto rounded-lg border border-border bg-card overflow-hidden items-center min-h-[500px]",
    icon: "size-5",
    buttons: "absolute right-1 top-1 flex h-fit w-fit items-center gap-1"
  },
  math: {
    block: "text-foreground",
    inline: "text-foreground"
  },
  br: {
    base: ""
  },
  em: {
    base: "italic"
  },
  del: {
    base: "text-muted-foreground"
  },
  footnoteRef: {
    base: "text-muted-foreground text-sm  rounded-full bg-muted cursor-pointer border border-border hover:bg-muted/50 tabular-nums min-w-5 min-h-5 outline-none focus:ring-1 focus:ring-primary"
  },
  descriptionList: {
    base: "my-4 space-y-2"
  },
  descriptionTerm: {
    base: "font-semibold text-foreground border-l-2 border-border pl-4"
  },
  descriptionDetail: {
    base: "text-muted-foreground ml-4 leading-relaxed"
  },
  inlineCitation: {
    preview: "text-sm text-muted-foreground bg-muted rounded-md px-2 py-0.5 cursor-pointer inline-flex border border-border hover:bg-muted/50 outline-none focus:ring-1 focus:ring-primary",
    carousel: {
      header: "flex items-center justify-between",
      stepCounter: "h-fit text-xs font-semibold text-muted-foreground tabular-nums",
      buttons: "flex w-fit items-center justify-end gap-2",
      title: "mb-2 line-clamp-2 font-semibold",
      url: "flex items-center gap-2 text-sm text-muted-foreground",
      favicon: "h-4 w-4 rounded"
    },
    list: {
      base: "grid gap-2",
      item: "grid gap-1 hover:bg-muted rounded-md p-2",
      title: "line-clamp-1 font-semibold text-sm",
      url: "flex items-center gap-2 text-xs text-muted-foreground",
      favicon: "h-3 w-3 rounded"
    }
  },
  components: {
    button: "disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer p-1 text-muted-foreground transition-all hover:text-foreground rounded hover:bg-border flex items-center justify-center w-6 h-6",
    popover: "min-w-[250px] max-w-md fixed z-[1000] max-h-md overflow-y-auto rounded-lg bg-popover border border-border p-2 shadow"
  }
};
const mergeTheme = (customTheme, baseTheme) => {
  const base = baseTheme === "shadcn" ? shadcnTheme : theme;
  if (!customTheme)
    return base;
  const mergedTheme = { ...base };
  for (const key in customTheme) {
    const origGroup = mergedTheme[key];
    const customGroup = customTheme[key];
    if (!origGroup || !customGroup)
      continue;
    const mergedGroup = { ...origGroup };
    for (const subKey of Object.keys(customGroup)) {
      const baseVal = origGroup[subKey];
      const customVal = customGroup[subKey];
      mergedGroup[subKey] = cn(baseVal, customVal);
    }
    mergedTheme[key] = mergedGroup;
  }
  return mergedTheme;
};
function Streamdown($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    props_id($$renderer2);
    let {
      content = "",
      class: className,
      shikiTheme,
      shikiLanguages,
      shikiThemes,
      parseIncompleteMarkdown: parseIncompleteMarkdown2,
      defaultOrigin,
      allowedLinkPrefixes = ["*"],
      allowedImagePrefixes = ["*"],
      theme: theme2,
      mermaidConfig = {},
      katexConfig,
      translations: translations2,
      baseTheme,
      mergeTheme: shouldMergeTheme = true,
      streamdown = void 0,
      renderHtml,
      controls,
      animation,
      element: element2 = void 0,
      icons,
      children,
      extensions,
      sources,
      inlineCitationsMode = "carousel",
      mdxComponents,
      components,
      static: isStatic,
      $$slots,
      $$events,
      ...snippets
    } = $$props;
    const shikiThemedTheme = shikiThemes ? Object.keys(shikiThemes)[0] || "github-light" : "github-light";
    const mermaidThemedTheme = mermaidConfig?.theme ? mermaidConfig.theme : "default";
    streamdown = new StreamdownContext({
      get element() {
        return element2;
      },
      get content() {
        return content;
      },
      get parseIncompleteMarkdown() {
        return parseIncompleteMarkdown2;
      },
      get defaultOrigin() {
        return defaultOrigin;
      },
      get allowedLinkPrefixes() {
        return allowedLinkPrefixes;
      },
      get allowedImagePrefixes() {
        return allowedImagePrefixes;
      },
      get shikiTheme() {
        return shikiTheme || shikiThemedTheme;
      },
      get snippets() {
        return snippets;
      },
      get theme() {
        return shouldMergeTheme ? mergeTheme(theme2, baseTheme) : theme2 || (baseTheme === "shadcn" ? shadcnTheme : theme2);
      },
      get baseTheme() {
        return baseTheme;
      },
      get mermaidConfig() {
        return { theme: mermaidThemedTheme, ...mermaidConfig };
      },
      get katexConfig() {
        return katexConfig;
      },
      get renderHtml() {
        return renderHtml;
      },
      get translations() {
        return translations2;
      },
      get shikiLanguages() {
        return shikiLanguages;
      },
      get shikiThemes() {
        return shikiThemes;
      },
      get sources() {
        return sources;
      },
      get inlineCitationsMode() {
        return inlineCitationsMode;
      },
      get animation() {
        if (!animation?.enabled) return { enabled: false };
        return {
          enabled: true,
          animateOnMount: animation.animateOnMount ?? false,
          type: animation.type || "blur",
          duration: animation.duration || 500,
          timingFunction: animation.timingFunction || "ease-in",
          tokenize: animation.tokenize || "word"
        };
      },
      get controls() {
        const codeControls = controls?.code ?? true;
        const mermaidControls = controls?.mermaid ?? true;
        const tableControls = controls?.table ?? true;
        return {
          code: codeControls,
          mermaid: mermaidControls,
          table: tableControls
        };
      },
      get children() {
        return children;
      },
      get extensions() {
        return extensions;
      },
      get icons() {
        return icons;
      },
      get mdxComponents() {
        return mdxComponents;
      },
      get components() {
        return components;
      }
    });
    const blocks = isStatic ? content : parseBlocks(content, streamdown.extensions);
    $$renderer2.push(`<div${attr_class(clsx$1(className))}>`);
    if (isStatic) {
      $$renderer2.push("<!--[-->");
      Block($$renderer2, { static: isStatic, block: content });
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<!--[-->`);
      const each_array = ensure_array_like(blocks);
      for (let index = 0, $$length = each_array.length; index < $$length; index++) {
        let block = each_array[index];
        Block($$renderer2, { static: isStatic, block });
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--></div>`);
    bind_props($$props, { streamdown, element: element2 });
  });
}
const bundledLanguagesInfo = [
  // Web essentials
  {
    id: "javascript",
    aliases: ["js"],
    import: () => import("@shikijs/langs/javascript")
  },
  {
    id: "typescript",
    aliases: ["ts"],
    import: () => import("@shikijs/langs/typescript")
  },
  {
    id: "html",
    import: () => import("@shikijs/langs/html")
  },
  {
    id: "css",
    import: () => import("@shikijs/langs/css")
  },
  {
    id: "json",
    import: () => import("@shikijs/langs/json")
  },
  {
    id: "jsx",
    import: () => import("@shikijs/langs/jsx")
  },
  {
    id: "tsx",
    import: () => import("@shikijs/langs/tsx")
  },
  {
    id: "markdown",
    aliases: ["md"],
    import: () => import("@shikijs/langs/markdown")
  },
  {
    id: "yaml",
    aliases: ["yml"],
    import: () => import("@shikijs/langs/yaml")
  },
  {
    id: "xml",
    import: () => import("@shikijs/langs/xml")
  },
  // Backend languages
  {
    id: "python",
    aliases: ["py"],
    import: () => import("@shikijs/langs/python")
  },
  {
    id: "java",
    import: () => import("@shikijs/langs/java")
  },
  {
    id: "go",
    import: () => import("@shikijs/langs/go")
  },
  {
    id: "rust",
    aliases: ["rs"],
    import: () => import("@shikijs/langs/rust")
  },
  {
    id: "ruby",
    aliases: ["rb"],
    import: () => import("@shikijs/langs/ruby")
  },
  {
    id: "php",
    import: () => import("@shikijs/langs/php")
  },
  {
    id: "c",
    import: () => import("@shikijs/langs/c")
  },
  {
    id: "cpp",
    aliases: ["c++"],
    import: () => import("@shikijs/langs/cpp")
  },
  {
    id: "csharp",
    aliases: ["c#", "cs"],
    import: () => import("@shikijs/langs/csharp")
  },
  {
    id: "sql",
    import: () => import("@shikijs/langs/sql")
  },
  {
    id: "swift",
    import: () => import("@shikijs/langs/swift")
  },
  {
    id: "kotlin",
    aliases: ["kt", "kts"],
    import: () => import("@shikijs/langs/kotlin")
  },
  // Config/Shell
  {
    id: "shellscript",
    aliases: ["bash", "sh", "shell", "zsh"],
    import: () => import("@shikijs/langs/shellscript")
  },
  {
    id: "docker",
    aliases: ["dockerfile"],
    import: () => import("@shikijs/langs/docker")
  },
  {
    id: "toml",
    import: () => import("@shikijs/langs/toml")
  },
  {
    id: "graphql",
    aliases: ["gql"],
    import: () => import("@shikijs/langs/graphql")
  },
  {
    id: "svelte",
    import: () => import("@shikijs/langs/svelte")
  },
  {
    id: "vue",
    import: () => import("@shikijs/langs/vue")
  }
];
function createLanguageSet(languages) {
  const set = /* @__PURE__ */ new Set();
  languages.forEach((lang) => {
    set.add(lang.id);
    if (lang.aliases) {
      lang.aliases.forEach((alias) => set.add(alias));
    }
  });
  return set;
}
const supportedLanguages = createLanguageSet(bundledLanguagesInfo);
const DEFAULT_THEMES = { "github-dark": githubDark, "github-light": githubLight };
class HighlighterManager {
  loadedLanguages = new SvelteMap();
  highlighter = null;
  customLanguages;
  languageLoaders;
  additionalThemes;
  constructor(languages, additionalThemes, additionalLanguages) {
    this.additionalThemes = additionalThemes || {};
    const allLanguages = additionalLanguages ? [...languages, ...additionalLanguages] : languages;
    this.languageLoaders = /* @__PURE__ */ new Map();
    allLanguages.forEach((l) => {
      this.languageLoaders.set(l.id, l.import);
      if (l.aliases) {
        l.aliases.forEach((alias) => this.languageLoaders.set(alias, l.import));
      }
    });
    if (additionalLanguages) {
      const additionalSet = createLanguageSet(additionalLanguages);
      this.customLanguages = /* @__PURE__ */ new Set([...supportedLanguages, ...additionalSet]);
    } else {
      this.customLanguages = supportedLanguages;
    }
    if (typeof window !== "undefined") {
      Object.assign(window, { STREAMDOWN_HIGHLIGHTER: this });
    }
  }
  async loadHighlighter() {
    if (this.highlighter instanceof Promise) {
      return this.highlighter;
    } else if (!this.highlighter) {
      this.highlighter = new Promise(async (resolve, reject) => {
        try {
          const engine = createJavaScriptRegexEngine({ forgiving: true });
          const allThemes = [
            ...Object.values(DEFAULT_THEMES),
            ...Object.values(this.additionalThemes)
          ];
          const highlighter = await createHighlighterCore({ themes: allThemes, langs: [], engine });
          this.highlighter = highlighter;
          resolve(highlighter);
        } catch (error) {
          reject(error);
        }
      });
      return this.highlighter;
    } else {
      return this.highlighter;
    }
  }
  isThemeAvailable(theme2) {
    return theme2 in DEFAULT_THEMES || theme2 in this.additionalThemes;
  }
  async loadLanguage(language, highlighter) {
    if (!this.isLanguageSupported(language)) {
      return;
    }
    const languageLoader = this.loadedLanguages.get(language);
    if (languageLoader instanceof Promise) {
      await languageLoader;
    } else if (!languageLoader) {
      const loader = this.languageLoaders.get(language);
      if (!loader) {
        this.loadedLanguages.set(language, false);
        return;
      }
      const languageLoaderPromise = loader().then((langModule) => {
        const langObj = langModule.default || langModule;
        return highlighter.loadLanguage(langObj);
      }).then(() => {
        this.loadedLanguages.set(language, true);
      }).catch((err) => {
        this.loadedLanguages.set(language, false);
        throw err;
      });
      this.loadedLanguages.set(language, languageLoaderPromise);
      await languageLoaderPromise;
    }
  }
  isLanguageSupported = (language) => {
    return this.customLanguages.has(language);
  };
  isReady(theme2, language) {
    if (!this.isThemeAvailable(theme2)) {
      return false;
    }
    if (!language || !this.isLanguageSupported(language)) {
      return !!this.highlighter && !(this.highlighter instanceof Promise);
    }
    return !!this.highlighter && !(this.highlighter instanceof Promise) && this.loadedLanguages.get(language) === true;
  }
  /**
   * Ensures the highlighter is ready for the given theme and language.
   */
  async load(theme2, language) {
    if (!language || !this.isLanguageSupported(language)) {
      if (this.highlighter !== null && !(this.highlighter instanceof Promise)) {
        return;
      }
      await this.loadHighlighter();
      return;
    }
    const languageLoader = this.loadedLanguages.get(language);
    if (this.highlighter !== null && !(this.highlighter instanceof Promise) && languageLoader === true) {
      return;
    }
    const highlighter = await this.loadHighlighter();
    await this.loadLanguage(language, highlighter);
  }
  /**
   * Highlights code synchronously. Must call isReady() first.
   * Returns plaintext tokens for unsupported languages.
   */
  highlightCode(code, language, theme2) {
    try {
      const highlighter = this.highlighter;
      if (!highlighter || highlighter instanceof Promise) {
        return code.split("\n").map((line) => [{ content: line, color: void 0, bgColor: void 0 }]);
      }
      if (!language || !this.isLanguageSupported(language)) {
        return code.split("\n").map((line) => [{ content: line, color: void 0, bgColor: void 0 }]);
      }
      const tokens = highlighter.codeToTokensBase(code, { lang: language, theme: theme2 });
      return tokens;
    } catch (error) {
      return code.split("\n").map((line) => [{ content: line, color: void 0, bgColor: void 0 }]);
    }
  }
  static create(languages = bundledLanguagesInfo, additionalThemes, additionalLanguages) {
    if (typeof window !== "undefined" && "STREAMDOWN_HIGHLIGHTER" in window) {
      const previousHighlighter = window.STREAMDOWN_HIGHLIGHTER;
      if (additionalThemes) {
        Object.assign(previousHighlighter.additionalThemes, additionalThemes);
      }
      if (additionalLanguages) {
        additionalLanguages.forEach((lang) => {
          previousHighlighter.languageLoaders.set(lang.id, lang.import);
          if (lang.aliases) {
            lang.aliases.forEach((alias) => previousHighlighter.languageLoaders.set(alias, lang.import));
          }
        });
        const additionalSet = createLanguageSet(additionalLanguages);
        additionalSet.forEach((lang) => previousHighlighter.customLanguages.add(lang));
      }
      return previousHighlighter;
    }
    return new HighlighterManager(languages, additionalThemes, additionalLanguages);
  }
}
function Code($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const { token, id } = $$props;
    const streamdown = useStreamdown();
    const highlighter = HighlighterManager.create(bundledLanguagesInfo, streamdown.shikiThemes, streamdown.shikiLanguages);
    const copy = useCopy({
      get content() {
        return token.text;
      }
    });
    function Tokens($$renderer3, lines) {
      $$renderer3.push(`<!--[-->`);
      const each_array = ensure_array_like(lines);
      for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
        let tokens = each_array[$$index_1];
        $$renderer3.push(`<span${attr_class(clsx$1(streamdown.theme.code.line))}><!--[-->`);
        const each_array_1 = ensure_array_like(tokens);
        for (let $$index = 0, $$length2 = each_array_1.length; $$index < $$length2; $$index++) {
          let token2 = each_array_1[$$index];
          $$renderer3.push(`<span${attr_style(streamdown.isMounted ? streamdown.animationTextStyle : "", { color: token2.color, "background-color": token2.bgColor })}>${escape_html(token2.content)}</span>`);
        }
        $$renderer3.push(`<!--]--></span>`);
      }
      $$renderer3.push(`<!--]-->`);
    }
    function Skeleton($$renderer3, lines) {
      $$renderer3.push(`<!--[-->`);
      const each_array_2 = ensure_array_like(lines);
      for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
        let line = each_array_2[$$index_2];
        $$renderer3.push(`<span${attr_class(clsx$1(streamdown.theme.code.skeleton))}>${escape_html(line.trim().length > 0 ? line : "​")}</span>`);
      }
      $$renderer3.push(`<!--]-->`);
    }
    $$renderer2.push(`<div${attr("data-streamdown-code", id)}${attr_style(streamdown.isMounted ? streamdown.animationBlockStyle : "")}${attr_class(clsx$1(streamdown.theme.code.base))}><div${attr_class(clsx$1(streamdown.theme.code.header))}><span${attr_class(clsx$1(streamdown.theme.code.language))}>${escape_html(token.lang)}</span> `);
    if (streamdown.controls.code) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div${attr_class(clsx$1(streamdown.theme.code.buttons))}><button${attr_class(clsx$1(streamdown.theme.components.button))} title="Download code" type="button">`);
      (streamdown.icons?.download || downloadIcon)($$renderer2);
      $$renderer2.push(`<!----></button> <button${attr_class(clsx$1(streamdown.theme.components.button))} type="button">`);
      if (copy.isCopied) {
        $$renderer2.push("<!--[-->");
        (streamdown.icons?.check || checkIcon)($$renderer2);
        $$renderer2.push(`<!---->`);
      } else {
        $$renderer2.push("<!--[!-->");
        (streamdown.icons?.copy || copyIcon)($$renderer2);
        $$renderer2.push(`<!---->`);
      }
      $$renderer2.push(`<!--]--></button></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div> <div style="height: fit-content; width: 100%;"${attr_class(clsx$1(streamdown.theme.code.container))}>`);
    if (highlighter.isReady(streamdown.shikiTheme, token.lang)) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<pre${attr_class(clsx$1(streamdown.theme.code.pre))}><code>`);
      Tokens($$renderer2, highlighter.highlightCode(token.text, token.lang, streamdown.shikiTheme));
      $$renderer2.push(`<!----></code></pre>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<pre${attr_class(clsx$1(streamdown.theme.code.pre))}><code>`);
      Skeleton($$renderer2, token.text.split("\n"));
      $$renderer2.push(`<!----></code></pre>`);
    }
    $$renderer2.push(`<!--]--></div></div>`);
  });
}
function Response$1($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { class: className, $$slots, $$events, ...restProps } = $$props;
    let currentTheme = derivedMode.current === "dark" ? "github-dark-default" : "github-light-default";
    Streamdown($$renderer2, spread_props([
      {
        class: cn$1("size-full [&>*:first-child]:mt-0 [&>*:last-child]:mb-0", className),
        shikiTheme: currentTheme,
        baseTheme: "shadcn",
        components: { code: Code },
        shikiThemes: {
          "github-light-default": githubLightDefault,
          "github-dark-default": githubDarkDefault
        },
        animation: restProps.parseIncompleteMarkdown ? {
          enabled: true,
          type: "fade",
          duration: 80,
          tokenize: "word",
          animateOnMount: false
        } : { enabled: false }
      },
      restProps
    ]));
  });
}
const defaultWindow = void 0;
function getActiveElement(document2) {
  let activeElement = document2.activeElement;
  while (activeElement?.shadowRoot) {
    const node = activeElement.shadowRoot.activeElement;
    if (node === activeElement)
      break;
    else
      activeElement = node;
  }
  return activeElement;
}
class ActiveElement3 {
  #document;
  #subscribe;
  constructor(options = {}) {
    const { window: window2 = defaultWindow, document: document2 = window2?.document } = options;
    if (window2 === void 0) return;
    this.#document = document2;
    this.#subscribe = createSubscriber();
  }
  get current() {
    this.#subscribe?.();
    if (!this.#document) return null;
    return getActiveElement(this.#document);
  }
}
new ActiveElement3();
function runWatcher(sources, flush, effect, options = {}) {
  const { lazy = false } = options;
}
function watch(sources, effect, options) {
  runWatcher(sources, "post", effect, options);
}
function watchPre(sources, effect, options) {
  runWatcher(sources, "pre", effect, options);
}
watch.pre = watchPre;
function Collapsible($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { ref = null, open = false, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Collapsible$1?.($$renderer3, spread_props([
        { "data-slot": "collapsible" },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          },
          get open() {
            return open;
          },
          set open($$value) {
            open = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref, open });
  });
}
function Collapsible_trigger($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { ref = null, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Collapsible_trigger$1?.($$renderer3, spread_props([
        { "data-slot": "collapsible-trigger" },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
function Collapsible_content($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { ref = null, $$slots, $$events, ...restProps } = $$props;
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      $$renderer3.push("<!---->");
      Collapsible_content$1?.($$renderer3, spread_props([
        { "data-slot": "collapsible-content" },
        restProps,
        {
          get ref() {
            return ref;
          },
          set ref($$value) {
            ref = $$value;
            $$settled = false;
          }
        }
      ]));
      $$renderer3.push(`<!---->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { ref });
  });
}
const REASONING_CONTEXT_KEY = /* @__PURE__ */ Symbol("reasoning-context");
class ReasoningContext {
  #isStreaming = false;
  #isOpen = true;
  #duration = 0;
  constructor(options = {}) {
    this.#isStreaming = options.isStreaming ?? false;
    this.#isOpen = options.isOpen ?? true;
    this.#duration = options.duration ?? 0;
  }
  get isStreaming() {
    return this.#isStreaming;
  }
  set isStreaming(value) {
    this.#isStreaming = value;
  }
  get isOpen() {
    return this.#isOpen;
  }
  set isOpen(value) {
    this.#isOpen = value;
  }
  get duration() {
    return this.#duration;
  }
  set duration(value) {
    this.#duration = value;
  }
  setIsOpen(open) {
    this.#isOpen = open;
  }
}
function setReasoningContext(context) {
  setContext(REASONING_CONTEXT_KEY, context);
}
function getReasoningContext() {
  let context = getContext(REASONING_CONTEXT_KEY);
  if (!context) {
    throw new Error("Reasoning components must be used within Reasoning");
  }
  return context;
}
function Reasoning($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      class: className = "",
      isStreaming: isStreaming2 = false,
      open = void 0,
      defaultOpen = true,
      onOpenChange,
      duration = void 0,
      children,
      $$slots,
      $$events,
      ...props
    } = $$props;
    let AUTO_CLOSE_DELAY = 1e3;
    let MS_IN_S = 1e3;
    let reasoningContext = new ReasoningContext({
      isStreaming: isStreaming2,
      isOpen: open ?? defaultOpen,
      duration: duration ?? 0
    });
    let isOpen = open ?? defaultOpen;
    let hasAutoClosed = false;
    let startTime = null;
    watch(() => isStreaming2, (isStreamingValue) => {
      if (isStreamingValue) {
        if (startTime === null) {
          startTime = Date.now();
        }
      } else if (startTime !== null) {
        let newDuration = Math.ceil((Date.now() - startTime) / MS_IN_S);
        reasoningContext.duration = newDuration;
        if (duration !== void 0) {
          duration = newDuration;
        }
        startTime = null;
      }
    });
    watch(() => [isStreaming2, isOpen, defaultOpen, hasAutoClosed], ([
      isStreamingValue,
      isOpenValue,
      defaultOpenValue,
      hasAutoClosedValue
    ]) => {
      if (defaultOpenValue && !isStreamingValue && isOpenValue && !hasAutoClosedValue) {
        let timer = setTimeout(
          () => {
            handleOpenChange(false);
            hasAutoClosed = true;
          },
          AUTO_CLOSE_DELAY
        );
        return () => clearTimeout(timer);
      }
    });
    let handleOpenChange = (newOpen) => {
      isOpen = newOpen;
      reasoningContext.setIsOpen(newOpen);
      if (open !== void 0) {
        open = newOpen;
      }
      onOpenChange?.(newOpen);
    };
    setReasoningContext(reasoningContext);
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      Collapsible($$renderer3, spread_props([
        {
          class: cn$1("not-prose mb-4", className),
          onOpenChange: handleOpenChange
        },
        props,
        {
          get open() {
            return isOpen;
          },
          set open($$value) {
            isOpen = $$value;
            $$settled = false;
          },
          children: ($$renderer4) => {
            children?.($$renderer4);
            $$renderer4.push(`<!---->`);
          },
          $$slots: { default: true }
        }
      ]));
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
    bind_props($$props, { open, duration });
  });
}
function Brain($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { $$slots, $$events, ...props } = $$props;
    const iconNode = [
      ["path", { "d": "M12 18V5" }],
      [
        "path",
        { "d": "M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4" }
      ],
      [
        "path",
        { "d": "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5" }
      ],
      ["path", { "d": "M17.997 5.125a4 4 0 0 1 2.526 5.77" }],
      ["path", { "d": "M18 18a4 4 0 0 0 2-7.464" }],
      [
        "path",
        { "d": "M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517" }
      ],
      ["path", { "d": "M6 18a4 4 0 0 1-2-7.464" }],
      ["path", { "d": "M6.003 5.125a4 4 0 0 0-2.526 5.77" }]
    ];
    Icon($$renderer2, spread_props([
      { name: "brain" },
      /**
       * @component @name Brain
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMThWNSIgLz4KICA8cGF0aCBkPSJNMTUgMTNhNC4xNyA0LjE3IDAgMCAxLTMtNCA0LjE3IDQuMTcgMCAwIDEtMyA0IiAvPgogIDxwYXRoIGQ9Ik0xNy41OTggNi41QTMgMyAwIDEgMCAxMiA1YTMgMyAwIDEgMC01LjU5OCAxLjUiIC8+CiAgPHBhdGggZD0iTTE3Ljk5NyA1LjEyNWE0IDQgMCAwIDEgMi41MjYgNS43NyIgLz4KICA8cGF0aCBkPSJNMTggMThhNCA0IDAgMCAwIDItNy40NjQiIC8+CiAgPHBhdGggZD0iTTE5Ljk2NyAxNy40ODNBNCA0IDAgMSAxIDEyIDE4YTQgNCAwIDEgMS03Ljk2Ny0uNTE3IiAvPgogIDxwYXRoIGQ9Ik02IDE4YTQgNCAwIDAgMS0yLTcuNDY0IiAvPgogIDxwYXRoIGQ9Ik02LjAwMyA1LjEyNWE0IDQgMCAwIDAtMi41MjYgNS43NyIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/brain
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      props,
      {
        iconNode,
        children: ($$renderer3) => {
          props.children?.($$renderer3);
          $$renderer3.push(`<!---->`);
        },
        $$slots: { default: true }
      }
    ]));
  });
}
function Chevron_down($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { $$slots, $$events, ...props } = $$props;
    const iconNode = [["path", { "d": "m6 9 6 6 6-6" }]];
    Icon($$renderer2, spread_props([
      { name: "chevron-down" },
      /**
       * @component @name ChevronDown
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtNiA5IDYgNiA2LTYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/chevron-down
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      props,
      {
        iconNode,
        children: ($$renderer3) => {
          props.children?.($$renderer3);
          $$renderer3.push(`<!---->`);
        },
        $$slots: { default: true }
      }
    ]));
  });
}
function ReasoningTrigger($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { class: className = "", children, $$slots, $$events, ...props } = $$props;
    let reasoningContext = getReasoningContext();
    let getThinkingMessage = (() => {
      let { isStreaming: isStreaming2, duration } = reasoningContext;
      if (isStreaming2 || duration === 0) {
        return "Thinking...";
      }
      if (duration === void 0) {
        return "Thought for a few seconds";
      }
      return `Thought for ${duration} seconds`;
    })();
    Collapsible_trigger($$renderer2, spread_props([
      {
        class: cn$1("text-muted-foreground hover:text-foreground flex w-full items-center gap-2 text-sm transition-colors", className)
      },
      props,
      {
        children: ($$renderer3) => {
          if (children) {
            $$renderer3.push("<!--[-->");
            children($$renderer3);
            $$renderer3.push(`<!---->`);
          } else {
            $$renderer3.push("<!--[!-->");
            Brain($$renderer3, { class: "size-4" });
            $$renderer3.push(`<!----> <p>${escape_html(getThinkingMessage)}</p> `);
            Chevron_down($$renderer3, {
              class: cn$1("size-4 transition-transform", reasoningContext.isOpen ? "rotate-180" : "rotate-0")
            });
            $$renderer3.push(`<!---->`);
          }
          $$renderer3.push(`<!--]-->`);
        },
        $$slots: { default: true }
      }
    ]));
  });
}
function Response($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { class: className = "", children, $$slots, $$events, ...props } = $$props;
    $$renderer2.push(`<div${attributes({
      class: clsx$1(cn$1("max-w-none", className)),
      style: "color: #a0a0a0;",
      ...props
    })}>`);
    children?.($$renderer2);
    $$renderer2.push(`<!----></div>`);
  });
}
function ReasoningContent($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { class: className = "", children, $$slots, $$events, ...props } = $$props;
    Collapsible_content($$renderer2, spread_props([
      {
        class: cn$1("mt-4 text-sm", "data-[state=closed]:fade-out-0 data-[state=closed]:slide-out-to-top-2 data-[state=open]:slide-in-from-top-2 text-[#a0a0a0] data-[state=closed]:animate-out data-[state=open]:animate-in outline-none", className)
      },
      props,
      {
        children: ($$renderer3) => {
          Response($$renderer3, {
            class: "grid gap-2",
            children: ($$renderer4) => {
              children?.($$renderer4);
              $$renderer4.push(`<!---->`);
            },
            $$slots: { default: true }
          });
        },
        $$slots: { default: true }
      }
    ]));
  });
}
function Shimmer($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      children,
      as = "p",
      class: className,
      duration = 2,
      spread = 2,
      content_length = 30,
      $$slots,
      $$events,
      ...rest
    } = $$props;
    let dynamicSpread = content_length * spread;
    element$1(
      $$renderer2,
      as,
      () => {
        $$renderer2.push(`${attributes(
          {
            class: clsx$1(cn$1("relative inline-block bg-[length:250%_100%,auto] bg-clip-text text-transparent", "[background-repeat:no-repeat,padding-box] [--bg:linear-gradient(90deg,#0000_calc(50%-var(--spread)),var(--background),#0000_calc(50%+var(--spread)))]", "animate-shimmer", className)),
            style: `--spread: ${stringify(dynamicSpread)}px; --shimmer-duration: ${stringify(duration)}s; background-image: var(--bg), linear-gradient(var(--muted-foreground), var(--muted-foreground)); background-position: 100% center;`,
            ...rest
          },
          "svelte-leaxeg"
        )}`);
      },
      () => {
        children($$renderer2);
        $$renderer2.push(`<!---->`);
      }
    );
  });
}
function AssetReadBlock($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { block, resultBlock } = $$props;
    let status = !resultBlock ? "running" : resultBlock.toolSuccess !== false ? "success" : "error";
    let statusColor = status === "running" ? "text-blue-400" : status === "success" ? "text-emerald-400" : "text-red-400";
    let args = (() => {
      if (!block.toolArguments) return null;
      try {
        return JSON.parse(block.toolArguments);
      } catch {
        return null;
      }
    })();
    let assetName = args?.name ?? "Unknown";
    let assetPath = args?.path ?? "";
    let graphTarget = args?.graph ?? "";
    let componentTarget = args?.component ?? "";
    assetName.startsWith("/") ? assetName : assetPath ? `${assetPath}/${assetName}` : assetName;
    let fullPath = assetPath ? `${assetPath}/${assetName}` : assetName;
    let displayName = () => {
      const n = assetName;
      if (!n) return "";
      const parts = n.replace(/\\/g, "/").split("/");
      return parts[parts.length - 1] || n;
    };
    let resultText = resultBlock?.toolResult ?? "";
    let assetType = (() => {
      if (!resultText) return "";
      const match = resultText.match(/^#\s+(\S+)/m);
      return match ? match[1] : "";
    })();
    const ASSET_TYPE_MAP = {
      BLUEPRINT: {
        label: "Blueprint",
        color: "text-blue-400",
        bg: "bg-blue-500/15"
      },
      ANIM_BLUEPRINT: {
        label: "Anim BP",
        color: "text-violet-400",
        bg: "bg-violet-500/15"
      },
      WIDGET_BLUEPRINT: {
        label: "Widget BP",
        color: "text-teal-400",
        bg: "bg-teal-500/15"
      },
      NIAGARA_SYSTEM: {
        label: "Niagara",
        color: "text-orange-400",
        bg: "bg-orange-500/15"
      },
      MATERIAL: {
        label: "Material",
        color: "text-emerald-400",
        bg: "bg-emerald-500/15"
      },
      MATERIAL_INSTANCE: {
        label: "Mat Instance",
        color: "text-emerald-400",
        bg: "bg-emerald-500/15"
      },
      STATIC_MESH: {
        label: "Static Mesh",
        color: "text-cyan-400",
        bg: "bg-cyan-500/15"
      },
      SKELETON: {
        label: "Skeleton",
        color: "text-amber-400",
        bg: "bg-amber-500/15"
      },
      BEHAVIOR_TREE: { label: "BT", color: "text-rose-400", bg: "bg-rose-500/15" },
      STATE_TREE: {
        label: "State Tree",
        color: "text-pink-400",
        bg: "bg-pink-500/15"
      },
      LEVEL_SEQUENCE: {
        label: "Sequencer",
        color: "text-indigo-400",
        bg: "bg-indigo-500/15"
      },
      CONTROL_RIG: {
        label: "Control Rig",
        color: "text-yellow-400",
        bg: "bg-yellow-500/15"
      },
      SOUND_CUE: { label: "Sound", color: "text-lime-400", bg: "bg-lime-500/15" },
      DATATABLE: {
        label: "DataTable",
        color: "text-sky-400",
        bg: "bg-sky-500/15"
      },
      STRUCT: {
        label: "Struct",
        color: "text-stone-400",
        bg: "bg-stone-500/15"
      },
      ENUM: {
        label: "Enum",
        color: "text-stone-400",
        bg: "bg-stone-500/15"
      },
      BLEND_SPACE: {
        label: "BlendSpace",
        color: "text-fuchsia-400",
        bg: "bg-fuchsia-500/15"
      },
      ANIM_MONTAGE: {
        label: "Montage",
        color: "text-purple-400",
        bg: "bg-purple-500/15"
      },
      GRAPH: { label: "Graph", color: "text-blue-400", bg: "bg-blue-500/15" },
      FILE: {
        label: "File",
        color: "text-neutral-400",
        bg: "bg-neutral-500/15"
      },
      ENVIRONMENT_QUERY: { label: "EQS", color: "text-lime-400", bg: "bg-lime-500/15" },
      PHYSICS_ASSET: {
        label: "PhysAsset",
        color: "text-red-400",
        bg: "bg-red-500/15"
      },
      GAMEPLAY_EFFECT: { label: "GE", color: "text-amber-400", bg: "bg-amber-500/15" }
    };
    let typeInfo = ASSET_TYPE_MAP[assetType] ?? {
      label: assetType || "Asset",
      color: "text-muted-foreground",
      bg: "bg-secondary/50"
    };
    (() => {
      if (!resultText) return [];
      const result = [];
      let current = null;
      for (const line of resultText.split("\n")) {
        const headerMatch = line.match(/^(#{1,3})\s+(.+)/);
        if (headerMatch) {
          if (current) result.push(current);
          current = {
            header: headerMatch[2],
            level: headerMatch[1].length,
            lines: []
          };
        } else {
          if (!current) {
            current = { header: "", level: 0, lines: [] };
          }
          current.lines.push(line);
        }
      }
      if (current) result.push(current);
      return result;
    })();
    const PREVIEW_LINES = 6;
    let resultLines = resultText ? resultText.split("\n") : [];
    let totalLines = resultLines.length;
    let previewText = resultLines.length > PREVIEW_LINES ? resultLines.slice(0, PREVIEW_LINES).join("\n") : resultText;
    let hasMoreLines = resultLines.length > PREVIEW_LINES;
    let remainingLines = Math.max(0, resultLines.length - PREVIEW_LINES);
    let contextBadge = (() => {
      if (graphTarget) return graphTarget;
      if (componentTarget) return componentTarget;
      return "";
    })();
    let hasImages = (resultBlock?.images && resultBlock.images.length > 0) ?? false;
    function imageDataUrl(base64, mimeType) {
      return `data:${mimeType};base64,${base64}`;
    }
    $$renderer2.push(`<div class="my-2.5 w-full overflow-hidden rounded-xl border border-border bg-card/50"><div class="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-[13px]"><span${attr_class(`flex h-4 w-4 shrink-0 items-center justify-center ${stringify(statusColor)}`)}>`);
    Icon$1($$renderer2, {
      icon: status === "running" ? Loading03Icon : Layers01Icon,
      size: 15,
      strokeWidth: 1.5,
      class: status === "running" ? "animate-spin" : ""
    });
    $$renderer2.push(`<!----></span> <button class="flex-1 min-w-0 truncate text-left font-medium text-foreground underline decoration-foreground/20 underline-offset-2 transition-colors hover:text-blue-400 hover:decoration-blue-400/40" title="Open in editor">${escape_html(displayName())}</button> `);
    if (contextBadge) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span class="shrink-0 rounded-md bg-secondary/60 px-1.5 py-0.5 text-[10px] font-mono text-muted-foreground">${escape_html(contextBadge)}</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (assetType) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span${attr_class(`shrink-0 rounded-md px-2 py-0.5 text-[10px] font-medium ${stringify(typeInfo.color)} ${stringify(typeInfo.bg)}`)}>${escape_html(typeInfo.label)}</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (status === "error") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span class="shrink-0 rounded-md bg-red-500/15 px-1.5 py-0.5 text-[10px] font-medium text-red-400">failed</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (status !== "running" && totalLines > 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span class="shrink-0 text-[10px] tabular-nums text-muted-foreground/60">${escape_html(totalLines)}L</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <button class="shrink-0 rounded p-1 text-muted-foreground/60 transition-colors hover:bg-accent/30 hover:text-foreground"${attr("title", "Expand")}>`);
    Icon$1($$renderer2, {
      icon: ArrowDown01Icon,
      size: 12,
      strokeWidth: 1.5
    });
    $$renderer2.push(`<!----></button></div> <div class="flex items-center gap-2 border-t border-border/50 px-3.5 py-1.5"><button class="flex-1 min-w-0 truncate text-left font-mono text-[10px] text-muted-foreground/60 transition-colors hover:text-blue-400"${attr("title", `Open ${stringify(fullPath)}`)}>${escape_html(fullPath)}</button> `);
    if (status !== "running" && resultText) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<button class="shrink-0 rounded p-0.5 text-muted-foreground/50 transition-colors hover:text-foreground" title="Copy result">`);
      {
        $$renderer2.push("<!--[!-->");
        Icon$1($$renderer2, { icon: Copy01Icon, size: 12, strokeWidth: 1.5 });
      }
      $$renderer2.push(`<!--]--></button>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div> `);
    if (hasImages && resultBlock?.images) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex gap-2 overflow-x-auto border-t border-border/50 px-3.5 py-2"><!--[-->`);
      const each_array = ensure_array_like(resultBlock.images);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let img = each_array[$$index];
        $$renderer2.push(`<button class="shrink-0 overflow-hidden rounded-lg border border-border/50"><img${attr("src", imageDataUrl(img.base64, img.mimeType))} alt="Asset preview" class="h-24 w-auto object-contain" style="max-width: 200px;"/></button>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (resultText) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="border-t border-border/50">`);
      {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="relative"><pre class="px-3.5 py-2 font-mono text-[11px] leading-relaxed text-foreground/60">${escape_html(previewText)}</pre> `);
        if (hasMoreLines) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="absolute inset-x-0 bottom-0 flex h-8 items-end justify-center" style="background: linear-gradient(to top, #353535 20%, transparent);"><span class="pb-1 text-[10px] text-muted-foreground/60">${escape_html(remainingLines)} more line${escape_html(remainingLines !== 1 ? "s" : "")}</span></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else if (status === "running") {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div class="border-t border-border/50 px-3.5 py-2.5"><span class="font-mono text-[11px] text-muted-foreground animate-pulse">Reading asset...</span></div>`);
    } else if (status === "error") {
      $$renderer2.push("<!--[2-->");
      $$renderer2.push(`<div class="border-t border-border/50 px-3.5 py-2"><pre class="font-mono text-[11px] leading-relaxed text-red-400/80">${escape_html(resultBlock?.toolResult ?? "Asset not found")}</pre></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function ScreenshotBlock($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { block, resultBlock } = $$props;
    let status = !resultBlock ? "running" : resultBlock.toolSuccess !== false ? "success" : "error";
    let statusColor = status === "running" ? "text-blue-400" : status === "success" ? "text-emerald-400" : "text-red-400";
    let args = (() => {
      if (!block.toolArguments) return null;
      try {
        return JSON.parse(block.toolArguments);
      } catch {
        return null;
      }
    })();
    let captureMode = args?.mode ?? "active";
    let assetPath = args?.asset_path ?? "";
    let viewMode = args?.view_mode ?? "";
    let focusActor = args?.focus_actor ?? "";
    let resultText = resultBlock?.toolResult ?? "";
    let cameraInfo = (() => {
      if (!resultText) return null;
      const locMatch = resultText.match(/Location=\(([^)]+)\)/);
      const rotMatch = resultText.match(/Rotation=\(([^)]+)\)/);
      const fovMatch = resultText.match(/FOV=([\d.]+)/);
      const resMatch = resultText.match(/\((\d+x\d+)\)/);
      if (!locMatch && !rotMatch && !fovMatch && !resMatch) return null;
      return {
        location: locMatch?.[1] ?? "",
        rotation: rotMatch?.[1] ?? "",
        fov: fovMatch?.[1] ?? "",
        resolution: resMatch?.[1] ?? ""
      };
    })();
    let captureDescription = (() => {
      if (!resultText) return "";
      return resultText.split("\n")[0] ?? "";
    })();
    let hasImages = (resultBlock?.images && resultBlock.images.length > 0) ?? false;
    let primaryImage = resultBlock?.images?.[0] ?? null;
    let modeBadge = (() => {
      if (captureMode === "asset") return assetPath ? assetPath.split("/").pop() ?? "Asset" : "Asset";
      if (captureMode === "level") return viewMode || "Level";
      return "Active";
    })();
    let modeBadgeColor = (() => {
      if (captureMode === "asset") return "text-violet-400 bg-violet-500/15";
      if (captureMode === "level") return "text-sky-400 bg-sky-500/15";
      return "text-neutral-400 bg-neutral-500/15";
    })();
    function imageDataUrl(base64, mimeType) {
      return `data:${mimeType};base64,${base64}`;
    }
    $$renderer2.push(`<div class="my-2.5 w-full overflow-hidden rounded-xl border border-border bg-card/50"><div class="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-[13px]"><span${attr_class(`flex h-4 w-4 shrink-0 items-center justify-center ${stringify(statusColor)}`)}>`);
    Icon$1($$renderer2, {
      icon: status === "running" ? Loading03Icon : Image01Icon,
      size: 15,
      strokeWidth: 1.5,
      class: status === "running" ? "animate-spin" : ""
    });
    $$renderer2.push(`<!----></span> <span class="flex-1 min-w-0 truncate font-medium text-foreground">Screenshot</span> <span${attr_class(`shrink-0 rounded-md px-2 py-0.5 text-[10px] font-medium ${stringify(modeBadgeColor)}`)}>${escape_html(modeBadge)}</span> `);
    if (cameraInfo?.resolution) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span class="shrink-0 text-[10px] tabular-nums text-muted-foreground/60">${escape_html(cameraInfo.resolution)}</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (status === "error") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span class="shrink-0 rounded-md bg-red-500/15 px-1.5 py-0.5 text-[10px] font-medium text-red-400">failed</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <button class="shrink-0 rounded p-1 text-muted-foreground/60 transition-colors hover:bg-accent/30 hover:text-foreground"${attr("title", "Collapse")}>`);
    Icon$1($$renderer2, {
      icon: ArrowUp01Icon,
      size: 12,
      strokeWidth: 1.5
    });
    $$renderer2.push(`<!----></button></div> `);
    if (status === "running") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="border-t border-border/50 px-3.5 py-6 flex items-center justify-center"><span class="font-mono text-[11px] text-muted-foreground animate-pulse">Capturing screenshot...</span></div>`);
    } else if (hasImages && primaryImage) {
      $$renderer2.push("<!--[1-->");
      {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="border-t border-border/50"><div class="relative bg-black/30"><img${attr("src", imageDataUrl(primaryImage.base64, primaryImage.mimeType))}${attr("alt", captureDescription || "Screenshot")} class="w-full h-auto object-contain" style="max-height: 500px;"/></div> <div class="flex items-center gap-2 px-3.5 py-2 text-[10px] text-muted-foreground/70"><span class="flex-1 min-w-0 truncate">${escape_html(captureDescription)}</span> `);
        if (focusActor) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="shrink-0 rounded bg-secondary/60 px-1.5 py-0.5 font-mono text-muted-foreground/60">${escape_html(focusActor)}</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <button class="shrink-0 rounded p-0.5 text-muted-foreground/50 transition-colors hover:text-foreground" title="Copy info">`);
        {
          $$renderer2.push("<!--[!-->");
          Icon$1($$renderer2, { icon: Copy01Icon, size: 12, strokeWidth: 1.5 });
        }
        $$renderer2.push(`<!--]--></button></div></div>`);
      }
      $$renderer2.push(`<!--]-->`);
    } else if (status === "error") {
      $$renderer2.push("<!--[2-->");
      $$renderer2.push(`<div class="border-t border-border/50 px-3.5 py-2.5"><pre class="font-mono text-[11px] leading-relaxed text-red-400/80">${escape_html(resultText || "Screenshot failed")}</pre></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="border-t border-border/50 px-3.5 py-2.5"><pre class="font-mono text-[11px] leading-relaxed text-foreground/60">${escape_html(resultText)}</pre></div>`);
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function GenerateAssetBlock($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { block, resultBlock } = $$props;
    let expanded = false;
    let status = !resultBlock ? "running" : resultBlock.toolSuccess !== false ? "success" : "error";
    let args = (() => {
      if (!block.toolArguments) return null;
      try {
        return JSON.parse(block.toolArguments);
      } catch {
        return null;
      }
    })();
    let action = args?.action ?? "";
    let assetType = args?.asset_type ?? args?.job_type ?? "";
    let prompt = args?.prompt ?? "";
    let artStyle = args?.art_style ?? "";
    args?.job_id ?? "";
    let is3D = assetType === "model_3d" || assetType === "text_to_3d" || assetType === "image_to_3d";
    let resultText = resultBlock?.toolResult ?? "";
    let hasImages = (resultBlock?.images && resultBlock.images.length > 0) ?? false;
    let primaryImage = resultBlock?.images?.[0] ?? null;
    let progress = (() => {
      if (!resultText) return null;
      const match = resultText.match(/(\d+)%/);
      return match ? parseInt(match[1]) : null;
    })();
    let jobSucceeded = resultText.includes("SUCCEEDED");
    let jobInProgress = resultText.includes("IN_PROGRESS") || resultText.includes("PENDING");
    let jobStage = (() => {
      if (!resultText) return "";
      const match = resultText.match(/stage:\s*(\S+)/);
      return match ? match[1] : "";
    })();
    (() => {
      if (!resultText) return "";
      const match = resultText.match(/job_type:\s*(\S+)/);
      return match ? match[1] : "";
    })();
    let heading = (() => {
      if (action === "create") {
        return is3D ? "Generate 3D Model" : "Generate Image";
      }
      if (action === "check") {
        if (jobSucceeded) return is3D ? "3D Model Ready" : "Image Ready";
        if (jobInProgress) return is3D ? "3D Model Status" : "Image Status";
        return "Check Status";
      }
      if (action === "import") return "Import Asset";
      return is3D ? "Generate 3D Model" : "Generate Image";
    })();
    let headingIcon = is3D ? ThreeDMoveIcon : Image01Icon;
    let actionBadge = (() => {
      if (action === "create") return { text: "Create", color: "text-blue-400 bg-blue-500/15" };
      if (action === "check" && jobSucceeded) return {
        text: "Complete",
        color: "text-emerald-400 bg-emerald-500/15"
      };
      if (action === "check" && jobInProgress) return {
        text: progress ? `${progress}%` : "In Progress",
        color: "text-amber-400 bg-amber-500/15"
      };
      if (action === "check") return { text: "Check", color: "text-sky-400 bg-sky-500/15" };
      if (action === "import") return { text: "Import", color: "text-violet-400 bg-violet-500/15" };
      return {
        text: action || "Generate",
        color: "text-neutral-400 bg-neutral-500/15"
      };
    })();
    let statusColor = status === "running" ? "text-blue-400" : status === "success" ? "text-emerald-400" : "text-red-400";
    (() => {
      if (!resultText) return "";
      const idx = resultText.indexOf("NEXT STEPS:");
      if (idx === -1) {
        const nextIdx = resultText.indexOf("NEXT:");
        if (nextIdx === -1) return "";
        return resultText.substring(nextIdx).trim();
      }
      return resultText.substring(idx).trim();
    })();
    let mainResult = (() => {
      if (!resultText) return "";
      let text = resultText;
      const idx = text.indexOf("NEXT STEPS:");
      if (idx !== -1) text = text.substring(0, idx);
      const nextIdx = text.indexOf("NEXT:");
      if (nextIdx !== -1) text = text.substring(0, nextIdx);
      return text.trim();
    })();
    let shouldAutoExpand = hasImages && jobSucceeded;
    function imageDataUrl(base64, mimeType) {
      return `data:${mimeType};base64,${base64}`;
    }
    $$renderer2.push(`<div class="my-2.5 w-full overflow-hidden rounded-xl border border-border bg-card/50"><div class="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-[13px]"><span${attr_class(`flex h-4 w-4 shrink-0 items-center justify-center ${stringify(statusColor)}`)}>`);
    Icon$1($$renderer2, {
      icon: status === "running" ? Loading03Icon : headingIcon,
      size: 15,
      strokeWidth: 1.5,
      class: status === "running" ? "animate-spin" : ""
    });
    $$renderer2.push(`<!----></span> <span class="flex-1 min-w-0 truncate font-medium text-foreground">${escape_html(heading)}</span> <span${attr_class(`shrink-0 rounded-md px-2 py-0.5 text-[10px] font-medium ${stringify(actionBadge.color)}`)}>${escape_html(actionBadge.text)}</span> `);
    if (action === "create" && artStyle) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span class="shrink-0 rounded-md bg-secondary/60 px-1.5 py-0.5 text-[10px] text-muted-foreground/70">${escape_html(artStyle)}</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (status === "error") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<span class="shrink-0 rounded-md bg-red-500/15 px-1.5 py-0.5 text-[10px] font-medium text-red-400">failed</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <button class="shrink-0 rounded p-1 text-muted-foreground/60 transition-colors hover:bg-accent/30 hover:text-foreground">`);
    Icon$1($$renderer2, {
      icon: shouldAutoExpand ? ArrowUp01Icon : ArrowDown01Icon,
      size: 12,
      strokeWidth: 1.5
    });
    $$renderer2.push(`<!----></button></div> `);
    if (action === "create" && prompt) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="border-t border-border/50 px-3.5 py-2"><p class="text-[12px] leading-relaxed text-foreground/70 italic">"${escape_html(prompt)}"</p></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (status === "success" && jobInProgress && action === "check") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="border-t border-border/50 px-3.5 py-2"><div class="flex items-center gap-2"><span class="font-mono text-[11px] text-muted-foreground/70">Status polled — ${escape_html(progress !== null ? `${progress}% complete` : "still processing")}</span> `);
      if (jobStage) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="text-[10px] text-muted-foreground/50">(${escape_html(jobStage)})</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div></div>`);
    } else if (status === "running") {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div class="border-t border-border/50 px-3.5 py-3 flex items-center justify-center"><span class="font-mono text-[11px] text-muted-foreground animate-pulse">${escape_html(action === "create" ? "Starting generation..." : action === "check" ? "Polling status..." : action === "import" ? "Importing asset..." : "Processing...")}</span></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (hasImages && primaryImage && (shouldAutoExpand || expanded)) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="border-t border-border/50"><div class="relative bg-black/30"><img${attr("src", imageDataUrl(primaryImage.base64, primaryImage.mimeType))}${attr("alt", prompt || "Generated asset")} class="w-full h-auto object-contain" style="max-height: 440px;"/></div></div>`);
    } else if (hasImages && primaryImage && !expanded) {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<button class="block w-full border-t border-border/50"><div class="relative bg-black/30"><img${attr("src", imageDataUrl(primaryImage.base64, primaryImage.mimeType))}${attr("alt", prompt || "Generated asset")} class="w-full h-auto object-contain" style="max-height: 120px;"/></div></button>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (shouldAutoExpand) {
      $$renderer2.push("<!--[-->");
      if (mainResult && status !== "running") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="border-t border-border/50 px-3.5 py-2"><pre class="font-mono text-[11px] leading-relaxed text-foreground/60 whitespace-pre-wrap">${escape_html(mainResult)}</pre></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]-->`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (status === "error" && resultText) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="border-t border-border/50 px-3.5 py-2.5"><pre class="font-mono text-[11px] leading-relaxed text-red-400/80 whitespace-pre-wrap">${escape_html(resultText)}</pre></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function ToolCallBlock($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      block,
      resultBlock,
      childBlocks = []
    } = $$props;
    let toolName = block.toolName?.replace(/^mcp__[^_]+__/, "") ?? "tool";
    let isTask = block.toolName === "Task";
    let isBash = block.toolName === "Bash";
    let isScreenshot = toolName === "screenshot";
    let isGenerateAsset = toolName === "generate_asset" || toolName === "generate_3d_model" || toolName === "generate_image";
    let isAssetRead = toolName === "read_asset";
    let isReadLike = toolName === "Read" || toolName === "read_file" || toolName === "ReadFile";
    let status = !resultBlock ? "running" : resultBlock.toolSuccess !== false ? "success" : "error";
    let statusIcon = status === "running" ? Loading03Icon : status === "success" ? CheckmarkCircle02Icon : Cancel01Icon;
    let statusColor = status === "running" ? "text-blue-400" : status === "success" ? "text-emerald-400" : "text-red-400";
    let taskArgs = (() => {
      if (!isTask || !block.toolArguments) return null;
      try {
        return JSON.parse(block.toolArguments);
      } catch {
        return null;
      }
    })();
    let subagentType = taskArgs?.subagent_type || "Task";
    let taskDescription = taskArgs?.description || "";
    taskArgs?.prompt || "";
    let taskModel = taskArgs?.model ? taskArgs.model.charAt(0).toUpperCase() + taskArgs.model.slice(1) : "";
    let taskHeading = taskDescription ? `${subagentType}(${taskDescription})` : subagentType;
    let bashArgs = (() => {
      if (!isBash || !block.toolArguments) return null;
      try {
        return JSON.parse(block.toolArguments);
      } catch {
        return null;
      }
    })();
    let bashCommand = bashArgs?.command ?? "";
    let bashDescription = bashArgs?.description ?? "";
    let bashOutput = resultBlock?.toolResult ?? "";
    let bashOutputLines = bashOutput ? bashOutput.split("\n") : [];
    bashOutputLines.length;
    const BASH_PREVIEW_LINES = 4;
    let bashPreview = bashOutputLines.length > BASH_PREVIEW_LINES ? bashOutputLines.slice(0, BASH_PREVIEW_LINES).join("\n") : bashOutput;
    let bashHasMoreLines = bashOutputLines.length > BASH_PREVIEW_LINES;
    let bashRemainingLines = Math.max(0, bashOutputLines.length - BASH_PREVIEW_LINES);
    let readArgs = (() => {
      if (!isReadLike || !block.toolArguments) return null;
      try {
        const parsed = JSON.parse(block.toolArguments);
        const filePath = parsed.file_path || parsed.path || parsed.file || parsed.filename || "";
        if (!filePath) return null;
        return {
          filePath,
          offset: parsed.offset ?? parsed.start_line ?? parsed.line,
          limit: parsed.limit ?? parsed.end_line ?? parsed.lines
        };
      } catch {
        return null;
      }
    })();
    let isRead = isReadLike && readArgs !== null;
    let readFilePath = readArgs?.filePath ?? "";
    let readFileName = () => {
      const p = readFilePath;
      if (!p) return "";
      const parts = p.replace(/\\/g, "/").split("/");
      return parts[parts.length - 1] || p;
    };
    let readDirPath = () => {
      const p = readFilePath;
      if (!p) return "";
      const normalized = p.replace(/\\/g, "/");
      const lastSlash = normalized.lastIndexOf("/");
      return lastSlash >= 0 ? normalized.substring(0, lastSlash) : "";
    };
    let readLineRange = () => {
      if (!readArgs) return "";
      const { offset: offset2, limit } = readArgs;
      if (offset2 && limit) return `Lines ${offset2}–${offset2 + limit - 1}`;
      if (offset2) return `From line ${offset2}`;
      if (limit) return `${limit} lines`;
      return "";
    };
    let readOutput = (() => {
      let raw = resultBlock?.toolResult ?? "";
      if (!raw) return "";
      raw = raw.replace(/^\.\.\.\n?/, "").replace(/\n?\.\.\.$/, "");
      return raw;
    })();
    let readOutputLines = readOutput ? readOutput.split("\n") : [];
    let readOutputLineCount = readOutputLines.length;
    const READ_PREVIEW_LINES = 6;
    let readPreview = readOutputLines.length > READ_PREVIEW_LINES ? readOutputLines.slice(0, READ_PREVIEW_LINES).join("\n") : readOutput;
    let readHasMoreLines = readOutputLines.length > READ_PREVIEW_LINES;
    let readRemainingLines = Math.max(0, readOutputLines.length - READ_PREVIEW_LINES);
    let hasImages = (resultBlock?.images && resultBlock.images.length > 0) ?? false;
    let hasChildren = childBlocks.length > 0;
    let taskResultParsed = (() => {
      const raw = resultBlock?.toolResult ?? "";
      if (!raw || !isTask) return {
        content: raw,
        tokens: "",
        tools: "",
        duration: "",
        agentId: ""
      };
      let text = raw;
      let tokens = "";
      let tools = "";
      let duration = "";
      const usageMatch = text.match(/<usage>([\s\S]*?)<\/usage>/);
      if (usageMatch) {
        const usageBlock = usageMatch[1];
        const tokensMatch = usageBlock.match(/total_tokens:\s*(\d+)/);
        const toolsMatch = usageBlock.match(/tool_uses:\s*(\d+)/);
        const durationMatch = usageBlock.match(/duration_ms:\s*(\d+)/);
        if (tokensMatch) {
          const n = parseInt(tokensMatch[1]);
          tokens = n >= 1e3 ? `${(n / 1e3).toFixed(1)}k` : `${n}`;
        }
        if (toolsMatch) tools = toolsMatch[1];
        if (durationMatch) {
          const ms = parseInt(durationMatch[1]);
          duration = ms >= 1e3 ? `${(ms / 1e3).toFixed(1)}s` : `${ms}ms`;
        }
        text = text.replace(/<usage>[\s\S]*?<\/usage>/, "");
      }
      let agentId = "";
      const agentMatch = text.match(/^agentId:\s*([a-f0-9-]+).*$/m);
      if (agentMatch) {
        agentId = agentMatch[1];
        text = text.replace(/^agentId:.*$/m, "");
      }
      const content = text.trim();
      return { content, tokens, tools, duration, agentId };
    })();
    function imageDataUrl(base64, mimeType) {
      return `data:${mimeType};base64,${base64}`;
    }
    if (isTask) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="my-1.5 w-full rounded-lg border border-border bg-card/40"><button class="flex w-full items-center gap-2 px-3 py-2 text-left text-[13px] transition-colors hover:bg-accent/30"><span${attr_class(`flex h-4 w-4 shrink-0 items-center justify-center ${stringify(statusColor)}`)}>`);
      Icon$1($$renderer2, {
        icon: statusIcon,
        size: 14,
        strokeWidth: 1.5,
        class: status === "running" ? "animate-spin" : ""
      });
      $$renderer2.push(`<!----></span> <span class="flex-1 min-w-0 truncate font-medium text-foreground/80">${escape_html(taskHeading)}</span> `);
      if (taskModel) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="shrink-0 rounded bg-secondary/60 px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground/60">${escape_html(taskModel)}</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (hasChildren) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="shrink-0 text-[11px] tabular-nums text-muted-foreground/50">${escape_html(childBlocks.length)} tool${escape_html(childBlocks.length !== 1 ? "s" : "")}</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <span class="shrink-0 text-muted-foreground/50">`);
      Icon$1($$renderer2, {
        icon: ArrowDown01Icon,
        size: 12,
        strokeWidth: 1.5
      });
      $$renderer2.push(`<!----></span></button> `);
      if (status !== "running" && (taskResultParsed.tokens || taskResultParsed.duration || taskResultParsed.tools)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="flex items-center gap-2 border-t border-border/15 px-3 py-1">`);
        if (taskResultParsed.tokens) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="text-[10px] text-muted-foreground/40">${escape_html(taskResultParsed.tokens)} tokens</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> `);
        if (taskResultParsed.tools && taskResultParsed.tools !== "0") {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="text-[10px] text-muted-foreground/25">·</span> <span class="text-[10px] text-muted-foreground/40">${escape_html(taskResultParsed.tools)} tool uses</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> `);
        if (taskResultParsed.duration) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="text-[10px] text-muted-foreground/25">·</span> <span class="text-[10px] text-muted-foreground/40">${escape_html(taskResultParsed.duration)}</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    } else if (isBash) {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div class="my-1 w-full overflow-hidden rounded-lg border border-border bg-card/40"><button class="flex w-full items-center gap-2 px-3 py-2 text-left text-[13px] transition-colors hover:bg-accent/30"><span${attr_class(`flex h-4 w-4 shrink-0 items-center justify-center ${stringify(statusColor)}`)}>`);
      if (status === "running") {
        $$renderer2.push("<!--[-->");
        Icon$1($$renderer2, {
          icon: Loading03Icon,
          size: 14,
          strokeWidth: 1.5,
          class: "animate-spin"
        });
      } else {
        $$renderer2.push("<!--[!-->");
        Icon$1($$renderer2, { icon: CommandLineIcon, size: 14, strokeWidth: 1.5 });
      }
      $$renderer2.push(`<!--]--></span> <span class="flex-1 min-w-0 flex items-center gap-1.5 truncate"><span class="shrink-0 font-medium text-foreground/80">Bash</span> `);
      if (bashDescription) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="text-muted-foreground/30">·</span> <span class="truncate text-muted-foreground/60">${escape_html(bashDescription)}</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></span> `);
      if (status === "error") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="shrink-0 rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] font-medium text-red-400/80">failed</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <span class="shrink-0 text-muted-foreground/50">`);
      Icon$1($$renderer2, {
        icon: ArrowDown01Icon,
        size: 12,
        strokeWidth: 1.5
      });
      $$renderer2.push(`<!----></span></button> <div class="border-t border-border/50 px-3 py-1.5"><pre class="overflow-x-auto font-mono text-[11px] leading-relaxed text-foreground/50"><span class="text-emerald-500/50 select-none">$</span> ${escape_html(bashCommand)}</pre></div> `);
      if (bashOutput) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="border-t border-border/50">`);
        {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<div class="relative"><pre${attr_class(`px-3 py-2 font-mono text-[11px] leading-relaxed ${stringify(status === "error" ? "text-red-400/70" : "text-muted-foreground/60")}`)}>${escape_html(bashPreview)}</pre> `);
          if (bashHasMoreLines) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<div class="absolute inset-x-0 bottom-0 flex h-8 items-end justify-center" style="background: linear-gradient(to top, hsl(var(--card)) 30%, transparent);"><span class="pb-1 text-[10px] text-muted-foreground/40">${escape_html(bashRemainingLines)} more line${escape_html(bashRemainingLines !== 1 ? "s" : "")}</span></div>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></div>`);
        }
        $$renderer2.push(`<!--]--></div>`);
      } else if (status === "running") {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<div class="border-t border-border/50 px-3 py-2"><span class="font-mono text-[11px] text-muted-foreground/40 animate-pulse">Running...</span></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    } else if (isRead) {
      $$renderer2.push("<!--[2-->");
      $$renderer2.push(`<div class="my-1 w-full overflow-hidden rounded-lg border border-border bg-card/40"><button class="flex w-full items-center gap-2 px-3 py-2 text-left text-[13px] transition-colors hover:bg-accent/30"><span${attr_class(`flex h-4 w-4 shrink-0 items-center justify-center ${stringify(statusColor)}`)}>`);
      if (status === "running") {
        $$renderer2.push("<!--[-->");
        Icon$1($$renderer2, {
          icon: Loading03Icon,
          size: 14,
          strokeWidth: 1.5,
          class: "animate-spin"
        });
      } else {
        $$renderer2.push("<!--[!-->");
        Icon$1($$renderer2, { icon: File01Icon, size: 14, strokeWidth: 1.5 });
      }
      $$renderer2.push(`<!--]--></span> <span class="flex-1 min-w-0 flex items-center gap-1.5 truncate"><span class="shrink-0 font-medium text-foreground/80">Read</span> <span class="text-muted-foreground/30">·</span> <span class="truncate text-muted-foreground/60">${escape_html(readFileName())}</span></span> `);
      if (readLineRange()) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="shrink-0 text-[10px] text-muted-foreground/40">${escape_html(readLineRange())}</span>`);
      } else if (status !== "running" && readOutputLineCount > 0) {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<span class="shrink-0 text-[10px] tabular-nums text-muted-foreground/40">${escape_html(readOutputLineCount)} line${escape_html(readOutputLineCount !== 1 ? "s" : "")}</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (status === "error") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="shrink-0 rounded bg-red-500/15 px-1.5 py-0.5 text-[10px] font-medium text-red-400/80">failed</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <span class="shrink-0 text-muted-foreground/50">`);
      Icon$1($$renderer2, {
        icon: ArrowDown01Icon,
        size: 12,
        strokeWidth: 1.5
      });
      $$renderer2.push(`<!----></span></button> <div class="border-t border-border/50 px-3 py-1"><span class="block truncate font-mono text-[10px] text-muted-foreground/35">${escape_html(readDirPath())}/</span></div> `);
      if (readOutput) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="border-t border-border/50">`);
        {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<div class="relative"><pre class="px-2 py-1.5 font-mono text-[11px] leading-snug text-muted-foreground/60">${escape_html(readPreview)}</pre> `);
          if (readHasMoreLines) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<div class="absolute inset-x-0 bottom-0 flex h-8 items-end justify-center" style="background: linear-gradient(to top, hsl(var(--card)) 30%, transparent);"><span class="pb-1 text-[10px] text-muted-foreground/40">${escape_html(readRemainingLines)} more line${escape_html(readRemainingLines !== 1 ? "s" : "")}</span></div>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></div>`);
        }
        $$renderer2.push(`<!--]--></div>`);
      } else if (status === "running") {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<div class="border-t border-border/50 px-3 py-2"><span class="font-mono text-[11px] text-muted-foreground/40 animate-pulse">Reading...</span></div>`);
      } else if (status === "error") {
        $$renderer2.push("<!--[2-->");
        $$renderer2.push(`<div class="border-t border-border/50 px-3 py-1.5"><pre class="font-mono text-[11px] leading-relaxed text-red-400/70">${escape_html(resultBlock?.toolResult ?? "File not found")}</pre></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    } else if (isScreenshot) {
      $$renderer2.push("<!--[3-->");
      ScreenshotBlock($$renderer2, { block, resultBlock });
    } else if (isGenerateAsset) {
      $$renderer2.push("<!--[4-->");
      GenerateAssetBlock($$renderer2, { block, resultBlock });
    } else if (isAssetRead) {
      $$renderer2.push("<!--[5-->");
      AssetReadBlock($$renderer2, { block, resultBlock });
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="my-1 w-full rounded-lg border border-border bg-card/40"><button class="flex w-full items-center gap-2 px-3 py-2 text-left text-[13px] transition-colors hover:bg-accent/30"><span${attr_class(`flex h-4 w-4 shrink-0 items-center justify-center ${stringify(statusColor)}`)}>`);
      Icon$1($$renderer2, {
        icon: statusIcon,
        size: 14,
        strokeWidth: 1.5,
        class: status === "running" ? "animate-spin" : ""
      });
      $$renderer2.push(`<!----></span> <span class="flex-1 truncate font-medium text-foreground/80">${escape_html(toolName)}</span> <span class="text-muted-foreground/50">`);
      Icon$1($$renderer2, {
        icon: ArrowDown01Icon,
        size: 12,
        strokeWidth: 1.5
      });
      $$renderer2.push(`<!----></span></button> `);
      if (hasImages && resultBlock?.images) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="flex gap-2 overflow-x-auto border-t border-border/50 px-3 py-2"><!--[-->`);
        const each_array_1 = ensure_array_like(resultBlock.images);
        for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
          let img = each_array_1[$$index_1];
          $$renderer2.push(`<button class="shrink-0 overflow-hidden rounded-md border border-border/50"><img${attr("src", imageDataUrl(img.base64, img.mimeType))} alt="Tool result" class="h-20 w-auto object-contain" style="max-width: 160px;"/></button>`);
        }
        $$renderer2.push(`<!--]--></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function StreamingTimer($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let elapsed = 0;
    onDestroy(() => {
    });
    let display = (() => {
      const sec = elapsed / 1e3;
      return `${sec.toFixed(1)}s`;
    })();
    $$renderer2.push(`<span class="tabular-nums text-muted-foreground/30">${escape_html(display)}</span>`);
  });
}
function ChatMessage($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { message } = $$props;
    const PATH_PATTERNS = [
      // UE asset paths: /Game/..., /Engine/..., /Script/...
      /^\/(?:Game|Engine|Script|Temp)\//,
      // Absolute filesystem paths
      /^\/(?:Users|home|var|tmp|opt|usr|etc)\//,
      /^[A-Z]:\\/,
      // Common source/project relative paths
      /^(?:Source|Plugins|Content|Config|Docs|Tests|Scripts|Binaries|Intermediate|Saved)\//
    ];
    const FILE_EXTENSIONS = /\.(?:h|cpp|c|cs|py|js|ts|svelte|json|ini|txt|md|uasset|umap|uplugin|uproject|build\.cs)$/i;
    function isClickablePath(text) {
      const clean = text.split(":")[0];
      if (PATH_PATTERNS.some((p) => p.test(clean))) return true;
      if (FILE_EXTENSIONS.test(clean)) return true;
      return false;
    }
    function findToolResult(toolCallId) {
      if (!toolCallId) return void 0;
      return message.contentBlocks.find((b) => b.type === "tool_result" && b.toolCallId === toolCallId);
    }
    const EMPTY_MAP = { childToParent: {}, parentToChildren: {} };
    let parentChildMap = (() => {
      const blocks = message.contentBlocks;
      if (!blocks.some((b) => b.type === "tool_call" && (b.parentToolCallId || b.toolName === "Task"))) {
        return EMPTY_MAP;
      }
      const childToParent = {};
      const parentToChildren = {};
      for (const b of blocks) {
        if (b.type === "tool_call" && b.parentToolCallId && b.toolCallId) {
          childToParent[b.toolCallId] = b.parentToolCallId;
          if (!parentToChildren[b.parentToolCallId]) parentToChildren[b.parentToolCallId] = [];
          parentToChildren[b.parentToolCallId].push(b.toolCallId);
        }
      }
      for (let i = 0; i < blocks.length; i++) {
        const b = blocks[i];
        if (b.type !== "tool_call" || b.toolName !== "Task" || !b.toolCallId) continue;
        if (parentToChildren[b.toolCallId]?.length) continue;
        const taskId = b.toolCallId;
        for (let j = i + 1; j < blocks.length; j++) {
          const next = blocks[j];
          if (next.type === "tool_result" && next.toolCallId === taskId) break;
          if (next.type === "tool_call" && next.toolCallId && !next.parentToolCallId) {
            if (childToParent[next.toolCallId]) continue;
            if (next.toolCallId === taskId) continue;
            childToParent[next.toolCallId] = taskId;
            if (!parentToChildren[taskId]) parentToChildren[taskId] = [];
            parentToChildren[taskId].push(next.toolCallId);
          }
        }
      }
      return { childToParent, parentToChildren };
    })();
    function getChildToolCalls(parentToolCallId) {
      if (!parentToolCallId) return [];
      const childIds = parentChildMap.parentToChildren[parentToolCallId];
      if (!childIds?.length) return [];
      return message.contentBlocks.filter((b) => b.type === "tool_call" && b.toolCallId && childIds.includes(b.toolCallId));
    }
    function isChildBlock(block) {
      if (!block.toolCallId) return false;
      return !!parentChildMap.childToParent[block.toolCallId];
    }
    function codespan($$renderer3, { children, token }) {
      if (isClickablePath(token.text)) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<button class="cursor-pointer rounded bg-muted px-1.5 py-0.5 font-mono text-[0.9em] text-blue-400 underline decoration-blue-400/30 transition-colors hover:text-blue-300 hover:decoration-blue-300/50">${escape_html(token.text)}</button>`);
      } else {
        $$renderer3.push("<!--[!-->");
        children($$renderer3);
        $$renderer3.push(`<!---->`);
      }
      $$renderer3.push(`<!--]-->`);
    }
    if (message.role === "user") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="message-enter group/msg mb-4 flex items-start justify-end gap-1"><button class="mt-2 shrink-0 rounded p-1 text-muted-foreground/0 transition-colors group-hover/msg:text-muted-foreground/40 hover:!text-muted-foreground" title="Copy">`);
      Icon$1($$renderer2, {
        icon: Copy01Icon,
        size: 14,
        strokeWidth: 1.5
      });
      $$renderer2.push(`<!----></button> <div class="max-w-[70%] rounded-2xl rounded-br-md border border-border/50 bg-card px-4 py-2.5 text-[14px] text-card-foreground">${escape_html(message.contentBlocks[0]?.text ?? "")}</div></div>`);
    } else if (message.role === "system") {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div class="message-enter my-4 flex items-center gap-3"><div class="h-px flex-1 bg-border/40"></div> <span class="text-[12px] italic text-muted-foreground/60">${escape_html(message.contentBlocks[0]?.text ?? "")}</span> <div class="h-px flex-1 bg-border/40"></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="message-enter group/msg mb-4 flex justify-start"><div class="w-full max-w-[85%] min-w-0"><!--[-->`);
      const each_array = ensure_array_like(message.contentBlocks);
      for (let i = 0, $$length = each_array.length; i < $$length; i++) {
        let block = each_array[i];
        if (block.type === "text") {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="max-w-none text-[14px] leading-relaxed text-foreground">`);
          Response$1($$renderer2, {
            content: block.text,
            parseIncompleteMarkdown: block.isStreaming ?? false,
            class: "text-[14px] leading-relaxed",
            codespan
          });
          $$renderer2.push(`<!----></div>`);
        } else if (block.type === "thought") {
          $$renderer2.push("<!--[1-->");
          Reasoning($$renderer2, {
            isStreaming: block.isStreaming ?? false,
            defaultOpen: true,
            class: "my-2",
            children: ($$renderer3) => {
              ReasoningTrigger($$renderer3, {});
              $$renderer3.push(`<!----> `);
              ReasoningContent($$renderer3, {
                children: ($$renderer4) => {
                  $$renderer4.push(`<!---->${escape_html(block.text)}`);
                },
                $$slots: { default: true }
              });
              $$renderer3.push(`<!---->`);
            },
            $$slots: { default: true }
          });
        } else if (block.type === "tool_call") {
          $$renderer2.push("<!--[2-->");
          if (!isChildBlock(block)) {
            $$renderer2.push("<!--[-->");
            ToolCallBlock($$renderer2, {
              block,
              resultBlock: findToolResult(block.toolCallId),
              childBlocks: getChildToolCalls(block.toolCallId),
              allBlocks: message.contentBlocks
            });
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]-->`);
        } else if (block.type === "tool_result") {
          $$renderer2.push("<!--[3-->");
        } else if (block.type === "error") {
          $$renderer2.push("<!--[4-->");
          $$renderer2.push(`<div class="my-2 flex items-start gap-2 rounded-lg border border-red-500/20 bg-red-500/5 px-3 py-2 text-[13px] text-red-400">`);
          Icon$1($$renderer2, {
            icon: Alert02Icon,
            size: 16,
            strokeWidth: 1.5,
            class: "mt-0.5 shrink-0"
          });
          $$renderer2.push(`<!----> <span>${escape_html(block.text)}</span></div>`);
        } else if (block.type === "system") {
          $$renderer2.push("<!--[5-->");
          if (block.systemStatus === "compacting") {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<div class="my-3 flex items-center gap-3"><div class="h-px flex-1 bg-border/30"></div> <div class="flex items-center gap-2 text-[12px] text-muted-foreground/60"><span class="inline-block h-1.5 w-1.5 rounded-full bg-muted-foreground/40 animate-pulse"></span> `);
            Shimmer($$renderer2, {
              children: ($$renderer3) => {
                $$renderer3.push(`<span>${escape_html(block.text)}</span>`);
              },
              $$slots: { default: true }
            });
            $$renderer2.push(`<!----></div> <div class="h-px flex-1 bg-border/30"></div></div>`);
          } else {
            $$renderer2.push("<!--[!-->");
            $$renderer2.push(`<div class="my-3 flex items-center gap-3"><div class="h-px flex-1 bg-border/30"></div> <span class="text-[12px] text-muted-foreground/50">${escape_html(block.text)}</span> <div class="h-px flex-1 bg-border/30"></div></div>`);
          }
          $$renderer2.push(`<!--]-->`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]-->`);
      }
      $$renderer2.push(`<!--]--> `);
      if (message.isStreaming) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="mt-2 flex items-center gap-2 text-[12px]">`);
        Shimmer($$renderer2, {
          children: ($$renderer3) => {
            $$renderer3.push(`<span>Generating</span>`);
          },
          $$slots: { default: true }
        });
        $$renderer2.push(`<!----> `);
        StreamingTimer($$renderer2);
        $$renderer2.push(`<!----></div>`);
      } else if (message.contentBlocks.some((b) => b.type === "text" && b.text)) {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<div class="mt-1 flex"><button class="rounded p-1 text-muted-foreground/0 transition-colors group-hover/msg:text-muted-foreground/40 hover:!text-muted-foreground" title="Copy">`);
        Icon$1($$renderer2, {
          icon: Copy01Icon,
          size: 14,
          strokeWidth: 1.5
        });
        $$renderer2.push(`<!----></button></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div></div>`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
function PermissionDialog($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { request } = $$props;
    let argsExpanded = false;
    let responding = false;
    let activeOptionIndex = 0;
    let isExitPlanMode = () => {
      const id = request.toolCall.toolCallId.toLowerCase();
      const title = request.toolCall.title.toLowerCase();
      return id.includes("exitplanmode") || title.includes("ready to code") || title.includes("exit plan");
    };
    let formattedArgs = () => {
      try {
        const parsed = JSON.parse(request.toolCall.rawInput);
        return JSON.stringify(parsed, null, 2);
      } catch {
        return request.toolCall.rawInput;
      }
    };
    let argsLong = request.toolCall.rawInput.length > 120;
    function buttonColor(kind) {
      if (kind === "allow_always" || kind === "allow_once") {
        return "border-emerald-500/35 bg-emerald-500/10 text-emerald-200";
      }
      if (kind === "reject_once") {
        return "border-red-500/35 bg-red-500/10 text-red-200";
      }
      return "border-border/40 bg-secondary/30 text-foreground";
    }
    function buttonIcon(kind) {
      if (kind === "allow_always" || kind === "allow_once") return Tick02Icon;
      if (kind === "reject_once") return Cancel01Icon;
      return null;
    }
    $$renderer2.push(`<div role="listbox" aria-label="Permission options" tabindex="0" class="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3 focus:outline-none focus:ring-2 focus:ring-[var(--ue-accent-muted)]"><div${attr_class(`rounded-lg border ${stringify(isExitPlanMode() ? "border-emerald-500/30 bg-emerald-500/5" : "border-amber-500/30 bg-amber-500/5")}`)}><div class="flex items-center justify-between gap-2 px-4 pt-3 pb-2"><div class="flex items-center gap-2">`);
    if (isExitPlanMode()) {
      $$renderer2.push("<!--[-->");
      Icon$1($$renderer2, {
        icon: CheckmarkBadge01Icon,
        size: 18,
        strokeWidth: 1.5,
        class: "text-emerald-400"
      });
      $$renderer2.push(`<!----> <span class="text-[14px] font-semibold text-emerald-400">Ready to code?</span>`);
    } else {
      $$renderer2.push("<!--[!-->");
      Icon$1($$renderer2, {
        icon: Shield02Icon,
        size: 18,
        strokeWidth: 1.5,
        class: "text-amber-400"
      });
      $$renderer2.push(`<!----> <span class="text-[14px] font-semibold text-amber-400">Permission Required</span>`);
    }
    $$renderer2.push(`<!--]--></div> <span class="text-[11px] text-muted-foreground/75">↑/↓ select • Enter confirm</span></div> <div class="px-4 pb-2"><div class="text-[13px] text-foreground">${escape_html(request.toolCall.title || "Tool request")}</div></div> `);
    if (request.toolCall.rawInput) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="px-4 pb-3">`);
      if (argsLong) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<button class="flex items-center gap-1 text-[11px] text-muted-foreground/60 transition-colors hover:text-muted-foreground">`);
        Icon$1($$renderer2, {
          icon: ArrowDown01Icon,
          size: 10,
          strokeWidth: 1.5
        });
        $$renderer2.push(`<!----> ${escape_html("Show")} arguments</button>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (!argsLong || argsExpanded) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<pre class="mt-1.5 max-h-[200px] overflow-auto rounded-lg bg-[#1c1c1c] p-3 text-[12px] leading-relaxed text-muted-foreground/70">${escape_html(formattedArgs())}</pre>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <div class="flex flex-col gap-1.5 border-t border-border/20 px-4 py-3"><!--[-->`);
    const each_array = ensure_array_like(request.options);
    for (let index = 0, $$length = each_array.length; index < $$length; index++) {
      let option = each_array[index];
      const icon = buttonIcon(option.kind);
      $$renderer2.push(`<button role="option"${attr("aria-selected", index === activeOptionIndex)}${attr("data-option-index", index)}${attr_class(`flex items-center gap-1.5 rounded-lg border px-3 py-2 text-[13px] font-medium transition-all ${stringify(buttonColor(option.kind))} ${stringify(index === activeOptionIndex ? "ring-2 ring-[var(--ue-accent-muted)]" : "hover:border-border/70")} ${stringify("")}`)}${attr("disabled", responding, true)}>`);
      if (icon) {
        $$renderer2.push("<!--[-->");
        Icon$1($$renderer2, { icon, size: 14, strokeWidth: 2 });
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> ${escape_html(option.name)}</button>`);
    }
    $$renderer2.push(`<!--]--></div></div></div>`);
  });
}
function AskUserDialog($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { request } = $$props;
    let singleAnswers = {};
    let multiAnswers = {};
    let otherText = {};
    let responding = false;
    let activeQuestionIndex = 0;
    let currentQuestion = request.questions[activeQuestionIndex];
    let currentOtherOptionIndex = currentQuestion ? currentQuestion.options.length : 0;
    let currentOtherActive = currentQuestion ? getActiveOptionIndex(activeQuestionIndex) === currentQuestion.options.length : false;
    function isMultiSelected(question, label) {
      return multiAnswers[question]?.has(label) ?? false;
    }
    function optionCount(q) {
      return q.options.length + 1;
    }
    function getActiveOptionIndex(questionIndex) {
      const question = request.questions[questionIndex];
      if (!question) return 0;
      const max = optionCount(question) - 1;
      const current = 0;
      return Math.max(0, Math.min(current, max));
    }
    function isQuestionAnswered(q) {
      if (otherText[q.question]) return true;
      if (q.multiSelect) {
        return (multiAnswers[q.question]?.size ?? 0) > 0;
      }
      return !!singleAnswers[q.question];
    }
    $$renderer2.push(`<div role="application" aria-label="Questionnaire" class="rounded-xl border border-blue-500/30 bg-blue-500/5 p-3 focus:outline-none focus:ring-2 focus:ring-[var(--ue-accent-muted)]"><div class="mb-2 flex items-center justify-between gap-2"><div class="flex items-center gap-2">`);
    Icon$1($$renderer2, {
      icon: MessageQuestionIcon,
      size: 18,
      strokeWidth: 1.5,
      class: "text-blue-400"
    });
    $$renderer2.push(`<!----> <span class="text-[14px] font-semibold text-blue-400">Questionnaire</span></div> <span class="text-[11px] text-muted-foreground/75">Tab switch • ↑/↓ select • Enter apply • Ctrl+Enter submit</span></div> <div class="mb-3 flex flex-wrap gap-1.5"><!--[-->`);
    const each_array = ensure_array_like(request.questions);
    for (let qi = 0, $$length = each_array.length; qi < $$length; qi++) {
      let q = each_array[qi];
      const answered = isQuestionAnswered(q);
      $$renderer2.push(`<button${attr("data-question-tab", qi)}${attr_class(`flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[12px] transition-all ${stringify(qi === activeQuestionIndex ? "border-blue-500/60 bg-blue-500/15 text-blue-200" : "border-border/35 bg-secondary/20 text-muted-foreground hover:border-border/60")}`)}><span>${escape_html(q.header || `Question ${qi + 1}`)}</span> `);
      if (answered) {
        $$renderer2.push("<!--[-->");
        Icon$1($$renderer2, {
          icon: Tick02Icon,
          size: 12,
          strokeWidth: 2.5,
          class: "text-emerald-400"
        });
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></button>`);
    }
    $$renderer2.push(`<!--]--></div> `);
    if (currentQuestion) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="rounded-lg border border-border/30 bg-card/40 p-3"><div class="mb-2 text-[13px] font-medium text-foreground">${escape_html(currentQuestion.question)}</div> <div class="flex flex-col gap-1.5"><!--[-->`);
      const each_array_1 = ensure_array_like(currentQuestion.options);
      for (let oi = 0, $$length = each_array_1.length; oi < $$length; oi++) {
        let opt = each_array_1[oi];
        const isSelected = currentQuestion.multiSelect ? isMultiSelected(currentQuestion.question, opt.label) : singleAnswers[currentQuestion.question] === opt.label;
        const isActive = getActiveOptionIndex(activeQuestionIndex) === oi;
        $$renderer2.push(`<button${attr_class(`flex items-start gap-2 rounded-lg border px-3 py-2 text-left text-[13px] transition-all ${stringify(isSelected ? "border-blue-500/55 bg-blue-500/10" : "border-border/30 bg-transparent hover:border-border/60 hover:bg-secondary/20")} ${stringify(isActive ? "ring-2 ring-[var(--ue-accent-muted)]" : "")}`)}><span${attr_class(`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded text-[11px] font-bold ${stringify(isSelected ? "bg-blue-500 text-white" : "bg-secondary/60 text-muted-foreground")}`)}>`);
        if (isSelected) {
          $$renderer2.push("<!--[-->");
          Icon$1($$renderer2, { icon: Tick02Icon, size: 12, strokeWidth: 2.5 });
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`${escape_html(oi + 1)}`);
        }
        $$renderer2.push(`<!--]--></span> <div class="min-w-0 flex-1"><div class="text-[13px] text-foreground">${escape_html(opt.label)}</div> `);
        if (opt.description) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="mt-0.5 text-[12px] text-muted-foreground/60">${escape_html(opt.description)}</div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div></button>`);
      }
      $$renderer2.push(`<!--]--> <div${attr_class(`flex items-start gap-2 rounded-lg border px-3 py-2 transition-all ${stringify(otherText[currentQuestion.question] ? "border-blue-500/55 bg-blue-500/10" : "border-border/30 bg-transparent")} ${stringify(currentOtherActive ? "ring-2 ring-[var(--ue-accent-muted)]" : "")}`)}><span${attr_class(`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded text-[11px] font-bold ${stringify(otherText[currentQuestion.question] ? "bg-blue-500 text-white" : "bg-secondary/60 text-muted-foreground")}`)}>`);
      if (otherText[currentQuestion.question]) {
        $$renderer2.push("<!--[-->");
        Icon$1($$renderer2, { icon: Tick02Icon, size: 12, strokeWidth: 2.5 });
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`${escape_html(currentOtherOptionIndex + 1)}`);
      }
      $$renderer2.push(`<!--]--></span> <input type="text"${attr("data-question-index", activeQuestionIndex)} placeholder="Other..." class="min-w-0 flex-1 bg-transparent text-[13px] text-foreground placeholder:text-muted-foreground/40 focus:outline-none"${attr("value", otherText[currentQuestion.question] ?? "")}/></div></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <div class="mt-3 flex items-center gap-2"><button${attr_class(`flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-1.5 text-[13px] font-medium text-white transition-all hover:bg-emerald-500 ${stringify("")}`)}${attr("disabled", responding, true)}>`);
    Icon$1($$renderer2, { icon: Tick02Icon, size: 14, strokeWidth: 2 });
    $$renderer2.push(`<!----> Submit</button> <button${attr_class(`flex items-center gap-1.5 rounded-lg bg-secondary/60 px-4 py-1.5 text-[13px] font-medium text-muted-foreground transition-all hover:bg-secondary hover:text-foreground ${stringify("")}`)}${attr("disabled", responding, true)}>`);
    Icon$1($$renderer2, { icon: Cancel01Icon, size: 14, strokeWidth: 2 });
    $$renderer2.push(`<!----> Skip</button></div></div>`);
  });
}
function ContextPopup($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { query, visible, onselect, ondismiss, onnavigate } = $$props;
    let results = [];
    let selectedIndex = 0;
    let flatResults = results;
    function handleItemAction(item) {
      if (item.type === "folder") {
        onnavigate(item.path);
      } else {
        onselect(item);
      }
    }
    function handleKeydown(e) {
      if (!visible || results.length === 0) return false;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        selectedIndex = (selectedIndex + 1) % flatResults.length;
        return true;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        selectedIndex = (selectedIndex - 1 + flatResults.length) % flatResults.length;
        return true;
      }
      if (e.key === "Enter" || e.key === "Tab") {
        e.preventDefault();
        if (flatResults[selectedIndex]) {
          handleItemAction(flatResults[selectedIndex]);
        }
        return true;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        ondismiss();
        return true;
      }
      return false;
    }
    if (visible) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="absolute bottom-full left-0 z-50 mb-1 max-h-[280px] w-[380px] overflow-y-auto rounded-lg border border-border/60 bg-[#1a1a1a] py-1 shadow-xl">`);
      if (results.length === 0) {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<div class="px-3 py-2 text-[13px] text-muted-foreground/40">No results</div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<!--[-->`);
        const each_array = ensure_array_like(flatResults);
        for (let idx = 0, $$length = each_array.length; idx < $$length; idx++) {
          let item = each_array[idx];
          $$renderer2.push(`<button${attr("data-index", idx)}${attr_class(`flex w-full items-center gap-2 px-2.5 py-[5px] text-left text-[13px] transition-colors ${stringify(idx === selectedIndex ? "bg-white/[0.08] text-foreground" : "text-foreground/70 hover:bg-white/[0.04]")}`)}><span class="context-icon flex h-4 w-4 shrink-0 items-center justify-center opacity-70 svelte-1ufxso5">`);
          if (item.type === "folder") {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.5 3C1.5 2.44772 1.94772 2 2.5 2H6.29289C6.4255 2 6.55268 2.05268 6.64645 2.14645L8 3.5H13.5C14.0523 3.5 14.5 3.94772 14.5 4.5V13C14.5 13.5523 14.0523 14 13.5 14H2.5C1.94772 14 1.5 13.5523 1.5 13V3Z" fill="white" fill-opacity="0.5"></path></svg>`);
          } else if (item.icon) {
            $$renderer2.push("<!--[1-->");
            $$renderer2.push(`${html(item.icon)}`);
          } else {
            $$renderer2.push("<!--[!-->");
            $$renderer2.push(`<svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 1.5C3 1.22386 3.22386 1 3.5 1H9.5L13 4.5V14.5C13 14.7761 12.7761 15 12.5 15H3.5C3.22386 15 3 14.7761 3 14.5V1.5Z" fill="white" fill-opacity="0.4"></path><path d="M9.5 1L13 4.5H10C9.72386 4.5 9.5 4.27614 9.5 4V1Z" fill="white" fill-opacity="0.6"></path></svg>`);
          }
          $$renderer2.push(`<!--]--></span> <span${attr_class(`truncate ${stringify(item.type === "folder" ? "text-foreground/90" : "")}`)}>${escape_html(item.name)}</span></button>`);
        }
        $$renderer2.push(`<!--]-->`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { handleKeydown });
  });
}
function CommandPopup($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { query, visible, commands, onselect, ondismiss } = $$props;
    let selectedIndex = 0;
    let filtered = () => {
      const q = query.toLowerCase();
      if (!q) return commands;
      return commands.filter((c) => c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q));
    };
    function handleKeydown(e) {
      const items = filtered();
      if (!visible || items.length === 0) return false;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        selectedIndex = (selectedIndex + 1) % items.length;
        return true;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        selectedIndex = (selectedIndex - 1 + items.length) % items.length;
        return true;
      }
      if (e.key === "Enter" || e.key === "Tab") {
        e.preventDefault();
        if (items[selectedIndex]) {
          onselect(items[selectedIndex]);
        }
        return true;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        ondismiss();
        return true;
      }
      return false;
    }
    if (visible) {
      $$renderer2.push("<!--[-->");
      const items = filtered();
      $$renderer2.push(`<div class="absolute bottom-full left-0 z-50 mb-1 max-h-[280px] w-[360px] overflow-y-auto rounded-xl border border-border bg-[#222] shadow-2xl">`);
      if (items.length === 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="px-3 py-3 text-[12px] text-muted-foreground/40">No matching commands</div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="px-3 pt-2 pb-0.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground/40">Commands</div> <!--[-->`);
        const each_array = ensure_array_like(items);
        for (let idx = 0, $$length = each_array.length; idx < $$length; idx++) {
          let cmd = each_array[idx];
          $$renderer2.push(`<button${attr("data-index", idx)}${attr_class(`flex w-full items-center gap-2.5 px-3 py-1.5 text-left text-[13px] transition-colors ${stringify(idx === selectedIndex ? "bg-accent/40 text-foreground" : "text-foreground/80 hover:bg-accent/20")}`)}><span class="flex h-4 w-4 shrink-0 items-center justify-center text-muted-foreground/60">`);
          Icon$1($$renderer2, { icon: CommandIcon, size: 14, strokeWidth: 1.5 });
          $$renderer2.push(`<!----></span> <div class="min-w-0 flex-1"><div class="flex items-baseline gap-1.5"><span class="font-medium">/${escape_html(cmd.name)}</span> `);
          if (cmd.inputHint) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<span class="text-[11px] text-muted-foreground/40">${escape_html(cmd.inputHint)}</span>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></div> `);
          if (cmd.description) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<div class="truncate text-[11px] text-muted-foreground/40">${escape_html(cmd.description)}</div>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></div></button>`);
        }
        $$renderer2.push(`<!--]-->`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { handleKeydown });
  });
}
function PlanPanel($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let currentTask = store_get($$store_subs ??= {}, "$currentPlan", currentPlan)?.entries.find((e) => e.status === "in_progress");
    if (store_get($$store_subs ??= {}, "$currentPlan", currentPlan) && store_get($$store_subs ??= {}, "$currentPlan", currentPlan).entries.length > 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="border-b border-border/50"><button class="flex w-full items-center gap-2.5 px-3 py-2 text-left text-[13px] transition-colors hover:bg-accent/20">`);
      {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="flex-1 flex items-center gap-2 min-w-0">`);
        if (currentTask) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="text-blue-400">`);
          Icon$1($$renderer2, {
            icon: Loading03Icon,
            size: 13,
            strokeWidth: 1.5,
            class: "animate-spin"
          });
          $$renderer2.push(`<!----></span> <span class="truncate text-[12px] text-foreground/70">${escape_html(currentTask.activeForm || currentTask.content)}</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<span class="text-emerald-400/60">`);
          Icon$1($$renderer2, { icon: CheckmarkCircle02Icon, size: 13, strokeWidth: 1.5 });
          $$renderer2.push(`<!----></span> <span class="truncate text-[12px] text-muted-foreground/50">All tasks complete</span>`);
        }
        $$renderer2.push(`<!--]--> <span class="shrink-0 text-[11px] text-muted-foreground/40">${escape_html(store_get($$store_subs ??= {}, "$currentPlan", currentPlan).completedCount)}/${escape_html(store_get($$store_subs ??= {}, "$currentPlan", currentPlan).totalCount)}</span></div>`);
      }
      $$renderer2.push(`<!--]--> <div class="h-1.5 w-16 shrink-0 overflow-hidden rounded-full bg-muted-foreground/15"><div class="h-full rounded-full bg-emerald-500 transition-all duration-300"${attr_style(`width: ${stringify(store_get($$store_subs ??= {}, "$planProgress", planProgress))}%;`)}></div></div> <span class="shrink-0 text-muted-foreground/50">`);
      Icon$1($$renderer2, {
        icon: ArrowDown01Icon,
        size: 12,
        strokeWidth: 1.5
      });
      $$renderer2.push(`<!----></span></button> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function AuthBanner($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let agent = store_get($$store_subs ??= {}, "$agents", agents).find((a) => a.name === store_get($$store_subs ??= {}, "$authAgentName", authAgentName));
    let agentColor = agent?.color ?? "#888";
    let agentDisplayName = agent?.shortName ?? (store_get($$store_subs ??= {}, "$authAgentName", authAgentName) || "Agent");
    if (store_get($$store_subs ??= {}, "$authState", authState) !== "none") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="mx-auto mb-5 w-full max-w-3xl"><div class="overflow-hidden rounded-xl border border-border/40" style="background: linear-gradient(135deg, #252525, #1f1f1f);">`);
      if (store_get($$store_subs ??= {}, "$authState", authState) === "required") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="flex items-start gap-4 p-5"><div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"${attr_style(`background-color: ${stringify(withAlpha(agentColor, 0.12))};`)}>`);
        if (agent?.iconUrl) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span${attr_style(`color: ${stringify(agentColor)};`)}><img${attr("src", agent.iconUrl)} alt="" class="h-5.5 w-5.5 invert opacity-70"/></span>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<span class="flex h-7 w-7 items-center justify-center rounded-lg text-[10px] font-bold text-white"${attr_style(`background-color: ${stringify(agentColor)};`)}>${escape_html(agent?.letter ?? "?")}</span>`);
        }
        $$renderer2.push(`<!--]--></div> <div class="flex-1 min-w-0"><h3 class="text-[14px] font-medium text-foreground">Sign in to ${escape_html(agentDisplayName)}</h3> <p class="mt-1 text-[13px] leading-relaxed text-muted-foreground/50">Authentication is required to continue. This will open your browser to complete sign-in.</p> `);
        if (store_get($$store_subs ??= {}, "$authError", authError)) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<p class="mt-1 text-[12px] leading-relaxed text-muted-foreground/40">${escape_html(store_get($$store_subs ??= {}, "$authError", authError))}</p>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <div class="mt-3.5 flex items-center gap-2.5"><button class="rounded-lg px-4 py-2 text-[13px] font-medium text-white transition-all hover:brightness-110 active:scale-[0.98]"${attr_style(`background-color: ${stringify(agentColor)};`)}>Sign in with browser</button> <button class="rounded-lg border border-border/40 bg-white/[0.03] px-3 py-2 text-[13px] text-muted-foreground/60 transition-colors hover:bg-white/[0.06] hover:text-muted-foreground">Dismiss</button></div></div></div>`);
      } else if (store_get($$store_subs ??= {}, "$authState", authState) === "logging_in") {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<div class="flex items-center gap-3.5 px-5 py-4"><div class="h-5 w-5 animate-spin rounded-full border-2 border-t-transparent"${attr_style(`border-color: ${stringify(withAlpha(agentColor, 0.3))}; border-top-color: ${stringify(agentColor)};`)}></div> <div><span class="text-[14px] font-medium text-foreground">Waiting for sign-in...</span> <p class="mt-0.5 text-[12px] text-muted-foreground/40">Complete authentication in your browser, then return here.</p></div></div>`);
      } else if (store_get($$store_subs ??= {}, "$authState", authState) === "success") {
        $$renderer2.push("<!--[2-->");
        $$renderer2.push(`<div class="flex items-center gap-3 px-5 py-4"><div class="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-500/10"><svg class="h-4 w-4 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path></svg></div> <span class="text-[14px] font-medium text-emerald-400">Signed in to ${escape_html(agentDisplayName)}</span></div>`);
      } else if (store_get($$store_subs ??= {}, "$authState", authState) === "error") {
        $$renderer2.push("<!--[3-->");
        $$renderer2.push(`<div class="flex items-start gap-4 p-5"><div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-red-500/8"><svg class="h-4.5 w-4.5 text-red-400/80" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"></path></svg></div> <div class="flex-1 min-w-0"><h3 class="text-[14px] font-medium text-red-400/90">Sign-in failed</h3> `);
        if (store_get($$store_subs ??= {}, "$authError", authError)) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<p class="mt-1 text-[12px] leading-relaxed text-muted-foreground/40">${escape_html(store_get($$store_subs ??= {}, "$authError", authError))}</p>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <div class="mt-3 flex items-center gap-2.5"><button class="rounded-lg px-4 py-2 text-[13px] font-medium text-white transition-all hover:brightness-110 active:scale-[0.98]"${attr_style(`background-color: ${stringify(agentColor)};`)}>Try again</button> <button class="rounded-lg border border-border/40 bg-white/[0.03] px-3 py-2 text-[13px] text-muted-foreground/60 transition-colors hover:bg-white/[0.06] hover:text-muted-foreground">Dismiss</button></div></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function AttachmentChips($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    if (store_get($$store_subs ??= {}, "$attachments", attachments).length > 0) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex flex-wrap gap-1.5 px-4 pt-3 pb-1"><!--[-->`);
      const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$attachments", attachments));
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let att = each_array[$$index];
        $$renderer2.push(`<div class="group flex items-center gap-1.5 rounded-lg border border-border/60 bg-card/60 px-2 py-1 text-[12px] text-foreground/80 transition-colors hover:border-border">`);
        if (att.type === "image") {
          $$renderer2.push("<!--[-->");
          if (att.thumbnail) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<img${attr("src", `data:${att.mimeType ?? "image/png"};base64,${att.thumbnail}`)}${attr("alt", att.displayName)} class="h-5 w-5 shrink-0 rounded object-cover"/>`);
          } else {
            $$renderer2.push("<!--[!-->");
            Icon$1($$renderer2, {
              icon: Image01Icon,
              size: 14,
              strokeWidth: 1.5,
              class: "shrink-0 text-blue-400/70"
            });
          }
          $$renderer2.push(`<!--]-->`);
        } else {
          $$renderer2.push("<!--[!-->");
          Icon$1($$renderer2, {
            icon: CodeIcon,
            size: 14,
            strokeWidth: 1.5,
            class: "shrink-0 text-orange-400/70"
          });
        }
        $$renderer2.push(`<!--]--> <span class="max-w-[140px] truncate">${escape_html(att.displayName)}</span> `);
        if (att.type === "image" && att.width && att.height) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="text-[10px] text-muted-foreground/50">${escape_html(att.width)}×${escape_html(att.height)}</span>`);
        } else if (att.type === "file" && att.sizeBytes) {
          $$renderer2.push("<!--[1-->");
          $$renderer2.push(`<span class="text-[10px] text-muted-foreground/50">${escape_html(Math.round(att.sizeBytes / 1024))} KB</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <button class="ml-0.5 rounded p-0.5 text-muted-foreground/40 transition-colors hover:bg-destructive/20 hover:text-red-400" title="Remove">`);
        Icon$1($$renderer2, { icon: Cancel01Icon, size: 12, strokeWidth: 2 });
        $$renderer2.push(`<!----></button></div>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function ChatSearchBar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let query = "";
    let matches = [];
    let currentIndex = -1;
    const hasHighlightAPI = typeof CSS !== "undefined" && "highlights" in CSS;
    onDestroy(() => {
      clearHighlights();
    });
    function clearHighlights() {
      if (hasHighlightAPI) {
        CSS.highlights.delete("search-results");
        CSS.highlights.delete("search-current");
      }
      matches = [];
      currentIndex = -1;
    }
    $$renderer2.push(`<div class="absolute right-4 top-2 z-20 flex items-center gap-1 rounded-lg border border-border bg-card px-2 py-1.5 shadow-lg" style="box-shadow: 0 2px 12px rgba(0,0,0,0.25);"><input${attr("value", query)}${attr("placeholder", store_get($$store_subs ??= {}, "$t", t)("search_in_chat"))} spellcheck="false" class="w-[200px] bg-transparent px-1.5 text-[13px] text-foreground placeholder:text-muted-foreground/50 focus:outline-none"/> <span class="min-w-[60px] text-center text-[11px] text-muted-foreground/60">`);
    if (query.trim()) {
      $$renderer2.push("<!--[-->");
      if (matches.length > 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`${escape_html(store_get($$store_subs ??= {}, "$t", t)("n_of_m_matches", { n: currentIndex + 1, m: matches.length }))}`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`${escape_html(store_get($$store_subs ??= {}, "$t", t)("no_matches"))}`);
      }
      $$renderer2.push(`<!--]-->`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></span> <button class="flex h-6 w-6 items-center justify-center rounded text-muted-foreground/60 transition-colors hover:bg-accent hover:text-foreground disabled:opacity-30"${attr("disabled", matches.length === 0, true)}>`);
    Icon$1($$renderer2, { icon: ArrowUp01Icon, size: 14, strokeWidth: 2 });
    $$renderer2.push(`<!----></button> <button class="flex h-6 w-6 items-center justify-center rounded text-muted-foreground/60 transition-colors hover:bg-accent hover:text-foreground disabled:opacity-30"${attr("disabled", matches.length === 0, true)}>`);
    Icon$1($$renderer2, { icon: ArrowDown01Icon, size: 14, strokeWidth: 2 });
    $$renderer2.push(`<!----></button> <button class="flex h-6 w-6 items-center justify-center rounded text-muted-foreground/60 transition-colors hover:bg-accent hover:text-foreground">`);
    Icon$1($$renderer2, { icon: Cancel01Icon, size: 14, strokeWidth: 2 });
    $$renderer2.push(`<!----></button></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function ChatPane($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let { sessionId, isFocused, showPaneHeader = false, onStartSession } = $$props;
    let inputText = "";
    let contextPopupVisible = false;
    let contextQuery = "";
    let commandPopupVisible = false;
    let commandQuery = "";
    let chatSearchVisible = false;
    function handleGlobalKeydown(e) {
      if ((e.metaKey || e.ctrlKey) && e.key === "f") {
        e.preventDefault();
        chatSearchVisible = true;
      }
    }
    onDestroy(() => {
      window.removeEventListener("keydown", handleGlobalKeydown);
    });
    let paneMessages = sessionId ? store_get($$store_subs ??= {}, "$messagesBySession", messagesBySession)[sessionId] ?? [] : [];
    let paneIsStreaming = sessionId === store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId) ? store_get($$store_subs ??= {}, "$globalIsStreaming", isStreaming) : false;
    let sessionInfo = store_get($$store_subs ??= {}, "$sessions", sessions).find((s) => s.sessionId === sessionId);
    let sessionAgent = sessionInfo?.agentName ?? "";
    let paneState = sessionId ? store_get($$store_subs ??= {}, "$sessionStates", sessionStates)[sessionId] : void 0;
    let isWorking = paneState?.state === "prompting";
    let needsAttention = sessionId ? store_get($$store_subs ??= {}, "$sessionsNeedingAttention", sessionsNeedingAttention).has(sessionId) : false;
    let waitingForMcp = store_get($$store_subs ??= {}, "$currentMcpStatus", currentMcpStatus) === "waiting" && isFocused;
    let panePermission = (() => {
      if (!sessionId) return null;
      const queue = store_get($$store_subs ??= {}, "$permissionQueues", permissionQueues)[sessionId] ?? [];
      return queue[0] ?? null;
    })();
    let paneCommands = store_get($$store_subs ??= {}, "$availableCommands", availableCommands);
    store_get($$store_subs ??= {}, "$currentPlan", currentPlan);
    let paneHasPlan = store_get($$store_subs ??= {}, "$hasPlan", hasPlan);
    let hasModels = store_get($$store_subs ??= {}, "$models", models).length > 0;
    let modelOptions = store_get($$store_subs ??= {}, "$models", models).filter((m) => m.id !== "special:browse_all");
    let currentModel = store_get($$store_subs ??= {}, "$models", models).find((m) => m.id === store_get($$store_subs ??= {}, "$currentModelId", currentModelId));
    let modelDisplayName = currentModel?.name ?? store_get($$store_subs ??= {}, "$currentModelId", currentModelId) ?? "Model";
    let groupedModelOptions = (() => {
      const groups = [];
      const map = /* @__PURE__ */ new Map();
      for (const m of modelOptions) {
        const key = m.providerDisplayName || m.provider || "";
        if (!map.has(key)) map.set(key, []);
        map.get(key).push(m);
      }
      for (const [provider, models2] of map) {
        if (provider.toLowerCase() !== "openrouter") {
          groups.push({ provider, models: models2 });
        }
      }
      const orModels = map.get("OpenRouter") ?? map.get("openrouter");
      if (orModels) groups.push({ provider: "OpenRouter", models: orModels });
      return groups;
    })();
    let currentModelSupportsReasoning = currentModel?.supportsReasoning ?? false;
    const reasoningLevels = ["none", "low", "medium", "high", "max"];
    let hasModes = store_get($$store_subs ??= {}, "$availableModes", availableModes).length > 0;
    let currentMode = store_get($$store_subs ??= {}, "$availableModes", availableModes).find((m) => m.id === store_get($$store_subs ??= {}, "$currentModeId", currentModeId));
    let modeDisplayName = currentMode?.name ?? store_get($$store_subs ??= {}, "$currentModeId", currentModeId) ?? "Default";
    let isPlanMode = isInPlanMode(store_get($$store_subs ??= {}, "$currentModeId", currentModeId));
    let usageHasContext = store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).contextSize > 0;
    let usageHasTokens = store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).inputTokens > 0 || store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).outputTokens > 0;
    let usageHasCost = store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).costAmount > 0;
    let usageContextLabel = (() => {
      if (usageHasContext) return `${store_get($$store_subs ??= {}, "$contextPercent", contextPercent)}%`;
      if (usageHasTokens) return `${formatTokens(store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).inputTokens + store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).outputTokens)}`;
      return "";
    })();
    let agentReady = (() => {
      if (waitingForMcp) return false;
      const state = paneState?.state;
      if (state === "ready" || state === "in_session" || state === "prompting") return true;
      if (!state && sessionId) return true;
      return false;
    })();
    let canSend = inputText.trim().length > 0 && !!sessionId && !paneIsStreaming && agentReady;
    let inputPlaceholder = waitingForMcp ? store_get($$store_subs ??= {}, "$t", t)("connecting_tools") : !agentReady ? store_get($$store_subs ??= {}, "$t", t)("waiting_for_agent") : paneMessages.length > 0 ? store_get($$store_subs ??= {}, "$t", t)("ask_follow_up") : store_get($$store_subs ??= {}, "$t", t)("describe_task");
    const INITIAL_WINDOW = 40;
    const WINDOW_INCREMENT = 30;
    let messageWindow = INITIAL_WINDOW;
    let visibleMessages = paneMessages.length <= messageWindow ? paneMessages : paneMessages.slice(-messageWindow);
    let hasHiddenMessages = paneMessages.length > messageWindow;
    function resizeTextarea() {
      return;
    }
    function handleContextSelect(item) {
      return;
    }
    function handleContextNavigate(folderPath) {
      return;
    }
    function handleCommandSelect(cmd) {
      return;
    }
    function getInputText() {
      return inputText;
    }
    function setInputText(text) {
      inputText = text;
      tick().then(() => resizeTextarea());
    }
    $$renderer2.push(`<div class="flex h-full flex-col overflow-hidden">`);
    if (!sessionId) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex h-full flex-col items-center justify-center gap-4 px-6"><span class="text-muted-foreground/40 text-[13px]">${escape_html(store_get($$store_subs ??= {}, "$t", t)("start_with"))}</span> <div class="flex flex-wrap items-center justify-center gap-2"><!--[-->`);
      const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$agents", agents).filter((a) => a.status === "available"));
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let agent = each_array[$$index];
        $$renderer2.push(`<button class="flex items-center gap-2 rounded-lg border border-border/60 bg-secondary/40 px-3 py-2 text-[12px] text-foreground transition-colors hover:bg-secondary hover:border-border">`);
        if (agent.iconUrl) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="flex h-4 w-4 items-center justify-center shrink-0"${attr_style(`color: ${stringify(agent.color)};`)}><img${attr("src", agent.iconUrl)} alt="" class="h-4 w-4 invert opacity-70"/></span>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<span class="flex h-4 w-4 items-center justify-center rounded text-[7px] font-bold text-white shrink-0"${attr_style(`background-color: ${stringify(agent.color)};`)}>${escape_html(agent.letter)}</span>`);
        }
        $$renderer2.push(`<!--]--> <span>${escape_html(agent.shortName)}</span></button>`);
      }
      $$renderer2.push(`<!--]--></div> <span class="text-muted-foreground/25 text-[11px]">or select a session from the sidebar</span></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      if (showPaneHeader) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="flex h-7 shrink-0 items-center justify-between border-b border-border/40 px-3 text-[11px]"><div class="flex items-center gap-1.5 min-w-0">`);
        if (needsAttention) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="h-2 w-2 shrink-0 rounded-full bg-amber-500 animate-pulse" title="Needs permission"></span>`);
        } else if (isWorking) {
          $$renderer2.push("<!--[1-->");
          $$renderer2.push(`<span class="h-2 w-2 shrink-0 rounded-full bg-blue-500 animate-pulse"></span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <span class="truncate text-muted-foreground">${escape_html(sessionInfo?.title || store_get($$store_subs ??= {}, "$t", t)("new_chat"))}</span> <span class="shrink-0 text-muted-foreground/40">${escape_html(sessionAgent)}</span></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <div class="relative flex-1 overflow-hidden">`);
      if (chatSearchVisible) {
        $$renderer2.push("<!--[-->");
        ChatSearchBar($$renderer2);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <div class="chat-scroll-area h-full overflow-y-auto px-6 pt-4 pb-52">`);
      AuthBanner($$renderer2);
      $$renderer2.push(`<!----> `);
      if (paneMessages.length === 0 && !paneIsStreaming) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="flex h-full flex-col items-center justify-center gap-3 text-muted-foreground/40">`);
        if (store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent)?.iconUrl) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span${attr_style(`color: ${stringify(store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).color)}; opacity: 0.3;`)}><img${attr("src", store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).iconUrl)} alt="" class="h-10 w-10 invert opacity-70"/></span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <span class="text-[14px]">${escape_html(store_get($$store_subs ??= {}, "$t", t)("send_message_to_get_started"))}</span></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        if (hasHiddenMessages) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="flex justify-center py-2"><button class="rounded-md border border-border/50 bg-secondary/40 px-3 py-1 text-[11px] text-muted-foreground/60 transition-colors hover:bg-secondary hover:text-muted-foreground">Show ${escape_html(Math.min(WINDOW_INCREMENT, paneMessages.length - messageWindow))} earlier messages</button></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <!--[-->`);
        const each_array_1 = ensure_array_like(visibleMessages);
        for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
          let message = each_array_1[$$index_1];
          ChatMessage($$renderer2, { message });
        }
        $$renderer2.push(`<!--]-->`);
      }
      $$renderer2.push(`<!--]--> `);
      if (paneIsStreaming && paneMessages[paneMessages.length - 1]?.role !== "assistant") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="mb-4 flex justify-start"><div class="flex items-center gap-2 text-[12px]">`);
        Shimmer($$renderer2, {
          children: ($$renderer3) => {
            $$renderer3.push(`<span>${escape_html(store_get($$store_subs ??= {}, "$t", t)("generating"))}</span>`);
          },
          $$slots: { default: true }
        });
        $$renderer2.push(`<!----></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <div class="pointer-events-none absolute inset-x-0 bottom-0 z-10 px-6 pb-3 pt-8" style="background: linear-gradient(to bottom, transparent, var(--background) 40%);"><div class="pointer-events-auto mx-auto max-w-3xl"><div${attr_class(`relative rounded-2xl border transition-colors focus-within:border-[var(--ue-accent-muted)] ${stringify("border-border bg-card")}`)} style="box-shadow: 0 0 0 1px rgba(0,0,0,0.2), 0 2px 8px rgba(0,0,0,0.15);" role="region" aria-label="Message input">`);
      if (paneHasPlan && isFocused) {
        $$renderer2.push("<!--[-->");
        PlanPanel($$renderer2);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (panePermission) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="p-3">`);
        if (panePermission.isAskUserQuestion) {
          $$renderer2.push("<!--[-->");
          AskUserDialog($$renderer2, { request: panePermission });
        } else {
          $$renderer2.push("<!--[!-->");
          PermissionDialog($$renderer2, { request: panePermission });
        }
        $$renderer2.push(`<!--]--></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        ContextPopup($$renderer2, {
          query: contextQuery,
          visible: contextPopupVisible,
          onselect: handleContextSelect,
          onnavigate: handleContextNavigate,
          ondismiss: () => {
            contextPopupVisible = false;
          }
        });
        $$renderer2.push(`<!----> `);
        CommandPopup($$renderer2, {
          query: commandQuery,
          visible: commandPopupVisible,
          commands: paneCommands,
          onselect: handleCommandSelect,
          ondismiss: () => {
            commandPopupVisible = false;
          }
        });
        $$renderer2.push(`<!----> `);
        if (waitingForMcp) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="flex items-center gap-2 px-4 pt-3 pb-1"><span class="inline-block h-2 w-2 animate-pulse rounded-full bg-amber-500"></span> <span class="text-[13px] text-amber-400/80">${escape_html(store_get($$store_subs ??= {}, "$t", t)("connecting_tools"))}</span></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> `);
        AttachmentChips($$renderer2);
        $$renderer2.push(`<!----> <textarea${attr("placeholder", inputPlaceholder)}${attr("disabled", !sessionId || !agentReady, true)}${attr("rows", 1)} spellcheck="false" autocomplete="off" autocorrect="off" class="w-full resize-none bg-transparent px-4 pt-3.5 pb-3 text-[14px] leading-normal text-foreground placeholder:text-muted-foreground/60 focus:outline-none disabled:opacity-50">`);
        const $$body = escape_html(inputText);
        if ($$body) {
          $$renderer2.push(`${$$body}`);
        }
        $$renderer2.push(`</textarea> <div class="flex items-center justify-between px-3 pb-2.5"><div class="flex items-center gap-1.5"><button class="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"${attr("title", store_get($$store_subs ??= {}, "$t", t)("attach_file"))}>`);
        Icon$1($$renderer2, { icon: Add01Icon, size: 18, strokeWidth: 1.5 });
        $$renderer2.push(`<!----></button> `);
        if (hasModels || store_get($$store_subs ??= {}, "$isLoadingModels", isLoadingModels)) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push("<!---->");
          Dropdown_menu?.($$renderer2, {
            children: ($$renderer3) => {
              $$renderer3.push("<!---->");
              Dropdown_menu_trigger?.($$renderer3, {
                class: "flex items-center gap-1 rounded-lg px-2 py-1 text-[12px] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground",
                disabled: store_get($$store_subs ??= {}, "$isLoadingModels", isLoadingModels),
                children: ($$renderer4) => {
                  if (store_get($$store_subs ??= {}, "$isLoadingModels", isLoadingModels)) {
                    $$renderer4.push("<!--[-->");
                    $$renderer4.push(`<span class="inline-block h-3 w-3 animate-spin rounded-full border-2 border-muted-foreground/30 border-t-muted-foreground"></span>`);
                  } else {
                    $$renderer4.push("<!--[!-->");
                    $$renderer4.push(`${escape_html(modelDisplayName)} `);
                    Icon$1($$renderer4, {
                      icon: ArrowDown01Icon,
                      size: 10,
                      strokeWidth: 1.5,
                      class: "opacity-50"
                    });
                    $$renderer4.push(`<!---->`);
                  }
                  $$renderer4.push(`<!--]-->`);
                },
                $$slots: { default: true }
              });
              $$renderer3.push(`<!----> `);
              $$renderer3.push("<!---->");
              Dropdown_menu_content?.($$renderer3, {
                class: "max-h-[300px] w-[280px] overflow-y-auto",
                side: "top",
                align: "start",
                sideOffset: 4,
                children: ($$renderer4) => {
                  $$renderer4.push(`<!--[-->`);
                  const each_array_2 = ensure_array_like(groupedModelOptions);
                  for (let gi = 0, $$length = each_array_2.length; gi < $$length; gi++) {
                    let group = each_array_2[gi];
                    if (gi > 0) {
                      $$renderer4.push("<!--[-->");
                      $$renderer4.push("<!---->");
                      Dropdown_menu_separator?.($$renderer4, {});
                      $$renderer4.push(`<!---->`);
                    } else {
                      $$renderer4.push("<!--[!-->");
                    }
                    $$renderer4.push(`<!--]--> `);
                    $$renderer4.push("<!---->");
                    Dropdown_menu_label?.($$renderer4, {
                      class: "text-[11px] text-muted-foreground",
                      children: ($$renderer5) => {
                        $$renderer5.push(`<!---->${escape_html(group.provider || store_get($$store_subs ??= {}, "$t", t)("model_label"))}`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer4.push(`<!----> <!--[-->`);
                    const each_array_3 = ensure_array_like(group.models);
                    for (let $$index_2 = 0, $$length2 = each_array_3.length; $$index_2 < $$length2; $$index_2++) {
                      let model = each_array_3[$$index_2];
                      $$renderer4.push("<!---->");
                      Dropdown_menu_item?.($$renderer4, {
                        class: "flex items-center gap-2 px-2 py-1.5",
                        onclick: () => store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent) && changeModel(store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).name, model.id),
                        children: ($$renderer5) => {
                          $$renderer5.push(`<div class="flex-1 min-w-0"><div class="text-[13px] truncate">${escape_html(model.name)}</div> `);
                          if (model.description) {
                            $$renderer5.push("<!--[-->");
                            $$renderer5.push(`<div class="text-[11px] text-muted-foreground/40 truncate">${escape_html(model.description)}</div>`);
                          } else {
                            $$renderer5.push("<!--[!-->");
                          }
                          $$renderer5.push(`<!--]--></div> `);
                          if (model.id === store_get($$store_subs ??= {}, "$currentModelId", currentModelId)) {
                            $$renderer5.push("<!--[-->");
                            $$renderer5.push(`<span class="h-1.5 w-1.5 shrink-0 rounded-full bg-foreground"></span>`);
                          } else {
                            $$renderer5.push("<!--[!-->");
                          }
                          $$renderer5.push(`<!--]-->`);
                        },
                        $$slots: { default: true }
                      });
                      $$renderer4.push(`<!---->`);
                    }
                    $$renderer4.push(`<!--]-->`);
                  }
                  $$renderer4.push(`<!--]-->`);
                },
                $$slots: { default: true }
              });
              $$renderer3.push(`<!---->`);
            },
            $$slots: { default: true }
          });
          $$renderer2.push(`<!---->`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> `);
        if (hasModels && !store_get($$store_subs ??= {}, "$isLoadingModels", isLoadingModels) && currentModelSupportsReasoning) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push("<!---->");
          Dropdown_menu?.($$renderer2, {
            children: ($$renderer3) => {
              $$renderer3.push("<!---->");
              Dropdown_menu_trigger?.($$renderer3, {
                class: `flex items-center gap-1 rounded-lg px-2 py-1 text-[12px] transition-colors ${stringify(store_get($$store_subs ??= {}, "$reasoningLevel", reasoningLevel) !== "none" ? "text-[var(--ue-accent)] hover:text-[var(--ue-accent-hover)]" : "text-muted-foreground hover:bg-accent hover:text-foreground")}`,
                children: ($$renderer4) => {
                  $$renderer4.push(`<!---->${escape_html(reasoningLabels[store_get($$store_subs ??= {}, "$reasoningLevel", reasoningLevel)])} `);
                  Icon$1($$renderer4, {
                    icon: ArrowDown01Icon,
                    size: 10,
                    strokeWidth: 1.5,
                    class: "opacity-50"
                  });
                  $$renderer4.push(`<!---->`);
                },
                $$slots: { default: true }
              });
              $$renderer3.push(`<!----> `);
              $$renderer3.push("<!---->");
              Dropdown_menu_content?.($$renderer3, {
                class: "w-[160px]",
                side: "top",
                align: "start",
                sideOffset: 4,
                children: ($$renderer4) => {
                  $$renderer4.push("<!---->");
                  Dropdown_menu_label?.($$renderer4, {
                    class: "text-[11px] text-muted-foreground",
                    children: ($$renderer5) => {
                      $$renderer5.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("effort"))}`);
                    },
                    $$slots: { default: true }
                  });
                  $$renderer4.push(`<!----> <!--[-->`);
                  const each_array_4 = ensure_array_like(reasoningLevels);
                  for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
                    let level = each_array_4[$$index_4];
                    $$renderer4.push("<!---->");
                    Dropdown_menu_item?.($$renderer4, {
                      class: "flex items-center justify-between px-2 py-1.5",
                      onclick: () => changeReasoningLevel(level),
                      children: ($$renderer5) => {
                        $$renderer5.push(`<span class="text-[13px]">${escape_html(reasoningLabels[level])}</span> `);
                        if (level === store_get($$store_subs ??= {}, "$reasoningLevel", reasoningLevel)) {
                          $$renderer5.push("<!--[-->");
                          $$renderer5.push(`<span class="h-1.5 w-1.5 shrink-0 rounded-full bg-foreground"></span>`);
                        } else {
                          $$renderer5.push("<!--[!-->");
                        }
                        $$renderer5.push(`<!--]-->`);
                      },
                      $$slots: { default: true }
                    });
                    $$renderer4.push(`<!---->`);
                  }
                  $$renderer4.push(`<!--]-->`);
                },
                $$slots: { default: true }
              });
              $$renderer3.push(`<!---->`);
            },
            $$slots: { default: true }
          });
          $$renderer2.push(`<!---->`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div> <div class="flex items-center gap-1.5">`);
        if (paneIsStreaming) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<button class="flex h-8 w-8 items-center justify-center rounded-full bg-red-500/90 text-white transition-all hover:bg-red-500 hover:scale-105 active:scale-95" style="box-shadow: 0 0 10px rgba(220,80,40,0.3);"${attr("title", store_get($$store_subs ??= {}, "$t", t)("stop_generating"))}>`);
          Icon$1($$renderer2, { icon: StopIcon, size: 16, strokeWidth: 2.5 });
          $$renderer2.push(`<!----></button>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<button${attr_class(`flex h-8 w-8 items-center justify-center rounded-full transition-all ${stringify(canSend ? "text-white hover:scale-105 active:scale-95" : "bg-muted-foreground/20 text-muted-foreground/40 cursor-not-allowed")}`)}${attr_style(canSend ? "background: var(--ue-accent); box-shadow: 0 0 12px rgba(50,130,230,0.35);" : "")}${attr("disabled", !canSend, true)}>`);
          Icon$1($$renderer2, { icon: ArrowUp01Icon, size: 18, strokeWidth: 2.5 });
          $$renderer2.push(`<!----></button>`);
        }
        $$renderer2.push(`<!--]--></div></div>`);
      }
      $$renderer2.push(`<!--]--></div> <div class="mt-2.5 flex items-center justify-between px-1 text-[12px] text-muted-foreground/70"><div class="flex items-center gap-4">`);
      if (hasModes) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push("<!---->");
        Dropdown_menu?.($$renderer2, {
          children: ($$renderer3) => {
            $$renderer3.push("<!---->");
            Dropdown_menu_trigger?.($$renderer3, {
              class: `flex items-center gap-1.5 transition-colors hover:text-foreground ${stringify(isPlanMode ? "text-blue-400" : "")}`,
              children: ($$renderer4) => {
                Icon$1($$renderer4, { icon: ChangeScreenModeIcon, size: 14, strokeWidth: 1.5 });
                $$renderer4.push(`<!----> ${escape_html(modeDisplayName)} `);
                Icon$1($$renderer4, {
                  icon: ArrowDown01Icon,
                  size: 10,
                  strokeWidth: 1.5,
                  class: "opacity-50"
                });
                $$renderer4.push(`<!---->`);
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!----> `);
            $$renderer3.push("<!---->");
            Dropdown_menu_content?.($$renderer3, {
              class: "w-[220px]",
              side: "top",
              align: "start",
              sideOffset: 4,
              children: ($$renderer4) => {
                $$renderer4.push("<!---->");
                Dropdown_menu_label?.($$renderer4, {
                  class: "text-[11px] text-muted-foreground",
                  children: ($$renderer5) => {
                    $$renderer5.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("mode_label"))}`);
                  },
                  $$slots: { default: true }
                });
                $$renderer4.push(`<!----> <!--[-->`);
                const each_array_5 = ensure_array_like(store_get($$store_subs ??= {}, "$availableModes", availableModes));
                for (let $$index_5 = 0, $$length = each_array_5.length; $$index_5 < $$length; $$index_5++) {
                  let mode = each_array_5[$$index_5];
                  $$renderer4.push("<!---->");
                  Dropdown_menu_item?.($$renderer4, {
                    class: "flex items-center gap-2 px-2 py-1.5",
                    onclick: () => store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent) && changeMode(store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).name, mode.id),
                    children: ($$renderer5) => {
                      $$renderer5.push(`<div class="flex-1 min-w-0"><div class="text-[13px] truncate">${escape_html(mode.name)}</div> `);
                      if (mode.description) {
                        $$renderer5.push("<!--[-->");
                        $$renderer5.push(`<div class="text-[11px] text-muted-foreground/40 truncate">${escape_html(mode.description)}</div>`);
                      } else {
                        $$renderer5.push("<!--[!-->");
                      }
                      $$renderer5.push(`<!--]--></div> `);
                      if (mode.id === store_get($$store_subs ??= {}, "$currentModeId", currentModeId)) {
                        $$renderer5.push("<!--[-->");
                        $$renderer5.push(`<span class="h-1.5 w-1.5 shrink-0 rounded-full bg-foreground"></span>`);
                      } else {
                        $$renderer5.push("<!--[!-->");
                      }
                      $$renderer5.push(`<!--]-->`);
                    },
                    $$slots: { default: true }
                  });
                  $$renderer4.push(`<!---->`);
                }
                $$renderer4.push(`<!--]-->`);
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!---->`);
          },
          $$slots: { default: true }
        });
        $$renderer2.push(`<!---->`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div> <div class="flex items-center gap-3">`);
      if (store_get($$store_subs ??= {}, "$hasUsage", hasUsage)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push("<!---->");
        Tooltip?.($$renderer2, {
          children: ($$renderer3) => {
            $$renderer3.push("<!---->");
            Tooltip_trigger?.($$renderer3, {
              class: "flex items-center gap-1.5 transition-colors hover:text-foreground",
              children: ($$renderer4) => {
                const pct = store_get($$store_subs ??= {}, "$contextPercent", contextPercent);
                const strokeColor = pct < 50 ? "#22c55e" : pct < 80 ? "#eab308" : "#ef4444";
                const circumference = 2 * Math.PI * 7;
                const dashOffset = circumference * (1 - pct / 100);
                $$renderer4.push(`<svg width="16" height="16" viewBox="0 0 18 18"><circle cx="9" cy="9" r="7" fill="none" stroke="currentColor" stroke-width="2.5" opacity="0.15"></circle><circle cx="9" cy="9" r="7" fill="none"${attr("stroke", strokeColor)} stroke-width="2.5"${attr("stroke-dasharray", circumference)}${attr("stroke-dashoffset", dashOffset)} stroke-linecap="round" transform="rotate(-90 9 9)"></circle></svg> <span class="text-[12px]">${escape_html(usageContextLabel)}</span>`);
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!----> `);
            $$renderer3.push("<!---->");
            Tooltip_content?.($$renderer3, {
              side: "top",
              sideOffset: 6,
              class: "w-[260px] !bg-popover !text-popover-foreground p-3 text-[12px]",
              arrowClasses: "!bg-popover",
              children: ($$renderer4) => {
                $$renderer4.push(`<div class="mb-1.5 text-[13px] font-medium">${escape_html(store_get($$store_subs ??= {}, "$t", t)("context_window"))}</div> <div class="mb-2.5 text-[11px] leading-relaxed text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("context_window_desc"))}</div> `);
                if (usageHasContext) {
                  $$renderer4.push("<!--[-->");
                  const pctVal = store_get($$store_subs ??= {}, "$contextPercent", contextPercent);
                  const remaining = 100 - pctVal;
                  $$renderer4.push(`<div class="mb-1 text-muted-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("used_left_pct", { used: pctVal, left: remaining }))}</div> <div class="mb-2 h-1.5 w-full overflow-hidden rounded-full bg-muted-foreground/15"><div class="h-full rounded-full transition-all duration-300"${attr_style(`width: ${stringify(pctVal)}%; background-color: ${stringify(pctVal < 50 ? "#22c55e" : pctVal < 80 ? "#eab308" : "#ef4444")};`)}></div></div> <div class="text-muted-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("tokens_used", {
                    used: formatTokens(store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).contextUsed),
                    total: formatTokens(store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).contextSize)
                  }))}</div>`);
                } else if (usageHasTokens) {
                  $$renderer4.push("<!--[1-->");
                  $$renderer4.push(`<div class="text-muted-foreground">${escape_html(formatTokens(store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).inputTokens))} input, ${escape_html(formatTokens(store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).outputTokens))} output</div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> `);
                if (store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).cacheReadTokens > 0) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<div class="mt-1 text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("cached", {
                    count: formatTokens(store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).cacheReadTokens)
                  }))}</div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> `);
                if (usageHasCost) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<div class="mt-1.5 border-t border-border/40 pt-1.5 text-muted-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("session_cost"))}: ${escape_html(formatCost(store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).costAmount, store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).costCurrency))} `);
                  if (store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).turnCostUSD > 0) {
                    $$renderer4.push("<!--[-->");
                    $$renderer4.push(`<span class="text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("last_turn_cost", {
                      cost: formatCost(store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).turnCostUSD)
                    }))}</span>`);
                  } else {
                    $$renderer4.push("<!--[!-->");
                  }
                  $$renderer4.push(`<!--]--></div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> `);
                if (store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).numTurns > 0) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<div class="mt-1 text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("turns", {
                    count: store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).numTurns
                  }))} `);
                  if (store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).durationMs > 0) {
                    $$renderer4.push("<!--[-->");
                    $$renderer4.push(`· ${escape_html((store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).durationMs / 1e3).toFixed(1))}s`);
                  } else {
                    $$renderer4.push("<!--[!-->");
                  }
                  $$renderer4.push(`<!--]--></div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]-->`);
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!---->`);
          },
          $$slots: { default: true }
        });
        $$renderer2.push(`<!---->`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (store_get($$store_subs ??= {}, "$scEnabled", scEnabled)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push("<!---->");
        Dropdown_menu?.($$renderer2, {
          children: ($$renderer3) => {
            $$renderer3.push("<!---->");
            Dropdown_menu_trigger?.($$renderer3, {
              class: "flex items-center gap-1.5 transition-colors hover:text-foreground",
              children: ($$renderer4) => {
                Icon$1($$renderer4, { icon: GitBranchIcon, size: 14, strokeWidth: 1.5 });
                $$renderer4.push(`<!----> ${escape_html(store_get($$store_subs ??= {}, "$branchName", branchName) || "...")} `);
                if (store_get($$store_subs ??= {}, "$hasChanges", hasChanges)) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<span class="rounded-full bg-amber-500/20 px-1.5 text-[10px] font-medium text-amber-400">${escape_html(store_get($$store_subs ??= {}, "$changesLabel", changesLabel))}</span>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> `);
                Icon$1($$renderer4, {
                  icon: ArrowDown01Icon,
                  size: 10,
                  strokeWidth: 1.5,
                  class: "opacity-50"
                });
                $$renderer4.push(`<!---->`);
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!----> `);
            $$renderer3.push("<!---->");
            Dropdown_menu_content?.($$renderer3, {
              class: "w-[200px]",
              side: "top",
              align: "end",
              sideOffset: 4,
              children: ($$renderer4) => {
                $$renderer4.push("<!---->");
                Dropdown_menu_label?.($$renderer4, {
                  class: "text-[11px] text-muted-foreground",
                  children: ($$renderer5) => {
                    $$renderer5.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("source_control"))}`);
                  },
                  $$slots: { default: true }
                });
                $$renderer4.push(`<!----> `);
                $$renderer4.push("<!---->");
                Dropdown_menu_item?.($$renderer4, {
                  class: "flex items-center gap-2 px-2 py-1.5",
                  onclick: () => openSourceControlChangelist(),
                  children: ($$renderer5) => {
                    $$renderer5.push(`<span class="text-[13px]">${escape_html(store_get($$store_subs ??= {}, "$t", t)("view_changelists"))}</span>`);
                  },
                  $$slots: { default: true }
                });
                $$renderer4.push(`<!----> `);
                $$renderer4.push("<!---->");
                Dropdown_menu_item?.($$renderer4, {
                  class: "flex items-center gap-2 px-2 py-1.5",
                  onclick: () => openSourceControlSubmit(),
                  children: ($$renderer5) => {
                    $$renderer5.push(`<span class="text-[13px]">${escape_html(store_get($$store_subs ??= {}, "$t", t)("submit_changes"))}</span>`);
                  },
                  $$slots: { default: true }
                });
                $$renderer4.push(`<!---->`);
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!---->`);
          },
          $$slots: { default: true }
        });
        $$renderer2.push(`<!---->`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<span class="flex items-center gap-1.5 text-muted-foreground/40">`);
        Icon$1($$renderer2, { icon: GitBranchIcon, size: 14, strokeWidth: 1.5 });
        $$renderer2.push(`<!----> ${escape_html(store_get($$store_subs ??= {}, "$t", t)("no_vcs"))}</span>`);
      }
      $$renderer2.push(`<!--]--></div></div></div></div></div>`);
    }
    $$renderer2.push(`<!--]--></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { getInputText, setInputText });
  });
}
const providers = writable([]);
const providersLoaded = writable(false);
derived$1(providers, ($providers) => {
  const actions = [];
  for (const p of $providers) {
    for (const a of p.actions) {
      actions.push({
        ...a,
        providerId: p.id,
        providerName: p.displayName
      });
    }
  }
  return actions;
});
const uniqueActions = derived$1(providers, ($providers) => {
  const map = /* @__PURE__ */ new Map();
  for (const p of $providers) {
    for (const a of p.actions) {
      if (!map.has(a.actionId)) {
        map.set(a.actionId, {
          actionId: a.actionId,
          description: a.description,
          inputHints: a.inputHints,
          outputHints: a.outputHints,
          providers: []
        });
      }
      map.get(a.actionId).providers.push({
        id: p.id,
        name: p.displayName,
        creditCost: a.creditCost
      });
    }
  }
  return Array.from(map.values());
});
const jobs = writable([]);
const balances = writable({});
function StudioPage($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    const actionIcons = {
      text_to_image: { icon: Image02Icon, color: "#f59e0b" },
      image_to_image: { icon: Image02Icon, color: "#e67e22" },
      text_to_3d: { icon: CubeIcon, color: "#3b82f6" },
      image_to_3d: { icon: CubeIcon, color: "#8b5cf6" },
      multi_image_to_3d: { icon: CubeIcon, color: "#7c3aed" },
      refine: { icon: PaintBrushIcon, color: "#10b981" },
      retexture: { icon: PaintBrushIcon, color: "#14b8a6" },
      remesh: { icon: RepeatIcon, color: "#6366f1" },
      rig: { icon: BodyPartMuscleIcon, color: "#ef4444" },
      animate: { icon: RunningShoesIcon, color: "#ec4899" },
      balance: { icon: RefreshIcon, color: "#6b7280" }
    };
    function getActionVisual(actionId) {
      return actionIcons[actionId] ?? { icon: CubeIcon, color: "#6b7280" };
    }
    let filterCategory = "all";
    let filteredActions = store_get($$store_subs ??= {}, "$uniqueActions", uniqueActions).filter((a) => {
      if (a.actionId === "balance") return false;
      return true;
    });
    let activeJobs = store_get($$store_subs ??= {}, "$jobs", jobs).filter((j) => j.status === "running" || j.status === "pending");
    let completedJobs = store_get($$store_subs ??= {}, "$jobs", jobs).filter((j) => j.status === "succeeded" || j.status === "failed");
    function statusColor(status) {
      switch (status) {
        case "succeeded":
          return "bg-emerald-400";
        case "running":
          return "bg-blue-400 animate-pulse";
        case "pending":
          return "bg-muted-foreground/40";
        case "failed":
          return "bg-red-400";
        case "cancelled":
          return "bg-muted-foreground/30";
        default:
          return "bg-muted-foreground/30";
      }
    }
    function statusLabel(status) {
      switch (status) {
        case "succeeded":
          return "Complete";
        case "running":
          return "Generating";
        case "pending":
          return "Queued";
        case "failed":
          return "Failed";
        case "cancelled":
          return "Cancelled";
        default:
          return status;
      }
    }
    function timeAgo(ts) {
      const diff = Date.now() - ts;
      const mins = Math.floor(diff / 6e4);
      if (mins < 1) return "just now";
      if (mins < 60) return `${mins}m ago`;
      const hrs = Math.floor(mins / 60);
      if (hrs < 24) return `${hrs}h ago`;
      return `${Math.floor(hrs / 24)}d ago`;
    }
    function formatActionId(id) {
      return id.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
    }
    $$renderer2.push(`<div class="flex h-full w-full flex-col overflow-hidden bg-background"><header class="flex h-10 shrink-0 items-center justify-between border-b border-border bg-[#222] px-4"><div class="flex items-center gap-3"><h1 class="text-[13px] font-medium text-foreground">Studio</h1> <div class="h-4 w-px bg-border/60"></div> <div class="flex items-center gap-0.5"><!--[-->`);
    const each_array = ensure_array_like([
      { id: "all", label: "All" },
      { id: "image", label: "Images" },
      { id: "3d", label: "3D Models" },
      { id: "pipeline", label: "Pipeline" }
    ]);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let cat = each_array[$$index];
      $$renderer2.push(`<button${attr_class(`rounded-md px-2 py-1 text-[11px] font-medium transition-colors ${stringify(filterCategory === cat.id ? "bg-accent text-foreground" : "text-muted-foreground hover:text-foreground")}`)}>${escape_html(cat.label)}</button>`);
    }
    $$renderer2.push(`<!--]--></div></div> <div class="flex items-center gap-3 text-[11px] text-muted-foreground/60"><!--[-->`);
    const each_array_1 = ensure_array_like(Object.entries(store_get($$store_subs ??= {}, "$balances", balances)));
    for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
      let [pid, bal] = each_array_1[$$index_1];
      const provider = store_get($$store_subs ??= {}, "$providers", providers).find((p) => p.id === pid);
      if (bal >= 0 && provider) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="rounded bg-secondary/50 px-1.5 py-0.5 text-[10px]">${escape_html(provider.displayName)}: ${escape_html(bal)} credits</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--> <span>${escape_html(activeJobs.length)} active</span> <span class="text-border">|</span> <span>${escape_html(completedJobs.length)} completed</span></div></header> <div class="flex min-h-0 flex-1 overflow-hidden"><div class="flex-1 overflow-y-auto px-6 py-5">`);
    if (!store_get($$store_subs ??= {}, "$providersLoaded", providersLoaded)) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center justify-center py-20"><div class="flex items-center gap-2 text-[13px] text-muted-foreground/60">`);
      Icon$1($$renderer2, { icon: Loading03Icon, size: 16, class: "animate-spin" });
      $$renderer2.push(`<!----> <span>Loading providers...</span></div></div>`);
    } else {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div class="mx-auto max-w-4xl">`);
      if (filteredActions.length === 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="flex flex-col items-center justify-center py-20 text-center"><p class="text-[13px] text-muted-foreground/60">No generative providers registered.</p> <p class="mt-1 text-[11px] text-muted-foreground/40">Configure API keys in Settings to enable generation.</p></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="mb-3 flex items-center gap-2"><span class="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50">Actions</span> <div class="h-px flex-1 bg-border/30"></div> <span class="text-[10px] text-muted-foreground/40">${escape_html(filteredActions.length)} available</span></div> <div class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3"><!--[-->`);
        const each_array_2 = ensure_array_like(filteredActions);
        for (let $$index_3 = 0, $$length = each_array_2.length; $$index_3 < $$length; $$index_3++) {
          let action = each_array_2[$$index_3];
          const visual = getActionVisual(action.actionId);
          $$renderer2.push(`<button class="group relative flex flex-col rounded-xl border border-border/60 bg-card/40 p-4 text-left transition-all duration-150 hover:border-border hover:bg-card/80 active:scale-[0.98]"><div class="mb-2.5 flex items-start justify-between"><div class="flex h-9 w-9 items-center justify-center rounded-lg"${attr_style(`background-color: ${stringify(visual.color)}15; color: ${stringify(visual.color)};`)}>`);
          Icon$1($$renderer2, { icon: visual.icon, size: 18, strokeWidth: 1.5 });
          $$renderer2.push(`<!----></div> `);
          Icon$1($$renderer2, {
            icon: ArrowRight01Icon,
            size: 14,
            strokeWidth: 1.5,
            class: "mt-1 text-muted-foreground/0 transition-all duration-150 group-hover:text-muted-foreground/60 group-hover:translate-x-0.5"
          });
          $$renderer2.push(`<!----></div> <h3 class="mb-1 text-[13px] font-medium text-foreground">${escape_html(formatActionId(action.actionId))}</h3> <p class="mb-3 line-clamp-2 text-[11px] leading-relaxed text-muted-foreground/70">${escape_html(action.description)}</p> <div class="mt-auto flex items-center gap-1.5"><!--[-->`);
          const each_array_3 = ensure_array_like(action.providers);
          for (let $$index_2 = 0, $$length2 = each_array_3.length; $$index_2 < $$length2; $$index_2++) {
            let provider = each_array_3[$$index_2];
            $$renderer2.push(`<span class="rounded bg-secondary/60 px-1.5 py-0.5 text-[9px] font-medium text-muted-foreground/60">${escape_html(provider.name)}</span>`);
          }
          $$renderer2.push(`<!--]--> `);
          if (action.providers[0]?.creditCost) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<span class="ml-auto text-[9px] text-muted-foreground/40">${escape_html(action.providers[0].creditCost)}</span>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></div></button>`);
        }
        $$renderer2.push(`<!--]--></div>`);
      }
      $$renderer2.push(`<!--]--> `);
      if (store_get($$store_subs ??= {}, "$jobs", jobs).length > 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="mt-8"><div class="mb-3 flex items-center gap-2"><span class="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground/50">Jobs</span> <div class="h-px flex-1 bg-border/30"></div> <span class="text-[10px] text-muted-foreground/40">${escape_html(store_get($$store_subs ??= {}, "$jobs", jobs).length)} total</span></div> <div class="space-y-2"><!--[-->`);
        const each_array_4 = ensure_array_like(store_get($$store_subs ??= {}, "$jobs", jobs));
        for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
          let job = each_array_4[$$index_4];
          $$renderer2.push(`<div class="flex items-center gap-3 rounded-lg border border-border/40 bg-card/30 px-4 py-3 transition-colors hover:bg-card/50"><span${attr_class(`h-2 w-2 shrink-0 rounded-full ${stringify(statusColor(job.status))}`)}></span> <div class="min-w-0 flex-1"><div class="flex items-center gap-2"><span class="text-[12px] font-medium text-foreground">${escape_html(formatActionId(job.actionId))}</span> <span class="rounded bg-secondary/40 px-1.5 py-0.5 text-[9px] text-muted-foreground/50">${escape_html(job.providerId)}</span></div> <p class="truncate text-[11px] text-muted-foreground/60">${escape_html(job.prompt || job.jobId)}</p></div> <div class="flex shrink-0 items-center gap-3">`);
          if (job.status === "running") {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<div class="flex items-center gap-2"><div class="h-1 w-16 overflow-hidden rounded-full bg-secondary/60"><div class="h-full rounded-full bg-blue-400 transition-all"${attr_style(`width: ${stringify(job.progress)}%`)}></div></div> <span class="text-[10px] tabular-nums text-blue-400">${escape_html(job.progress)}%</span></div>`);
          } else {
            $$renderer2.push("<!--[!-->");
            $$renderer2.push(`<span class="text-[10px] text-muted-foreground/50">${escape_html(statusLabel(job.status))}</span>`);
          }
          $$renderer2.push(`<!--]--> <span class="text-[10px] text-muted-foreground/30">${escape_html(timeAgo(job.createdAt))}</span></div></div>`);
        }
        $$renderer2.push(`<!--]--></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    }
    $$renderer2.push(`<!--]--></div></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function TerminalInstance($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { onBridgeLost } = $$props;
    onDestroy(() => {
      onBridgeLost?.();
    });
    $$renderer2.push(`<div class="flex h-full min-h-0 w-full min-w-0 flex-col bg-[#1a1a1a]"><div class="flex h-7 shrink-0 items-center justify-end border-b border-border/50 bg-[#222] px-2">`);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div> <div class="min-h-0 flex-1 p-1"></div></div>`);
  });
}
function TerminalPane($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    const MAX_TERMINALS = 8;
    const initialTabId = createUUID();
    let tabs = [{ localId: initialTabId }];
    let activeTabId = initialTabId;
    let bridgeByTab = {};
    function clearBridge(localId) {
      if (!bridgeByTab[localId]) return;
      const next = { ...bridgeByTab };
      delete next[localId];
      bridgeByTab = next;
    }
    $$renderer2.push(`<div class="flex h-full w-full flex-col bg-[#1a1a1a]"><div class="flex h-8 shrink-0 items-center gap-1 border-b border-border/50 bg-[#222] px-2"><div class="flex min-w-0 flex-1 items-center gap-0.5 overflow-x-auto"><!--[-->`);
    const each_array = ensure_array_like(tabs);
    for (let i = 0, $$length = each_array.length; i < $$length; i++) {
      let tab = each_array[i];
      $$renderer2.push(`<div${attr_class(`flex max-w-[140px] shrink-0 items-center rounded-md transition-colors ${stringify(tab.localId === activeTabId ? "bg-sidebar-accent text-sidebar-foreground" : "text-muted-foreground hover:bg-sidebar-accent/50")}`)}><button type="button" class="truncate px-2 py-1 text-left text-[11px] font-medium">${escape_html(store_get($$store_subs ??= {}, "$t", t)("terminal_tab", { n: i + 1 }))}</button> `);
      if (tabs.length > 1) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<button type="button" class="mr-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded text-muted-foreground hover:bg-destructive/20 hover:text-destructive"${attr("aria-label", store_get($$store_subs ??= {}, "$t", t)("close_terminal_tab"))}>`);
        Icon$1($$renderer2, { icon: Cancel01Icon, size: 12, strokeWidth: 2 });
        $$renderer2.push(`<!----></button>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    }
    $$renderer2.push(`<!--]--></div> <button type="button" class="flex h-6 w-6 shrink-0 items-center justify-center rounded text-muted-foreground hover:bg-accent hover:text-foreground disabled:cursor-not-allowed disabled:opacity-40"${attr("disabled", tabs.length >= MAX_TERMINALS, true)}${attr("title", store_get($$store_subs ??= {}, "$t", t)("new_terminal"))}${attr("aria-label", store_get($$store_subs ??= {}, "$t", t)("new_terminal"))}>`);
    Icon$1($$renderer2, { icon: Add01Icon, size: 16, strokeWidth: 1.5 });
    $$renderer2.push(`<!----></button></div> <div class="relative min-h-0 flex-1"><!--[-->`);
    const each_array_1 = ensure_array_like(tabs);
    for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
      let tab = each_array_1[$$index_1];
      $$renderer2.push(`<div${attr_class("absolute inset-0 flex min-h-0 min-w-0 flex-col", void 0, { "hidden": tab.localId !== activeTabId })}>`);
      TerminalInstance($$renderer2, {
        isActiveTab: tab.localId === activeTabId,
        onBridgeLost: () => clearBridge(tab.localId)
      });
      $$renderer2.push(`<!----></div>`);
    }
    $$renderer2.push(`<!--]--></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
const MAX_PANES = 4;
function createPane(sessionId) {
  return { paneId: createUUID(), sessionId };
}
class PaneManager {
  panes = [];
  focusedIndex = 0;
  get focusedPane() {
    return this.panes[this.focusedIndex];
  }
  get focusedSessionId() {
    return this.focusedPane?.sessionId ?? null;
  }
  get isMultiPane() {
    return this.panes.length > 1;
  }
  get canSplit() {
    return this.panes.length < MAX_PANES;
  }
  get paneCount() {
    return this.panes.length;
  }
  /** Initialize with a single pane for the given session */
  init(sessionId) {
    if (this.panes.length === 0) {
      this.panes = [createPane(sessionId)];
      this.focusedIndex = 0;
    }
  }
  /** Open a session in the focused pane */
  openInFocused(sessionId) {
    if (this.panes.length === 0) {
      this.panes = [createPane(sessionId)];
      this.focusedIndex = 0;
      return;
    }
    this.panes[this.focusedIndex] = { ...this.panes[this.focusedIndex], sessionId };
  }
  /** Split: add a new pane next to the focused one */
  split(sessionId = null) {
    if (!this.canSplit) return;
    const insertAt = this.focusedIndex + 1;
    this.panes.splice(insertAt, 0, createPane(sessionId));
    this.focusedIndex = insertAt;
  }
  /** Remove a pane by index */
  closePane(index) {
    if (this.panes.length <= 1) return;
    this.panes.splice(index, 1);
    if (this.focusedIndex >= this.panes.length) {
      this.focusedIndex = this.panes.length - 1;
    } else if (this.focusedIndex > index) {
      this.focusedIndex--;
    }
  }
  /** Collapse to single pane (keep focused) */
  unsplit() {
    if (this.panes.length <= 1) return;
    const kept = this.panes[this.focusedIndex];
    this.panes = [kept];
    this.focusedIndex = 0;
  }
  /** Set focus to a specific pane */
  setFocus(index) {
    if (index >= 0 && index < this.panes.length) {
      this.focusedIndex = index;
    }
  }
  /** Update a pane's session (e.g., from sidebar click while pane is focused) */
  updatePaneSession(paneIndex, sessionId) {
    if (paneIndex >= 0 && paneIndex < this.panes.length) {
      this.panes[paneIndex] = { ...this.panes[paneIndex], sessionId };
    }
  }
  /** Find which pane (if any) has a given session open */
  findPaneWithSession(sessionId) {
    return this.panes.findIndex((p) => p.sessionId === sessionId);
  }
  /** Clean up panes referencing deleted sessions */
  cleanupDeletedSession(sessionId) {
    for (let i = 0; i < this.panes.length; i++) {
      if (this.panes[i].sessionId === sessionId) {
        this.panes[i] = { ...this.panes[i], sessionId: null };
      }
    }
  }
}
const paneManager = new PaneManager();
function AgentSetup($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let { agent } = $$props;
    function parseColorToRgb(color) {
      const value = color.trim().toLowerCase();
      if (value.startsWith("#")) {
        const hex = value.slice(1);
        if (hex.length === 3) {
          const r = parseInt(hex[0] + hex[0], 16);
          const g = parseInt(hex[1] + hex[1], 16);
          const b = parseInt(hex[2] + hex[2], 16);
          return { r, g, b };
        }
        if (hex.length === 6) {
          const r = parseInt(hex.slice(0, 2), 16);
          const g = parseInt(hex.slice(2, 4), 16);
          const b = parseInt(hex.slice(4, 6), 16);
          return { r, g, b };
        }
      }
      const rgbMatch = value.match(/^rgba?\(([^)]+)\)$/);
      if (rgbMatch) {
        const parts = rgbMatch[1].split(",").map((part) => Number.parseFloat(part.trim()));
        if (parts.length >= 3 && parts.slice(0, 3).every((num) => Number.isFinite(num))) {
          return {
            r: Math.max(0, Math.min(255, parts[0])),
            g: Math.max(0, Math.min(255, parts[1])),
            b: Math.max(0, Math.min(255, parts[2]))
          };
        }
      }
      return null;
    }
    function isLightColor(color) {
      const rgb = parseColorToRgb(color);
      if (!rgb) return false;
      const luminance = (0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b) / 255;
      return luminance >= 0.65;
    }
    function primaryTextClass(color) {
      return isLightColor(color) ? "text-[#111827]" : "text-white";
    }
    const openRouterCreditsHint = agent.name === "OpenRouter" && store_get($$store_subs ??= {}, "$setupError", setupError).toLowerCase().includes("betide api token");
    $$renderer2.push(`<div class="flex flex-1 flex-col items-center justify-center px-6"><div class="flex w-full max-w-md flex-col items-center gap-6">`);
    if (store_get($$store_subs ??= {}, "$setupState", setupState) === "idle") {
      $$renderer2.push("<!--[-->");
      if (agent.iconUrl) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span${attr_style(`color: ${stringify(agent.color)}; opacity: 0.5;`)}><img${attr("src", agent.iconUrl)} alt="" class="h-14 w-14 invert opacity-70"/></span>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<span class="flex h-14 w-14 items-center justify-center rounded-xl text-lg font-bold text-white"${attr_style(`background-color: ${stringify(agent.color)}; opacity: 0.7;`)}>${escape_html(agent.letter)}</span>`);
      }
      $$renderer2.push(`<!--]--> <div class="flex flex-col items-center gap-2 text-center"><h2 class="text-lg font-medium text-foreground/80">${escape_html(agent.name)} is not set up</h2> <p class="max-w-xs text-[13px] leading-relaxed text-muted-foreground/50">${escape_html(agent.name)} needs to be installed before you can start a conversation.</p> `);
      if (store_get($$store_subs ??= {}, "$setupError", setupError)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<p class="max-w-xs text-[12px] leading-relaxed text-amber-400/70">${escape_html(store_get($$store_subs ??= {}, "$setupError", setupError))}</p>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div> `);
      if (store_get($$store_subs ??= {}, "$setupInstallInfo", setupInstallInfo)?.installCommand) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="w-full max-w-sm"><p class="mb-2 text-[12px] text-muted-foreground/40">Install command:</p> <div class="relative rounded-lg bg-[#1c1c1c] p-3"><pre class="overflow-x-auto pr-10 text-[12px] leading-relaxed text-emerald-400/80">${escape_html(store_get($$store_subs ??= {}, "$setupInstallInfo", setupInstallInfo).installCommand)}</pre> <button class="absolute right-2 top-2 rounded-md p-1.5 text-muted-foreground/40 transition-colors hover:bg-white/5 hover:text-muted-foreground/70" title="Copy command">`);
        {
          $$renderer2.push("<!--[!-->");
          Icon$1($$renderer2, { icon: Copy01Icon, size: 14, strokeWidth: 1.5 });
        }
        $$renderer2.push(`<!--]--></button></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <button${attr_class(`rounded-xl px-6 py-2.5 text-[14px] font-medium transition-all hover:brightness-110 ${primaryTextClass(agent.color)}`)}${attr_style(`background-color: ${stringify(agent.color)};`)}>Set up ${escape_html(agent.shortName)}</button>`);
    } else if (store_get($$store_subs ??= {}, "$setupState", setupState) === "checking") {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div class="flex flex-col items-center gap-4"><div class="h-10 w-10 animate-spin rounded-full border-2 border-muted-foreground/20 border-t-muted-foreground/60"></div> <p class="text-[14px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$setupProgress", setupProgress) || "Checking prerequisites...")}</p></div>`);
    } else if (store_get($$store_subs ??= {}, "$setupState", setupState) === "installing") {
      $$renderer2.push("<!--[2-->");
      $$renderer2.push(`<div class="flex flex-col items-center gap-4">`);
      if (agent.iconUrl) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span${attr_style(`color: ${stringify(agent.color)}; opacity: 0.4;`)}><img${attr("src", agent.iconUrl)} alt="" class="h-10 w-10 invert opacity-70"/></span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <div class="h-10 w-10 animate-spin rounded-full border-2 border-muted-foreground/20 border-t-muted-foreground/60"></div> <div class="flex flex-col items-center gap-1.5"><p class="text-[14px] text-foreground/70">Setting up ${escape_html(agent.name)}...</p> <p class="max-w-xs text-center text-[12px] text-muted-foreground/40">${escape_html(store_get($$store_subs ??= {}, "$setupProgress", setupProgress))}</p></div></div>`);
    } else if (store_get($$store_subs ??= {}, "$setupState", setupState) === "cli_missing") {
      $$renderer2.push("<!--[3-->");
      $$renderer2.push(`<div class="flex w-full flex-col items-center gap-5"><div class="flex h-12 w-12 items-center justify-center rounded-full bg-amber-500/10">`);
      Icon$1($$renderer2, {
        icon: Alert02Icon,
        size: 24,
        strokeWidth: 1.5,
        class: "text-amber-400"
      });
      $$renderer2.push(`<!----></div> <div class="flex flex-col items-center gap-2 text-center"><h2 class="text-lg font-medium text-foreground/80">${escape_html(store_get($$store_subs ??= {}, "$setupInstallInfo", setupInstallInfo)?.baseExecutableName || "CLI")} Required</h2> <p class="max-w-xs text-[13px] leading-relaxed text-muted-foreground/50">`);
      if (store_get($$store_subs ??= {}, "$setupInstallInfo", setupInstallInfo)?.requiresAdapter) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`The adapter is ready, but ${escape_html(agent.name)} requires the`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`${escape_html(agent.name)} requires the`);
      }
      $$renderer2.push(`<!--]--> <span class="font-mono text-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$setupInstallInfo", setupInstallInfo)?.baseExecutableName)}</span> CLI to be installed on your system.</p></div> `);
      if (store_get($$store_subs ??= {}, "$setupInstallInfo", setupInstallInfo)?.installCommand) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="w-full"><p class="mb-2 text-[12px] text-muted-foreground/40">Run this in your terminal:</p> <div class="relative rounded-lg bg-[#1c1c1c] p-3"><pre class="overflow-x-auto pr-10 text-[13px] leading-relaxed text-emerald-400/80">${escape_html(store_get($$store_subs ??= {}, "$setupInstallInfo", setupInstallInfo).installCommand)}</pre> <button class="absolute right-2 top-2 rounded-md p-1.5 text-muted-foreground/40 transition-colors hover:bg-white/5 hover:text-muted-foreground/70" title="Copy command">`);
        {
          $$renderer2.push("<!--[!-->");
          Icon$1($$renderer2, { icon: Copy01Icon, size: 14, strokeWidth: 1.5 });
        }
        $$renderer2.push(`<!--]--></button></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <div class="flex flex-wrap justify-center gap-2.5">`);
      if (store_get($$store_subs ??= {}, "$setupInstallInfo", setupInstallInfo)?.installUrl) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<button class="flex items-center gap-1.5 rounded-lg border border-border/50 bg-secondary/50 px-3.5 py-2 text-[13px] text-foreground/70 transition-colors hover:bg-secondary">`);
        Icon$1($$renderer2, { icon: Download04Icon, size: 14, strokeWidth: 1.5 });
        $$renderer2.push(`<!----> Download Page</button>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <button${attr_class(`flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-[13px] font-medium transition-all hover:brightness-110 ${primaryTextClass(agent.color)}`)}${attr_style(`background-color: ${stringify(agent.color)};`)}>`);
      Icon$1($$renderer2, { icon: ReloadIcon, size: 14, strokeWidth: 1.5 });
      $$renderer2.push(`<!----> Try Again</button></div></div>`);
    } else if (store_get($$store_subs ??= {}, "$setupState", setupState) === "missing_key") {
      $$renderer2.push("<!--[4-->");
      $$renderer2.push(`<div class="flex w-full flex-col items-center gap-5"><div class="flex h-12 w-12 items-center justify-center rounded-full bg-amber-500/10">`);
      Icon$1($$renderer2, {
        icon: Key01Icon,
        size: 24,
        strokeWidth: 1.5,
        class: "text-amber-400"
      });
      $$renderer2.push(`<!----></div> <div class="flex flex-col items-center gap-2 text-center"><h2 class="text-lg font-medium text-foreground/80">API Key Required</h2> <p class="max-w-xs text-[13px] leading-relaxed text-muted-foreground/50">${escape_html(agent.name)} requires an API key. Configure it in <span class="text-foreground/60">Project Settings > Plugins > Agent Integration Kit</span>.</p> `);
      if (store_get($$store_subs ??= {}, "$setupError", setupError)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<p class="max-w-xs text-[12px] leading-relaxed text-amber-400/80">${escape_html(store_get($$store_subs ??= {}, "$setupError", setupError))}</p>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (openRouterCreditsHint) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<p class="max-w-xs text-[12px] leading-relaxed text-muted-foreground/55">If your OpenRouter key is already set, disable <span class="text-foreground/65">Use Betide Studio Credits</span> in the Auto-Update section, then click Check Again.</p>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div> <div class="flex flex-wrap justify-center gap-2.5"><button class="flex items-center gap-1.5 rounded-lg border border-border/50 bg-secondary/50 px-3.5 py-2 text-[13px] text-foreground/70 transition-colors hover:bg-secondary">`);
      Icon$1($$renderer2, { icon: Settings02Icon, size: 14, strokeWidth: 1.5 });
      $$renderer2.push(`<!----> Open Settings</button> <button${attr_class(`flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-[13px] font-medium transition-all hover:brightness-110 ${primaryTextClass(agent.color)}`)}${attr_style(`background-color: ${stringify(agent.color)};`)}>`);
      Icon$1($$renderer2, { icon: ReloadIcon, size: 14, strokeWidth: 1.5 });
      $$renderer2.push(`<!----> Check Again</button></div></div>`);
    } else if (store_get($$store_subs ??= {}, "$setupState", setupState) === "success") {
      $$renderer2.push("<!--[5-->");
      $$renderer2.push(`<div class="flex flex-col items-center gap-5"><div class="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10">`);
      Icon$1($$renderer2, {
        icon: Tick02Icon,
        size: 28,
        strokeWidth: 2,
        class: "text-emerald-400"
      });
      $$renderer2.push(`<!----></div> <div class="flex flex-col items-center gap-2 text-center"><h2 class="text-lg font-medium text-emerald-400">${escape_html(agent.name)} is ready!</h2> <p class="max-w-xs text-[13px] leading-relaxed text-muted-foreground/50">Please restart the editor to start using ${escape_html(agent.name)}. The agent will be available after relaunch.</p></div> <button class="rounded-lg border border-border/50 bg-secondary/50 px-4 py-2 text-[13px] text-foreground/70 transition-colors hover:bg-secondary">Restart</button></div>`);
    } else if (store_get($$store_subs ??= {}, "$setupState", setupState) === "error") {
      $$renderer2.push("<!--[6-->");
      $$renderer2.push(`<div class="flex w-full flex-col items-center gap-5"><div class="flex h-12 w-12 items-center justify-center rounded-full bg-red-500/10">`);
      Icon$1($$renderer2, {
        icon: Cancel01Icon,
        size: 24,
        strokeWidth: 1.5,
        class: "text-red-400"
      });
      $$renderer2.push(`<!----></div> <div class="flex flex-col items-center gap-2 text-center"><h2 class="text-lg font-medium text-red-400">Setup Failed</h2></div> `);
      if (store_get($$store_subs ??= {}, "$setupError", setupError)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="relative w-full rounded-lg bg-[#1c1c1c] p-3"><pre class="max-h-[160px] overflow-auto text-[12px] leading-relaxed text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$setupError", setupError))}</pre> <button class="absolute right-2 top-2 rounded-md p-1.5 text-muted-foreground/40 transition-colors hover:bg-white/5 hover:text-muted-foreground/70" title="Copy error">`);
        {
          $$renderer2.push("<!--[!-->");
          Icon$1($$renderer2, { icon: Copy01Icon, size: 14, strokeWidth: 1.5 });
        }
        $$renderer2.push(`<!--]--></button></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <div class="flex flex-wrap justify-center gap-2.5"><button class="rounded-lg border border-border/50 bg-secondary/50 px-3.5 py-2 text-[13px] text-foreground/70 transition-colors hover:bg-secondary">Cancel</button> <button${attr_class(`flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-[13px] font-medium transition-all hover:brightness-110 ${primaryTextClass(agent.color)}`)}${attr_style(`background-color: ${stringify(agent.color)};`)}>`);
      Icon$1($$renderer2, { icon: ReloadIcon, size: 14, strokeWidth: 1.5 });
      $$renderer2.push(`<!----> Try Again</button></div></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
const showOnboarding = writable(false);
const onboardingLoading = writable(true);
function OnboardingWizard($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<div class="flex flex-1 flex-col items-center justify-center px-6"><div class="flex w-full max-w-md flex-col items-center gap-8"><div class="relative flex items-center justify-center"><div class="absolute h-24 w-24 rounded-full bg-gradient-to-br from-violet-500/8 to-amber-500/8 blur-xl"></div> <div class="relative flex h-20 w-20 items-center justify-center rounded-2xl border border-border/30 bg-card/40 shadow-lg shadow-black/20 backdrop-blur-sm">`);
    Icon$1($$renderer2, {
      icon: SparklesIcon,
      size: 36,
      strokeWidth: 1.2,
      class: "text-foreground/50"
    });
    $$renderer2.push(`<!----></div></div> <div class="flex flex-col items-center gap-3 text-center"><h1 class="text-[22px] font-semibold tracking-tight text-foreground/90">Welcome to Agent Integration Kit</h1> <p class="max-w-xs text-[13.5px] leading-relaxed text-muted-foreground/50">Connect AI coding agents to Unreal Engine. Install agents from the ACP Registry to get started.</p></div> <div class="flex flex-col items-center gap-3"><button class="group flex items-center gap-2 rounded-xl bg-[var(--ue-accent)] px-7 py-2.5 text-[14px] font-medium text-white transition-all hover:opacity-90">`);
    Icon$1($$renderer2, { icon: Settings02Icon, size: 16, strokeWidth: 1.5 });
    $$renderer2.push(`<!----> Set Up Agents `);
    Icon$1($$renderer2, {
      icon: ArrowRight01Icon,
      size: 16,
      strokeWidth: 2,
      class: "transition-transform group-hover:translate-x-0.5"
    });
    $$renderer2.push(`<!----></button> <button class="text-[12px] text-muted-foreground/30 transition-colors hover:text-muted-foreground/50">Skip for now</button></div></div></div>`);
  });
}
function UsageBar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    if (store_get($$store_subs ??= {}, "$hasRateLimits", hasRateLimits) && store_get($$store_subs ??= {}, "$currentRateLimits", currentRateLimits)) {
      $$renderer2.push("<!--[-->");
      const data = store_get($$store_subs ??= {}, "$currentRateLimits", currentRateLimits);
      const peak = store_get($$store_subs ??= {}, "$peakUsagePercent", peakUsagePercent);
      const color = data.hasData ? usageColor(peak) : "#71717a";
      $$renderer2.push("<!---->");
      Tooltip?.($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push("<!---->");
          Tooltip_trigger?.($$renderer3, {
            class: "flex items-center gap-1.5 rounded-md px-1.5 py-1 transition-colors hover:bg-accent/50",
            children: ($$renderer4) => {
              if (data.isLoading && !data.hasData) {
                $$renderer4.push("<!--[-->");
                $$renderer4.push(`<div class="h-3 w-3 animate-spin rounded-full border border-muted-foreground/30 border-t-muted-foreground/70"></div> <span class="text-[11px] text-muted-foreground/50">...</span>`);
              } else if (data.hasData) {
                $$renderer4.push("<!--[1-->");
                $$renderer4.push(`<div class="flex h-[6px] w-[40px] overflow-hidden rounded-full bg-muted-foreground/15"><div class="h-full rounded-full transition-all duration-500"${attr_style(`width: ${stringify(peak)}%; background-color: ${stringify(color)};`)}></div></div> <span class="text-[11px] tabular-nums"${attr_style(`color: ${stringify(color)};`)}>${escape_html(peak)}%</span>`);
              } else {
                $$renderer4.push("<!--[!-->");
              }
              $$renderer4.push(`<!--]-->`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!----> `);
          $$renderer3.push("<!---->");
          Tooltip_content?.($$renderer3, {
            side: "bottom",
            sideOffset: 8,
            class: "w-[290px] rounded-lg border border-border bg-[#222] p-3 text-[12px] text-foreground shadow-xl",
            children: ($$renderer4) => {
              $$renderer4.push(`<div class="mb-2.5 flex items-center justify-between"><div class="flex items-baseline gap-2"><span class="text-[13px] font-medium">${escape_html(data.agentName || store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent)?.name || "Usage")}</span> `);
              if (data.planType) {
                $$renderer4.push("<!--[-->");
                $$renderer4.push(`<span class="rounded bg-muted-foreground/10 px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">${escape_html(data.planType)}</span>`);
              } else {
                $$renderer4.push("<!--[!-->");
              }
              $$renderer4.push(`<!--]--></div> <button${attr_class(`rounded p-1 text-muted-foreground/40 transition-colors hover:bg-accent/50 hover:text-muted-foreground/80 ${stringify("")}`)} title="Refresh usage">`);
              Icon$1($$renderer4, { icon: ReloadIcon, size: 12, strokeWidth: 1.5 });
              $$renderer4.push(`<!----></button></div> <div class="mb-2.5 text-[11px] leading-relaxed text-muted-foreground/50">Your API rate limit — how many requests your plan allows in a time window. Resets automatically.</div> `);
              if (data.isLoading && !data.hasData) {
                $$renderer4.push("<!--[-->");
                $$renderer4.push(`<div class="flex items-center gap-2 py-4 justify-center"><div class="h-3.5 w-3.5 animate-spin rounded-full border-2 border-muted-foreground/20 border-t-muted-foreground/60"></div> <span class="text-[11px] text-muted-foreground/50">Fetching usage data...</span></div>`);
              } else if (data.hasData) {
                $$renderer4.push("<!--[1-->");
                $$renderer4.push(`<div class="flex flex-col gap-2.5">`);
                if (data.primary.hasData) {
                  $$renderer4.push("<!--[-->");
                  const pct = Math.round(data.primary.usedPercent);
                  $$renderer4.push(`<div><div class="mb-1 flex items-baseline justify-between"><span class="text-muted-foreground">Session (${escape_html(formatWindowDuration(data.primary.windowDurationMinutes))})</span> <span class="font-medium tabular-nums"${attr_style(`color: ${stringify(usageColor(pct))};`)}>${escape_html(pct)}%</span></div> <div class="h-1.5 w-full overflow-hidden rounded-full bg-muted-foreground/15"><div class="h-full rounded-full transition-all duration-300"${attr_style(`width: ${stringify(pct)}%; background-color: ${stringify(usageColor(pct))};`)}></div></div> `);
                  if (data.primary.resetsAt) {
                    $$renderer4.push("<!--[-->");
                    $$renderer4.push(`<div class="mt-0.5 text-[11px] text-muted-foreground/40">Resets in ${escape_html(formatResetTime(data.primary.resetsAt))}</div>`);
                  } else {
                    $$renderer4.push("<!--[!-->");
                  }
                  $$renderer4.push(`<!--]--></div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> `);
                if (data.secondary.hasData) {
                  $$renderer4.push("<!--[-->");
                  const pct = Math.round(data.secondary.usedPercent);
                  $$renderer4.push(`<div><div class="mb-1 flex items-baseline justify-between"><span class="text-muted-foreground">All Models (${escape_html(formatWindowDuration(data.secondary.windowDurationMinutes))})</span> <span class="font-medium tabular-nums"${attr_style(`color: ${stringify(usageColor(pct))};`)}>${escape_html(pct)}%</span></div> <div class="h-1.5 w-full overflow-hidden rounded-full bg-muted-foreground/15"><div class="h-full rounded-full transition-all duration-300"${attr_style(`width: ${stringify(pct)}%; background-color: ${stringify(usageColor(pct))};`)}></div></div> `);
                  if (data.secondary.resetsAt) {
                    $$renderer4.push("<!--[-->");
                    $$renderer4.push(`<div class="mt-0.5 text-[11px] text-muted-foreground/40">Resets in ${escape_html(formatResetTime(data.secondary.resetsAt))}</div>`);
                  } else {
                    $$renderer4.push("<!--[!-->");
                  }
                  $$renderer4.push(`<!--]--></div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> `);
                if (data.modelSpecific.hasData) {
                  $$renderer4.push("<!--[-->");
                  const pct = Math.round(data.modelSpecific.usedPercent);
                  const label = data.modelSpecificLabel ? `${data.modelSpecificLabel} Only` : "Model";
                  $$renderer4.push(`<div><div class="mb-1 flex items-baseline justify-between"><span class="text-muted-foreground">${escape_html(label)} (${escape_html(formatWindowDuration(data.modelSpecific.windowDurationMinutes))})</span> <span class="font-medium tabular-nums"${attr_style(`color: ${stringify(usageColor(pct))};`)}>${escape_html(pct)}%</span></div> <div class="h-1.5 w-full overflow-hidden rounded-full bg-muted-foreground/15"><div class="h-full rounded-full transition-all duration-300"${attr_style(`width: ${stringify(pct)}%; background-color: ${stringify(usageColor(pct))};`)}></div></div> `);
                  if (data.modelSpecific.resetsAt) {
                    $$renderer4.push("<!--[-->");
                    $$renderer4.push(`<div class="mt-0.5 text-[11px] text-muted-foreground/40">Resets in ${escape_html(formatResetTime(data.modelSpecific.resetsAt))}</div>`);
                  } else {
                    $$renderer4.push("<!--[!-->");
                  }
                  $$renderer4.push(`<!--]--></div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--></div> `);
                if (data.extraUsage.hasData) {
                  $$renderer4.push("<!--[-->");
                  const sym = currencySymbol(data.extraUsage.currencyCode);
                  const extraPct = data.extraUsage.limitAmount > 0 ? Math.min(100, data.extraUsage.usedAmount / data.extraUsage.limitAmount * 100) : 0;
                  $$renderer4.push(`<div class="mt-2.5 border-t border-border/40 pt-2"><div class="mb-1 flex items-baseline justify-between"><span class="text-muted-foreground">Claude Extra</span> <span class="font-medium tabular-nums"${attr_style(`color: ${stringify(usageColor(extraPct))};`)}>${escape_html(sym)}${escape_html(data.extraUsage.usedAmount.toFixed(2))} / ${escape_html(sym)}${escape_html(data.extraUsage.limitAmount.toFixed(2))}</span></div> <div class="h-1.5 w-full overflow-hidden rounded-full bg-muted-foreground/15"><div class="h-full rounded-full transition-all duration-300"${attr_style(`width: ${stringify(extraPct)}%; background-color: ${stringify(usageColor(extraPct))};`)}></div></div> <div class="mt-0.5 text-[11px] text-muted-foreground/40">Monthly spend</div></div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> `);
                if (data.meshy) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<div class="mt-2.5 border-t border-border/40 pt-2"><div class="flex items-baseline justify-between"><span class="text-muted-foreground">Meshy Credits</span> `);
                  if (!data.meshy.configured) {
                    $$renderer4.push("<!--[-->");
                    $$renderer4.push(`<span class="text-[11px] text-muted-foreground/40">Not configured</span>`);
                  } else if (data.meshy.isLoading && data.meshy.balance < 0) {
                    $$renderer4.push("<!--[1-->");
                    $$renderer4.push(`<span class="text-[11px] text-muted-foreground/40">Loading...</span>`);
                  } else if (data.meshy.error && data.meshy.balance < 0) {
                    $$renderer4.push("<!--[2-->");
                    $$renderer4.push(`<span class="text-[11px] text-amber-400/70">${escape_html(data.meshy.error)}</span>`);
                  } else if (data.meshy.balance >= 0) {
                    $$renderer4.push("<!--[3-->");
                    $$renderer4.push(`<span${attr_class(`font-medium tabular-nums ${stringify(data.meshy.balance >= 100 ? "text-emerald-400" : "text-red-400")}`)}>${escape_html(data.meshy.balance)} credits</span>`);
                  } else {
                    $$renderer4.push("<!--[!-->");
                  }
                  $$renderer4.push(`<!--]--></div></div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> `);
                if (data.errorMessage) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<div class="mt-2 text-[11px] text-amber-400/70">${escape_html(data.errorMessage)}</div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> `);
                if (data.lastUpdated) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<div class="mt-2 text-[10px] text-muted-foreground/30">${escape_html(formatLastUpdated(data.lastUpdated))}</div>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]-->`);
              } else if (data.errorMessage) {
                $$renderer4.push("<!--[2-->");
                $$renderer4.push(`<div class="py-2 text-[11px] text-amber-400/70">${escape_html(data.errorMessage)}</div>`);
              } else {
                $$renderer4.push("<!--[!-->");
                $$renderer4.push(`<div class="py-2 text-center text-[11px] text-muted-foreground/40">Usage tracking is available for<br/>Claude Code and Codex CLI agents.</div>`);
              }
              $$renderer4.push(`<!--]-->`);
            },
            $$slots: { default: true }
          });
          $$renderer3.push(`<!---->`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!---->`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function CustomSelect($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { options, value = "", onchange, id = "" } = $$props;
    let open = false;
    const selectedLabel = options.find((o) => o.value === value)?.label ?? value;
    $$renderer2.push(`<div class="relative"${attr("id", id)}><button type="button" class="flex w-full items-center justify-between rounded-md border border-border/60 bg-transparent px-3 py-2 text-left text-[13px] text-foreground transition-colors hover:border-foreground/20 focus:border-foreground/30 focus:outline-none"><span>${escape_html(selectedLabel)}</span> <span${attr_class("ml-2 text-muted-foreground/60 transition-transform", void 0, { "rotate-180": open })}>`);
    Icon$1($$renderer2, { icon: ArrowDown01Icon, size: 14 });
    $$renderer2.push(`<!----></span></button> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
    bind_props($$props, { value });
  });
}
function ProjectIndexPanel($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let settings = {
      provider: "openrouter",
      endpointUrl: "",
      apiKey: "",
      model: "google/gemini-embedding-001",
      dimensions: 768,
      autoIndex: false,
      scope: {
        blueprints: true,
        cppFiles: true,
        assets: true,
        levels: true,
        config: false,
        documents: true
      },
      hasOpenRouterKey: false
    };
    let status = {
      state: "idle",
      totalChunks: 0,
      indexedChunks: 0,
      lastIndexedAt: "",
      indexSizeBytes: 0,
      errorMessage: "",
      breakdown: {
        blueprints: 0,
        cppFiles: 0,
        assets: 0,
        levels: 0,
        config: 0,
        documents: 0
      },
      embeddingModel: "",
      embeddingDimensions: 0
    };
    let loading = true;
    let indexing = false;
    let progress = 0;
    let dims = 768;
    let mismatch = status.state === "ready" && status.embeddingModel !== "" && (status.embeddingModel !== (settings.model || "google/gemini-embedding-001") || status.embeddingDimensions !== dims);
    const SCOPES = [
      {
        key: "blueprints",
        label: "Blueprints",
        desc: store_get($$store_subs ??= {}, "$t", t)("scope_blueprints_desc")
      },
      {
        key: "cppFiles",
        label: "C++ Source",
        desc: store_get($$store_subs ??= {}, "$t", t)("scope_cpp_desc")
      },
      {
        key: "assets",
        label: "Assets",
        desc: store_get($$store_subs ??= {}, "$t", t)("scope_assets_desc")
      },
      {
        key: "levels",
        label: "Levels",
        desc: store_get($$store_subs ??= {}, "$t", t)("scope_levels_desc")
      },
      {
        key: "documents",
        label: "Documents",
        desc: store_get($$store_subs ??= {}, "$t", t)("scope_documents_desc")
      },
      {
        key: "config",
        label: "Config",
        desc: store_get($$store_subs ??= {}, "$t", t)("scope_config_desc")
      }
    ];
    const DIM_OPTIONS = [256, 384, 768, 1024, 3072];
    async function load() {
      loading = true;
      try {
        const [s, st] = await Promise.all([getIndexingSettings(), getIndexingStatus()]);
        settings = s;
        status = st;
        dims = s.dimensions;
        indexing = st.state === "indexing";
        if (indexing && st.totalChunks > 0) {
          progress = Math.round(st.indexedChunks / st.totalChunks * 100);
        }
      } catch (e) {
        console.warn("Failed to load indexing settings:", e);
      } finally {
        loading = false;
      }
    }
    function fmtBytes(b) {
      if (b === 0) return "0 B";
      const k = 1024;
      const s = ["B", "KB", "MB", "GB"];
      const i = Math.floor(Math.log(b) / Math.log(k));
      return parseFloat((b / Math.pow(k, i)).toFixed(1)) + " " + s[i];
    }
    function fmtAgo(iso) {
      if (!iso) return "Never";
      const m = Math.floor((Date.now() - new Date(iso).getTime()) / 6e4);
      if (m < 1) return "Just now";
      if (m < 60) return `${m}m ago`;
      const h = Math.floor(m / 60);
      if (h < 24) return `${h}h ago`;
      return `${Math.floor(h / 24)}d ago`;
    }
    $$renderer2.push(`<div class="mb-6 svelte-1n5kg1j"><h2 class="mb-1 text-[18px] font-medium text-foreground svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("project_index_heading"))}</h2> <p class="text-[13px] text-muted-foreground/60 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("project_index_desc"))}</p> <p class="mt-1 text-[11px] text-muted-foreground/30 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("project_index_hint_small"))}</p></div> `);
    if (loading) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center gap-2 py-12 text-[13px] text-muted-foreground/50 svelte-1n5kg1j"><span class="inline-block h-4 w-4 animate-spin rounded-full border-2 border-muted-foreground/30 border-t-muted-foreground svelte-1n5kg1j"></span> ${escape_html(store_get($$store_subs ??= {}, "$t", t)("loading"))}</div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<section class="idx-card mb-5 svelte-1n5kg1j"><div class="flex items-center justify-between px-4 py-3.5 svelte-1n5kg1j"><div class="flex items-center gap-3 svelte-1n5kg1j"><span class="relative flex h-2.5 w-2.5 shrink-0 svelte-1n5kg1j">`);
      if (status.state === "ready") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-50 svelte-1n5kg1j"></span> <span class="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-400 svelte-1n5kg1j"></span>`);
      } else if (status.state === "indexing") {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<span class="absolute inline-flex h-full w-full animate-ping rounded-full bg-blue-400 opacity-50 svelte-1n5kg1j"></span> <span class="relative inline-flex h-2.5 w-2.5 rounded-full bg-blue-400 svelte-1n5kg1j"></span>`);
      } else if (status.state === "error") {
        $$renderer2.push("<!--[2-->");
        $$renderer2.push(`<span class="relative inline-flex h-2.5 w-2.5 rounded-full bg-red-400 svelte-1n5kg1j"></span>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<span class="relative inline-flex h-2.5 w-2.5 rounded-full bg-foreground/20 svelte-1n5kg1j"></span>`);
      }
      $$renderer2.push(`<!--]--></span> <div class="svelte-1n5kg1j"><span class="text-[13px] font-medium text-foreground svelte-1n5kg1j">`);
      if (status.state === "ready") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`${escape_html(store_get($$store_subs ??= {}, "$t", t)("index_ready"))}`);
      } else if (status.state === "indexing") {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`${escape_html(store_get($$store_subs ??= {}, "$t", t)("indexing"))}`);
      } else if (status.state === "error") {
        $$renderer2.push("<!--[2-->");
        $$renderer2.push(`${escape_html(store_get($$store_subs ??= {}, "$t", t)("error"))}`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`${escape_html(store_get($$store_subs ??= {}, "$t", t)("not_indexed"))}`);
      }
      $$renderer2.push(`<!--]--></span> <p class="text-[11px] text-muted-foreground/45 svelte-1n5kg1j">`);
      if (status.state === "ready") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`${escape_html(status.totalChunks.toLocaleString())} chunks · ${escape_html(fmtBytes(status.indexSizeBytes))} · ${escape_html(fmtAgo(status.lastIndexedAt))}`);
      } else if (status.state === "indexing") {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`${escape_html(status.indexedChunks.toLocaleString())} / ${escape_html(status.totalChunks.toLocaleString())} chunks`);
      } else if (status.state === "error") {
        $$renderer2.push("<!--[2-->");
        $$renderer2.push(`${escape_html(status.errorMessage)}`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`${escape_html(store_get($$store_subs ??= {}, "$t", t)("configure_and_build"))}`);
      }
      $$renderer2.push(`<!--]--></p></div></div> <div class="flex items-center gap-2 svelte-1n5kg1j">`);
      if (status.state === "ready") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<button class="idx-btn-ghost svelte-1n5kg1j"${attr("disabled", indexing, true)}>`);
        Icon$1($$renderer2, { icon: ArrowReloadHorizontalIcon, size: 13, strokeWidth: 1.5 });
        $$renderer2.push(`<!----> ${escape_html(store_get($$store_subs ??= {}, "$t", t)("rebuild"))}</button> <button class="idx-btn-ghost text-muted-foreground/40 hover:text-red-400 svelte-1n5kg1j"${attr("aria-label", store_get($$store_subs ??= {}, "$t", t)("clear_index"))}>`);
        Icon$1($$renderer2, { icon: Delete02Icon, size: 13, strokeWidth: 1.5 });
        $$renderer2.push(`<!----></button>`);
      } else if (status.state === "indexing") {
        $$renderer2.push("<!--[1-->");
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<button class="idx-btn svelte-1n5kg1j"${attr("disabled", indexing, true)}>${escape_html(store_get($$store_subs ??= {}, "$t", t)("build_index"))}</button>`);
      }
      $$renderer2.push(`<!--]--></div></div> `);
      if (status.state === "indexing") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="h-[3px] w-full bg-foreground/5 svelte-1n5kg1j"><div class="h-full bg-blue-400 transition-all duration-500 ease-out svelte-1n5kg1j"${attr_style(`width: ${stringify(progress)}%`)}></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (status.state === "ready") {
        $$renderer2.push("<!--[-->");
        const bd = status.breakdown;
        const cats = [
          { k: "blueprints", n: bd.blueprints, l: "Blueprints" },
          { k: "cppFiles", n: bd.cppFiles, l: "C++" },
          { k: "assets", n: bd.assets, l: "Assets" },
          { k: "levels", n: bd.levels, l: "Levels" },
          { k: "documents", n: bd.documents, l: "Docs" },
          { k: "config", n: bd.config, l: "Config" }
        ].filter((c) => c.n > 0);
        if (cats.length > 0) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="flex items-center gap-4 border-t border-border/25 px-4 py-2.5 svelte-1n5kg1j"><!--[-->`);
          const each_array = ensure_array_like(cats);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let cat = each_array[$$index];
            $$renderer2.push(`<span class="text-[11px] text-muted-foreground/40 svelte-1n5kg1j"><span class="font-medium tabular-nums text-muted-foreground/60 svelte-1n5kg1j">${escape_html(cat.n)}</span> ${escape_html(cat.l)}</span>`);
          }
          $$renderer2.push(`<!--]--> `);
          if (status.embeddingModel) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<span class="ml-auto font-mono text-[10px] text-muted-foreground/25 svelte-1n5kg1j">${escape_html(status.embeddingModel)} · ${escape_html(status.embeddingDimensions)}d</span>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]-->`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></section> `);
      if (mismatch) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="idx-card mb-5 border-amber-500/20 bg-amber-500/[0.04] px-4 py-3 svelte-1n5kg1j"><p class="text-[12px] leading-relaxed text-amber-300/80 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("index_mismatch_prefix"))} <span class="font-mono text-amber-200/90 svelte-1n5kg1j">${escape_html(status.embeddingModel)}</span> at <span class="font-mono text-amber-200/90 svelte-1n5kg1j">${escape_html(status.embeddingDimensions)}d</span>.
			${escape_html(store_get($$store_subs ??= {}, "$t", t)("index_mismatch_suffix"))}</p> <div class="mt-2.5 flex items-center gap-3 svelte-1n5kg1j"><button class="idx-btn text-[12px] svelte-1n5kg1j">`);
        Icon$1($$renderer2, { icon: ArrowReloadHorizontalIcon, size: 12, strokeWidth: 1.5 });
        $$renderer2.push(`<!----> ${escape_html(store_get($$store_subs ??= {}, "$t", t)("rebuild_index"))}</button> <button class="text-[12px] text-amber-400/50 transition-colors hover:text-amber-300 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("clear_instead"))}</button></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <section class="idx-card mb-5 px-4 py-4 svelte-1n5kg1j"><h3 class="mb-1 text-[13px] font-medium text-foreground svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("embedding_provider_heading"))}</h3> <p class="mb-4 text-[11px] text-muted-foreground/40 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("embedding_provider_desc"))} <code class="rounded bg-foreground/[0.06] px-1 py-px font-mono text-[10px] text-foreground/50 svelte-1n5kg1j">/v1/embeddings</code> format works.</p> <div class="mb-4 inline-flex rounded-lg border border-border/50 bg-foreground/[0.02] p-0.5 svelte-1n5kg1j"><button${attr_class(
        `flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[12px] transition-all ${stringify(settings.provider === "openrouter" ? "bg-foreground/[0.08] text-foreground shadow-sm" : "text-muted-foreground/50 hover:text-muted-foreground")}`,
        "svelte-1n5kg1j"
      )}>`);
      Icon$1($$renderer2, { icon: CloudIcon, size: 13, strokeWidth: 1.5 });
      $$renderer2.push(`<!----> OpenRouter</button> <button${attr_class(
        `flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[12px] transition-all ${stringify(settings.provider === "custom" ? "bg-foreground/[0.08] text-foreground shadow-sm" : "text-muted-foreground/50 hover:text-muted-foreground")}`,
        "svelte-1n5kg1j"
      )}>`);
      Icon$1($$renderer2, { icon: Link01Icon, size: 13, strokeWidth: 1.5 });
      $$renderer2.push(`<!----> ${escape_html(store_get($$store_subs ??= {}, "$t", t)("custom_endpoint"))}</button></div> <div class="flex flex-col gap-3.5 svelte-1n5kg1j">`);
      if (settings.provider === "openrouter") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="svelte-1n5kg1j"><label for="idx-model" class="idx-label svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("model"))}</label> <input id="idx-model" type="text"${attr("value", settings.model || "google/gemini-embedding-001")} class="idx-input svelte-1n5kg1j" placeholder="google/gemini-embedding-001"/> <p class="idx-hint svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("openrouter_embedding_help"))}</p></div> `);
        if (!settings.hasOpenRouterKey) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="rounded-md border border-amber-500/20 bg-amber-500/[0.06] px-3 py-2 text-[12px] text-amber-300/80 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("no_openrouter_key_configured"))}</div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]-->`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="svelte-1n5kg1j"><label for="idx-endpoint" class="idx-label svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("endpoint_url"))}</label> <input id="idx-endpoint" type="text"${attr("value", settings.endpointUrl)} class="idx-input font-mono svelte-1n5kg1j" placeholder="http://localhost:11434/v1/embeddings"/> <p class="idx-hint svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("custom_endpoint_help"))}</p></div> <div class="svelte-1n5kg1j"><label for="idx-key" class="idx-label svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("api_key_needed"))} <span class="font-normal text-muted-foreground/25 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("api_key_optional_short"))}</span></label> <input id="idx-key" type="password"${attr("value", settings.apiKey)} class="idx-input svelte-1n5kg1j" placeholder="sk-..."/> <p class="idx-hint svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("local_server_no_auth"))}</p></div> <div class="svelte-1n5kg1j"><label for="idx-cmodel" class="idx-label svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("model_name"))}</label> <input id="idx-cmodel" type="text"${attr("value", settings.model)} class="idx-input svelte-1n5kg1j" placeholder="nomic-embed-text"/></div>`);
      }
      $$renderer2.push(`<!--]--> <div class="svelte-1n5kg1j"><span class="idx-label svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("dimensions"))}</span> <div class="flex gap-1.5 svelte-1n5kg1j"><!--[-->`);
      const each_array_1 = ensure_array_like(DIM_OPTIONS);
      for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
        let d = each_array_1[$$index_1];
        $$renderer2.push(`<button${attr_class(
          `rounded-md border px-3 py-1.5 font-mono text-[12px] transition-all ${stringify(dims === d ? "border-foreground/15 bg-foreground/[0.07] text-foreground" : "border-transparent text-muted-foreground/35 hover:bg-foreground/[0.03] hover:text-muted-foreground/60")}`,
          "svelte-1n5kg1j"
        )}>${escape_html(d)}`);
        if (d === 768) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="ml-1 font-sans text-[10px] text-muted-foreground/30 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("default_short"))}</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></button>`);
      }
      $$renderer2.push(`<!--]--></div> <p class="idx-hint svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("dimensions_help"))}</p></div></div></section> <section class="idx-card mb-5 px-4 py-4 svelte-1n5kg1j"><h3 class="mb-1 text-[13px] font-medium text-foreground svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("index_scope_heading"))}</h3> <p class="mb-3.5 text-[11px] text-muted-foreground/40 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("index_scope_desc"))}</p> <div class="flex flex-col gap-0.5 svelte-1n5kg1j"><!--[-->`);
      const each_array_2 = ensure_array_like(SCOPES);
      for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
        let scope = each_array_2[$$index_2];
        $$renderer2.push(`<label class="group flex cursor-pointer items-center gap-3 rounded-md px-2.5 py-2 transition-colors hover:bg-foreground/[0.025] svelte-1n5kg1j"><span class="relative flex h-4 w-4 shrink-0 items-center justify-center svelte-1n5kg1j"><input type="checkbox"${attr("checked", settings.scope[scope.key], true)} class="peer sr-only svelte-1n5kg1j"/> <span${attr_class(
          `h-4 w-4 rounded border transition-all ${stringify(settings.scope[scope.key] ? "border-foreground/30 bg-foreground/10" : "border-foreground/12 bg-transparent")}`,
          "svelte-1n5kg1j"
        )}></span> `);
        if (settings.scope[scope.key]) {
          $$renderer2.push("<!--[-->");
          Icon$1($$renderer2, {
            icon: Tick02Icon,
            size: 10,
            strokeWidth: 2.5,
            class: "absolute text-foreground/80"
          });
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></span> <div class="flex flex-1 items-baseline gap-2 svelte-1n5kg1j"><span class="text-[13px] text-foreground/80 svelte-1n5kg1j">${escape_html(scope.label)}</span> <span class="text-[11px] text-muted-foreground/30 svelte-1n5kg1j">${escape_html(scope.desc)}</span> `);
        if (status.state === "ready" && status.breakdown[scope.key] > 0) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="ml-auto tabular-nums text-[10px] text-muted-foreground/25 svelte-1n5kg1j">${escape_html(status.breakdown[scope.key])}</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div></label>`);
      }
      $$renderer2.push(`<!--]--></div></section> <section class="idx-card px-4 py-4 svelte-1n5kg1j"><div class="flex items-center justify-between svelte-1n5kg1j"><div class="svelte-1n5kg1j"><h3 class="text-[13px] font-medium text-foreground svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("auto_index_heading"))}</h3> <p class="mt-0.5 text-[11px] text-muted-foreground/40 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("auto_index_desc"))}</p></div> <button role="switch"${attr("aria-checked", settings.autoIndex)}${attr_class("idx-toggle svelte-1n5kg1j", void 0, { "idx-toggle-on": settings.autoIndex })}><span${attr_class("idx-toggle-thumb svelte-1n5kg1j", void 0, { "idx-toggle-thumb-on": settings.autoIndex })}></span></button></div> `);
      if (settings.autoIndex && status.state === "idle") {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<p class="mt-3 rounded-md border border-amber-500/15 bg-amber-500/[0.04] px-3 py-2 text-[11px] text-amber-300/70 svelte-1n5kg1j">${escape_html(store_get($$store_subs ??= {}, "$t", t)("auto_index_warning"))}</p>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></section> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { load });
  });
}
function NotificationsPanel($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let settings = {
      onlyWhenUnfocused: false,
      notifyOnComplete: true,
      flashTaskbar: true,
      playSound: true,
      soundVolume: 1,
      completionSound: "",
      errorSound: "",
      playPermissionSound: false,
      permissionSoundVolume: 1,
      permissionRequestSound: ""
    };
    let isLoading = false;
    async function load() {
      if (isLoading) return;
      isLoading = true;
      try {
        settings = await getNotificationSettings();
      } catch (e) {
        console.warn("Failed to load notification settings:", e);
      } finally {
        isLoading = false;
      }
    }
    let volumePercent = Math.round(settings.soundVolume * 100);
    let permissionVolumePercent = Math.round(settings.permissionSoundVolume * 100);
    $$renderer2.push(`<div class="mb-6"><h2 class="mb-1 text-[18px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("tab_notifications"))}</h2> <p class="text-[13px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_desc"))}</p> <p class="mt-1 text-[12px] text-muted-foreground/45">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_permission_gate_note"))}</p></div> `);
    if (isLoading) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center gap-2 py-8 text-muted-foreground/50"><span class="inline-block h-4 w-4 animate-spin rounded-full border-2 border-muted-foreground/30 border-t-muted-foreground"></span> Loading...</div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="mb-4 rounded-lg border border-border/60 bg-card p-4"><h3 class="mb-3 text-[14px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_when_heading"))}</h3> <label class="flex cursor-pointer items-center justify-between rounded-md px-1 py-2.5 transition-colors hover:bg-accent/20"><div><span class="text-[13px] text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_only_unfocused"))}</span> <p class="mt-0.5 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_only_unfocused_desc"))}</p></div> <input type="checkbox"${attr("checked", settings.onlyWhenUnfocused, true)} class="h-4 w-4 shrink-0 rounded border-border accent-[var(--ue-accent)]"/></label></div> <div class="mb-4 rounded-lg border border-border/60 bg-card p-4"><h3 class="mb-3 text-[14px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_types_heading"))}</h3> <div class="flex flex-col"><label class="flex cursor-pointer items-center justify-between rounded-md px-1 py-2.5 transition-colors hover:bg-accent/20"><div><span class="text-[13px] text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_toast"))}</span> <p class="mt-0.5 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_toast_desc"))}</p></div> <input type="checkbox"${attr("checked", settings.notifyOnComplete, true)} class="h-4 w-4 shrink-0 rounded border-border accent-[var(--ue-accent)]"/></label> <label class="flex cursor-pointer items-center justify-between rounded-md px-1 py-2.5 transition-colors hover:bg-accent/20"><div><span class="text-[13px] text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_flash"))}</span> <p class="mt-0.5 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_flash_desc"))}</p></div> <input type="checkbox"${attr("checked", settings.flashTaskbar, true)} class="h-4 w-4 shrink-0 rounded border-border accent-[var(--ue-accent)]"/></label> <label class="flex cursor-pointer items-center justify-between rounded-md px-1 py-2.5 transition-colors hover:bg-accent/20"><div><span class="text-[13px] text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_sound"))}</span> <p class="mt-0.5 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_sound_desc"))}</p></div> <input type="checkbox"${attr("checked", settings.playSound, true)} class="h-4 w-4 shrink-0 rounded border-border accent-[var(--ue-accent)]"/></label> <label class="flex cursor-pointer items-center justify-between rounded-md px-1 py-2.5 transition-colors hover:bg-accent/20"><div><span class="text-[13px] text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_permission_sound"))}</span> <p class="mt-0.5 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_permission_sound_desc"))}</p></div> <input type="checkbox"${attr("checked", settings.playPermissionSound, true)} class="h-4 w-4 shrink-0 rounded border-border accent-[var(--ue-accent)]"/></label></div></div> `);
      if (settings.playSound) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="mb-4 rounded-lg border border-border/60 bg-card p-4"><h3 class="mb-3 text-[14px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_volume_heading"))}</h3> <div class="flex items-center gap-3"><input type="range" min="0" max="1" step="0.05"${attr("value", settings.soundVolume)} class="h-1.5 flex-1 cursor-pointer appearance-none rounded-full bg-border/60 accent-[var(--ue-accent)] [&amp;::-webkit-slider-thumb]:h-3.5 [&amp;::-webkit-slider-thumb]:w-3.5 [&amp;::-webkit-slider-thumb]:appearance-none [&amp;::-webkit-slider-thumb]:rounded-full [&amp;::-webkit-slider-thumb]:bg-foreground"/> <span class="w-10 text-right text-[13px] text-muted-foreground">${escape_html(volumePercent)}%</span></div> `);
        if (settings.completionSound || settings.errorSound) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="mt-3 rounded-md bg-foreground/5 px-3 py-2 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_custom_sounds_set"))}</div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (settings.playPermissionSound) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="mb-4 rounded-lg border border-border/60 bg-card p-4"><h3 class="mb-3 text-[14px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_permission_volume_heading"))}</h3> <div class="flex items-center gap-3"><input type="range" min="0" max="1" step="0.05"${attr("value", settings.permissionSoundVolume)} class="h-1.5 flex-1 cursor-pointer appearance-none rounded-full bg-border/60 accent-[var(--ue-accent)] [&amp;::-webkit-slider-thumb]:h-3.5 [&amp;::-webkit-slider-thumb]:w-3.5 [&amp;::-webkit-slider-thumb]:appearance-none [&amp;::-webkit-slider-thumb]:rounded-full [&amp;::-webkit-slider-thumb]:bg-foreground"/> <span class="w-10 text-right text-[13px] text-muted-foreground">${escape_html(permissionVolumePercent)}%</span></div> `);
        if (settings.permissionRequestSound) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="mt-3 rounded-md bg-foreground/5 px-3 py-2 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_permission_custom_sound_set"))}</div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <div class="rounded-md bg-foreground/5 px-3 py-2 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_sound_assets_note"))} <button class="ml-1 text-[var(--ue-accent)] underline-offset-2 hover:underline">${escape_html(store_get($$store_subs ??= {}, "$t", t)("notif_open_project_settings"))}</button></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
    bind_props($$props, { load });
  });
}
function AgentRegistry($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let searchQuery = "";
    let filteredAgents = (() => {
      let agents2 = store_get($$store_subs ??= {}, "$registryAgents", registryAgents);
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        agents2 = agents2.filter((a) => a.name.toLowerCase().includes(q) || a.id.toLowerCase().includes(q) || a.description.toLowerCase().includes(q));
      }
      return agents2.sort((a, b) => {
        if (a.isInstalled !== b.isInstalled) return a.isInstalled ? -1 : 1;
        return a.name.localeCompare(b.name);
      });
    })();
    let installedCount = store_get($$store_subs ??= {}, "$registryAgents", registryAgents).filter((a) => a.isInstalled).length;
    let totalCount = store_get($$store_subs ??= {}, "$registryAgents", registryAgents).length;
    $$renderer2.push(`<div class="flex flex-col gap-4"><div class="flex items-center justify-between"><div><h2 class="mb-1 text-[18px] font-medium text-foreground">ACP Agent Registry</h2> <p class="text-[13px] text-muted-foreground/60">${escape_html(installedCount)} installed of ${escape_html(totalCount)} available agents.</p></div> <button class="flex items-center gap-1.5 rounded-md border border-border/60 px-3 py-1.5 text-[12px] text-muted-foreground transition-colors hover:bg-accent/20 hover:text-foreground"${attr("disabled", store_get($$store_subs ??= {}, "$registryLoading", registryLoading), true)}>`);
    Icon$1($$renderer2, {
      icon: RefreshIcon,
      size: 14,
      class: store_get($$store_subs ??= {}, "$registryLoading", registryLoading) ? "animate-spin" : ""
    });
    $$renderer2.push(`<!----> Refresh</button></div> <div class="flex gap-2"><input type="text" placeholder="Search agents..."${attr("value", searchQuery)} class="flex-1 rounded-md border border-border/60 bg-transparent px-3 py-2 text-[13px] text-foreground placeholder:text-muted-foreground/40 focus:border-foreground/30 focus:outline-none"/> <button${attr_class(`rounded-md border px-3 py-2 text-[11px] transition-colors ${stringify(
      "border-border/60 text-muted-foreground hover:bg-accent/20"
    )}`)}>${escape_html("All")}</button></div> `);
    if (store_get($$store_subs ??= {}, "$registryLoading", registryLoading) && !store_get($$store_subs ??= {}, "$registryLoaded", registryLoaded)) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center justify-center gap-2 py-12 text-muted-foreground/50"><span class="inline-block h-4 w-4 animate-spin rounded-full border-2 border-muted-foreground/30 border-t-muted-foreground"></span> Loading registry...</div>`);
    } else if (filteredAgents.length === 0) {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div class="py-12 text-center text-[13px] text-muted-foreground/40">${escape_html("No agents available.")}</div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="grid gap-3"><!--[-->`);
      const each_array = ensure_array_like(filteredAgents);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let agent = each_array[$$index];
        const isInstalling = store_get($$store_subs ??= {}, "$installingAgents", installingAgents).has(agent.id);
        $$renderer2.push(`<div${attr_class(`group rounded-lg border p-4 transition-colors ${stringify(agent.isInstalled ? "border-border/60 bg-card" : "border-border/30 bg-card/50")}`)}><div class="flex items-start gap-3"><div class="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-border/40 bg-background">`);
        if (agent.icon && agent.icon.startsWith("http")) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<img${attr("src", agent.icon)} alt="" class="h-5 w-5 invert opacity-70"/>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<span class="text-[14px] font-semibold text-muted-foreground/40">${escape_html(agent.name.charAt(0))}</span>`);
        }
        $$renderer2.push(`<!--]--></div> <div class="min-w-0 flex-1"><div class="flex items-center gap-2"><h3 class="text-[14px] font-medium text-foreground">${escape_html(agent.name)}</h3> <span class="rounded-full bg-muted/50 px-2 py-0.5 text-[10px] text-muted-foreground">v${escape_html(agent.version)}</span> `);
        if (agent.isInstalled) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-400">`);
          Icon$1($$renderer2, { icon: CheckmarkCircle02Icon, size: 10 });
          $$renderer2.push(`<!----> Installed</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div> <p class="mt-0.5 line-clamp-2 text-[12px] text-muted-foreground/70">${escape_html(agent.description)}</p> <div class="mt-2 flex flex-wrap items-center gap-1.5">`);
        if (agent.hasBinary) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="rounded bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-medium text-emerald-400">Binary</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> `);
        if (agent.hasNpx) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="rounded bg-blue-500/10 px-1.5 py-0.5 text-[10px] font-medium text-blue-400">npx</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> `);
        if (agent.hasUvx) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="rounded bg-purple-500/10 px-1.5 py-0.5 text-[10px] font-medium text-purple-400">uvx</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> `);
        if (agent.license) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="text-[10px] text-muted-foreground/30">${escape_html(agent.license)}</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div></div> <div class="flex shrink-0 items-center gap-2">`);
        if (agent.repository) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<a${attr("href", agent.repository)} target="_blank" rel="noopener noreferrer" class="flex items-center justify-center rounded-md p-1.5 text-muted-foreground/40 transition-colors hover:bg-accent/20 hover:text-foreground" title="View source">`);
          Icon$1($$renderer2, { icon: Globe02Icon, size: 14 });
          $$renderer2.push(`<!----></a>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> `);
        if (agent.isInstalled) {
          $$renderer2.push("<!--[-->");
          if (agent.updateAvailable) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<button class="flex items-center gap-1.5 rounded-md bg-amber-500/20 border border-amber-500/30 px-3 py-1.5 text-[12px] font-medium text-amber-400 transition-opacity hover:opacity-90">`);
            Icon$1($$renderer2, { icon: Download04Icon, size: 14 });
            $$renderer2.push(`<!----> Update to ${escape_html(agent.latestVersion)}</button>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--> <button class="flex items-center gap-1.5 rounded-md border border-border/60 px-3 py-1.5 text-[12px] text-muted-foreground transition-colors hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/30">Remove</button>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<button class="flex items-center gap-1.5 rounded-md bg-[var(--ue-accent)] px-3 py-1.5 text-[12px] font-medium text-white transition-opacity hover:opacity-90 disabled:opacity-50"${attr("disabled", isInstalling, true)}>`);
          if (isInstalling) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<span class="inline-block h-3 w-3 animate-spin rounded-full border-2 border-white/30 border-t-white"></span> Adding...`);
          } else {
            $$renderer2.push("<!--[!-->");
            Icon$1($$renderer2, { icon: Download04Icon, size: 14 });
            $$renderer2.push(`<!----> Install`);
          }
          $$renderer2.push(`<!--]--></button>`);
        }
        $$renderer2.push(`<!--]--></div></div></div>`);
      }
      $$renderer2.push(`<!--]--></div> <p class="text-[11px] text-muted-foreground/40">Showing ${escape_html(filteredAgents.length)} of ${escape_html(totalCount)} agents</p>`);
    }
    $$renderer2.push(`<!--]--></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function PrerequisitesPanel($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let isLoading = false;
    $$renderer2.push(`<div class="flex flex-col gap-3"><div class="flex items-center justify-between"><div><h3 class="text-[14px] font-medium text-foreground">Prerequisites</h3> <p class="text-[12px] text-muted-foreground/60">Tools needed to run ACP agents.</p></div> <button class="flex items-center gap-1.5 rounded-md border border-border/60 px-2.5 py-1 text-[11px] text-muted-foreground transition-colors hover:bg-accent/20 hover:text-foreground"${attr("disabled", isLoading, true)}>`);
    Icon$1($$renderer2, {
      icon: RefreshIcon,
      size: 12,
      class: ""
    });
    $$renderer2.push(`<!----> Recheck</button></div> `);
    {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center gap-2 py-4 text-[12px] text-muted-foreground/50"><span class="inline-block h-3.5 w-3.5 animate-spin rounded-full border-2 border-muted-foreground/30 border-t-muted-foreground"></span> Checking...</div>`);
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function SettingsPanel($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let tabs = [
      {
        id: "general",
        label: store_get($$store_subs ??= {}, "$t", t)("tab_general"),
        icon: Settings02Icon
      },
      { id: "indexing", label: "Project Index", icon: Database02Icon },
      {
        id: "tools",
        label: store_get($$store_subs ??= {}, "$t", t)("tab_tools"),
        icon: Wrench01Icon
      },
      {
        id: "agents",
        label: store_get($$store_subs ??= {}, "$t", t)("tab_agents"),
        icon: UserIcon
      },
      {
        id: "notifications",
        label: store_get($$store_subs ??= {}, "$t", t)("tab_notifications"),
        icon: Notification03Icon
      },
      { id: "crashes", label: "Crashes", icon: Alert02Icon },
      {
        id: "about",
        label: store_get($$store_subs ??= {}, "$t", t)("tab_about"),
        icon: InformationCircleIcon
      }
    ];
    let crashRecords = [];
    let reportingCrashId = "";
    let profiles = [];
    let tools = [];
    let toolsByCategory = tools.reduce(
      (acc, tool) => {
        if (!acc[tool.category]) acc[tool.category] = [];
        acc[tool.category].push(tool);
        return acc;
      },
      {}
    );
    Object.keys(toolsByCategory).sort();
    let collapsedCategories = /* @__PURE__ */ new Set();
    let enabledCount = tools.filter((t2) => t2.enabled).length;
    let totalCount = tools.length;
    let searchQuery = "";
    let filteredTools = searchQuery.trim() ? tools.filter((t2) => t2.displayName.toLowerCase().includes(searchQuery.toLowerCase()) || t2.name.toLowerCase().includes(searchQuery.toLowerCase()) || t2.description.toLowerCase().includes(searchQuery.toLowerCase())) : tools;
    let filteredToolsByCategory = filteredTools.reduce(
      (acc, tool) => {
        if (!acc[tool.category]) acc[tool.category] = [];
        acc[tool.category].push(tool);
        return acc;
      },
      {}
    );
    let filteredCategoryNames = Object.keys(filteredToolsByCategory).sort();
    let continuationSummarySettings = {
      provider: "openrouter",
      modelId: "x-ai/grok-4.1-fast",
      defaultDetail: "compact",
      hasOpenRouterKey: false
    };
    let isCheckingForUpdates = false;
    let providerSettings = { priority: [], providers: [] };
    let selectedProviderId = "openrouter";
    let providerApiKeyInput = "";
    let selectedProvider = providerSettings.providers.find((p) => p.id === selectedProviderId);
    let priorityProviders = providerSettings.priority.map((id) => providerSettings.providers.find((p) => p.id === id)).filter((p) => !!p);
    let availableToAdd = providerSettings.providers.filter((p) => !p.inPriorityList);
    let showDeleteConfirm = "";
    let builtinAvailableToAdd = availableToAdd.filter((p) => !p.isUserDefined);
    let settingsModels = [];
    let modelSearchQuery = "";
    let filteredSettingsModels = modelSearchQuery.trim() ? settingsModels.filter((m) => m.name.toLowerCase().includes(modelSearchQuery.toLowerCase()) || m.id.toLowerCase().includes(modelSearchQuery.toLowerCase())) : settingsModels;
    settingsModels.length;
    function isModelEnabled(modelId) {
      return true;
    }
    async function handleSummaryProviderChange(provider) {
      continuationSummarySettings = { ...continuationSummarySettings, provider };
      try {
        await setContinuationSummaryProvider(provider);
      } catch (e) {
        console.warn("Failed to save summary provider:", e);
      }
    }
    async function handleSummaryDetailChange(detail) {
      continuationSummarySettings = { ...continuationSummarySettings, defaultDetail: detail };
      try {
        await setContinuationSummaryDefaultDetail(detail);
      } catch (e) {
        console.warn("Failed to save summary detail:", e);
      }
    }
    $$renderer2.push(`<div class="flex h-full w-full"><nav class="flex w-[200px] shrink-0 flex-col border-r border-border bg-sidebar"><div class="flex items-center gap-2 px-4 pt-4 pb-3"><button class="rounded p-1 text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"${attr("title", store_get($$store_subs ??= {}, "$t", t)("back_to_chat"))}>`);
    Icon$1($$renderer2, { icon: ArrowLeft02Icon, size: 16, strokeWidth: 1.5 });
    $$renderer2.push(`<!----></button> <span class="text-[14px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("settings"))}</span></div> <div class="flex flex-col gap-0.5 px-2"><!--[-->`);
    const each_array = ensure_array_like(tabs);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let tab = each_array[$$index];
      $$renderer2.push(`<button${attr_class(`flex items-center gap-2.5 rounded-md px-3 py-2 text-[13px] transition-colors ${stringify(store_get($$store_subs ??= {}, "$settingsTab", settingsTab) === tab.id ? "bg-sidebar-accent text-foreground" : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground")}`)}>`);
      Icon$1($$renderer2, { icon: tab.icon, size: 15, strokeWidth: 1.5 });
      $$renderer2.push(`<!----> ${escape_html(tab.label)}</button>`);
    }
    $$renderer2.push(`<!--]--></div></nav> <div class="flex-1 overflow-y-auto p-8"><div class="mx-auto max-w-3xl">`);
    if (store_get($$store_subs ??= {}, "$settingsTab", settingsTab) === "tools") {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="mb-6"><h2 class="mb-1 text-[18px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("tool_profiles_heading"))}</h2> <p class="text-[13px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("tool_profiles_desc"))}</p></div> `);
      {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="mb-6 flex flex-wrap gap-2"><button${attr_class(`flex items-center gap-2 rounded-lg border px-3 py-2 text-[13px] transition-colors ${stringify(
          "border-foreground/30 bg-foreground/5 text-foreground"
        )}`)}>`);
        {
          $$renderer2.push("<!--[-->");
          Icon$1($$renderer2, {
            icon: Tick02Icon,
            size: 14,
            strokeWidth: 2,
            class: "text-emerald-500"
          });
        }
        $$renderer2.push(`<!--]--> ${escape_html(store_get($$store_subs ??= {}, "$t", t)("all_tools"))}</button> <!--[-->`);
        const each_array_1 = ensure_array_like(profiles);
        for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
          let profile = each_array_1[$$index_1];
          $$renderer2.push(`<button${attr_class(`group flex items-center gap-2 rounded-lg border px-3 py-2 text-[13px] transition-colors ${stringify(profile.isActive ? "border-foreground/30 bg-foreground/5 text-foreground" : "border-border/60 text-muted-foreground hover:border-border hover:text-foreground")}`)}>`);
          if (profile.isActive) {
            $$renderer2.push("<!--[-->");
            Icon$1($$renderer2, {
              icon: Tick02Icon,
              size: 14,
              strokeWidth: 2,
              class: "text-emerald-500"
            });
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--> ${escape_html(profile.displayName)} `);
          if (profile.enabledToolCount > 0) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<span class="text-[11px] text-muted-foreground/40">${escape_html(profile.enabledToolCount)}</span>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--> `);
          if (!profile.isBuiltIn) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<span role="button" tabindex="-1" class="ml-0.5 rounded p-0.5 text-muted-foreground/30 opacity-0 transition-all hover:text-red-400 group-hover:opacity-100"${attr("title", store_get($$store_subs ??= {}, "$t", t)("delete_profile"))}>`);
            Icon$1($$renderer2, { icon: Delete02Icon, size: 12, strokeWidth: 1.5 });
            $$renderer2.push(`<!----></span>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></button>`);
        }
        $$renderer2.push(`<!--]--> `);
        {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<button class="flex items-center gap-1.5 rounded-lg border border-dashed border-border/60 px-3 py-2 text-[13px] text-muted-foreground/50 transition-colors hover:border-border hover:text-muted-foreground">`);
          Icon$1($$renderer2, { icon: Add01Icon, size: 14, strokeWidth: 1.5 });
          $$renderer2.push(`<!----> ${escape_html(store_get($$store_subs ??= {}, "$t", t)("new_profile"))}</button>`);
        }
        $$renderer2.push(`<!--]--></div> `);
        {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <div class="mb-4 flex flex-col gap-3"><div class="flex items-center justify-between"><div class="flex items-center gap-3"><span class="text-[13px] text-muted-foreground">`);
        {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`${escape_html(store_get($$store_subs ??= {}, "$t", t)("showing_global_tool_settings"))}`);
        }
        $$renderer2.push(`<!--]--></span> <span class="text-[12px] text-muted-foreground/40">${escape_html(store_get($$store_subs ??= {}, "$t", t)("enabled_fraction", { enabled: enabledCount, total: totalCount }))}</span></div> <div class="flex items-center gap-1.5"><button class="rounded-md px-2 py-1 text-[12px] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("enable_all"))}</button> <button class="rounded-md px-2 py-1 text-[12px] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("disable_all"))}</button></div></div> <input type="text"${attr("value", searchQuery)} class="w-full rounded-md border border-border/40 bg-transparent px-3 py-1.5 text-[13px] text-foreground placeholder:text-muted-foreground/30 focus:border-foreground/20 focus:outline-none"${attr("placeholder", store_get($$store_subs ??= {}, "$t", t)("search_tools"))}/></div> <div class="flex flex-col gap-1"><!--[-->`);
        const each_array_2 = ensure_array_like(filteredCategoryNames);
        for (let $$index_3 = 0, $$length = each_array_2.length; $$index_3 < $$length; $$index_3++) {
          let category = each_array_2[$$index_3];
          const catTools = filteredToolsByCategory[category];
          const catEnabled = catTools.filter((t2) => t2.enabled).length;
          const isCollapsed = collapsedCategories.has(category);
          $$renderer2.push(`<button class="flex items-center gap-2 rounded-md px-2 py-1.5 text-[12px] font-medium uppercase tracking-wider text-muted-foreground/60 transition-colors hover:bg-accent/40">`);
          Icon$1($$renderer2, {
            icon: isCollapsed ? ArrowRight01Icon : ArrowDown01Icon,
            size: 12,
            strokeWidth: 1.5
          });
          $$renderer2.push(`<!----> ${escape_html(category)} <span class="font-normal normal-case tracking-normal text-muted-foreground/30">${escape_html(catEnabled)}/${escape_html(catTools.length)}</span></button> `);
          if (!isCollapsed) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<div class="mb-2 flex flex-col"><!--[-->`);
            const each_array_3 = ensure_array_like(catTools);
            for (let $$index_2 = 0, $$length2 = each_array_3.length; $$index_2 < $$length2; $$index_2++) {
              let tool = each_array_3[$$index_2];
              $$renderer2.push(`<div class="group rounded-md px-3 py-2 transition-colors hover:bg-accent/30"><div class="flex items-start gap-3"><input type="checkbox"${attr("checked", tool.enabled, true)} class="mt-0.5 h-4 w-4 shrink-0 cursor-pointer rounded border-border accent-foreground"/> <div class="min-w-0 flex-1"><div class="flex items-baseline gap-2"><span class="text-[13px] font-medium text-foreground">${escape_html(tool.displayName)}</span> <span class="text-[11px] text-muted-foreground/40">${escape_html(tool.name)}</span> `);
              if (tool.descriptionOverride) {
                $$renderer2.push("<!--[-->");
                $$renderer2.push(`<span class="rounded bg-blue-500/10 px-1 py-0.5 text-[10px] text-blue-400">${escape_html(store_get($$store_subs ??= {}, "$t", t)("overridden"))}</span>`);
              } else {
                $$renderer2.push("<!--[!-->");
              }
              $$renderer2.push(`<!--]--></div> `);
              if (tool.descriptionOverride) {
                $$renderer2.push("<!--[-->");
                $$renderer2.push(`<p class="mt-0.5 text-[12px] leading-relaxed text-blue-300/70">${escape_html(tool.descriptionOverride)}</p> <p class="mt-0.5 text-[11px] leading-relaxed text-muted-foreground/30 line-through">${escape_html(tool.description)}</p>`);
              } else {
                $$renderer2.push("<!--[!-->");
                $$renderer2.push(`<p class="mt-0.5 text-[12px] leading-relaxed text-muted-foreground/60">${escape_html(tool.description)}</p>`);
              }
              $$renderer2.push(`<!--]--> `);
              {
                $$renderer2.push("<!--[!-->");
              }
              $$renderer2.push(`<!--]--></div></div></div>`);
            }
            $$renderer2.push(`<!--]--></div>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]-->`);
        }
        $$renderer2.push(`<!--]--></div>`);
      }
      $$renderer2.push(`<!--]-->`);
    } else if (store_get($$store_subs ??= {}, "$settingsTab", settingsTab) === "general") {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div class="mb-6"><h2 class="mb-1 text-[18px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("general_heading"))}</h2> <p class="text-[13px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("general_desc"))}</p></div> `);
      {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="mb-4 rounded-lg border border-border/60 bg-card p-4"><h3 class="mb-1 text-[14px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("language_heading"))}</h3> <p class="mb-3 text-[12px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("language_desc"))}</p> <div class="flex flex-wrap gap-2"><!--[-->`);
        const each_array_4 = ensure_array_like(locales);
        for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
          let currentLocale = each_array_4[$$index_4];
          $$renderer2.push(`<button${attr_class(`rounded-md border px-3 py-1.5 text-[13px] transition-colors ${stringify(store_get($$store_subs ??= {}, "$locale", locale) === currentLocale ? "border-[var(--ue-accent)] bg-[var(--ue-accent)]/10 text-foreground" : "border-border/60 text-muted-foreground hover:border-border hover:text-foreground")}`)}>${escape_html(localeNames[currentLocale])}</button>`);
        }
        $$renderer2.push(`<!--]--></div></div> <div class="mb-4 rounded-lg border border-border/60 bg-card p-4"><div class="flex items-center justify-between"><div><h3 class="text-[14px] font-medium text-foreground">Enter to send</h3> <p class="mt-0.5 text-[12px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$enterToSend", enterToSend) ? "Enter sends message, Shift+Enter for new line" : "Enter for new line, Cmd/Ctrl+Enter sends message")}</p></div> <button role="switch"${attr("aria-checked", store_get($$store_subs ??= {}, "$enterToSend", enterToSend))}${attr_class(`relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full transition-colors ${stringify(store_get($$store_subs ??= {}, "$enterToSend", enterToSend) ? "bg-[var(--ue-accent)]" : "bg-muted-foreground/30")}`)}><span${attr_class(`pointer-events-none inline-block h-3.5 w-3.5 rounded-full bg-white shadow-sm transition-transform ${stringify(store_get($$store_subs ??= {}, "$enterToSend", enterToSend) ? "translate-x-[18px]" : "translate-x-[3px]")}`)}></span></button></div></div> <div class="rounded-lg border border-border/60 bg-card p-4"><div class="mb-4"><h3 class="text-[14px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("handoff_heading"))}</h3> <p class="mt-1 text-[12px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("handoff_desc"))}</p></div> <div class="grid gap-4"><div><label for="continuation-provider" class="mb-1.5 block text-[12px] font-medium text-muted-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("provider_label"))}</label> `);
        CustomSelect($$renderer2, {
          id: "continuation-provider",
          value: continuationSummarySettings.provider,
          options: [
            {
              value: "openrouter",
              label: store_get($$store_subs ??= {}, "$t", t)("provider_openrouter")
            },
            {
              value: "local",
              label: store_get($$store_subs ??= {}, "$t", t)("provider_local")
            }
          ],
          onchange: (v) => handleSummaryProviderChange(v)
        });
        $$renderer2.push(`<!----> <p class="mt-1 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("provider_help"))}</p></div> <div><label for="continuation-model" class="mb-1.5 block text-[12px] font-medium text-muted-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("openrouter_model_label"))}</label> <input id="continuation-model" type="text"${attr("value", continuationSummarySettings.modelId)} class="w-full rounded-md border border-border/60 bg-transparent px-3 py-2 text-[13px] text-foreground placeholder:text-muted-foreground/40 focus:border-foreground/30 focus:outline-none" placeholder="x-ai/grok-4.1-fast"/> <p class="mt-1 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("openrouter_model_help"))}</p></div> <div><label for="continuation-detail" class="mb-1.5 block text-[12px] font-medium text-muted-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("default_detail_label"))}</label> `);
        CustomSelect($$renderer2, {
          id: "continuation-detail",
          value: continuationSummarySettings.defaultDetail,
          options: [
            {
              value: "compact",
              label: store_get($$store_subs ??= {}, "$t", t)("compact")
            },
            {
              value: "detailed",
              label: store_get($$store_subs ??= {}, "$t", t)("detailed")
            }
          ],
          onchange: (v) => handleSummaryDetailChange(v)
        });
        $$renderer2.push(`<!----></div></div> `);
        if (continuationSummarySettings.provider === "openrouter" && !continuationSummarySettings.hasOpenRouterKey) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="mt-4 rounded-md border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-[12px] text-amber-300">${escape_html(store_get($$store_subs ??= {}, "$t", t)("openrouter_missing_key"))}</div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> `);
        {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div>`);
      }
      $$renderer2.push(`<!--]-->`);
    } else if (store_get($$store_subs ??= {}, "$settingsTab", settingsTab) === "indexing") {
      $$renderer2.push("<!--[2-->");
      ProjectIndexPanel($$renderer2, {});
    } else if (store_get($$store_subs ??= {}, "$settingsTab", settingsTab) === "about") {
      $$renderer2.push("<!--[3-->");
      $$renderer2.push(`<div class="mb-6"><h2 class="mb-1 text-[18px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("about_heading"))}</h2> <p class="text-[13px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("about_desc"))}</p></div> <div class="rounded-lg border border-border/60 bg-card p-4"><div class="mb-3"><h3 class="text-[14px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("updates_heading"))}</h3> <p class="mt-1 text-[12px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("updates_desc"))}</p></div> <button class="rounded-md border border-border/60 px-3 py-2 text-[13px] text-foreground transition-colors hover:bg-accent disabled:cursor-not-allowed disabled:opacity-60"${attr("disabled", isCheckingForUpdates, true)}>${escape_html(store_get($$store_subs ??= {}, "$t", t)("check_for_updates"))}</button> `);
      {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    } else if (store_get($$store_subs ??= {}, "$settingsTab", settingsTab) === "agents") {
      $$renderer2.push("<!--[4-->");
      $$renderer2.push(`<div class="mb-6">`);
      AgentRegistry($$renderer2);
      $$renderer2.push(`<!----></div> <div class="border-t border-border/40 pt-6 mb-6"><h2 class="mb-1 text-[18px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("providers_heading"))}</h2> <p class="text-[13px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("providers_desc"))}</p></div> `);
      {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="mb-4 rounded-lg border border-border/60 bg-card p-4"><h3 class="mb-1 text-[14px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("active_provider_label"))}</h3> <p class="mb-3 text-[12px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("active_provider_desc"))}</p> `);
        if (priorityProviders.length === 0) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<p class="py-3 text-[12px] text-muted-foreground/40">No providers configured. Add one below.</p>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<div class="flex flex-col gap-1"><!--[-->`);
          const each_array_5 = ensure_array_like(priorityProviders);
          for (let i = 0, $$length = each_array_5.length; i < $$length; i++) {
            let provider = each_array_5[i];
            $$renderer2.push(`<div${attr_class(`group flex items-center gap-2 rounded-md border border-border/40 px-3 py-2 transition-colors hover:bg-accent/20 ${stringify(selectedProviderId === provider.id ? "border-[var(--ue-accent)]/30 bg-[var(--ue-accent)]/5" : "")}`)}><span class="w-5 text-center text-[11px] font-medium text-muted-foreground/40">${escape_html(i + 1)}</span> <div class="flex flex-col gap-0"><button class="rounded px-0.5 text-[10px] text-muted-foreground/30 transition-colors hover:text-foreground disabled:opacity-20"${attr("disabled", i === 0, true)}>↑</button> <button class="rounded px-0.5 text-[10px] text-muted-foreground/30 transition-colors hover:text-foreground disabled:opacity-20"${attr("disabled", i === priorityProviders.length - 1, true)}>↓</button></div> <button class="flex-1 text-left"><span class="text-[13px] font-medium text-foreground">${escape_html(provider.name)}</span> `);
            if (provider.isUserDefined) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<span class="ml-1 rounded bg-[var(--ue-accent)]/10 px-1 py-0.5 text-[9px] text-[var(--ue-accent)]/70">custom</span>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--> `);
            if (provider.configured) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<span class="ml-1.5 text-[10px] text-emerald-400">• ready</span>`);
            } else if (provider.requiresApiKey && !provider.hasApiKey) {
              $$renderer2.push("<!--[1-->");
              $$renderer2.push(`<span class="ml-1.5 text-[10px] text-amber-400">• needs key</span>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--></button> <button class="rounded p-1 text-muted-foreground/20 opacity-0 transition-all hover:text-red-400 group-hover:opacity-100" title="Remove">✕</button></div>`);
          }
          $$renderer2.push(`<!--]--></div>`);
        }
        $$renderer2.push(`<!--]--> `);
        if (builtinAvailableToAdd.length > 0) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="mt-3 flex flex-wrap gap-1.5"><!--[-->`);
          const each_array_6 = ensure_array_like(builtinAvailableToAdd);
          for (let $$index_6 = 0, $$length = each_array_6.length; $$index_6 < $$length; $$index_6++) {
            let provider = each_array_6[$$index_6];
            $$renderer2.push(`<button class="rounded-md border border-dashed border-border/40 px-2.5 py-1 text-[12px] text-muted-foreground/40 transition-colors hover:border-border hover:text-muted-foreground">+ ${escape_html(provider.name)}</button>`);
          }
          $$renderer2.push(`<!--]--></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <div class="mt-3 border-t border-border/20 pt-3">`);
        {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<button class="rounded-md border border-dashed border-[var(--ue-accent)]/30 px-2.5 py-1 text-[12px] text-[var(--ue-accent)]/60 transition-colors hover:border-[var(--ue-accent)]/60 hover:text-[var(--ue-accent)]">+ Add Custom Provider</button>`);
        }
        $$renderer2.push(`<!--]--></div></div> `);
        if (selectedProvider) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="mb-4 rounded-lg border border-border/60 bg-card p-4"><div class="mb-3 flex items-start justify-between"><div><div class="flex items-center gap-2"><h4 class="text-[14px] font-medium text-foreground">${escape_html(selectedProvider.name)}</h4> `);
          if (selectedProvider.isUserDefined) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<span class="rounded bg-[var(--ue-accent)]/10 px-1.5 py-0.5 text-[9px] font-medium text-[var(--ue-accent)]">custom</span>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></div> <p class="mt-0.5 text-[12px] text-muted-foreground/60">${escape_html(selectedProvider.description)}</p></div> `);
          if (selectedProvider.isUserDefined) {
            $$renderer2.push("<!--[-->");
            if (showDeleteConfirm === selectedProvider.id) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<div class="flex items-center gap-1.5"><span class="text-[11px] text-red-400">Delete?</span> <button class="rounded px-2 py-0.5 text-[11px] text-red-400 transition-colors hover:bg-red-500/10">Yes</button> <button class="rounded px-2 py-0.5 text-[11px] text-muted-foreground transition-colors hover:bg-accent">No</button></div>`);
            } else {
              $$renderer2.push("<!--[!-->");
              $$renderer2.push(`<button class="rounded p-1 text-muted-foreground/30 transition-colors hover:text-red-400" title="Delete provider">✕</button>`);
            }
            $$renderer2.push(`<!--]-->`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></div> <div class="grid gap-4">`);
          if (selectedProvider.requiresApiKey) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<div><span class="mb-1.5 block text-[12px] font-medium text-muted-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("provider_api_key_label"))}</span> `);
            if (selectedProvider.hasApiKey) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<div class="mb-1.5 flex items-center gap-2"><span class="font-mono text-[12px] text-muted-foreground/50">····${escape_html(selectedProvider.apiKeyMasked.slice(-4))}</span> <span class="rounded-full bg-emerald-500/10 px-1.5 py-0.5 text-[10px] text-emerald-400">${escape_html(store_get($$store_subs ??= {}, "$t", t)("provider_key_set"))}</span></div>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--> <div class="flex gap-2"><input type="password"${attr("value", providerApiKeyInput)} class="flex-1 rounded-md border border-border/60 bg-transparent px-3 py-2 text-[13px] text-foreground placeholder:text-muted-foreground/40 focus:border-foreground/30 focus:outline-none"${attr("placeholder", selectedProvider.hasApiKey ? store_get($$store_subs ??= {}, "$t", t)("provider_api_key_replace") : store_get($$store_subs ??= {}, "$t", t)("provider_api_key_enter"))}/> <button class="rounded-md border border-border/60 px-3 py-2 text-[13px] text-foreground transition-colors hover:bg-accent disabled:cursor-not-allowed disabled:opacity-40"${attr("disabled", !providerApiKeyInput.trim(), true)}>${escape_html(store_get($$store_subs ??= {}, "$t", t)("save"))}</button></div></div>`);
          } else {
            $$renderer2.push("<!--[!-->");
            $$renderer2.push(`<div class="rounded-md bg-emerald-500/5 px-3 py-2 text-[12px] text-emerald-400/80">${escape_html(store_get($$store_subs ??= {}, "$t", t)("provider_no_key_needed"))}</div>`);
          }
          $$renderer2.push(`<!--]--> <div><span class="mb-1.5 block text-[12px] font-medium text-muted-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("provider_base_url_label"))}</span> `);
          if (selectedProvider.isUserDefined) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<input type="text"${attr("value", selectedProvider.baseUrl)} class="w-full rounded-md border border-border/60 bg-transparent px-3 py-2 text-[13px] text-foreground placeholder:text-muted-foreground/40 focus:border-foreground/30 focus:outline-none" placeholder="https://api.example.com/v1"/>`);
          } else {
            $$renderer2.push("<!--[!-->");
            $$renderer2.push(`<input type="text"${attr("value", selectedProvider.baseUrl)} class="w-full rounded-md border border-border/60 bg-transparent px-3 py-2 text-[13px] text-foreground placeholder:text-muted-foreground/40 focus:border-foreground/30 focus:outline-none"${attr("placeholder", selectedProvider.defaultBaseUrl)}/>`);
          }
          $$renderer2.push(`<!--]--> <p class="mt-1 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("provider_base_url_help"))}</p></div> `);
          if (selectedProvider.isUserDefined || selectedProvider.supportsModelDiscovery) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<div class="border-t border-border/30 pt-3"><div class="mb-2 flex items-center justify-between"><span class="text-[12px] font-medium text-muted-foreground">Models</span> <div class="flex items-center gap-2">`);
            if (!selectedProvider.isUserDefined && selectedProvider.supportsModelDiscovery) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<button class="rounded-md border border-border/60 px-2 py-0.5 text-[11px] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">Refresh</button>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--> `);
            if (selectedProvider.isUserDefined) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<button class="rounded-md border border-border/60 px-2 py-0.5 text-[11px] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">Import JSON</button>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--> <button class="rounded-md border border-border/60 px-2 py-0.5 text-[11px] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">+ Add</button></div></div> `);
            if (!selectedProvider.isUserDefined && selectedProvider.supportsModelDiscovery) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<p class="mb-2 text-[11px] text-muted-foreground/50">Models are auto-discovered from the provider's /models endpoint. Use + Add for models not yet discovered.</p>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--> `);
            {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--> `);
            if (selectedProvider.models && selectedProvider.models.length > 0) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<div class="max-h-[200px] overflow-y-auto rounded-md border border-border/30"><!--[-->`);
              const each_array_7 = ensure_array_like(selectedProvider.models);
              for (let $$index_7 = 0, $$length = each_array_7.length; $$index_7 < $$length; $$index_7++) {
                let model = each_array_7[$$index_7];
                $$renderer2.push(`<div class="group flex items-center gap-2 border-b border-border/20 px-3 py-1.5 last:border-b-0"><div class="min-w-0 flex-1"><span class="text-[12px] text-foreground">${escape_html(model.name || model.id)}</span> <span class="ml-1.5 text-[10px] text-muted-foreground/40">${escape_html(model.id)}</span></div> <button class="rounded p-0.5 text-muted-foreground/20 opacity-0 transition-all hover:text-red-400 group-hover:opacity-100" title="Remove">✕</button></div>`);
              }
              $$renderer2.push(`<!--]--></div>`);
            } else if (selectedProvider.isUserDefined) {
              $$renderer2.push("<!--[1-->");
              $$renderer2.push(`<p class="py-2 text-[11px] text-muted-foreground/40">No models defined. Add manually or import from JSON.</p>`);
            } else {
              $$renderer2.push("<!--[!-->");
              $$renderer2.push(`<p class="py-2 text-[11px] text-muted-foreground/40">No extra models added. Discovered models appear in the model picker.</p>`);
            }
            $$renderer2.push(`<!--]--> `);
            if (selectedProvider.isUserDefined) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<label class="mt-2 flex cursor-pointer items-center gap-2"><input type="checkbox"${attr("checked", selectedProvider.enableModelDiscovery, true)} class="h-3.5 w-3.5 rounded border-border accent-[var(--ue-accent)]"/> <span class="text-[12px] text-muted-foreground">Auto-discover models from /models endpoint</span></label>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--></div> `);
            {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]-->`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></div></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <div class="rounded-md bg-foreground/5 px-3 py-2 text-[11px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("provider_reconnect_note"))}</div> <div class="mt-6 mb-4"><h2 class="mb-1 text-[18px] font-medium text-foreground">Models</h2> <p class="text-[13px] text-muted-foreground/60">Choose which models appear in the model selector. `);
        {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`All models shown`);
        }
        $$renderer2.push(`<!--]--></p></div> `);
        if (settingsModels.length > 0) {
          $$renderer2.push("<!--[1-->");
          $$renderer2.push(`<div class="mb-3 flex items-center gap-2"><input type="text"${attr("value", modelSearchQuery)} class="flex-1 rounded-md border border-border/60 bg-transparent px-3 py-2 text-[13px] text-foreground placeholder:text-muted-foreground/40 focus:border-foreground/30 focus:outline-none" placeholder="Search models..."/></div> <div class="mb-3 flex items-center gap-2"><button class="rounded-md border border-border/60 px-2.5 py-1 text-[11px] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">Enable All</button> <button class="rounded-md border border-border/60 px-2.5 py-1 text-[11px] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">Disable All</button> `);
          {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--> <span class="ml-auto text-[11px] text-muted-foreground/40">${escape_html(filteredSettingsModels.length)} models</span></div> <div class="rounded-lg border border-border/60 bg-card"><div class="max-h-[400px] overflow-y-auto"><!--[-->`);
          const each_array_9 = ensure_array_like(filteredSettingsModels);
          for (let $$index_9 = 0, $$length = each_array_9.length; $$index_9 < $$length; $$index_9++) {
            let model = each_array_9[$$index_9];
            $$renderer2.push(`<label class="flex cursor-pointer items-center gap-3 border-b border-border/20 px-4 py-2.5 transition-colors last:border-b-0 hover:bg-accent/20"><input type="checkbox"${attr("checked", isModelEnabled(model.id), true)} class="h-3.5 w-3.5 shrink-0 rounded border-border accent-[var(--ue-accent)]"/> <div class="min-w-0 flex-1"><div class="flex items-center gap-1.5"><span class="truncate text-[13px] text-foreground">${escape_html(model.name)}</span> `);
            if (model.providerDisplayName) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<span class="shrink-0 rounded bg-foreground/5 px-1 py-0.5 text-[9px] text-muted-foreground/40">${escape_html(model.providerDisplayName)}</span>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--></div> <div class="truncate text-[11px] text-muted-foreground/40">${escape_html(model.id)}</div></div></label>`);
          }
          $$renderer2.push(`<!--]--></div></div> `);
          if (filteredSettingsModels.length === 0 && modelSearchQuery.trim()) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<p class="py-4 text-center text-[12px] text-muted-foreground/40">No models match your search.</p>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]-->`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<p class="py-4 text-[12px] text-muted-foreground/40">No models available. Configure a provider above first.</p>`);
        }
        $$renderer2.push(`<!--]-->`);
      }
      $$renderer2.push(`<!--]--> <div class="mt-8 border-t border-border/40 pt-6">`);
      PrerequisitesPanel($$renderer2);
      $$renderer2.push(`<!----></div>`);
    } else if (store_get($$store_subs ??= {}, "$settingsTab", settingsTab) === "crashes") {
      $$renderer2.push("<!--[5-->");
      $$renderer2.push(`<div class="mb-6"><h2 class="mb-1 text-[18px] font-medium text-foreground">Crash History</h2> <p class="text-[13px] text-muted-foreground/60">Recent crashes detected by Agent Integration Kit. You can send crash reports to help us fix issues.</p></div> `);
      if (crashRecords.length === 0) {
        $$renderer2.push("<!--[1-->");
        $$renderer2.push(`<div class="rounded-lg border border-border/60 bg-card p-6 text-center"><p class="text-[13px] text-muted-foreground/60">No crashes recorded. That's good!</p></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="space-y-3"><!--[-->`);
        const each_array_10 = ensure_array_like(crashRecords);
        for (let $$index_10 = 0, $$length = each_array_10.length; $$index_10 < $$length; $$index_10++) {
          let crash = each_array_10[$$index_10];
          const status = crash.fullLogSent || crash.manuallyReported ? "sent" : crash.fullLogDeclined ? "declined" : crash.basicReported ? "basic" : "none";
          $$renderer2.push(`<div class="rounded-lg border border-border/60 bg-card overflow-hidden"><div class="p-4"><div class="flex items-center justify-between mb-2"><div class="flex items-center gap-2"><span${attr_class(`inline-block h-2 w-2 rounded-full ${stringify(status === "sent" ? "bg-emerald-400" : status === "basic" ? "bg-amber-400" : status === "declined" ? "bg-red-400/60" : "bg-muted-foreground/30")}`)}></span> <span class="text-[12px] font-mono text-muted-foreground/70">${escape_html(crash.crashType || "Crash")}</span></div> <span class="text-[11px] text-muted-foreground/50">${escape_html(new Date(crash.timestamp).toLocaleDateString(void 0, {
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit"
          }))}</span></div> <p class="text-[12px] font-mono text-red-400/80 break-all leading-relaxed mb-3 line-clamp-3">${escape_html(crash.errorMessage)}</p> <div class="flex items-center justify-between"><span class="text-[11px] text-muted-foreground/50">`);
          if (status === "sent") {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`Full report sent`);
          } else if (status === "basic") {
            $$renderer2.push("<!--[1-->");
            $$renderer2.push(`Basic report sent`);
          } else if (status === "declined") {
            $$renderer2.push("<!--[2-->");
            $$renderer2.push(`Full log not sent`);
          } else {
            $$renderer2.push("<!--[!-->");
            $$renderer2.push(`Not reported`);
          }
          $$renderer2.push(`<!--]--></span> `);
          if (status !== "sent") {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<button class="rounded-md border border-border/60 px-3 py-1.5 text-[12px] text-foreground transition-colors hover:bg-accent disabled:opacity-50 disabled:cursor-not-allowed"${attr("disabled", reportingCrashId === crash.crashId, true)}>`);
            if (reportingCrashId === crash.crashId) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`Sending...`);
            } else {
              $$renderer2.push("<!--[!-->");
              $$renderer2.push(`Send Full Report`);
            }
            $$renderer2.push(`<!--]--></button>`);
          } else {
            $$renderer2.push("<!--[!-->");
          }
          $$renderer2.push(`<!--]--></div></div></div>`);
        }
        $$renderer2.push(`<!--]--></div> <p class="mt-4 text-[11px] text-muted-foreground/40">Can't send from here? Share crash details on our <a href="https://discord.gg/betide" target="_blank" rel="noopener" class="underline hover:text-foreground">Discord</a>.</p>`);
      }
      $$renderer2.push(`<!--]-->`);
    } else if (store_get($$store_subs ??= {}, "$settingsTab", settingsTab) === "notifications") {
      $$renderer2.push("<!--[6-->");
      NotificationsPanel($$renderer2, {});
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<h2 class="mb-1 text-[18px] font-medium text-foreground">${escape_html(tabs.find((t2) => t2.id === store_get($$store_subs ??= {}, "$settingsTab", settingsTab))?.label ?? store_get($$store_subs ??= {}, "$t", t)("settings"))}</h2> <p class="text-[13px] text-muted-foreground/60">${escape_html(store_get($$store_subs ??= {}, "$t", t)("coming_soon"))}</p>`);
    }
    $$renderer2.push(`<!--]--></div></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let sidebarOpen = (() => {
      try {
        const v = localStorage.getItem("sidebar_open");
        return v !== null ? v === "true" : true;
      } catch {
        return true;
      }
    })();
    let inputText = "";
    let currentSession = store_get($$store_subs ??= {}, "$sessions", sessions).find((s) => s.sessionId === store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId));
    let headerTitle = store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId) ? currentSession?.title || store_get($$store_subs ??= {}, "$t", t)("new_chat") : store_get($$store_subs ??= {}, "$t", t)("agent_chat");
    let headerAgent = store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId) ? currentSession?.agentName ?? store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent)?.name ?? "" : "";
    store_get($$store_subs ??= {}, "$models", models).length > 0;
    let currentModel = store_get($$store_subs ??= {}, "$models", models).find((m) => m.id === store_get($$store_subs ??= {}, "$currentModelId", currentModelId));
    currentModel?.name ?? store_get($$store_subs ??= {}, "$currentModelId", currentModelId) ?? "Model";
    currentModel?.supportsReasoning ?? false;
    let connectionInfo = store_get($$store_subs ??= {}, "$currentState", currentState$1) ? stateDisplay[store_get($$store_subs ??= {}, "$currentState", currentState$1).state] : null;
    store_get($$store_subs ??= {}, "$availableModes", availableModes).length > 0;
    let currentMode = store_get($$store_subs ??= {}, "$availableModes", availableModes).find((m) => m.id === store_get($$store_subs ??= {}, "$currentModeId", currentModeId));
    currentMode?.name ?? store_get($$store_subs ??= {}, "$currentModeId", currentModeId) ?? store_get($$store_subs ??= {}, "$t", t)("mode_default");
    isInPlanMode(store_get($$store_subs ??= {}, "$currentModeId", currentModeId));
    let usageHasContext = store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).contextSize > 0;
    let usageHasTokens = store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).inputTokens > 0 || store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).outputTokens > 0;
    store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).costAmount > 0;
    usageHasContext ? `${store_get($$store_subs ??= {}, "$contextPercent", contextPercent)}% context` : usageHasTokens ? `${formatTokens(store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).inputTokens + store_get($$store_subs ??= {}, "$sessionUsage", sessionUsage).outputTokens)} tokens` : "";
    let waitingForMcp = store_get($$store_subs ??= {}, "$currentMcpStatus", currentMcpStatus) === "waiting";
    let modelSearchQuery = "";
    store_get($$store_subs ??= {}, "$models", models).filter((m) => m.id !== "special:browse_all");
    store_get($$store_subs ??= {}, "$models", models).some((m) => m.id === "special:browse_all");
    let filteredAllModels = (() => {
      const q = modelSearchQuery.trim().toLowerCase();
      if (!q) return store_get($$store_subs ??= {}, "$allModels", allModels);
      return store_get($$store_subs ??= {}, "$allModels", allModels).filter((model) => model.name.toLowerCase().includes(q) || model.id.toLowerCase().includes(q) || (model.description ?? "").toLowerCase().includes(q));
    })();
    let agentReady = (() => {
      if (waitingForMcp) return false;
      const state = store_get($$store_subs ??= {}, "$currentState", currentState$1)?.state;
      if (state === "ready" || state === "in_session" || state === "prompting" || state === "error") return true;
      if (!state && store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId) && store_get($$store_subs ??= {}, "$models", models).length > 0) return true;
      return false;
    })();
    inputText.trim().length > 0 && !!store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId) && !store_get($$store_subs ??= {}, "$isStreaming", isStreaming) && agentReady;
    waitingForMcp ? store_get($$store_subs ??= {}, "$t", t)("connecting_tools") : !agentReady ? store_get($$store_subs ??= {}, "$currentState", currentState$1)?.state === "connecting" || store_get($$store_subs ??= {}, "$currentState", currentState$1)?.state === "initializing" ? store_get($$store_subs ??= {}, "$t", t)("waiting_for_agent_connect") : store_get($$store_subs ??= {}, "$currentState", currentState$1)?.state === "ready" ? store_get($$store_subs ??= {}, "$t", t)("ready_to_send") : store_get($$store_subs ??= {}, "$currentState", currentState$1)?.state === "error" ? store_get($$store_subs ??= {}, "$currentState", currentState$1)?.message || store_get($$store_subs ??= {}, "$t", t)("agent_error_check_connection") : store_get($$store_subs ??= {}, "$t", t)("waiting_for_agent") : store_get($$store_subs ??= {}, "$messages", messages).length > 0 ? store_get($$store_subs ??= {}, "$t", t)("ask_follow_up") : store_get($$store_subs ??= {}, "$t", t)("describe_task");
    async function selectAgent(agent) {
      if (agent.status !== "available") {
        currentSessionId.set(null);
        enterSetup(agent);
      } else {
        setupAgent.set(null);
        selectedAgent.set(agent);
        await createNewSession(agent.name);
        loadModelsForAgent(agent.name);
      }
    }
    async function handlePaneStartSession(agentName) {
      const agent = store_get($$store_subs ??= {}, "$agents", agents).find((a) => a.name === agentName);
      if (!agent || agent.status !== "available") return;
      setupAgent.set(null);
      selectedAgent.set(agent);
      await createNewSession(agent.name);
      loadModelsForAgent(agent.name);
    }
    if (store_get($$store_subs ??= {}, "$settingsOpen", settingsOpen)) {
      $$renderer2.push("<!--[-->");
      SettingsPanel($$renderer2);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div${attr_class("flex min-w-0 flex-1", void 0, {
        "hidden": store_get($$store_subs ??= {}, "$currentTab", currentTab) !== "studio"
      })}>`);
      StudioPage($$renderer2);
      $$renderer2.push(`<!----></div> <div${attr_class("flex min-w-0 flex-1", void 0, {
        "hidden": store_get($$store_subs ??= {}, "$currentTab", currentTab) !== "terminal"
      })}>`);
      TerminalPane($$renderer2);
      $$renderer2.push(`<!----></div> <div${attr_class("flex min-w-0 flex-1", void 0, {
        "hidden": store_get($$store_subs ??= {}, "$currentTab", currentTab) !== "chat"
      })}><div${attr_class(`shrink-0 overflow-hidden ${stringify("")}`)}${attr_style(`width: ${stringify(sidebarOpen ? "280px" : "0px")};`)}><div class="h-full w-[280px]">`);
      Sidebar($$renderer2);
      $$renderer2.push(`<!----></div></div> <main class="flex min-w-0 flex-1 flex-col"><header class="flex h-10 shrink-0 items-center justify-between border-b border-border bg-[#222] px-3"><div class="flex min-w-0 flex-1 items-center gap-2 text-[13px]"><button class="shrink-0 rounded p-1 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"${attr("title", sidebarOpen ? store_get($$store_subs ??= {}, "$t", t)("hide_sidebar") : store_get($$store_subs ??= {}, "$t", t)("show_sidebar"))}>`);
      Icon$1($$renderer2, { icon: SidebarLeftIcon, size: 16, strokeWidth: 1.5 });
      $$renderer2.push(`<!----></button> <div class="min-w-0 flex flex-1 items-center gap-2"><span class="min-w-0 flex-1 truncate font-medium text-foreground"${attr("title", headerTitle)}>${escape_html(headerTitle)}</span> `);
      if (headerAgent) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="max-w-[120px] truncate text-muted-foreground"${attr("title", headerAgent)}>${escape_html(headerAgent)}</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div> `);
      if (paneManager.isMultiPane) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<button class="shrink-0 rounded p-0.5 text-muted-foreground hover:text-foreground" title="Close split panes">`);
        Icon$1($$renderer2, { icon: Cancel01Icon, size: 14, strokeWidth: 1.5 });
        $$renderer2.push(`<!----></button>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (paneManager.canSplit && store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<button class="shrink-0 rounded p-0.5 text-muted-foreground hover:text-foreground" title="Split pane">`);
        Icon$1($$renderer2, { icon: LayoutLeftIcon, size: 16, strokeWidth: 1.5 });
        $$renderer2.push(`<!----></button>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> <button class="shrink-0 rounded p-0.5 text-muted-foreground hover:text-foreground">`);
      Icon$1($$renderer2, { icon: MoreHorizontalIcon, size: 16, strokeWidth: 1.5 });
      $$renderer2.push(`<!----></button></div> <div class="ml-2 flex shrink-0 items-center gap-2">`);
      UsageBar($$renderer2);
      $$renderer2.push(`<!----> `);
      if (connectionInfo) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="flex items-center gap-1.5 rounded-md border border-border/80 bg-secondary/30 px-2 py-1 text-[11px] text-muted-foreground"><span${attr_class(`h-2 w-2 shrink-0 rounded-full ${stringify(connectionInfo.dotClass)} ${stringify(connectionInfo.pulse ? "animate-pulse" : "")}`)}></span> ${escape_html(connectionInfo.label)}</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (!sidebarOpen) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="flex items-stretch"><button class="flex items-center gap-1.5 rounded-l-md border border-border/80 bg-secondary/50 px-2 py-1 text-[12px] text-sidebar-foreground transition-colors hover:bg-secondary"${attr("title", store_get($$store_subs ??= {}, "$t", t)("new_chat_agent", {
          agentName: store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent)?.shortName ?? ""
        }))}>`);
        if (store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent)?.iconUrl) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span class="flex h-4 w-4 items-center justify-center shrink-0"${attr_style(`color: ${stringify(store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).color)};`)}><img${attr("src", store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).iconUrl)} alt="" class="h-3.5 w-3.5 invert opacity-70"/></span>`);
        } else if (store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent)) {
          $$renderer2.push("<!--[1-->");
          $$renderer2.push(`<span class="flex h-4 w-4 items-center justify-center rounded text-[7px] font-bold text-white"${attr_style(`background-color: ${stringify(store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).color)};`)}>${escape_html(store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).letter)}</span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <span>${escape_html(store_get($$store_subs ??= {}, "$t", t)("new_short"))}</span></button> `);
        $$renderer2.push("<!---->");
        Dropdown_menu?.($$renderer2, {
          children: ($$renderer3) => {
            $$renderer3.push("<!---->");
            Dropdown_menu_trigger?.($$renderer3, {
              class: "flex items-center rounded-r-md border border-l-0 border-border/80 bg-secondary/50 px-1 transition-colors hover:bg-secondary",
              children: ($$renderer4) => {
                Icon$1($$renderer4, {
                  icon: ArrowDown01Icon,
                  size: 12,
                  strokeWidth: 1.5,
                  class: "text-muted-foreground"
                });
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!----> `);
            $$renderer3.push("<!---->");
            Dropdown_menu_content?.($$renderer3, {
              class: "w-[220px]",
              side: "bottom",
              align: "end",
              sideOffset: 4,
              children: ($$renderer4) => {
                $$renderer4.push("<!---->");
                Dropdown_menu_label?.($$renderer4, {
                  class: "text-[11px] text-muted-foreground",
                  children: ($$renderer5) => {
                    $$renderer5.push(`<!---->${escape_html(store_get($$store_subs ??= {}, "$t", t)("start_with"))}`);
                  },
                  $$slots: { default: true }
                });
                $$renderer4.push(`<!----> <!--[-->`);
                const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$agents", agents));
                for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
                  let agent = each_array[$$index];
                  $$renderer4.push("<!---->");
                  Dropdown_menu_item?.($$renderer4, {
                    class: "flex items-center gap-2.5 px-2 py-1.5",
                    onclick: () => selectAgent(agent),
                    children: ($$renderer5) => {
                      if (agent.iconUrl) {
                        $$renderer5.push("<!--[-->");
                        $$renderer5.push(`<span class="flex h-5 w-5 items-center justify-center shrink-0"${attr_style(`color: ${stringify(agent.color)};`)}><img${attr("src", agent.iconUrl)} alt="" class="h-4 w-4 invert opacity-70"/></span>`);
                      } else {
                        $$renderer5.push("<!--[!-->");
                        $$renderer5.push(`<span class="flex h-5 w-5 items-center justify-center rounded text-[8px] font-bold text-white"${attr_style(`background-color: ${stringify(agent.color)};`)}>${escape_html(agent.letter)}</span>`);
                      }
                      $$renderer5.push(`<!--]--> <div class="flex-1 min-w-0"><div class="flex items-baseline gap-1.5"><span class="text-[13px] truncate">${escape_html(agent.name)}</span> `);
                      if (agent.provider) {
                        $$renderer5.push("<!--[-->");
                        $$renderer5.push(`<span class="text-[11px] text-muted-foreground/50 shrink-0">${escape_html(agent.provider)}</span>`);
                      } else {
                        $$renderer5.push("<!--[!-->");
                      }
                      $$renderer5.push(`<!--]--></div> `);
                      if (agent.status === "not_installed") {
                        $$renderer5.push("<!--[-->");
                        $$renderer5.push(`<div class="text-[11px] text-amber-400/60 truncate">${escape_html(store_get($$store_subs ??= {}, "$t", t)("setup_click"))}</div>`);
                      } else if (agent.status === "missing_key") {
                        $$renderer5.push("<!--[1-->");
                        $$renderer5.push(`<div class="text-[11px] text-amber-400/60 truncate">${escape_html(store_get($$store_subs ??= {}, "$t", t)("api_key_needed"))}</div>`);
                      } else if (agent.description) {
                        $$renderer5.push("<!--[2-->");
                        $$renderer5.push(`<div class="text-[11px] text-muted-foreground/40 truncate">${escape_html(agent.description)}</div>`);
                      } else {
                        $$renderer5.push("<!--[!-->");
                      }
                      $$renderer5.push(`<!--]--></div> <span${attr_class(`h-2 w-2 shrink-0 rounded-full ${stringify(statusDotColor(agent.status))}`)}></span>`);
                    },
                    $$slots: { default: true }
                  });
                  $$renderer4.push(`<!----> `);
                  if (agent.id === "OpenRouter") {
                    $$renderer4.push("<!--[-->");
                    $$renderer4.push("<!---->");
                    Dropdown_menu_separator?.($$renderer4, {});
                    $$renderer4.push(`<!---->`);
                  } else {
                    $$renderer4.push("<!--[!-->");
                  }
                  $$renderer4.push(`<!--]-->`);
                }
                $$renderer4.push(`<!--]-->`);
              },
              $$slots: { default: true }
            });
            $$renderer3.push(`<!---->`);
          },
          $$slots: { default: true }
        });
        $$renderer2.push(`<!----></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></div></header> `);
      if (store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="flex-1 overflow-hidden">`);
        if (paneManager.paneCount <= 1) {
          $$renderer2.push("<!--[-->");
          ChatPane($$renderer2, {
            sessionId: store_get($$store_subs ??= {}, "$currentSessionId", currentSessionId),
            isFocused: true
          });
        } else {
          $$renderer2.push("<!--[!-->");
          Pane_group($$renderer2, {
            direction: "horizontal",
            autoSaveId: "chat-panes",
            children: ($$renderer3) => {
              $$renderer3.push(`<!--[-->`);
              const each_array_1 = ensure_array_like(paneManager.panes);
              for (let idx = 0, $$length = each_array_1.length; idx < $$length; idx++) {
                let pane = each_array_1[idx];
                Pane($$renderer3, {
                  defaultSize: Math.round(100 / paneManager.paneCount),
                  minSize: 20,
                  order: idx + 1,
                  children: ($$renderer4) => {
                    $$renderer4.push(`<div${attr_class(`h-full ${stringify(paneManager.focusedIndex === idx ? "ring-1 ring-inset ring-[var(--ue-accent)]/20" : "")}`)} role="region" tabindex="-1">`);
                    ChatPane($$renderer4, {
                      sessionId: pane.sessionId,
                      isFocused: paneManager.focusedIndex === idx,
                      showPaneHeader: true,
                      onStartSession: handlePaneStartSession
                    });
                    $$renderer4.push(`<!----></div>`);
                  },
                  $$slots: { default: true }
                });
                $$renderer3.push(`<!----> `);
                if (idx < paneManager.paneCount - 1) {
                  $$renderer3.push("<!--[-->");
                  Pane_resizer($$renderer3, {
                    children: ($$renderer4) => {
                      $$renderer4.push(`<div class="w-1 h-full bg-border/40 hover:bg-[var(--ue-accent)]/40 transition-colors cursor-col-resize"></div>`);
                    },
                    $$slots: { default: true }
                  });
                } else {
                  $$renderer3.push("<!--[!-->");
                }
                $$renderer3.push(`<!--]-->`);
              }
              $$renderer3.push(`<!--]-->`);
            },
            $$slots: { default: true }
          });
        }
        $$renderer2.push(`<!--]--></div>`);
      } else if (!store_get($$store_subs ??= {}, "$onboardingLoading", onboardingLoading) && store_get($$store_subs ??= {}, "$showOnboarding", showOnboarding)) {
        $$renderer2.push("<!--[1-->");
        OnboardingWizard($$renderer2);
      } else if (store_get($$store_subs ??= {}, "$setupAgent", setupAgent)) {
        $$renderer2.push("<!--[2-->");
        AgentSetup($$renderer2, {
          agent: store_get($$store_subs ??= {}, "$setupAgent", setupAgent)
        });
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push(`<div class="flex flex-1 flex-col items-center justify-center gap-8 px-6"><div class="flex flex-col items-center gap-3">`);
        if (store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent)?.iconUrl) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<span${attr_style(`color: ${stringify(store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).color)}; opacity: 0.4;`)}><img${attr("src", store_get($$store_subs ??= {}, "$selectedAgent", selectedAgent).iconUrl)} alt="" class="h-12 w-12 invert opacity-70"/></span>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--> <h2 class="text-lg font-light text-foreground/70">${escape_html(store_get($$store_subs ??= {}, "$t", t)("start_new_conversation"))}</h2> <p class="text-[13px] text-muted-foreground/50">${escape_html(store_get($$store_subs ??= {}, "$t", t)("choose_agent_below"))}</p></div> <div class="flex flex-wrap justify-center gap-2.5"><!--[-->`);
        const each_array_2 = ensure_array_like(store_get($$store_subs ??= {}, "$agents", agents).filter((a) => a.status === "available"));
        for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
          let agent = each_array_2[$$index_2];
          $$renderer2.push(`<button class="flex items-center gap-2.5 rounded-xl border border-border bg-card/40 px-4 py-2.5 text-[13px] text-foreground/80 transition-all hover:border-[var(--ue-accent-muted)] hover:bg-card/70 active:scale-[0.98]">`);
          if (agent.iconUrl) {
            $$renderer2.push("<!--[-->");
            $$renderer2.push(`<span class="flex h-5 w-5 items-center justify-center"${attr_style(`color: ${stringify(agent.color)};`)}><img${attr("src", agent.iconUrl)} alt="" class="h-4.5 w-4.5 invert opacity-70"/></span>`);
          } else {
            $$renderer2.push("<!--[!-->");
            $$renderer2.push(`<span class="flex h-5 w-5 items-center justify-center rounded text-[8px] font-bold text-white"${attr_style(`background-color: ${stringify(agent.color)};`)}>${escape_html(agent.letter)}</span>`);
          }
          $$renderer2.push(`<!--]--> ${escape_html(agent.shortName)}</button>`);
        }
        $$renderer2.push(`<!--]--></div> `);
        if (store_get($$store_subs ??= {}, "$agents", agents).some((a) => a.status !== "available")) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="flex flex-wrap justify-center gap-2"><!--[-->`);
          const each_array_3 = ensure_array_like(store_get($$store_subs ??= {}, "$agents", agents).filter((a) => a.status !== "available"));
          for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
            let agent = each_array_3[$$index_3];
            $$renderer2.push(`<button class="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12px] text-muted-foreground/40 transition-colors hover:bg-card/30 hover:text-muted-foreground/60 cursor-pointer">`);
            if (agent.iconUrl) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<span${attr_style(`color: ${stringify(agent.color)}; opacity: 0.35;`)}><img${attr("src", agent.iconUrl)} alt="" class="h-3.5 w-3.5 invert opacity-70"/></span>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--> ${escape_html(agent.shortName)} <span class="text-[10px]">(${escape_html(agent.status === "not_installed" ? store_get($$store_subs ??= {}, "$t", t)("set_up") : agent.status === "missing_key" ? store_get($$store_subs ??= {}, "$t", t)("configure") : store_get($$store_subs ??= {}, "$t", t)("unavailable"))})</span></button>`);
          }
          $$renderer2.push(`<!--]--></div>`);
        } else {
          $$renderer2.push("<!--[!-->");
        }
        $$renderer2.push(`<!--]--></div>`);
      }
      $$renderer2.push(`<!--]--> `);
      if (store_get($$store_subs ??= {}, "$modelBrowserOpen", modelBrowserOpen)) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4"><button class="absolute inset-0 bg-black/55 backdrop-blur-[1px]"${attr("aria-label", store_get($$store_subs ??= {}, "$t", t)("close_model_browser"))}></button> <div class="relative z-10 flex h-[min(78vh,720px)] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl"><div class="flex items-center justify-between border-b border-border px-4 py-3"><div><div class="text-[15px] font-medium text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("browse_openrouter_models"))}</div> <div class="text-[12px] text-muted-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("search_full_catalog"))}</div></div> <button class="rounded-md px-2 py-1 text-[12px] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">${escape_html(store_get($$store_subs ??= {}, "$t", t)("close"))}</button></div> <div class="border-b border-border px-4 py-3"><input type="text"${attr("value", modelSearchQuery)}${attr("placeholder", store_get($$store_subs ??= {}, "$t", t)("search_models_placeholder"))} class="w-full rounded-lg border border-border bg-secondary/40 px-3 py-2 text-[13px] text-foreground placeholder:text-muted-foreground/55 focus:border-[var(--ue-accent-muted)] focus:outline-none"/></div> <div class="min-h-0 flex-1 overflow-y-auto px-2 py-2">`);
        if (store_get($$store_subs ??= {}, "$isLoadingAllModels", isLoadingAllModels)) {
          $$renderer2.push("<!--[-->");
          $$renderer2.push(`<div class="flex items-center justify-center py-10 text-[13px] text-muted-foreground/70">${escape_html(store_get($$store_subs ??= {}, "$t", t)("loading_models"))}</div>`);
        } else if (filteredAllModels.length === 0) {
          $$renderer2.push("<!--[1-->");
          $$renderer2.push(`<div class="flex items-center justify-center py-10 text-[13px] text-muted-foreground/70">${escape_html(store_get($$store_subs ??= {}, "$t", t)("no_models_match_search"))}</div>`);
        } else {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<!--[-->`);
          const each_array_4 = ensure_array_like(filteredAllModels);
          for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
            let model = each_array_4[$$index_4];
            $$renderer2.push(`<button class="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left transition-colors hover:bg-accent/60"><div class="min-w-0 flex-1"><div class="flex items-center gap-2 truncate"><span class="text-[13px] text-foreground">${escape_html(model.name)}</span> `);
            if (model.providerDisplayName) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<span class="shrink-0 rounded bg-foreground/5 px-1 py-0.5 text-[9px] uppercase tracking-wider text-muted-foreground/40">${escape_html(model.providerDisplayName)}</span>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--></div> <div class="truncate font-mono text-[11px] text-muted-foreground/70">${escape_html(model.id)}</div> `);
            if (model.description) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<div class="truncate text-[11px] text-muted-foreground/55">${escape_html(model.description)}</div>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--></div> `);
            if (model.id === store_get($$store_subs ??= {}, "$currentModelId", currentModelId)) {
              $$renderer2.push("<!--[-->");
              $$renderer2.push(`<span class="h-2 w-2 shrink-0 rounded-full bg-foreground"></span>`);
            } else {
              $$renderer2.push("<!--[!-->");
            }
            $$renderer2.push(`<!--]--></button>`);
          }
          $$renderer2.push(`<!--]-->`);
        }
        $$renderer2.push(`<!--]--></div></div></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></main></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _page as default
};
